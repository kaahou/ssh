# 🔧 رفع خطای "column does not exist"

## 📋 خلاصه مشکل

خطا: `column products.stock does not exist`

این خطا زمانی رخ می‌دهد که backend سعی می‌کند فیلدی را select کند که در دیتابیس وجود ندارد.

---

## ✅ راه‌حل اعمال شده

### تغییرات Backend:

1. **حذف فیلد `stock` از selectFields**
   ```typescript
   // قبل (با stock)
   const selectFields = '...,stock,...';
   
   // بعد (بدون stock)
   const selectFields = 'id,product_name,variant_name,slug,price,old_price,category,category_id,image_urls,short_description,score,created_at';
   ```

2. **اضافه کردن مقدار پیش‌فرض برای stock در response**
   ```typescript
   const mappedProducts = products?.map(p => ({
     ...p,
     product_id: p.id,
     stock: 100 // مقدار پیش‌فرض برای سازگاری با frontend
   }));
   ```

3. **Fallback Strategy چند لایه**
   - لایه ۱: سعی با تمام فیلدها + score ✅
   - لایه ۲: اگر score نبود → بدون score ✅
   - لایه ۳: اگر فیلد دیگری نبود → فقط فیلدهای حداقلی ✅
   - لایه ۴: اگر جدول نبود → KV Store ✅

---

## 🔍 چگونه Schema واقعی را بررسی کنیم؟

### روش ۱: از Debug Endpoint استفاده کنید

```bash
curl https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-fbc72c25/products/schema/debug
```

**خروجی:**
```json
{
  "schema": [
    "id",
    "product_name",
    "slug",
    "price",
    "old_price",
    "category_id",
    "image_urls",
    "created_at",
    "updated_at"
    // ... بقیه ستون‌ها
  ],
  "sample": {
    "id": 1,
    "product_name": "نمونه محصول",
    ...
  }
}
```

این لیست **دقیقاً** ستون‌هایی که در جدول products وجود دارند را نشان می‌دهد.

---

### روش ۲: از Supabase Dashboard استفاده کنید

1. **Supabase Dashboard** > **Table Editor**
2. انتخاب جدول `products`
3. مشاهده لیست ستون‌ها در بالای جدول

---

### روش ۳: از SQL Query استفاده کنید

در **SQL Editor**:

```sql
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'products'
ORDER BY ordinal_position;
```

**خروجی:**
```
column_name       | data_type | is_nullable
------------------+-----------+------------
id                | integer   | NO
product_name      | text      | NO
slug              | text      | NO
price             | numeric   | NO
old_price         | numeric   | YES
category_id       | integer   | YES
image_urls        | text      | YES
score             | integer   | YES
created_at        | timestamp | YES
updated_at        | timestamp | YES
...
```

---

## 🛠️ راهنمای اصلاح selectFields

### گام ۱: بررسی Schema

از یکی از روش‌های بالا schema را بررسی کنید.

### گام ۲: تنظیم selectFields

فقط فیلدهایی که **واقعاً وجود دارند** را اضافه کنید:

```typescript
// ❌ اشتباه - فیلدهای فرضی
const selectFields = 'id,name,stock,inventory,quantity';

// ✅ صحیح - فقط فیلدهای موجود
const selectFields = 'id,product_name,slug,price,old_price,category_id,image_urls,score,created_at';
```

### گام ۳: اضافه کردن فیلدهای پیش‌فرض

اگر frontend به فیلدی نیاز دارد که در DB نیست:

```typescript
const mappedProducts = products.map(p => ({
  ...p,
  stock: 100,              // مقدار پیش‌فرض
  name: p.product_name,    // نام جایگزین
  image: p.image_urls      // نام جایگزین
}));
```

---

## 📊 لیست فیلدهای رایج و نام‌های جایگزین

| فیلد مورد نیاز Frontend | نام احتمالی در DB | راه‌حل |
|------------------------|-------------------|--------|
| `name` | `product_name` | mapping در backend |
| `stock` | ممکن است نباشد | مقدار پیش‌فرض: 100 |
| `image` | `image_urls` | mapping در backend |
| `originalPrice` | `old_price` | mapping در backend |
| `category` | `category_id` | join یا mapping |
| `description` | `short_description` یا `full_description` | mapping |

---

## 🧪 تست کردن

### تست ۱: بررسی خطا رفع شده است

```bash
# تست محصولات ویژه
curl https://YOUR_PROJECT.supabase.co/functions/v1/make-server-fbc72c25/products/featured

# تست تمام محصولات
curl https://YOUR_PROJECT.supabase.co/functions/v1/make-server-fbc72c25/products
```

**انتظار:**
- ✅ بدون خطای `column does not exist`
- ✅ محصولات با موفقیت برگشت داده می‌شوند
- ✅ فیلد `stock` در response وجود دارد (با مقدار 100)

### تست ۲: بررسی لاگ‌ها

Supabase Dashboard > Edge Functions > Logs

**پیام‌های مورد انتظار:**
- ✅ `📦 Fetching all products...`
- ✅ `✅ Returned X products`
- ❌ `column products.stock does not exist` (نباید دیده شود)

---

## 🔄 اگر فیلد جدیدی اضافه کردید

### در دیتابیس:

```sql
-- اضافه کردن فیلد جدید
ALTER TABLE products 
ADD COLUMN inventory INTEGER DEFAULT 100;

-- ایجاد Index (اختیاری)
CREATE INDEX idx_products_inventory 
ON products(inventory);
```

### در Backend:

```typescript
// اضافه کردن به selectFields
const selectFields = 
  'id,product_name,...,inventory,created_at';

// اگر نیاز به mapping دارید
const mappedProducts = products.map(p => ({
  ...p,
  stock: p.inventory || 100 // mapping inventory به stock
}));
```

---

## 💡 Best Practices

### ✅ انجام دهید:

1. **همیشه schema را قبل از نوشتن query بررسی کنید**
2. **از Debug Endpoint استفاده کنید**
3. **Fallback Strategy چندلایه داشته باشید**
4. **فیلدهای پیش‌فرض برای سازگاری اضافه کنید**
5. **خطاها را با جزئیات log کنید**

### ❌ انجام ندهید:

1. **فرض نکنید فیلدی بدون بررسی وجود دارد**
2. **از `select('*')` در production استفاده نکنید**
3. **خطاها را بدون لاگ نادیده نگیرید**
4. **بدون fallback query ننویسید**

---

## 🚨 خطاهای رایج دیگر

### خطا: `relation "products" does not exist`

**علت:** جدول products وجود ندارد

**راه‌حل:**
```sql
CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  product_name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  price NUMERIC NOT NULL,
  ...
);
```

### خطا: `permission denied for table products`

**علت:** RLS Policy یا سطح دسترسی

**راه‌حل:**
```sql
-- غیرفعال کردن RLS (برای تست)
ALTER TABLE products DISABLE ROW LEVEL SECURITY;

-- یا ایجاد Policy مناسب
CREATE POLICY "Allow read for all users"
ON products FOR SELECT
USING (true);
```

### خطا: `null value in column "X" violates not-null constraint`

**علت:** فیلد اجباری است ولی مقدار ندارد

**راه‌حل:**
```typescript
// در insert/update مقدار دهید
const product = {
  product_name: data.product_name || 'بدون نام',
  slug: data.slug || 'default-slug',
  price: data.price || 0
};
```

---

## 📞 عیب‌یابی

### اگر هنوز خطا می‌بینید:

1. **Cache را پاک کنید**
   - Ctrl + Shift + Delete
   - Hard Reload: Ctrl + F5

2. **Edge Function را دوباره deploy کنید**
   ```bash
   supabase functions deploy make-server-fbc72c25
   ```

3. **لاگ‌های کامل را بررسی کنید**
   - Dashboard > Edge Functions > Logs
   - Console.log در frontend (F12)

4. **Debug Endpoint را تست کنید**
   ```bash
   curl .../products/schema/debug
   ```

---

## ✅ خلاصه تغییرات

### فایل‌های به‌روز شده:
- ✅ `/supabase/functions/server/product_routes.ts`
  - حذف `stock` از selectFields
  - اضافه کردن fallback برای column errors
  - اضافه کردن مقدار پیش‌فرض `stock: 100`

### نتیجه:
- ✅ خطای `column stock does not exist` رفع شد
- ✅ محصولات با موفقیت fetch می‌شوند
- ✅ سازگاری با frontend حفظ شد
- ✅ Fallback strategy چندلایه فعال است

---

**تاریخ:** ۱۴۰۳/۱۰/۰۸  
**وضعیت:** ✅ رفع شده  
**نسخه:** 1.0.0
