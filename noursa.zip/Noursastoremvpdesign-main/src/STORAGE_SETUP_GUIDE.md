# راهنمای رفع خطای Storage RLS

## مشکل
هنگام آپلود فایل‌ها در سیستم مشاوره، خطای زیر رخ می‌دهد:
```
❌ Error uploading file: StorageApiError: new row violates row-level security policy
```

## علت
Supabase Storage از Row-Level Security (RLS) استفاده می‌کند که برای امنیت بالاتر، به‌صورت پیش‌فرض هیچ کاربری نمی‌تواند فایل آپلود یا دانلود کند مگر اینکه policy مربوطه را ایجاد کنید.

## راه حل (مراحل رفع خطا)

### مرحله 1: ورود به Supabase Dashboard
1. به [Supabase Dashboard](https://supabase.com/dashboard) بروید
2. پروژه خود را انتخاب کنید
3. از منوی سمت چپ، گزینه **SQL Editor** را انتخاب کنید

### مرحله 2: اجرای SQL Commands

در SQL Editor، کوئری‌های زیر را یک‌به‌یک کپی کرده و اجرا کنید:

#### ✅ Policy 1: اجازه آپلود (INSERT)
```sql
CREATE POLICY "Allow public uploads to consultation photos"
ON storage.objects
FOR INSERT
TO anon, authenticated
WITH CHECK (bucket_id = 'make-fbc72c25-consultation-photos');
```

#### ✅ Policy 2: اجازه خواندن (SELECT)
```sql
CREATE POLICY "Allow public reads from consultation photos"
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (bucket_id = 'make-fbc72c25-consultation-photos');
```

#### ✅ Policy 3: اجازه به‌روزرسانی (UPDATE) - اختیاری
```sql
CREATE POLICY "Allow public updates to consultation photos"
ON storage.objects
FOR UPDATE
TO anon, authenticated
USING (bucket_id = 'make-fbc72c25-consultation-photos');
```

#### ✅ Policy 4: اجازه حذف (DELETE) - اختیاری
```sql
CREATE POLICY "Allow public deletes from consultation photos"
ON storage.objects
FOR DELETE
TO anon, authenticated
USING (bucket_id = 'make-fbc72c25-consultation-photos');
```

### مرحله 3: تست
پس از اجرای کوئری‌های بالا:
1. سیستم مشاوره را باز کنید
2. یک فایل جدید آپلود کنید
3. خطا باید برطرف شده باشد ✅

## توضیحات تکنیکال

### Bucket Information
- **Bucket Name**: `make-fbc72c25-consultation-photos`
- **Public**: `false` (خصوصی - نیاز به signed URLs)
- **File Size Limit**: 10MB
- **Allowed MIME Types**: 
  - `image/jpeg`
  - `image/png`
  - `image/webp`
  - `image/jpg`
  - `video/mp4`
  - `video/quicktime`

### Policy Roles
- `anon`: کاربران ناشناس (بدون احراز هویت)
- `authenticated`: کاربران احراز هویت شده

در این پروژه، هر دو role اجازه دسترسی دارند تا فرآیند مشاوره بدون نیاز به ثبت‌نام کار کند.

## بررسی Policies موجود

برای مشاهده policies فعلی bucket، این کوئری را اجرا کنید:

```sql
SELECT *
FROM storage.policies
WHERE bucket_id = 'make-fbc72c25-consultation-photos';
```

## حذف Policy (در صورت نیاز)

اگر می‌خواهید یک policy را حذف کنید:

```sql
DROP POLICY IF EXISTS "Allow public uploads to consultation photos" ON storage.objects;
```

## منابع بیشتر
- [Supabase Storage RLS Documentation](https://supabase.com/docs/guides/storage/security/access-control)
- [Supabase Storage Policies](https://supabase.com/docs/guides/storage/security/access-policies)

---

✅ **پس از اجرای این مراحل، خطای "new row violates row-level security policy" برطرف می‌شود.**
