-- ====================================================================
-- اسکریپت راه‌اندازی ستون Score برای جدول Products
-- این اسکریپت را در Supabase SQL Editor اجرا کنید
-- ====================================================================

-- گام ۱: اضافه کردن ستون score به جدول products
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS score INTEGER DEFAULT NULL;

-- گام ۲: اضافه کردن comment برای مستندسازی
COMMENT ON COLUMN products.score IS 'امتیاز محصول برای مرتب‌سازی (۱-۱۰۰)، هرچه بالاتر رتبه بهتر';

-- گام ۳: تنظیم امتیاز پیش‌فرض برای محصولات موجود (اختیاری)
-- این query به محصولات جدید امتیاز ۵۰ می‌دهد
-- UPDATE products 
-- SET score = 50 
-- WHERE score IS NULL;

-- گام ۴: ایجاد Index برای بهبود سرعت
CREATE INDEX IF NOT EXISTS idx_products_score 
ON products(score DESC NULLS LAST);

CREATE INDEX IF NOT EXISTS idx_products_score_created 
ON products(score DESC NULLS LAST, created_at DESC);

-- گام ۵: بررسی نتیجه
SELECT 
  COUNT(*) as total_products,
  COUNT(score) as products_with_score,
  COUNT(*) - COUNT(score) as products_without_score,
  MIN(score) as min_score,
  MAX(score) as max_score,
  AVG(score) as avg_score
FROM products;

-- ====================================================================
-- پیشنهاد: امتیازدهی به محصولات پرفروش
-- این query ها را بر اساس نیاز خود تغییر دهید
-- ====================================================================

-- روش ۱: امتیازدهی دستی به محصولات خاص
-- محصولات برتر (پرفروش‌ترین‌ها)
UPDATE products SET score = 95 WHERE id IN (
  1, 2, 3  -- IDهای محصولات برتر را اینجا قرار دهید
);

-- محصولات محبوب
UPDATE products SET score = 80 WHERE id IN (
  4, 5, 6  -- IDهای محصولات محبوب را اینجا قرار دهید
);

-- محصولات معمولی
UPDATE products SET score = 60 WHERE id IN (
  7, 8, 9  -- IDهای محصولات معمولی را اینجا قرار دهید
);

-- ====================================================================
-- روش ۲: امتیازدهی خودکار بر اساس تاریخ
-- محصولات جدید: امتیاز بالاتر
-- ====================================================================

-- محصولات ماه اخیر: امتیاز ۷۰
UPDATE products 
SET score = 70 
WHERE created_at > NOW() - INTERVAL '30 days' 
  AND score IS NULL;

-- محصولات ۱-۳ ماه اخیر: امتیاز ۵۰
UPDATE products 
SET score = 50 
WHERE created_at > NOW() - INTERVAL '90 days' 
  AND created_at <= NOW() - INTERVAL '30 days'
  AND score IS NULL;

-- محصولات قدیمی‌تر: امتیاز ۳۰
UPDATE products 
SET score = 30 
WHERE created_at <= NOW() - INTERVAL '90 days'
  AND score IS NULL;

-- ====================================================================
-- گزارش نهایی: نمایش محصولات بر اساس امتیاز
-- ====================================================================

SELECT 
  id,
  product_name,
  slug,
  score,
  created_at,
  CASE 
    WHEN score >= 90 THEN '⭐⭐⭐⭐⭐ عالی'
    WHEN score >= 70 THEN '⭐⭐⭐⭐ خوب'
    WHEN score >= 50 THEN '⭐⭐⭐ متوسط'
    WHEN score >= 30 THEN '⭐⭐ ضعیف'
    WHEN score IS NULL THEN '❓ بدون امتیاز'
    ELSE '⭐ خیلی ضعیف'
  END as rating
FROM products
ORDER BY score DESC NULLS LAST, created_at DESC
LIMIT 20;

-- ====================================================================
-- تمام! حالا سیستم باید محصولات را بر اساس score نمایش دهد
-- ====================================================================
