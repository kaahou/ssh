# 🌟 راهنمای مدیریت محصولات ویژه و محبوب

این راهنما به شما کمک می‌کند محصولات دلخواه یا با امتیاز بالا را در صفحه اصلی نمایش دهید.

---

## 📊 وضعیت فعلی سیستم

✅ **سیستم اکنون بر اساس فیلد `score` کار می‌کند!**

در حال حاضر، سیستم محصولات را بر اساس **فیلد `score`** مرتب می‌کند:
- محصولات با **امتیاز بالاتر** در **رتبه بهتر** قرار می‌گیرند
- محصولات بدون امتیاز (NULL) در انتهای لیست نمایش داده می‌شوند
- در صورت برابری امتیاز، **جدیدترین محصولات** اولویت دارند

**مسیر endpoint فعلی:**
```
/products/featured → نمایش 8 محصول برتر بر اساس score
/products → نمایش تمام محصولات بر اساس score
```

**کد فعلی در:** 
- `/supabase/functions/server/product_routes.ts` (خط ۳۹-۸۶ و ۸۹-۱۳۳)
- `/supabase/functions/server/product_service.ts` (کل فانکشن‌ها)

---

## ✅ تغییرات اعمال شده

### ✅ فیلد `score` به جدول اضافه شده
### ✅ ۱۸ محصول پرفروش مقدار‌دهی شده‌اند
### ✅ تمام endpoint ها بر اساس `score` مرتب می‌شوند

برای جزئیات کامل تغییرات، فایل `/SCORE_FIELD_IMPLEMENTATION_REPORT.md` را مطالعه کنید.

---

## 🎨 تغییر تعداد محصولات نمایش داده شده

### در صفحه اصلی

فایل `/supabase/functions/server/product_routes.ts` را باز کنید و خط ۴۶ را تغییر دهید:

**فعلی: ۸ محصول**
```typescript
.limit(8);
```

**برای ۱۲ محصول:**
```typescript
.limit(12);
```

**برای ۶ محصول:**
```typescript
.limit(6);
```

### در صفحه محصولات

فایل `/App.tsx` را باز کنید و خط ۳۲۷ را پیدا کنید:

```typescript
`https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/featured`,
```

این endpoint را فراخوانی می‌کند که تعداد را در backend تغییر دادید.

---

## 🔧 مثال کامل: پیاده‌سازی سیستم امتیاز‌دهی

### قدم ۱: ایجاد ساختار دیتابیس

```sql
-- اضافه کردن فیلدهای امتیاز و فروش
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS rating DECIMAL(3, 2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS review_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS sales_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS view_count INTEGER DEFAULT 0;

-- ایجاد indexها
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured) WHERE is_featured = true;
CREATE INDEX IF NOT EXISTS idx_products_rating ON products(rating DESC);
CREATE INDEX IF NOT EXISTS idx_products_sales ON products(sales_count DESC);

-- کامنت‌ها
COMMENT ON COLUMN products.is_featured IS 'آیا محصول ویژه است؟';
COMMENT ON COLUMN products.rating IS 'امتیاز محصول (0-5)';
COMMENT ON COLUMN products.review_count IS 'تعداد نظرات';
COMMENT ON COLUMN products.sales_count IS 'تعداد فروش';
COMMENT ON COLUMN products.view_count IS 'تعداد بازدید';
```

### قدم ۲: به‌روزرسانی کد Backend

فایل `/supabase/functions/server/product_routes.ts` را ویرایش کنید:

```typescript
// Get featured products - MUST be before /products/:id
productRoutes.get("/products/featured", async (c) => {
  try {
    // استراتژی ترکیبی: 
    // 1. محصولات ویژه (is_featured = true) با بالاترین امتیاز
    // 2. اگر کافی نبود، محصولات پرفروش
    // 3. اگر باز کافی نبود، جدیدترین‌ها
    
    const limit = 8;
    let products = [];
    
    // ابتدا محصولات ویژه با امتیاز بالا
    const { data: featuredProducts, error: featuredError } = await supabase
      .from('products')
      .select('*')
      .eq('is_featured', true)
      .eq('is_active', true)  // فقط محصولات فعال
      .gt('stock', 0)  // فقط محصولات موجود
      .order('rating', { ascending: false })
      .order('sales_count', { ascending: false })
      .limit(limit);
    
    if (!featuredError && featuredProducts && featuredProducts.length > 0) {
      products = featuredProducts;
      console.log(`✅ Found ${products.length} featured products`);
    }
    
    // اگر محصول ویژه کافی نبود، از پرفروش‌ترین‌ها استفاده کن
    if (products.length < limit) {
      const remaining = limit - products.length;
      const { data: bestSellers } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .gt('stock', 0)
        .order('sales_count', { ascending: false })
        .order('rating', { ascending: false })
        .limit(remaining);
      
      if (bestSellers && bestSellers.length > 0) {
        // جلوگیری از تکراری شدن
        const newProducts = bestSellers.filter(
          bp => !products.some(p => p.id === bp.id)
        );
        products = [...products, ...newProducts];
        console.log(`✅ Added ${newProducts.length} best-sellers`);
      }
    }
    
    // اگر هنوز کافی نیست، از جدیدترین‌ها استفاده کن
    if (products.length < limit) {
      const remaining = limit - products.length;
      const { data: newestProducts } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .gt('stock', 0)
        .order('created_at', { ascending: false })
        .limit(remaining);
      
      if (newestProducts && newestProducts.length > 0) {
        const newProducts = newestProducts.filter(
          np => !products.some(p => p.id === np.id)
        );
        products = [...products, ...newProducts];
        console.log(`✅ Added ${newProducts.length} newest products`);
      }
    }
    
    // Map 'id' to 'product_id' for frontend compatibility
    const mappedProducts = products?.map(p => ({
      ...p,
      product_id: p.id
    })) || [];
    
    console.log(`📦 Total featured products: ${mappedProducts.length}`);
    return c.json({ products: mappedProducts });
    
  } catch (error) {
    console.error("Exception in /products/featured endpoint:", error);
    return c.json({ products: [] });
  }
});
```

---

## 📝 به‌روزرسانی خودکار تعداد فروش

برای به‌روزرسانی خودکار `sales_count` هنگام خرید، فایل مدیریت سفارشات را ویرایش کنید:

### فایل: `/supabase/functions/server/order_routes.ts`

پس از ثبت موفق سفارش، کد زیر را اضافه کنید:

```typescript
// بعد از ثبت سفارش موفق
if (orderResponse.success && orderItems && orderItems.length > 0) {
  // به‌روزرسانی تعداد فروش محصولات
  for (const item of orderItems) {
    const productId = item.product_id;
    const quantity = item.quantity || 1;
    
    // افزایش sales_count
    await supabase.rpc('increment_sales_count', {
      product_id: productId,
      increment_by: quantity
    });
  }
}
```

### ایجاد Function در دیتابیس:

```sql
-- Function برای افزایش تعداد فروش
CREATE OR REPLACE FUNCTION increment_sales_count(
  product_id UUID,
  increment_by INTEGER DEFAULT 1
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE products
  SET 
    sales_count = COALESCE(sales_count, 0) + increment_by,
    updated_at = NOW()
  WHERE id = product_id;
END;
$$;

-- مجوز اجرا
GRANT EXECUTE ON FUNCTION increment_sales_count TO authenticated, anon;
```

---

## 🎯 استراتژی‌های پیشنهادی

### استراتژی ۱: ساده (برای شروع)
- فقط از `is_featured` استفاده کنید
- محصولات ویژه را دستی انتخاب کنید
- اگر محصول ویژه نبود، جدیدترین‌ها را نمایش دهید

### استراتژی ۲: متوسط (توصیه می‌شود)
- ترکیب `is_featured` و `sales_count`
- محصولات ویژه اولویت دارند
- سپس پرفروش‌ترین‌ها نمایش داده می‌شوند

### استراتژی ۳: پیشرفته (برای فروشگاه‌های بزرگ)
- ترکیب همه معیارها: `is_featured`, `rating`, `sales_count`, `view_count`
- الگوریتم امتیازدهی وزن‌دار
- به‌روزرسانی خودکار بر اساس عملکرد

---

## ⚙️ الگوریتم امتیازدهی پیشرفته (اختیاری)

اگر می‌خواهید یک الگوریتم هوشمند داشته باشید:

### قدم ۱: ایجاد فیلد امتیاز کلی

```sql
ALTER TABLE products 
ADD COLUMN popularity_score DECIMAL(10, 2) DEFAULT 0.00;

CREATE INDEX idx_products_popularity ON products(popularity_score DESC);
```

### قدم ۲: ایجاد Function محاسبه امتیاز

```sql
CREATE OR REPLACE FUNCTION calculate_popularity_score()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- فرمول امتیازدهی:
  -- Score = (rating * 20) + (sales_count * 2) + (view_count * 0.1) + (is_featured ? 100 : 0)
  
  NEW.popularity_score := 
    (COALESCE(NEW.rating, 0) * 20) +
    (COALESCE(NEW.sales_count, 0) * 2) +
    (COALESCE(NEW.view_count, 0) * 0.1) +
    (CASE WHEN NEW.is_featured THEN 100 ELSE 0 END);
  
  RETURN NEW;
END;
$$;

-- ایجاد Trigger
CREATE TRIGGER update_popularity_score
BEFORE INSERT OR UPDATE ON products
FOR EACH ROW
EXECUTE FUNCTION calculate_popularity_score();
```

### قدم ۳: استفاده از امتیاز در Backend

```typescript
// Return products with highest popularity score
const { data: products, error } = await supabase
  .from('products')
  .select('*')
  .eq('is_active', true)
  .gt('stock', 0)
  .order('popularity_score', { ascending: false })
  .limit(8);
```

---

## 📊 مدیریت از پنل ادمین

اگر می‌خواهید مدیران بتوانند از پنل ادمین محصولات ویژه را مدیریت کنند:

### گزینه ۱: استفاده از Supabase Dashboard
1. وارد Supabase Dashboard شوید
2. Table Editor > products
3. محصول مورد نظر را پیدا کنید
4. فیلد `is_featured` را ویرایش کنید

### گزینه ۲: افزودن قابلیت به پنل ادمین (پیشنهاد برای آینده)
می‌توانید یک صفحه ادمین اضافه کنید که:
- لیست تمام محصولات را نمایش دهد
- دکمه‌ای برای تنظیم/حذف ویژه بودن داشته باشد
- امکان تنظیم ترتیب نمایش را بدهد

---

## ✅ چک‌لیست پیاده‌سازی

- [ ] تصمیم‌گیری در مورد استراتژی (ویژه، امتیاز، فروش، یا ترکیبی)
- [ ] اجرای SQL commands در Supabase Dashboard
- [ ] ویرایش `/supabase/functions/server/product_routes.ts`
- [ ] تست endpoint: `/products/featured`
- [ ] بررسی نمایش در صفحه اصلی
- [ ] تست در مرورگرهای مختلف
- [ ] علامت‌گذاری محصولات ویژه (اگر از روش `is_featured` استفاده کردید)
- [ ] مستندسازی تغییرات

---

## 🆘 عیب‌یابی

### مشکل: محصولات نمایش داده نمی‌شوند

**راه‌حل:**
1. Console مرورگر را چک کنید (F12)
2. Network tab را بررسی کنید
3. Response از `/products/featured` را ببینید
4. مطمئن شوید `is_active = true` و `stock > 0` هستند

### مشکل: فیلد `is_featured` وجود ندارد

**راه‌حل:**
SQL زیر را در Supabase Dashboard اجرا کنید:

```sql
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_products_featured 
ON products(is_featured) WHERE is_featured = true;
```

### مشکل: تغییرات اعمال نمی‌شوند

**راه‌حل:**
1. Cache مرورگر را پاک کنید (Ctrl+Shift+Delete)
2. صفحه را Hard Refresh کنید (Ctrl+F5)
3. مطمئن شوید Backend را دوباره deploy کرده‌اید

---

## 📚 منابع اضافی

- [Supabase Documentation](https://supabase.com/docs)
- [PostgreSQL ORDER BY](https://www.postgresql.org/docs/current/queries-order.html)
- [Supabase Indexes](https://supabase.com/docs/guides/database/indexes)

---

**تاریخ ایجاد سند:** ۱۴۰۳/۱۰/۰۷  
**آخرین بروزرسانی:** ۱۴۰۳/۱۰/۰۷  
**نسخه:** 1.0.0