/**
 * Logger Utility for Development and Production
 * 
 * در production فقط error ها نمایش داده می‌شوند
 * در development همه لاگ‌ها فعال هستند
 */

// بررسی محیط به صورت safe - با fallback به production
const isDev = (() => {
  try {
    // بررسی Vite environment
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      return import.meta.env.DEV === true || import.meta.env.MODE === 'development';
    }
    // بررسی Node environment
    if (typeof process !== 'undefined' && process.env) {
      return process.env.NODE_ENV === 'development';
    }
    // Default: production (برای امنیت بیشتر)
    return false;
  } catch {
    // اگر خطا رخ داد، فرض می‌کنیم production است
    return false;
  }
})();

export const logger = {
  /**
   * لاگ عادی - فقط در development
   */
  log: (...args: any[]) => {
    if (isDev) {
      console.log(...args);
    }
  },

  /**
   * لاگ خطا - در هر دو محیط
   */
  error: (...args: any[]) => {
    console.error(...args);
    
    // در production می‌توانید به سرویس error tracking بفرستید
    if (!isDev) {
      // TODO: ارسال به سرویس monitoring (مثل Sentry)
    }
  },

  /**
   * لاگ هشدار - فقط در development
   */
  warn: (...args: any[]) => {
    if (isDev) {
      console.warn(...args);
    }
  },

  /**
   * لاگ اطلاعات حساس - فقط در development
   * برای دیباگ اطلاعاتی مثل phone, OTP, user data
   */
  sensitive: (label: string, ...args: any[]) => {
    if (isDev) {
      console.log(`🔒 [SENSITIVE] ${label}:`, ...args);
    }
  },

  /**
   * لاگ موفقیت - فقط در development
   */
  success: (...args: any[]) => {
    if (isDev) {
      console.log('✅', ...args);
    }
  },

  /**
   * لاگ شروع عملیات - فقط در development
   */
  info: (...args: any[]) => {
    if (isDev) {
      console.info('ℹ️', ...args);
    }
  },

  /**
   * لاگ دیباگ با group - فقط در development
   */
  group: (label: string, callback: () => void) => {
    if (isDev) {
      console.group(label);
      callback();
      console.groupEnd();
    }
  },

  /**
   * لاگ performance - فقط در development
   */
  perf: (label: string, startTime: number) => {
    if (isDev) {
      const duration = performance.now() - startTime;
      console.log(`⏱️ [PERF] ${label}: ${duration.toFixed(2)}ms`);
    }
  },

  /**
   * لاگ دیباگ - فقط در development
   */
  debug: (...args: any[]) => {
    if (isDev) {
      console.debug('🐛', ...args);
    }
  },
};

// Export هم به صورت default
export default logger;