# 👨‍💻 راهنمای توسعه‌دهنده - فروشگاه نورسا

این راهنما برای توسعه‌دهندگانی است که می‌خواهند پروژه را توسعه دهند یا تغییرات جدیدی اعمال کنند.

---

## 🏗 معماری پروژه

### ساختار کلی
```
Frontend (React) → Server (Hono) → Database (KV Store)
```

### Flow داده
1. کاربر با UI تعامل می‌کند
2. Frontend درخواست به Server می‌فرستد
3. Server با Database ارتباط می‌گیرد
4. نتیجه به Frontend برمی‌گردد
5. UI به‌روز می‌شود

---

## 📦 افزودن محصول جدید

### روش 1: از طریق کد (Development)

در فایل `/supabase/functions/server/index.tsx`:

```typescript
const newProduct = {
  id: "7",
  name: "نام محصول",
  price: 299000,
  originalPrice: 399000, // optional
  category: "electronics", // یا fashion, home, sports
  description: "توضیحات محصول",
  image: "https://images.unsplash.com/photo-...",
  stock: 10,
  featured: true, // برای نمایش در صفحه اصلی
};

await kv.set(`product:${newProduct.id}`, newProduct);
```

### روش 2: از طریق API

```javascript
// در آینده می‌توان یک endpoint POST اضافه کرد
POST /make-server-fbc72c25/products
{
  "name": "محصول جدید",
  "price": 299000,
  ...
}
```

---

## 🎨 تغییر رنگ‌های سایت

### مرحله 1: به‌روزرسانی CSS Variables

در `/styles/globals.css`:

```css
:root {
  /* تغییر رنگ اصلی */
  --color-primary-dark: #YOUR_COLOR;
  --color-primary-medium: #YOUR_COLOR;
  
  /* تغییر رنگ ثانویه */
  --color-cream: #YOUR_COLOR;
}
```

### مرحله 2: به‌روزرسانی کلاس‌های Tailwind

جایگزینی در تمام فایل‌ها:
- `bg-[#1A2011]` → `bg-[#YOUR_COLOR]`
- `text-[#1A2011]` → `text-[#YOUR_COLOR]`

---

## 🔌 افزودن API Endpoint جدید

### مثال: لیست علاقه‌مندی‌ها

در `/supabase/functions/server/index.tsx`:

```typescript
// GET - دریافت لیست علاقه‌مندی‌ها
app.get("/make-server-fbc72c25/wishlist", async (c) => {
  try {
    const wishlist = await kv.getByPrefix("wishlist:");
    return c.json({ wishlist });
  } catch (error) {
    console.error("Error fetching wishlist:", error);
    return c.json({ error: "Failed to fetch wishlist" }, 500);
  }
});

// POST - افزودن به لیست علاقه‌مندی‌ها
app.post("/make-server-fbc72c25/wishlist", async (c) => {
  try {
    const body = await c.req.json();
    const { productId, userId } = body;
    
    const wishlistId = `wishlist:${userId}:${productId}`;
    await kv.set(wishlistId, {
      productId,
      userId,
      addedAt: new Date().toISOString(),
    });
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error adding to wishlist:", error);
    return c.json({ error: "Failed to add to wishlist" }, 500);
  }
});
```

---

## 🧩 ساخت کامپوننت جدید

### ساختار پیشنهادی

```typescript
// /components/MyComponent.tsx

import { ReactNode } from "react";
import { Button } from "./ui/button";

interface MyComponentProps {
  title: string;
  children?: ReactNode;
  onAction?: () => void;
}

export function MyComponent({ title, children, onAction }: MyComponentProps) {
  return (
    <div className="bg-white rounded-[16px] p-6 border border-[#E8E8E8]">
      <h3 className="mb-4 text-[#1A2011]">{title}</h3>
      {children}
      {onAction && (
        <Button onClick={onAction} className="mt-4">
          عملیات
        </Button>
      )}
    </div>
  );
}
```

### استفاده از کامپوننت

```typescript
import { MyComponent } from "./components/MyComponent";

<MyComponent 
  title="عنوان من" 
  onAction={() => console.log("clicked")}
>
  <p>محتوای داخلی</p>
</MyComponent>
```

---

## 🔄 مدیریت State

### Context API (برای state سراسری)

```typescript
// 1. ایجاد Context
const MyContext = createContext<MyContextType | undefined>(undefined);

// 2. ایجاد Provider
export function MyProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState(initialState);
  
  return (
    <MyContext.Provider value={{ state, setState }}>
      {children}
    </MyContext.Provider>
  );
}

// 3. ایجاد Hook
export function useMyContext() {
  const context = useContext(MyContext);
  if (!context) {
    throw new Error("useMyContext must be used within MyProvider");
  }
  return context;
}

// 4. استفاده در کامپوننت
function MyComponent() {
  const { state, setState } = useMyContext();
  // ...
}
```

### useState (برای state محلی)

```typescript
function MyComponent() {
  const [isOpen, setIsOpen] = useState(false);
  const [data, setData] = useState<DataType[]>([]);
  
  // ...
}
```

---

## 🎯 بهترین روش‌ها (Best Practices)

### 1. نام‌گذاری
- **کامپوننت‌ها**: PascalCase (`ProductCard`, `HomePage`)
- **فایل‌ها**: kebab-case یا PascalCase
- **متغیرها**: camelCase (`productList`, `isLoading`)
- **ثابت‌ها**: UPPER_SNAKE_CASE (`MAX_ITEMS`)

### 2. Import ها
```typescript
// ✅ خوب
import { Button } from "./ui/button";
import { Product } from "./ProductCard";

// ❌ بد
import Button from "./ui/button";
```

### 3. Type Safety
```typescript
// ✅ همیشه از TypeScript types استفاده کنید
interface Product {
  id: string;
  name: string;
  price: number;
}

// ❌ از any استفاده نکنید
const products: any[] = [];
```

### 4. Error Handling
```typescript
// ✅ همیشه خطاها را handle کنید
try {
  const data = await fetchData();
} catch (error) {
  console.error("Error message with context:", error);
  toast.error("پیام خطا برای کاربر");
}
```

### 5. Accessibility
```typescript
// ✅ همیشه accessibility را در نظر بگیرید
<button 
  aria-label="افزودن به سبد خرید"
  onClick={handleClick}
>
  <ShoppingCart />
</button>
```

---

## 🔍 دیباگ کردن

### 1. مشکلات Backend

```typescript
// در server/index.tsx
console.log("Request received:", c.req.url);
console.log("Body:", await c.req.json());
```

مشاهده logs در:
- Console browser (Network tab)
- Supabase Dashboard → Edge Functions → Logs

### 2. مشکلات Frontend

```typescript
// در کامپوننت
console.log("State:", state);
console.log("Props:", props);

// استفاده از React DevTools
```

### 3. مشکلات CSS

```typescript
// اضافه کردن outline موقتی
className="outline outline-2 outline-red-500"
```

---

## 📊 کار با KV Store

### عملیات پایه

```typescript
import * as kv from "./kv_store.tsx";

// ذخیره
await kv.set("key", { data: "value" });

// دریافت یک مورد
const item = await kv.get("key");

// دریافت چند مورد
const items = await kv.mget(["key1", "key2"]);

// دریافت با prefix
const products = await kv.getByPrefix("product:");

// حذف
await kv.del("key");

// حذف چند مورد
await kv.mdel(["key1", "key2"]);
```

### ساختار کلیدها

```
product:{id}              → محصولات
order:{id}                → سفارشات
consultation:{id}         → مشاوره‌ها
user:{id}                 → کاربران (در صورت افزودن auth)
category:{id}             → دسته‌بندی‌ها
```

---

## 🚀 عملکرد (Performance)

### 1. بهینه‌سازی تصاویر

```typescript
// استفاده از lazy loading
<img 
  src={product.image} 
  alt={product.name}
  loading="lazy"
/>

// استفاده از Unsplash با پارامترهای بهینه
const imageUrl = "https://images.unsplash.com/photo-...?w=400&h=500&fit=crop";
```

### 2. مموریزیشن

```typescript
import { useMemo, useCallback } from "react";

// برای محاسبات سنگین
const expensiveValue = useMemo(() => {
  return computeExpensiveValue(data);
}, [data]);

// برای توابع
const handleClick = useCallback(() => {
  doSomething();
}, [dependency]);
```

### 3. Code Splitting

```typescript
// استفاده از dynamic import
const HeavyComponent = lazy(() => import("./HeavyComponent"));

<Suspense fallback={<Loading />}>
  <HeavyComponent />
</Suspense>
```

---

## 🔐 امنیت

### 1. محافظت از Environment Variables

```typescript
// ✅ فقط در سرور
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

// ✅ در frontend
const publicKey = publicAnonKey; // از info.tsx
```

### 2. Validation ورودی‌ها

```typescript
// در server
if (!name || !phone || !email) {
  return c.json({ error: "فیلدهای الزامی خالی است" }, 400);
}

// بررسی نوع
if (typeof price !== 'number' || price < 0) {
  return c.json({ error: "قیمت نامعتبر است" }, 400);
}
```

### 3. Sanitization

```typescript
// تمیز کردن ورودی از کاراکترهای خطرناک
const sanitizedInput = input.trim().replace(/[<>]/g, '');
```

---

## 📝 تست

### نمونه تست دستی

```typescript
// چک‌لیست تست برای هر feature:

// ✅ افزودن محصول به سبد
1. کلیک روی "افزودن به سبد"
2. بررسی toast notification
3. بررسی badge تعداد در header
4. رفتن به صفحه سبد و بررسی محصول

// ✅ فرم مشاوره
1. باز کردن فرم
2. پر نکردن فیلد الزامی و ارسال → بررسی خطا
3. پر کردن تمام فیلدها
4. ارسال و بررسی پیام موفقیت
5. بررسی ذخیره در KV Store
```

---

## 🎓 منابع مفید

### داکیومنتیشن
- [React Docs](https://react.dev)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [TypeScript](https://www.typescriptlang.org/docs/)
- [Hono](https://hono.dev)

### ابزارها
- React DevTools (Browser Extension)
- VS Code با ESLint و Prettier
- Supabase Dashboard

### کامیونیتی
- Stack Overflow
- GitHub Discussions
- Discord/Telegram Groups

---

## 💡 نکات و ترفندها

### 1. RTL Helper Classes

```typescript
// برای عناصری که در RTL معکوس می‌شوند
className="mr-2" → در RTL به ml-2 تبدیل می‌شود

// برای جلوگیری از معکوس شدن
<div style={{ direction: 'ltr' }}>
  Phone: 09123456789
</div>
```

### 2. Tailwind Arbitrary Values

```typescript
// استفاده از رنگ دلخواه
className="bg-[#1A2011]"

// استفاده از مقدار دلخواه
className="w-[450px]"
```

### 3. Conditional Classes

```typescript
// استفاده از template literals
className={`base-class ${isActive ? 'active-class' : 'inactive-class'}`}

// یا استفاده از کتابخانه clsx
import { clsx } from 'clsx';
className={clsx('base-class', { 'active-class': isActive })}
```

---

## 🐛 مشکلات متداول

### مشکل: تصاویر لود نمی‌شوند
**راه‌حل**: بررسی URL و استفاده از `figma:asset` برای تصاویر داخلی

### مشکل: سبد خرید بعد از رفرش پاک می‌شود
**راه‌حل**: بررسی localStorage - باید به صورت خودکار ذخیره شود

### مشکل: فرم ارسال نمی‌شود
**راه‌حل**: 
1. بررسی console برای خطاها
2. بررسی Network tab
3. بررسی validation فیلدها

### مشکل: استایل‌ها اعمال نمی‌شوند
**راه‌حل**:
1. بررسی Tailwind class names
2. بررسی globals.css
3. Hard refresh (Ctrl+Shift+R)

---

**نکته پایانی**: همیشه قبل از commit، کد را تست کنید و مطمئن شوید که break نمی‌کند! 🚀
