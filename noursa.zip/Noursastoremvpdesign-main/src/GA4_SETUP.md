# راهنمای سریع GA4 - Oil Global

## نصب سریع

### 1. دریافت Measurement ID
از Google Analytics یک GA4 Property بسازید و Measurement ID (مثل `G-XXXXXXXXXX`) را کپی کنید.

### 2. فعال‌سازی در App.tsx

```tsx
import { useEffect } from 'react';
import { initializeGA4 } from './utils/analytics';
import { usePageTracking } from './utils/useAnalytics';

function App() {
  useEffect(() => {
    initializeGA4('G-XXXXXXXXXX'); // با ID خود جایگزین کنید
  }, []);
  return <BrowserRouter>...</BrowserRouter>;
}

function AppContent() {
  usePageTracking(); // Auto-track page views
  return ...;
}
```

### 3. استفاده در کامپوننت‌ها

```tsx
import { useAnalytics } from './utils/useAnalytics';

const analytics = useAnalytics();

// افزودن به سبد
analytics.trackAddToCart(product, quantity);

// خرید موفق
analytics.trackPurchase(orderId, items, total, shipping, tax);

// جستجو
analytics.trackSearch(searchTerm);

// ورود
analytics.trackLogin('email');
```

## فایل‌های موجود

- `/utils/analytics.ts` - تمام توابع tracking
- `/utils/useAnalytics.ts` - React Hooks
- `/utils/analyticsConstants.ts` - ثابت‌ها
- `/utils/analyticsTypes.ts` - Type definitions

## تمام Eventها (122 Event)

### E-commerce
- trackViewItemList, trackViewItem, trackSelectItem
- trackAddToCart, trackRemoveFromCart, trackViewCart
- trackBeginCheckout, trackAddShippingInfo, trackAddPaymentInfo
- trackPurchase, trackRefund

### User
- trackLogin, trackSignUp, trackShare

### Search
- trackSearch, trackViewSearchResults

### Consultation
- trackStartConsultation, trackConsultationStep, trackCompleteConsultation

### Blog
- trackViewBlogList, trackViewArticle, trackArticleReadTime

### Navigation
- trackClickNavigation, trackClickBreadcrumb, trackOpenMobileMenu

### Contact
- trackClickFloatingContact, trackSubmitContactForm

### Profile
- trackViewProfile, trackUpdateProfile, trackViewOrderHistory

### و 50+ event دیگر...

## تست

```javascript
// در Console:
console.log(window.gtag);
console.log(window.dataLayer);
```

مشاهده در GA4 > DebugView
