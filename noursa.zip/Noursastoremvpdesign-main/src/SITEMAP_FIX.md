# 🔧 رفع خطای Sitemap در Google Search Console

## 📌 مشکل اولیه

Google Search Console خطای زیر را گزارش کرد:

```
❌ Sitemap can be read, but has errors
❌ Sitemap is HTML
❌ Your Sitemap appears to be an HTML page. Please use a supported sitemap format instead.
```

**علت:** URL `/sitemap.xml` به صفحه HTML React هدایت می‌شد به جای یک فایل XML معتبر.

---

## ✅ راه‌حل پیاده‌سازی شده

### 1️⃣ **ایجاد Endpoint دینامیک در سرور** (`/supabase/functions/server/index.tsx`)

یک endpoint جدید با مشخصات زیر ایجاد شد:

```typescript
api.get("/sitemap.xml", async (c) => { ... })
```

**ویژگی‌ها:**
- ✅ تولید خودکار XML از دیتابیس
- ✅ شامل صفحات استاتیک با priority و changefreq
- ✅ شامل تمام محصولات (از جدول `products`)
- ✅ شامل تمام دسته‌بندی‌ها (از جدول `categories`)
- ✅ شامل تمام مقالات منتشر شده (از جدول `articles`)
- ✅ Header صحیح: `Content-Type: application/xml; charset=utf-8`
- ✅ Cache 1 ساعته برای بهینه‌سازی

**مثال خروجی:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://nursaa.ir/</loc>
    <lastmod>2025-12-24</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://nursaa.ir/product/argan-oil</loc>
    <lastmod>2025-12-20</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  ...
</urlset>
```

---

### 2️⃣ **ایجاد Redirect Component در Frontend** (`/components/SitemapXmlRedirect.tsx`)

برای حالاتی که کاربر `/sitemap.xml` را مستقیماً در مرورگر باز می‌کند:

```typescript
export function SitemapXmlRedirect() {
  useEffect(() => {
    window.location.href = `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/sitemap.xml`;
  }, []);
  ...
}
```

**مزیت:** اطمینان از دریافت XML واقعی حتی اگر React Router فعال شود.

---

### 3️⃣ **اضافه کردن Route به App.tsx**

```typescript
<Route
  path="/sitemap.xml"
  element={<SitemapXmlRedirect />}
/>
```

---

## 🧪 تست و Validation

### دسترسی مستقیم به Sitemap:

**URL سرور:**
```
https://[PROJECT_ID].supabase.co/functions/v1/make-server-fbc72c25/sitemap.xml
```

**URL دامنه (بعد از Deploy):**
```
https://nursaa.ir/sitemap.xml
```

### چک‌لیست تست:

- [ ] باز کردن `/sitemap.xml` در مرورگر → باید XML خام نمایش دهد (نه HTML)
- [ ] `curl -I https://nursaa.ir/sitemap.xml` → باید `Content-Type: application/xml` برگرداند
- [ ] View Source در مرورگر → باید XML ساده باشد (بدون React HTML)
- [ ] تعداد URL‌ها باید شامل: محصولات + دسته‌ها + مقالات + صفحات استاتیک باشد

---

## 📝 فایل‌های تغییر یافته

### Backend:
1. ✅ `/supabase/functions/server/index.tsx` - اضافه شدن endpoint `/sitemap.xml`

### Frontend:
2. ✅ `/components/SitemapXmlRedirect.tsx` - کامپوننت redirect جدید
3. ✅ `/App.tsx` - اضافه شدن route برای `/sitemap.xml`

---

## 🚀 گام‌های بعدی (Post-Deploy)

### 1. **ثبت مجدد Sitemap در Google Search Console**

1. به [Google Search Console](https://search.google.com/search-console) بروید
2. پروپرتی `nursaa.ir` را انتخاب کنید
3. از منوی چپ **Sitemaps** را انتخاب کنید
4. اگر sitemap قبلی وجود دارد، آن را حذف کنید
5. URL جدید را وارد کنید:
   ```
   https://nursaa.ir/sitemap.xml
   ```
6. روی **Submit** کلیک کنید

### 2. **بررسی وضعیت**

بعد از چند ساعت/روز:
- ✅ Status: **Success**
- ✅ Discovered URLs: باید تعداد درست URL‌ها نمایش داده شود
- ✅ خطای "Sitemap is HTML" برطرف شود

### 3. **مانیتورینگ**

- Coverage Report → بررسی index شدن صفحات
- Performance → بررسی کلیک‌ها و نمایش‌ها
- Crawl Stats → بررسی تعداد صفحات crawl شده

---

## 🔍 نکات مهم

### Cache Management:
- Sitemap هر ۱ ساعت cache می‌شود
- برای force refresh:
  ```
  curl -H "Cache-Control: no-cache" https://nursaa.ir/sitemap.xml
  ```

### Auto-Update:
- هر محصول جدید خودکار به sitemap اضافه می‌شود
- هر مقاله منتشر شده خودکار اضافه می‌شود
- تغییر در دسته‌بندی‌ها خودکار اعمال می‌شود

### SEO Best Practices:
- ✅ Priority values: 0.6 تا 1.0
- ✅ Changefreq: daily, weekly, monthly
- ✅ Lastmod: بر اساس `update_at` از دیتابیس
- ✅ UTF-8 encoding
- ✅ No BOM
- ✅ Valid XML structure

---

## 🎯 نتیجه

✅ Sitemap به صورت دینامیک از دیتابیس تولید می‌شود  
✅ Header های HTTP صحیح برای XML  
✅ Google می‌تواند sitemap را parse کند  
✅ خطای "Sitemap is HTML" برطرف شد  
✅ Auto-scaling برای محصولات و مقالات جدید  
✅ SEO-friendly و مطابق با استانداردهای Google  

---

**تاریخ پیاده‌سازی:** 24 دسامبر 2025  
**نسخه:** 1.0  
**وضعیت:** ✅ آماده Deploy
