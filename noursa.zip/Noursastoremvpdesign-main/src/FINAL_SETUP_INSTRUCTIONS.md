# 🚀 راهنمای نهایی راه‌اندازی سیستم امتیازدهی محصولات

## ✅ تغییرات کامل شده

### کدهای Frontend و Backend ✅
- ✅ Backend: تمام endpoint ها بر اساس `score` مرتب می‌شوند
- ✅ Frontend: صفحه محصولات بر اساس `score` مرتب می‌شود
- ✅ TypeScript Interfaces: فیلد `score` اضافه شده
- ✅ مرتب‌سازی پیش‌فرض: به `score` تغییر کرده

---

## 🔴 گام حیاتی: اجرای SQL Script

**برای اینکه محصولات بر اساس امتیاز نمایش داده شوند، باید ستون `score` را در دیتابیس اضافه کنید.**

### مراحل:

#### گام ۱: ورود به Supabase Dashboard
1. به https://supabase.com وارد شوید
2. پروژه خود را انتخاب کنید
3. از منوی سمت چپ، **SQL Editor** را انتخاب کنید

#### گام ۲: اجرای SQL Script
فایل `/SETUP_SCORE_COLUMN.sql` را باز کنید و کل محتوای آن را در SQL Editor کپی کنید، سپس **RUN** کنید.

**یا اگر می‌خواهید سریع انجام دهید، فقط این query را اجرا کنید:**

```sql
-- اضافه کردن ستون score
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS score INTEGER DEFAULT NULL;

-- اضافه کردن comment
COMMENT ON COLUMN products.score IS 'امتیاز محصول برای مرتب‌سازی (۱-۱۰۰)';

-- ایجاد Index
CREATE INDEX IF NOT EXISTS idx_products_score 
ON products(score DESC NULLS LAST);

CREATE INDEX IF NOT EXISTS idx_products_score_created 
ON products(score DESC NULLS LAST, created_at DESC);
```

#### گام ۳: مقدار‌دهی محصولات
حالا باید به محصولات امتیاز بدهید. روش‌های مختلف:

##### روش ۱: امتیازدهی دستی به محصولات خاص
```sql
-- محصولات برتر (۹۰-۱۰۰)
UPDATE products SET score = 95 WHERE id IN (1, 2, 3);

-- محصولات محبوب (۷۰-۸۹)
UPDATE products SET score = 80 WHERE id IN (4, 5, 6);

-- محصولات معمولی (۵۰-۶۹)
UPDATE products SET score = 60 WHERE id IN (7, 8, 9);
```

##### روش ۲: امتیازدهی خودکار بر اساس تاریخ
```sql
-- محصولات ماه اخیر: امتیاز ۷۰
UPDATE products 
SET score = 70 
WHERE created_at > NOW() - INTERVAL '30 days' 
  AND score IS NULL;

-- محصولات ۱-۳ ماه اخیر: امتیاز ۵۰
UPDATE products 
SET score = 50 
WHERE created_at > NOW() - INTERVAL '90 days' 
  AND created_at <= NOW() - INTERVAL '30 days'
  AND score IS NULL;

-- محصولات قدیمی‌تر: امتیاز ۳۰
UPDATE products 
SET score = 30 
WHERE created_at <= NOW() - INTERVAL '90 days'
  AND score IS NULL;
```

##### روش ۳: امتیازدهی به همه محصولات (اختیاری)
```sql
-- همه محصولات بدون score امتیاز ۵۰ بگیرند
UPDATE products 
SET score = 50 
WHERE score IS NULL;
```

#### گام ۴: بررسی نتیجه
```sql
SELECT 
  id,
  product_name,
  slug,
  score,
  created_at,
  CASE 
    WHEN score >= 90 THEN '⭐⭐⭐⭐⭐ عالی'
    WHEN score >= 70 THEN '⭐⭐⭐⭐ خوب'
    WHEN score >= 50 THEN '⭐⭐⭐ متوسط'
    WHEN score >= 30 THEN '⭐⭐ ضعیف'
    WHEN score IS NULL THEN '❓ بدون امتیاز'
    ELSE '⭐ خیلی ضعیف'
  END as rating
FROM products
ORDER BY score DESC NULLS LAST, created_at DESC
LIMIT 20;
```

---

## 🎯 نحوه کار سیستم

### صفحه اصلی (HomePage)
- محصولات ویژه از endpoint `/products/featured` می‌آیند
- Backend آن‌ها را بر اساس `score` مرتب می‌کند
- ۸ محصول با بالاترین امتیاز نمایش داده می‌شوند

### صفحه محصولات (ProductListPage)
- تمام محصولات از App.tsx می‌آیند (که از backend آمده‌اند)
- Frontend آن‌ها را بر اساس `score` مرتب می‌کند
- مرتب‌سازی پیش‌فرض: **امتیاز (بالا به پایین)**
- محصولات بدون امتیاز در آخر لیست

### صفحات دسته‌بندی
- همان ProductListPage است
- فیلتر category اعمال می‌شود
- مرتب‌سازی همچنان بر اساس `score`

---

## 📊 منطق مرتب‌سازی

```javascript
محصولات مرتب می‌شوند بر اساس:
1. امتیاز (score) از بالا به پایین
2. اگر امتیاز یکسان بود → جدیدترین اول
3. محصولات بدون امتیاز → در آخر لیست
```

**مثال:**
```
محصول A: score = 95  → رتبه ۱
محصول B: score = 90  → رتبه ۲
محصول C: score = 90, created_at جدیدتر → رتبه ۳
محصول D: score = 80  → رتبه ۴
محصول E: score = NULL → رتبه آخر
```

---

## ✅ چک‌لیست نهایی

قبل از تست، اطمینان حاصل کنید:

- [ ] SQL script اجرا شده است
- [ ] ستون `score` در جدول `products` وجود دارد
- [ ] Index ها ایجاد شده‌اند
- [ ] حداقل چند محصول امتیاز دارند
- [ ] سرور Supabase Edge Function deploy شده است
- [ ] Cache مرورگر پاک شده است (Ctrl + Shift + Delete)

---

## 🧪 تست کردن

### تست ۱: بررسی دیتابیس
```sql
-- بررسی ستون score
SELECT column_name, data_type, is_nullable
FROM information_schema.columns 
WHERE table_name = 'products' AND column_name = 'score';

-- نمایش محصولات بر اساس score
SELECT product_name, score, created_at
FROM products
ORDER BY score DESC NULLS LAST
LIMIT 10;
```

### تست ۲: بررسی Backend
باز کردن در مرورگر:
```
https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-fbc72c25/products/featured
```

باید محصولات بر اساس score مرتب باشند (بالاترین اول).

### تست ۳: بررسی Frontend

#### A. صفحه اصلی
1. باز کردن `https://YOUR_DOMAIN/`
2. بخش "محصولات ویژه" را بررسی کنید
3. محصولات با امتیاز بالاتر باید اول باشند

#### B. صفحه محصولات
1. باز کردن `https://YOUR_DOMAIN/products`
2. محصولات باید به ترتیب امتیاز نمایش داده شوند
3. کشویی "مرتب‌سازی" را باز کنید
4. "پیش‌فرض" باید انتخاب شده باشد

#### C. صفحه دسته‌بندی
1. انتخاب یک دسته‌بندی
2. محصولات همان دسته به ترتیب امتیاز نمایش داده شوند

---

## 🔄 مدیریت امتیاز محصولات

### از Supabase Dashboard:
1. Table Editor > products
2. یک محصول را پیدا کنید
3. ستون `score` را ویرایش کنید
4. مقدار ۱ تا ۱۰۰ وارد کنید
5. Save

### از SQL:
```sql
-- تنظیم امتیاز یک محصول
UPDATE products 
SET score = 95 
WHERE id = YOUR_PRODUCT_ID;

-- تنظیم امتیاز چند محصول
UPDATE products 
SET score = 80 
WHERE product_name LIKE '%کلمه کلیدی%';
```

---

## 💡 پیشنهادات امتیازدهی

| دسته محصول | امتیاز پیشنهادی | توضیحات |
|-----------|-----------------|---------|
| محصولات جدید VIP | 95-100 | محصولات استراتژیک و پرفروش |
| محصولات محبوب | 80-94 | محصولاتی که فروش خوبی دارند |
| محصولات معمولی | 50-79 | محصولات استاندارد |
| محصولات کم‌فروش | 20-49 | محصولاتی که نیاز به تبلیغ دارند |
| محصولات قدیمی | 1-19 | محصولاتی که می‌خواهید تخفیف بدهید |
| محصولات جدید | NULL | تا زمانی که امتیاز ندهید |

---

## ❓ سوالات متداول

### Q: چرا محصولات همچنان به ترتیب تاریخ نمایش داده می‌شوند؟
**A:** احتمالاً ستون score اضافه نشده یا محصولات امتیاز ندارند. SQL script را اجرا کنید.

### Q: چطور می‌توانم محصول خاصی را همیشه اول نمایش بدهم؟
**A:** بالاترین امتیاز (۱۰۰) را به آن بدهید.

### Q: آیا محصولات بدون امتیاز نمایش داده می‌شوند؟
**A:** بله، اما در انتهای لیست.

### Q: آیا می‌توانم امتیازدهی را خودکار کنم؟
**A:** بله، از Trigger ها و Function های SQL استفاده کنید. راهنما در `/SQL_OPTIMIZATION_FOR_SCORE.sql`.

### Q: چرا سرعت سایت کند شده؟
**A:** Index ها را ایجاد کنید (در SQL script وجود دارد).

---

## 📞 پشتیبانی و عیب‌یابی

### اگر مشکلی پیش آمد:

1. **Console مرورگر را چک کنید** (F12)
   - آیا خطایی وجود دارد؟
   - آیا محصولات fetch می‌شوند؟

2. **لاگ‌های Supabase را بررسی کنید**
   - Dashboard > Edge Functions > Logs
   - به دنبال پیام‌های "⚠️ Score column not found" بگردید

3. **دیتابیس را بررسی کنید**
   ```sql
   SELECT * FROM products LIMIT 1;
   -- آیا ستون score وجود دارد؟
   ```

4. **Cache را پاک کنید**
   - Ctrl + Shift + Delete
   - Hard Reload: Ctrl + F5

---

## 📚 فایل‌های مرتبط

| فایل | توضیحات |
|------|---------|
| `/SETUP_SCORE_COLUMN.sql` | SQL برای اضافه کردن ستون و Index |
| `/SQL_OPTIMIZATION_FOR_SCORE.sql` | SQL های پیشرفته برای بهینه‌سازی |
| `/SCORE_FIELD_IMPLEMENTATION_REPORT.md` | گزارش کامل تغییرات |
| `/ERROR_FIX_SUMMARY.md` | راهنمای رفع خطاها |
| `/SCORE_QUICK_REFERENCE.md` | راهنمای سریع |

---

## ✅ خلاصه

**۳ گام برای راه‌اندازی:**

1. **اجرای SQL Script** → اضافه کردن ستون score
2. **امتیازدهی محصولات** → تنظیم score برای محصولات
3. **تست و بررسی** → مشاهده نتیجه در سایت

**بعد از این مراحل، محصولات به ترتیب امتیاز نمایش داده می‌شوند! 🎉**

---

**تاریخ:** ۱۴۰۳/۱۰/۰۷  
**وضعیت:** ✅ آماده استفاده  
**نسخه:** 2.0.0
