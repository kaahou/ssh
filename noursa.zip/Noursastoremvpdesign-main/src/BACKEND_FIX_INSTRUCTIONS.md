# Backend File Cleanup Instructions

## Problem
The file `/supabase/functions/server/index.tsx` has orphan/duplicate code from approximately line 1094 to line 1226.

## Root Cause
Lines 1094-1226 contain duplicate route handlers that already exist earlier in the file:
- Duplicate "Get all categories" route (original at line 1001, duplicate at line 1134)
- Duplicate "Get all articles" route (original at line 1024, duplicate at line 1157)
- Duplicate "Create new article" route (original at line 1047, duplicate at line 1180)

Additionally, there's orphan code starting at line 1094 that's not inside any function.

## Solution
Delete lines 1094-1226 completely. The code should go directly from line 1093 to line 1227.

### Before (Lines 1091-1094):
```
  }
});

 // Get all categoriesمشاوره شما در نورسا با موفقیت ثبت شد...
```

### After (Lines 1091-1093 directly to 1227):
```
  }
});

// Get single article by slug
api.get("/articles/:slug", async (c) => {
```

## Manual Fix Required
Due to Persian characters and string interpolation in the corrupted section, automated tools are having difficulty. 

Please manually:
1. Open `/supabase/functions/server/index.tsx`
2. Delete lines 1094-1226 (inclusive)
3. Save the file

The file should compile without syntax errors after this change.
