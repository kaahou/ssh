# 🚨 گزارش مشکلات بحرانی و قابل بهبود

> تحلیل عمیق مشکلات، خطاها و نقاط ضعف پروژه **بدون تغییر در کارکرد**

**تاریخ بررسی**: دسامبر 2025  
**وضعیت**: بررسی کامل کد

---

## 📊 خلاصه اجرایی

### شدت مشکلات

| سطح | تعداد | اولویت رفع |
|-----|-------|------------|
| 🔴 بحرانی | 8 | فوری (این هفته) |
| 🟡 مهم | 12 | کوتاه‌مدت (این ماه) |
| 🟢 جزئی | 15 | بلندمدت (آینده) |

### تاثیر بر Performance

- ⚠️ **150+ console.log** در production → کاهش 5-10KB bundle
- ⚠️ **Memory Leaks احتمالی** در 5 مورد → مصرف RAM بالا
- ⚠️ **عدم cleanup** در setTimeout/setInterval → CPU waste
- ⚠️ **Re-renders غیرضروری** → تجربه کاربری ضعیف

---

## 🔴 مشکلات بحرانی (Critical Issues)

### 1. Memory Leaks در setTimeout/setInterval ❗

**شدت**: 🔴 CRITICAL  
**تاثیر**: Memory Leak + Performance Degradation

#### مکان‌های مشکل‌دار:

**فایل: `/components/pages/LoginPage.tsx` (خط 37)**
```tsx
// ❌ مشکل: interval cleanup نادرست
useEffect(() => {
  let interval: any;
  if (otpSent && timer > 0) {
    interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);
  }
  return () => clearInterval(interval); // ⚠️ فقط اگر interval set شده باشد
}, [otpSent, timer]);
```

**مشکل**: اگر `timer <= 0` یا `!otpSent` باشد، interval set نمی‌شود اما cleanup اجرا می‌شود و `clearInterval(undefined)` صدا زده می‌شود.

**راه‌حل**:
```tsx
// ✅ درست
useEffect(() => {
  if (otpSent && timer > 0) {
    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);
    
    return () => clearInterval(interval);
  }
  // اگر شرط false بود، هیچ cleanup نداریم
}, [otpSent, timer]);
```

---

**فایل: `/components/admin/AdminLayout.tsx` (خط 82)**
```tsx
// ❌ مشکل: unmount نشدن interval
useEffect(() => {
  if (ADMIN_PHONES.includes(user?.phone)) {
    fetchUnreadCount();
    const interval = setInterval(fetchUnreadCount, 30000);
    return () => clearInterval(interval);
  }
}, [user]); // ⚠️ fetchUnreadCount در dependencies نیست
```

**مشکل**: 
1. `fetchUnreadCount` در dependencies نیست → stale closure
2. هر تغییر `user` یک interval جدید می‌سازد بدون clear کردن قبلی

**راه‌حل**:
```tsx
// ✅ درست
useEffect(() => {
  if (!user?.phone || !ADMIN_PHONES.includes(user.phone)) {
    return;
  }
  
  fetchUnreadCount(); // اولین بار
  const interval = setInterval(fetchUnreadCount, 30000);
  
  return () => clearInterval(interval);
}, [user?.phone]); // فقط phone را track کن
```

---

### 2. عدم Abort کردن Fetch Requests در Unmount ❗

**شدت**: 🔴 CRITICAL  
**تاثیر**: Memory Leak + Warning در Console + Network Waste

**مکان‌های مشکل‌دار**: تقریباً همه صفحات!

**مثال: `/components/pages/HomePage.tsx`**
```tsx
// ❌ مشکل: اگر کامپوننت unmount شود، fetch ادامه می‌دهد
useEffect(() => {
  const fetchCategories = async () => {
    const response = await fetch(apiUrl);
    const data = await response.json();
    setCategories(data.categories); // ⚠️ setState روی unmounted component
  };
  fetchCategories();
}, []);
```

**راه‌حل**:
```tsx
// ✅ درست
useEffect(() => {
  const controller = new AbortController();
  
  const fetchCategories = async () => {
    try {
      const response = await fetch(apiUrl, {
        signal: controller.signal
      });
      const data = await response.json();
      setCategories(data.categories);
    } catch (error) {
      if (error.name === 'AbortError') {
        // Fetch was cancelled, این طبیعی است
        return;
      }
      console.error('Error fetching categories:', error);
    }
  };
  
  fetchCategories();
  
  return () => controller.abort();
}, []);
```

**فایل‌های نیازمند رفع**:
- `/components/pages/HomePage.tsx`
- `/components/pages/ProductListPage.tsx`
- `/components/pages/BlogListPage.tsx`
- `/components/pages/MyOrders.tsx`
- `/components/pages/MyConsultations.tsx`
- `/components/pages/ConsultationDetail.tsx`
- و حدود 15 فایل دیگر!

---

### 3. 150+ console.log در Production Code ❗

**شدت**: 🔴 HIGH  
**تاثیر**: 
- افزایش 5-10KB bundle size
- کاهش performance
- افشای اطلاعات حساس

**آمار**:
- `console.log`: ~120 مورد
- `console.error`: ~30 مورد
- `console.warn`: ~5 مورد

**نمونه‌های خطرناک**:

```tsx
// /components/pages/ConsultationDetail.tsx:66
console.log('📞 Fetching consultation with ID:', id, 'for phone:', savedPhone);
// ⚠️ افشای شماره تلفن کاربر

// /components/ConsultationWizard.tsx:193
console.log("🔐 کد تایید برای تست:", result.debug.otpCode);
// ⚠️ افشای OTP code

// /App.tsx:235
console.log('🔍 Fetching full product details for ID:', productId);
// ⚠️ حجم زیاد لاگ
```

**راه‌حل**: استفاده از Logger Utility

```typescript
// utils/logger.ts
const isDev = import.meta.env.DEV;

export const logger = {
  log: (...args: any[]) => {
    if (isDev) console.log(...args);
  },
  error: (...args: any[]) => {
    if (isDev) console.error(...args);
    // در production، می‌تونید به سرویس error tracking بفرستید
  },
  warn: (...args: any[]) => {
    if (isDev) console.warn(...args);
  },
  // برای دیباگ حساس (فقط در development)
  sensitive: (...args: any[]) => {
    if (isDev) console.log('🔒 [SENSITIVE]', ...args);
  }
};

// استفاده
logger.log('Fetching products...');
logger.sensitive('User phone:', phone); // فقط در dev نمایش داده می‌شود
```

---

### 4. Stale Closure Problem در useEffect ❗

**شدت**: 🔴 HIGH  
**تاثیر**: Bugs + Unpredictable Behavior

**مکان: `/components/admin/AdminLayout.tsx`**
```tsx
// ❌ مشکل
const fetchUnreadCount = async () => {
  // استفاده از user کهممکن است قدیمی باشد
  const response = await fetch(`...`, {
    headers: { 'X-User-Phone': user.phone }
  });
};

useEffect(() => {
  if (ADMIN_PHONES.includes(user?.phone)) {
    fetchUnreadCount();
    const interval = setInterval(fetchUnreadCount, 30000);
    return () => clearInterval(interval);
  }
}, [user]); // ⚠️ fetchUnreadCount در deps نیست
```

**مشکل**: `fetchUnreadCount` به `user` اشاره دارد که در زمان تعریف تابع مقداردهی شده. اگر `user` تغییر کند، تابع داخل setInterval همچنان user قدیمی را می‌بیند.

**راه‌حل**:
```tsx
// ✅ درست
useEffect(() => {
  if (!user?.phone || !ADMIN_PHONES.includes(user.phone)) {
    return;
  }
  
  const fetchUnreadCount = async () => {
    try {
      const response = await fetch(`...`, {
        headers: { 'X-User-Phone': user.phone }
      });
      // ...
    } catch (error) {
      console.error('Error fetching unread count:', error);
    }
  };
  
  fetchUnreadCount();
  const interval = setInterval(fetchUnreadCount, 30000);
  
  return () => clearInterval(interval);
}, [user?.phone]); // فقط phone را track کنید
```

---

### 5. Race Condition در Navigation ❗

**شدت**: 🔴 MEDIUM-HIGH  
**تاثیر**: Unexpected Redirects

**مکان: `/App.tsx` - LegacyCategoryRedirect**
```tsx
// ❌ مشکل
const LegacyCategoryRedirect = () => {
  const { oldSlug } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const newSlug = oldSlug ? legacySlugMap[oldSlug] : null;
    if (newSlug) {
      navigate(`/category/${newSlug}`, { replace: true });
    } else {
      navigate("/products", { replace: true });
    }
  }, [oldSlug, navigate]); // ⚠️ navigate در deps
  
  return <LoadingSpinner />;
};
```

**مشکل**: 
1. `navigate` تابعی stable است و نباید در dependencies باشد
2. اگر component چند بار render شود، navigate چند بار صدا زده می‌شود

**راه‌حل**:
```tsx
// ✅ درست
useEffect(() => {
  const newSlug = oldSlug ? legacySlugMap[oldSlug] : null;
  if (newSlug) {
    navigate(`/category/${newSlug}`, { replace: true });
  } else {
    navigate("/products", { replace: true });
  }
}, [oldSlug]); // فقط oldSlug
```

---

### 6. Type Safety Issues با `as any` ❗

**شدت**: 🟡 MEDIUM  
**تاثیر**: Loss of Type Safety

**موارد یافت شده**:
- `/components/pages/DBStatusPage.tsx:9` - `useState<any>(null)`
- `/components/admin/DebugSchema.tsx:5` - `useState<any>(null)`
- `/components/admin/pages/AdminConsultationDetail.tsx:390` - `(consultation as any)[key]`

**مشکل**: از بین رفتن type safety TypeScript

**راه‌حل**: تعریف Interface مناسب

```typescript
// ❌ قبل
const [status, setStatus] = useState<any>(null);

// ✅ بعد
interface DBStatus {
  connected: boolean;
  message: string;
  timestamp: string;
}

const [status, setStatus] = useState<DBStatus | null>(null);
```

---

### 7. عدم Error Boundary در Root ❗

**شدت**: 🟡 MEDIUM  
**تاثیر**: Crash کل اپلیکیشن با یک خطای کوچک

**وضعیت فعلی**: ErrorBoundary وجود دارد اما ممکن است به درستی wrap نشده باشد.

**بررسی لازم در `/App.tsx`**:
```tsx
// اطمینان حاصل کنید که ErrorBoundary تمام Routes را wrap می‌کند
<ErrorBoundary>
  <BrowserRouter>
    <UserProvider>
      <CartProvider>
        <Routes>
          {/* ... */}
        </Routes>
      </CartProvider>
    </UserProvider>
  </BrowserRouter>
</ErrorBoundary>
```

---

### 8. Timeout بدون Clear در AbortController ❗

**شدت**: 🟡 MEDIUM  
**تاثیر**: Memory Leak

**مکان: `/components/admin/orders/OrderDetailsModal.tsx:80`**
```tsx
// ❌ مشکل
const controller = new AbortController();
const timeoutId = setTimeout(() => controller.abort(), 30000);

const response = await fetch(url, { signal: controller.signal });
// ⚠️ اگر fetch زودتر complete شود، timeout clear نمی‌شود
```

**راه‌حل**:
```tsx
// ✅ درست
const controller = new AbortController();
const timeoutId = setTimeout(() => controller.abort(), 30000);

try {
  const response = await fetch(url, { signal: controller.signal });
  clearTimeout(timeoutId); // ✅ clear کردن timeout
  // ...
} catch (error) {
  clearTimeout(timeoutId); // ✅ clear در catch هم
  throw error;
}
```

---

## 🟡 مشکلات مهم (Important Issues)

### 9. عدم استفاده از useCallback در Event Handlers

**شدت**: 🟡 MEDIUM  
**تاثیر**: Re-renders غیرضروری

**مکان‌ها**:
- `/components/CartContext.tsx` - `addItem`, `removeItem`, `updateQuantity`
- `/components/pages/HomePage.tsx` - `handleAddToCart`

**مثال**:
```tsx
// ❌ قبل
const addItem = (product: Product) => {
  setItems(currentItems => {
    // ...
  });
};

// ✅ بعد
const addItem = useCallback((product: Product) => {
  setItems(currentItems => {
    // ...
  });
}, []); // empty deps چون از functional update استفاده می‌کنیم
```

---

### 10. عدم استفاده از React.memo برای کامپوننت‌های سنگین

**تاثیر**: Performance Issue در لیست‌های بزرگ

**کامپوننت‌های نیازمند**:
- `ProductCard.tsx`
- `CartItem.tsx`
- `OrderRow.tsx` در پنل ادمین
- `ArticleCard.tsx`

```tsx
// قبل
export function ProductCard({ product, onAddToCart }) {
  // ...
}

// بعد
export const ProductCard = React.memo(({ product, onAddToCart }) => {
  // ...
}, (prevProps, nextProps) => {
  // shallow comparison برای product
  return prevProps.product.product_id === nextProps.product.product_id &&
         prevProps.onAddToCart === nextProps.onAddToCart;
});
```

---

### 11. Duplicate Code - ADMIN_PHONES در 6 فایل

**مکان‌ها**:
- `/components/Header.tsx`
- `/components/admin/AdminLayout.tsx`
- `/components/admin/AdminTopBar.tsx`
- `/components/admin/ProtectedAdminRoute.tsx`
- `/supabase/functions/server/constants.ts`
- `/supabase/functions/server/middleware.ts`

**راه‌حل**: ایجاد یک فایل مشترک

```typescript
// src/constants/admin.ts
export const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
] as const;

export type AdminPhone = typeof ADMIN_PHONES[number];

export const isAdminPhone = (phone: string): phone is AdminPhone => {
  return ADMIN_PHONES.includes(phone as AdminPhone);
};
```

---

### 12. CartContext در LocalStorage بدون Validation

**مکان**: `/components/CartContext.tsx:25`

```tsx
// ❌ مشکل
const saved = localStorage.getItem('noursa-cart');
return saved ? JSON.parse(saved) : [];
```

**مشکل**: اگر localStorage corrupt شده باشد، JSON.parse exception می‌دهد.

**راه‌حل**:
```tsx
// ✅ بهتر
try {
  const saved = localStorage.getItem('noursa-cart');
  if (!saved) return [];
  
  const parsed = JSON.parse(saved);
  
  // Validation
  if (!Array.isArray(parsed)) {
    console.warn('Invalid cart data, resetting');
    localStorage.removeItem('noursa-cart');
    return [];
  }
  
  return parsed;
} catch (error) {
  console.error('Error loading cart:', error);
  localStorage.removeItem('noursa-cart');
  return [];
}
```

---

### 13. عدم Debounce در Search Input

**تاثیر**: درخواست‌های زیاد به API

اگر search box دارید، باید debounce شود:

```tsx
import { useMemo, useCallback } from 'react';

function debounce<T extends (...args: any[]) => void>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
}

// استفاده
const debouncedSearch = useMemo(
  () => debounce((query: string) => {
    // انجام search
  }, 300),
  []
);
```

---

### 14. Nested Ternary Operators - خوانایی پایین

**مثال در کد**:
```tsx
const productName = product.variant_name 
  ? `${product.product_name} - ${product.variant_name}`
  : product.product_name || product.name || 'محصول';
```

**بهتر است**:
```tsx
const getProductName = (product: Product): string => {
  if (product.variant_name) {
    return `${product.product_name} - ${product.variant_name}`;
  }
  return product.product_name || product.name || 'محصول';
};

const productName = getProductName(product);
```

---

### 15. Performance Monitor در Production

بررسی کنید که آیا performance monitoring در production فعال است یا خیر. باید controlled باشد.

---

## 🟢 مشکلات جزئی (Minor Issues)

### 16. Magic Numbers در کد

```tsx
// ❌ قبل
setTimeout(showPopup, 2000);
setInterval(fetchUnreadCount, 30000);

// ✅ بعد
const POPUP_DELAY_MS = 2 * 1000; // 2 seconds
const UNREAD_CHECK_INTERVAL_MS = 30 * 1000; // 30 seconds

setTimeout(showPopup, POPUP_DELAY_MS);
setInterval(fetchUnreadCount, UNREAD_CHECK_INTERVAL_MS);
```

---

### 17. تکرار کد Loading Spinner

Loading spinner در چند فایل تکرار شده. بهتر است یک component مشترک باشد:

```tsx
// components/LoadingSpinner.tsx
export function LoadingSpinner({ message = 'در حال بارگذاری...' }) {
  return (
    <div className="min-h-[50vh] flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-muted-foreground">{message}</p>
      </div>
    </div>
  );
}
```

---

### 18. useState Initial Value از Function

برای initial value های سنگین، از function استفاده کنید:

```tsx
// ❌ inefficient
const [items, setItems] = useState(loadFromLocalStorage());
// loadFromLocalStorage هر render اجرا می‌شود

// ✅ efficient
const [items, setItems] = useState(() => loadFromLocalStorage());
// فقط اولین render
```

---

### 19. Error Messages فارسی و انگلیسی مخلوط

سازگار کنید:
```tsx
// ❌
throw new Error('خطا در ارسال پیام. لطفاً دوباره تلاش کنید.');
throw new Error('Failed to fetch products');

// ✅ یا همه فارسی یا همه انگلیسی
```

---

### 20. عدم استفاده از `?.` در جاهایی که ممکن است

```tsx
// ❌ ممکن است null/undefined باشد
const userName = user.first_name;

// ✅
const userName = user?.first_name;
```

---

## 📝 چک‌لیست رفع فوری (این هفته)

### روز 1: Memory Leaks
- [ ] رفع setInterval در `LoginPage.tsx`
- [ ] رفع setInterval در `AdminLayout.tsx`
- [ ] اضافه کردن AbortController به fetch ها (حداقل 5 فایل مهم)

### روز 2: Console.log
- [ ] ساخت logger utility
- [ ] جایگزینی در فایل‌های اصلی (App, HomePage, CartContext)
- [ ] حذف لاگ‌های حساس (phone, OTP)

### روز 3: Type Safety
- [ ] تعریف interface برای DBStatus
- [ ] تعریف interface برای DebugSchema
- [ ] حذف `as any` ها

### روز 4-5: Performance
- [ ] افزودن useCallback به CartContext
- [ ] افزودن React.memo به ProductCard
- [ ] رفع stale closure در AdminLayout

---

## 🎯 اولویت‌بندی براساس تاثیر

| مشکل | تاثیر Performance | تاثیر Security | تاثیر UX | اولویت کلی |
|------|-------------------|----------------|----------|-------------|
| Memory Leaks | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | 🔴 فوری |
| console.log زیاد | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | 🔴 فوری |
| Fetch بدون Abort | ⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ | 🔴 فوری |
| Stale Closure | ⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ | 🟡 مهم |
| عدم useCallback | ⭐⭐⭐ | ⭐ | ⭐⭐⭐ | 🟡 مهم |
| عدم React.memo | ⭐⭐⭐ | ⭐ | ⭐⭐⭐ | 🟡 مهم |
| Duplicate ADMIN_PHONES | ⭐ | ⭐⭐ | ⭐ | 🟢 متوسط |

---

## 💡 نکات مهم برای رفع

### قبل از شروع:
1. ✅ Git branch جدید بسازید
2. ✅ یک commit از وضعیت فعلی بگیرید
3. ✅ لیست فایل‌های تغییر یافته را یادداشت کنید

### در حین رفع:
1. ✅ هر مشکل را در یک commit جداگانه رفع کنید
2. ✅ بعد از هر تغییر، سایت را تست کنید
3. ✅ commit message واضح بنویسید (مثلاً "Fix: Memory leak in LoginPage timer")

### بعد از رفع:
1. ✅ تست کامل تمام صفحات
2. ✅ بررسی console برای warnings
3. ✅ بررسی memory usage در Chrome DevTools
4. ✅ Lighthouse audit

---

## 📞 پشتیبانی

**یادآوری**: تمام تغییرات باید بدون تاثیر منفی روی کارکرد فعلی باشند. در صورت بروز مشکل، بلافاصله rollback کنید.

---

*آخرین به‌روزرسانی: دسامبر 2025*  
*نسخه: 1.0.0*
