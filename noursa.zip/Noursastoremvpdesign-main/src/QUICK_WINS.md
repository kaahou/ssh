# ⚡ Quick Wins - بهینه‌سازی‌های سریع و تاثیرگذار

> بهینه‌سازی‌هایی که با کمترین زمان، بیشترین تاثیر را دارند

---

## 🎯 اولویت 1: افزودن React.memo (15 دقیقه)

**تاثیر**: کاهش 50-70% re-renders غیرضروری

```tsx
// فایل: /components/ProductCard.tsx
import { memo } from 'react';

export const ProductCard = memo(({ product, onAddToCart }: ProductCardProps) => {
  // ... همان کد قبلی
}, (prevProps, nextProps) => {
  return prevProps.product.product_id === nextProps.product.product_id;
});
```

**فایل‌های نیازمند memo**:
- ✅ `/components/ProductCard.tsx`
- ✅ `/components/admin/OrderRow.tsx`
- ✅ `/components/ArticleCard.tsx`

---

## 🎯 اولویت 2: حذف console.log (10 دقیقه)

**تاثیر**: کاهش 5-10KB bundle size

**مرحله 1**: ایجاد logger utility
```typescript
// فایل: /src/utils/logger.ts
export const logger = {
  log: (...args: any[]) => import.meta.env.DEV && console.log(...args),
  error: (...args: any[]) => import.meta.env.DEV && console.error(...args),
  warn: (...args: any[]) => import.meta.env.DEV && console.warn(...args),
};
```

**مرحله 2**: جایگزینی در کل پروژه
```bash
# جستجو و جایگزینی با VS Code
# Find: console.log
# Replace: logger.log
```

---

## 🎯 اولویت 3: افزودن Compression (5 دقیقه)

**تاثیر**: کاهش 60-80% حجم API responses

```typescript
// فایل: /supabase/functions/server/index.tsx
import { compress } from 'npm:hono/compress';

const app = new Hono();
app.use('*', compress()); // ✅ فقط این خط را اضافه کنید

// ... بقیه کد
```

---

## 🎯 اولویت 4: افزودن Database Indexes (10 دقیقه)

**تاثیر**: کاهش 50-80% query time

**در Supabase SQL Editor اجرا کنید**:

```sql
-- محصولات
CREATE INDEX IF NOT EXISTS idx_products_category_score 
ON products(category_id, score DESC NULLS LAST);

-- سفارشات
CREATE INDEX IF NOT EXISTS idx_orders_status_created 
ON orders(status, created_at DESC);

-- مقالات
CREATE INDEX IF NOT EXISTS idx_articles_slug 
ON articles(slug);
```

---

## 🎯 اولویت 5: Code Splitting برای Admin Panel (20 دقیقه)

**تاثیر**: کاهش 40-50KB از initial bundle

```tsx
// فایل: /App.tsx
import { lazy, Suspense } from 'react';

// ✅ lazy load کردن پنل ادمین
const AdminDashboard = lazy(() => import('./components/admin/AdminDashboard'));
const AdminProducts = lazy(() => import('./components/admin/AdminProducts'));
const AdminOrders = lazy(() => import('./components/admin/AdminOrders'));

// در routes
<Route path="/admin" element={
  <Suspense fallback={<div className="p-8 text-center">در حال بارگذاری...</div>}>
    <AdminLayout />
  </Suspense>
}>
  <Route index element={<AdminDashboard />} />
  <Route path="products" element={<AdminProducts />} />
  <Route path="orders" element={<AdminOrders />} />
</Route>
```

---

## 🎯 اولویت 6: یکسان‌سازی ADMIN_PHONES (10 دقیقه)

**تاثیر**: کاهش 2-3KB + بهبود maintainability

**مرحله 1**: ایجاد فایل مشترک
```typescript
// فایل: /src/constants/admin.ts
export const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
] as const;

export const isAdminPhone = (phone: string): boolean => {
  return ADMIN_PHONES.includes(phone as any);
};
```

**مرحله 2**: استفاده در تمام فایل‌ها
```typescript
// حذف ADMIN_PHONES از این فایل‌ها و import کنید:
// /components/Header.tsx
// /components/admin/AdminLayout.tsx
// /components/admin/AdminTopBar.tsx
// /components/admin/ProtectedAdminRoute.tsx

import { ADMIN_PHONES, isAdminPhone } from '@/constants/admin';
```

---

## 🎯 اولویت 7: بهبود cachedFetch (15 دقیقه)

**تاثیر**: کاهش 70-90% درخواست‌های تکراری

```typescript
// فایل: /src/utils/cachedFetch.ts
const cache = new Map<string, { data: any; timestamp: number }>();

export async function cachedFetch<T>(
  url: string,
  options: RequestInit = {},
  ttl: number = 5 * 60 * 1000,
): Promise<T> {
  const cacheKey = `${url}:${JSON.stringify(options)}`;
  const cached = cache.get(cacheKey);
  
  // ✅ اضافه کنید: stale-while-revalidate
  if (cached && Date.now() - cached.timestamp < ttl) {
    // اگر نیمی از TTL گذشته، در پس‌زمینه refresh کن
    if (Date.now() - cached.timestamp > ttl / 2) {
      fetch(url, options)
        .then(r => r.json())
        .then(data => cache.set(cacheKey, { data, timestamp: Date.now() }))
        .catch(() => {}); // silent fail
    }
    return cached.data;
  }
  
  const response = await fetch(url, options);
  const data = await response.json();
  cache.set(cacheKey, { data, timestamp: Date.now() });
  return data;
}
```

---

## 🎯 اولویت 8: افزودن useCallback (20 دقیقه)

**تاثیر**: بهبود performance در لیست‌های بزرگ

```tsx
// در CartContext.tsx
const addItem = useCallback((product: Product) => {
  setItems(prev => {
    const existing = prev.find(item => item.product_id === product.product_id);
    if (existing) {
      return prev.map(item =>
        item.product_id === product.product_id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
    }
    return [...prev, { ...product, quantity: 1 }];
  });
}, []);

const removeItem = useCallback((productId: number) => {
  setItems(prev => prev.filter(item => item.product_id !== productId));
}, []);

const updateQuantity = useCallback((productId: number, quantity: number) => {
  if (quantity <= 0) {
    removeItem(productId);
    return;
  }
  setItems(prev =>
    prev.map(item =>
      item.product_id === productId ? { ...item, quantity } : item
    )
  );
}, [removeItem]);
```

---

## 🎯 اولویت 9: Lazy Loading تصاویر (5 دقیقه)

**تاثیر**: کاهش 40-60% initial page load

```tsx
// فایل: /components/ProductCard.tsx
<img
  src={product.image_urls[0]}
  alt={product.product_name}
  loading="lazy" // ✅ فقط این attribute را اضافه کنید
  decoding="async"
  className="..."
/>
```

**استثنا**: تصاویر hero و above-the-fold باید `loading="eager"` داشته باشند

---

## 🎯 اولویت 10: Rate Limiting برای OTP (15 دقیقه)

**تاثیر**: جلوگیری از سوء استفاده + کاهش هزینه SMS

```typescript
// فایل: /supabase/functions/server/rate_limiter.ts
const otpRequests = new Map<string, number[]>();

export function otpRateLimiter(c: Context, next: Next) {
  const phone = c.req.json().phone;
  const now = Date.now();
  const userRequests = otpRequests.get(phone) || [];
  
  // حذف درخواست‌های قدیمی‌تر از 1 ساعت
  const recentRequests = userRequests.filter(time => now - time < 60 * 60 * 1000);
  
  // محدودیت: 5 درخواست در ساعت
  if (recentRequests.length >= 5) {
    return c.json({ 
      error: 'تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً یک ساعت دیگر تلاش کنید.' 
    }, 429);
  }
  
  recentRequests.push(now);
  otpRequests.set(phone, recentRequests);
  
  return next();
}

// در auth_routes.ts
app.post('/send-otp', otpRateLimiter, async (c) => {
  // ...
});
```

---

## 📊 نتایج مورد انتظار

بعد از اعمال این 10 بهینه‌سازی:

| شاخص | قبل | بعد | بهبود |
|------|-----|-----|-------|
| Initial Bundle Size | ~180KB | ~110KB | 39% ⬇️ |
| First Contentful Paint | ~1.8s | ~1.1s | 39% ⬇️ |
| Time to Interactive | ~3.2s | ~2.0s | 38% ⬇️ |
| Re-renders (ProductsPage) | ~15 | ~4 | 73% ⬇️ |
| API Response Time | ~300ms | ~120ms | 60% ⬇️ |

**زمان کل**: 2-3 ساعت  
**تاثیر کل**: بهبود 35-45% در تمام شاخص‌های performance

---

## ✅ Checklist اجرایی

### روز 1 (1 ساعت)
- [ ] افزودن React.memo به ProductCard
- [ ] افزودن compression به backend
- [ ] افزودن database indexes
- [ ] افزودن lazy loading به تصاویر

### روز 2 (1 ساعت)
- [ ] ساخت logger utility و جایگزینی console.log
- [ ] بهبود cachedFetch با stale-while-revalidate
- [ ] یکسان‌سازی ADMIN_PHONES

### روز 3 (1 ساعت)
- [ ] Code splitting برای admin panel
- [ ] افزودن useCallback به CartContext
- [ ] افزودن rate limiting برای OTP

---

## 🚀 مرحله بعدی

بعد از اعمال این quick wins، به سراغ بهینه‌سازی‌های پیشرفته‌تر بروید:
- تقسیم CartContext به contexts کوچکتر
- پیاده‌سازی Service Worker
- بهینه‌سازی تصاویر با WebP
- افزودن Web Vitals monitoring

---

**نکته مهم**: قبل از هر تغییر، یک git commit بسازید تا در صورت مشکل بتوانید rollback کنید!
