# Fixed Import Versions

تمام versioned imports از فایل‌های UI components حذف شدند:

## Fixed Files:
- ✅ dialog.tsx
- ✅ sheet.tsx
- ✅ alert.tsx
- ✅ badge.tsx
- ✅ button.tsx
- ✅ navigation-menu.tsx
- ✅ sidebar.tsx
- ✅ toggle-group.tsx
- ✅ toggle.tsx
- ✅ accordion.tsx

## Remaining files to fix:
- alert-dialog.tsx
- aspect-ratio.tsx
- avatar.tsx
- breadcrumb.tsx
- collapsible.tsx  
- context-menu.tsx
- dropdown-menu.tsx
- form.tsx
- hover-card.tsx
- label.tsx
- menubar.tsx
- popover.tsx
- progress.tsx
- radio-group.tsx
- scroll-area.tsx
- separator.tsx
- slider.tsx
- switch.tsx
- calendar.tsx
- carousel.tsx
- command.tsx
- checkbox.tsx
- drawer.tsx
- input-otp.tsx
- pagination.tsx
- resizable.tsx
- select.tsx
- tabs.tsx
- tooltip.tsx

## Pattern to replace:
- `@radix-ui/[package]@[version]` → `@radix-ui/[package]`
- `lucide-react@[version]` → `lucide-react`
