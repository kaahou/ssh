# 📊 راهنمای کامل پیاده‌سازی SEO - Oil Global

## ✅ خلاصه پیاده‌سازی‌های انجام شده

### 1. **صفحه Sitemap کاربرپسند** (`/site-map`)
✅ نمایش تمام صفحات، دسته‌بندی‌ها و خدمات  
✅ بارگذاری دینامیک از دیتابیس  
✅ طراحی responsive و user-friendly  
✅ آمارهای سریع (Quick Stats)  
✅ متن SEO در پایین صفحه  

**دسترسی:** [https://nursaa.ir/site-map](https://nursaa.ir/site-map)

---

### 2. **XML Sitemap برای موتورهای جستجو** (`/sitemap.xml`)
✅ تولید خودکار با داده‌های دیتابیس  
✅ شامل تمام صفحات استاتیک  
✅ شامل دسته‌بندی‌ها، محصولات و مقالات  
✅ Priority و Changefreq برای هر صفحه  
✅ Cache 1 ساعته برای بهینه‌سازی سرعت  

**دسترسی:** [https://nursaa.ir/sitemap.xml](https://nursaa.ir/sitemap.xml)

#### نحوه ارسال به Google Search Console:
1. به [Google Search Console](https://search.google.com/search-console) بروید
2. دامنه `nursaa.ir` را اضافه کنید
3. از منوی سمت چپ **Sitemaps** را انتخاب کنید
4. URL زیر را وارد کنید: `https://nursaa.ir/sitemap.xml`
5. روی **Submit** کلیک کنید

---

### 3. **Google Tag Manager (GTM)**
✅ Container ID: `GTM-MWPHTW6B`  
✅ کامپوننت GoogleTagManager پیاده‌سازی شده  
✅ DataLayer برای ردیابی رویدادها  
✅ Noscript fallback  
✅ یکپارچگی با GA4 موجود  

**وضعیت:** آماده و فعال

---

### 4. **SEO Meta Tags و Structured Data**
✅ کامپوننت `SEOHead` برای مدیریت meta tags  
✅ Open Graph tags برای شبکه‌های اجتماعی  
✅ Twitter Card tags  
✅ Structured Data (JSON-LD) برای موتورهای جستجو  
✅ Canonical URLs  

---

### 5. **Robots.txt**
✅ فایل `/public/robots.txt` ایجاد شده  
✅ دسترسی موتورهای جستجو به صفحات مهم  
✅ مسدود کردن صفحات ادمین و پروفایل  
✅ مرجع sitemap.xml  

---

### 6. **URL Redirects برای SEO**
✅ ۳۰+ redirect از URL‌های قدیمی  
✅ Redirect 301 برای حفظ رتبه SEO  
✅ تمام URL‌های legacy به format جدید هدایت می‌شوند  

---

## 🚀 راهنمای گام به گام بهینه‌سازی SEO

### مرحله 1: Google Search Console

#### تنظیمات اولیه:
1. **افزودن دامنه**
   - به [Google Search Console](https://search.google.com/search-console) بروید
   - روی **Add Property** کلیک کنید
   - دامنه `nursaa.ir` را وارد کنید
   - مالکیت را تأیید کنید (از طریق TXT Record یا فایل HTML)

2. **ارسال Sitemap**
   ```
   URL: https://nursaa.ir/sitemap.xml
   ```

3. **بررسی Coverage**
   - **Coverage** → **Submitted URLs**
   - اطمینان از index شدن صفحات

#### مشکلات رایج و راه‌حل:
| مشکل | راه‌حل |
|------|--------|
| Submitted URL not indexed | صبر کنید (2-7 روز) یا از "Request Indexing" استفاده کنید |
| Crawled - currently not indexed | محتوای صفحه را بهبود دهید |
| Discovered - currently not indexed | Internal linking را افزایش دهید |

---

### مرحله 2: Google Tag Manager

#### راه‌اندازی تگ‌ها:

**1. GA4 Configuration Tag**
```javascript
// در GTM → Tags → New
Tag Type: Google Analytics: GA4 Configuration
Measurement ID: G-XXXXXXXXXX
Trigger: All Pages
```

**2. E-commerce Tracking**
```javascript
// Purchase Event
Tag Type: GA4 Event
Event Name: purchase
Configuration Tag: {{GA4 Configuration}}
Trigger: Custom Event - purchase
```

**3. Form Tracking**
```javascript
// Contact Form
Tag Type: GA4 Event
Event Name: generate_lead
Parameters:
  - form_name: contact_form
Trigger: Form Submission - contact-form
```

---

### مرحله 3: بهینه‌سازی محتوا

#### Checklist برای هر صفحه:

- [ ] **Title Tag**: 50-60 کاراکتر
- [ ] **Meta Description**: 150-160 کاراکتر
- [ ] **H1**: یک عنوان واضح و شامل کلمه کلیدی
- [ ] **H2-H6**: ساختار سلسله مراتبی
- [ ] **Alt Text**: برای تمام تصاویر
- [ ] **Internal Links**: حداقل 3-5 لینک داخلی
- [ ] **External Links**: لینک به منابع معتبر
- [ ] **Mobile Friendly**: تست در Mobile-Friendly Test
- [ ] **Page Speed**: سرعت بالای 80 در PageSpeed Insights

#### کلمات کلیدی پیشنهادی:

**Primary Keywords:**
- روغن طبیعی
- روغن مو
- روغن آرگان
- روغن نارگیل
- روغن درمانی

**Long-tail Keywords:**
- خرید روغن آرگان اصل
- روغن مو برای رشد سریع
- روغن نارگیل ارگانیک خالص
- روغن درمانی برای پوست
- اسانس گیاهی طبیعی

---

### مرحله 4: Structured Data

#### نمونه پیاده‌سازی برای صفحات مختلف:

**صفحه محصول:**
```typescript
import { SEOHead, createProductStructuredData } from '../SEOHead';

// در کامپوننت:
<SEOHead
  title={product.name}
  description={product.description}
  image={product.image}
  type="product"
  structuredData={createProductStructuredData(product)}
/>
```

**صفحه مقاله:**
```typescript
import { SEOHead, createArticleStructuredData } from '../SEOHead';

<SEOHead
  title={article.title}
  description={article.excerpt}
  image={article.featured_image}
  type="article"
  structuredData={createArticleStructuredData(article)}
/>
```

**صفحه دسته‌بندی:**
```typescript
import { SEOHead, createBreadcrumbStructuredData } from '../SEOHead';

<SEOHead
  title={`دسته‌بندی ${category.name}`}
  description={category.description}
  structuredData={createBreadcrumbStructuredData([
    { name: 'خانه', url: '/' },
    { name: 'محصولات', url: '/products' },
    { name: category.name, url: `/category/${category.slug}` }
  ])}
/>
```

---

### مرحله 5: Performance Optimization

#### Core Web Vitals:

| متریک | هدف | بهینه‌سازی |
|-------|-----|-----------|
| **LCP** (Largest Contentful Paint) | < 2.5s | ✅ تصاویر Lazy Load<br>✅ CDN<br>✅ Image Optimization |
| **FID** (First Input Delay) | < 100ms | ✅ کد JavaScript بهینه<br>✅ Event Handlers کم |
| **CLS** (Cumulative Layout Shift) | < 0.1 | ✅ Width/Height برای تصاویر<br>✅ Skeleton Loaders |

#### بهینه‌سازی‌های انجام شده:
- ✅ Lazy Loading برای تصاویر
- ✅ Code Splitting با React
- ✅ Caching برای API Calls
- ✅ Minification برای CSS/JS
- ✅ GZIP Compression

---

### مرحله 6: Schema Markup Testing

#### ابزارهای تست:

1. **Rich Results Test** (Google)
   ```
   https://search.google.com/test/rich-results
   ```
   - URL صفحه را وارد کنید
   - بررسی صحت Structured Data

2. **Schema Markup Validator**
   ```
   https://validator.schema.org/
   ```
   - کد JSON-LD را کپی کنید
   - خطاها را برطرف کنید

3. **Chrome Extension**
   - نصب "Structured Data Testing Tool"
   - بررسی لحظه‌ای صفحات

---

## 📈 KPIs و متریک‌های SEO

### Organic Search Traffic
- **هدف**: افزایش 20% ماهانه
- **ابزار**: Google Analytics 4
- **مسیر**: GA4 → Reports → Acquisition → Traffic Acquisition

### Keyword Rankings
- **ابزار**: Google Search Console
- **مسیر**: Performance → Search Results
- **متریک‌ها**:
  - Total Clicks
  - Total Impressions
  - Average CTR
  - Average Position

### Conversion Rate
- **هدف**: 2-5%
- **فرمول**: `(تعداد خرید / تعداد بازدید) × 100`
- **ردیابی**: از طریق GA4 E-commerce

### Backlinks
- **ابزار**: Google Search Console → Links
- **هدف**: افزایش تدریجی backlink های با کیفیت

---

## 🛠️ ابزارهای پیشنهادی

### رایگان:
- ✅ Google Search Console
- ✅ Google Analytics 4
- ✅ Google PageSpeed Insights
- ✅ Google Mobile-Friendly Test
- ✅ Bing Webmaster Tools

### پولی (اختیاری):
- Ahrefs (تحلیل رقبا)
- SEMrush (کلمات کلیدی)
- Screaming Frog (Crawling)
- Hotjar (Heatmaps)

---

## 🔧 Troubleshooting

### مشکل: صفحات Index نمی‌شوند

**راه‌حل:**
1. بررسی `robots.txt` - اطمینان از Allow
2. بررسی `meta robots` - نباید `noindex` باشد
3. بررسی `canonical` - صحیح باشد
4. درخواست Indexing از Search Console

### مشکل: سرعت پایین

**راه‌حل:**
1. فعال‌سازی Caching
2. بهینه‌سازی تصاویر (WebP format)
3. استفاده از CDN
4. Minify CSS/JS
5. حذف کدهای غیرضروری

### مشکل: Duplicate Content

**راه‌حل:**
1. استفاده از `canonical` tags
2. یکپارچه‌سازی URL‌ها (با/بدون trailing slash)
3. Redirect 301 برای URL‌های قدیمی

---

## 📝 Checklist نهایی SEO

### Technical SEO
- [x] XML Sitemap ارسال شده
- [x] Robots.txt تنظیم شده
- [x] HTTPS فعال
- [x] Mobile-Responsive
- [x] Page Speed > 80
- [ ] Structured Data تست شده
- [ ] Broken Links برطرف شده
- [ ] 404 Page سفارشی

### On-Page SEO
- [x] Title Tags بهینه
- [x] Meta Descriptions
- [x] Header Tags (H1-H6)
- [ ] Alt Text برای تصاویر
- [ ] Internal Linking
- [ ] Schema Markup

### Content SEO
- [ ] کلمات کلیدی Research شده
- [ ] محتوای unique و با کیفیت
- [ ] Blog منتشر می‌شود
- [ ] FAQ Section
- [ ] User Reviews

### Off-Page SEO
- [ ] Google My Business
- [ ] شبکه‌های اجتماعی فعال
- [ ] Backlink Building
- [ ] Guest Posting
- [ ] Local Citations

---

## 📊 گزارش‌دهی ماهانه

### Template گزارش:

```markdown
# گزارش SEO - [ماه]

## Highlights
- Organic Traffic: +X%
- New Keywords Ranking: X
- Top Performing Pages: [لیست]

## Google Search Console
- Total Clicks: X
- Total Impressions: X
- Average CTR: X%
- Average Position: X

## Google Analytics
- Sessions: X
- Users: X
- Bounce Rate: X%
- Avg Session Duration: X

## Actions این ماه
- [ ] بهینه‌سازی صفحات X
- [ ] انتشار X مقاله جدید
- [ ] دریافت X backlink

## برنامه ماه بعد
- [ ] ...
```

---

## 🎉 نتیجه‌گیری

پیاده‌سازی‌های SEO انجام شده در Oil Global شامل:

✅ **Sitemap کاربرپسند و XML**  
✅ **Google Tag Manager فعال**  
✅ **Meta Tags و Structured Data**  
✅ **Robots.txt بهینه**  
✅ **URL Redirects کامل**  
✅ **Performance بهینه‌سازی شده**  

### قدم‌های بعدی:
1. ارسال sitemap به Google Search Console
2. تکمیل راه‌اندازی GTM Tags
3. تست Structured Data
4. شروع Content Marketing
5. بررسی و بهینه‌سازی ماهانه

**موفق باشید! 🚀**

---

## 📞 منابع و پشتیبانی

- [Google Search Central](https://developers.google.com/search)
- [Schema.org](https://schema.org/)
- [Web.dev](https://web.dev/)
- [GTM Documentation](https://developers.google.com/tag-platform/tag-manager)

**تاریخ به‌روزرسانی:** دسامبر 2025