# 📋 راهنمای مدیریت پاپ‌آپ خوش‌آمدگویی

این راهنما به شما کمک می‌کند بدون نیاز به Figma Make، پاپ‌آپ خوش‌آمدگویی سایت را مدیریت کنید.

---

## 📍 محل فایل پاپ‌آپ

فایل پاپ‌آپ در مسیر زیر قرار دارد:
```
/components/WelcomePopup.tsx
```

---

## 🎯 غیرفعال کردن کامل پاپ‌آپ

### روش ۱: غیرفعال کردن موقت (توصیه می‌شود)

فایل `/App.tsx` را باز کنید و خط ۷۶۱ را پیدا کنید:

```tsx
<WelcomePopup />
```

این خط را با افزودن `{/* ... */}` کامنت کنید:

```tsx
{/* <WelcomePopup /> */}
```

### روش ۲: غیرفعال کردن دائمی

فایل `/components/WelcomePopup.tsx` را باز کنید و در خط ۱۱۰ تغییر دهید:

**قبل از تغییر:**
```tsx
if (!isOpen) return null;
```

**بعد از تغییر:**
```tsx
return null; // پاپ‌آپ غیرفعال است
```

---

## ⏰ تغییر زمان نمایش پاپ‌آپ

فایل `/components/WelcomePopup.tsx` را باز کنید و خط ۴۸ و ۵۰ را پیدا کنید:

**زمان فعلی: ۲ ثانیه (۲۰۰۰ میلی‌ثانیه)**

```tsx
(window as any).requestIdleCallback(showPopup, { timeout: 2000 });
```

و

```tsx
setTimeout(showPopup, 2000);
```

**برای تغییر زمان نمایش:**
- برای ۳ ثانیه: عدد `2000` را به `3000` تغییر دهید
- برای ۵ ثانیه: عدد `2000` را به `5000` تغییر دهید
- برای ۱۰ ثانیه: عدد `2000` را به `10000` تغییر دهید

**مثال (۵ ثانیه):**
```tsx
(window as any).requestIdleCallback(showPopup, { timeout: 5000 });
```

و

```tsx
setTimeout(showPopup, 5000);
```

---

## 📱 تغییر صفحاتی که پاپ‌آپ در آن‌ها نمایش داده می‌شود

فایل `/components/WelcomePopup.tsx` را باز کنید و خطوط ۱۸ تا ۲۷ را پیدا کنید:

**تنظیمات فعلی:**
```tsx
const currentPath = location.pathname;
const isAllowedPage = 
  currentPath === '/products' ||
  currentPath.startsWith('/product/') || 
  currentPath.startsWith('/category/');

if (!isAllowedPage) {
  return; // فقط در صفحات محصولات نمایش بده
}
```

### گزینه‌های مختلف:

#### 1️⃣ نمایش فقط در صفحه اصلی:
```tsx
const isAllowedPage = currentPath === '/';
```

#### 2️⃣ نمایش در همه صفحات:
```tsx
const isAllowedPage = true;
```

#### 3️⃣ نمایش در صفحه اصلی و محصولات:
```tsx
const isAllowedPage = 
  currentPath === '/' ||
  currentPath === '/products' ||
  currentPath.startsWith('/product/');
```

#### 4️⃣ نمایش در صفحه اصلی، محصولات و وبلاگ:
```tsx
const isAllowedPage = 
  currentPath === '/' ||
  currentPath === '/products' ||
  currentPath.startsWith('/product/') ||
  currentPath === '/blog' ||
  currentPath.startsWith('/blog/');
```

---

## ✏️ تغییر محتوای متنی پاپ‌آپ

فایل `/components/WelcomePopup.tsx` را باز کنید:

### 1. تغییر عنوان اصلی (خط ۱۳۴):
```tsx
<h2 className="text-[#1A2011] flex items-center justify-center gap-2">
  <span className="text-3xl">👋</span>
  سلام به دوستان خوبمون
</h2>
```

**مثال تغییر:**
```tsx
<h2 className="text-[#1A2011] flex items-center justify-center gap-2">
  <span className="text-3xl">🎉</span>
  به nursaa خوش آمدید
</h2>
```

### 2. تغییر متن پیام اصلی (خطوط ۱۴۲-۱۵۰):
```tsx
<p className="text-[#484D2C] leading-relaxed">
  اگر این روزها یه کم شلوغی، کندی یا ضعف توی جابه‌جایی‌ها می‌بینید،
  صمیمانه بابتش عذر می‌خوایم{' '}
  <span className="text-xl">🙏</span>
</p>
<p className="text-[#484D2C] leading-relaxed">
  در حال اسباب‌کشی به خونه جدیدمون هستیم و قول می‌دیم خیلی زود جمع‌وجورش کنیم{' '}
  <span className="text-xl">💪</span>
</p>
```

**این بخش را با متن دلخواه خود جایگزین کنید.**

### 3. تغییر بخش "نظرت خیلی مهمه" (خطوط ۱۵۷-۱۸۶):

**عنوان:**
```tsx
<h3 className="text-[#1A2011]\">نظرت خیلی مهمه</h3>
```

**متن:**
```tsx
<p className="text-[#484D2C] leading-relaxed text-center">
  هر جا از گشتن تو سایت تا خرید به مشکلی خوردی یا پیشنهادی داشتی،
  خیلی خوشحال می‌شیم تو پیام‌رسان محبوبت با ما به شماره{' '}
  <a 
    href=\"tel:09219675992\"
    className=\"font-bold text-[#1A2011] hover:text-[#16A34A] transition-colors\"
  >
    ۰۹۲۱۹۶۷۵۹۹۲
  </a>
  {' '}در ارتباط باشی{' '}
  <span className=\"text-xl\">💬</span>
</p>
```

**تغییر شماره تماس:**
- خط `href=\"tel:09219675992\"` را به شماره دلخواه تغییر دهید
- متن `۰۹۲۱۹۶۷۵۹۹۲` را نیز به شماره دلخواه تغییر دهید

### 4. تغییر بخش "اما خبر خوب!" (خطوط ۱۸۹-۲۰۳):

**عنوان:**
```tsx
<h3 className="text-[#1A2011]\">اما خبر خوب!</h3>
```

**متن:**
```tsx
<p className="text-[#065F46] leading-relaxed text-center">
  مشاوره هوشمند و صفحه پروفایل شخصی فعال شده{' '}
  <span className="text-xl">🎉</span>
</p>

<p className="text-[#484D2C] text-sm leading-relaxed text-center">
  حتی همین الان هم می‌تونی تغییراتش رو ببینی
</p>
```

**این بخش را با متن دلخواه خود جایگزین کنید.**

### 5. تغییر متن دکمه‌ها (خطوط ۲۰۶-۲۲۲):

**دکمه اول (مشاوره هوشمند):**
```tsx
<span>مشاوره هوشمند</span>
```

**دکمه دوم (ثبت‌نام):**
```tsx
<span>ثبت‌نام</span>
```

### 6. تغییر متن پایانی (خط ۲۲۵-۲۲۷):
```tsx
<p className="text-center text-xs text-[#888888] pt-2">
  این پیام فقط یکبار نمایش داده می‌شود
</p>
```

---

## 🔗 تغییر لینک دکمه‌ها

فایل `/components/WelcomePopup.tsx` را باز کنید:

### دکمه اول - "مشاوره هوشمند" (خطوط ۸۰-۹۰):

**لینک فعلی: `/consultation`**

```tsx
const handleConsultationClick = useCallback(() => {
  requestAnimationFrame(() => {
    trackEvent('welcome_popup_cta_click', {
      button_type: 'consultation',
      destination: '/consultation'
    });
  });
  setIsOpen(false);
  navigate('/consultation');
}, [navigate]);
```

**برای تغییر مقصد:**
- خط `navigate('/consultation');` را به مسیر دلخواه تغییر دهید
- مثال: `navigate('/products');`

### دکمه دوم - "ثبت‌نام" (خطوط ۹۲-۱۰۲):

**لینک فعلی: `/login`**

```tsx
const handleSignupClick = useCallback(() => {
  requestAnimationFrame(() => {
    trackEvent('welcome_popup_cta_click', {
      button_type: 'signup',
      destination: '/login'
    });
  });
  setIsOpen(false);
  navigate('/login');
}, [navigate]);
```

**برای تغییر مقصد:**
- خط `navigate('/login');` را به مسیر دلخواه تغییر دهید
- مثال: `navigate('/products');`

---

## 🎨 تغییر رنگ‌ها

فایل `/components/WelcomePopup.tsx` را باز کنید:

### رنگ‌های اصلی فعلی:
- **رنگ اصلی متن:** `#1A2011` (سبز تیره)
- **رنگ متن فرعی:** `#484D2C` (خاکستری سبز)
- **رنگ سبز:** `#16A34A`
- **رنگ پس‌زمینه بخش نظرت مهمه:** `from-[#F9E1B4]/30 to-[#F9E1B4]/10` (زرد طلایی)
- **رنگ پس‌زمینه بخش خبر خوب:** `from-[#D1FAE5] to-[#D1FAE5]/30` (سبز روشن)

### تغییر رنگ دکمه‌ها:

**دکمه اول (سبز):**
```tsx
className=\"w-full bg-gradient-to-l from-[#16A34A] to-[#065F46] hover:from-[#065F46] hover:to-[#16A34A] text-white py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-3 group\"
```

**مثال تغییر به آبی:**
```tsx
className=\"w-full bg-gradient-to-l from-[#3B82F6] to-[#1E40AF] hover:from-[#1E40AF] hover:to-[#3B82F6] text-white py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-3 group\"
```

---

## 🔄 بازنشانی پاپ‌آپ (نمایش مجدد)

پاپ‌آپ فقط یکبار به هر کاربر نمایش داده می‌شود و این اطلاعات در `localStorage` مرورگر ذخیره می‌شود.

### برای بازنشانی و نمایش مجدد پاپ‌آپ:

1. **کنسول مرورگر را باز کنید:**
   - در Chrome/Edge: `F12` یا `Ctrl+Shift+I`
   - در Firefox: `F12` یا `Ctrl+Shift+K`

2. **به تب Console بروید**

3. **کد زیر را وارد کنید و Enter بزنید:**
   ```javascript
   localStorage.removeItem('welcome_popup_shown');
   ```

4. **صفحه را رفرش کنید** (F5)

### برای بازنشانی برای همه کاربران:

فایل `/components/WelcomePopup.tsx` را باز کنید و خط ۱۳ را تغییر دهید:

**قبل:**
```tsx
const hasSeenPopup = localStorage.getItem('welcome_popup_shown');
```

**بعد (با تغییر نام کلید):**
```tsx
const hasSeenPopup = localStorage.getItem('welcome_popup_shown_v2');
```

و خط ۳۳ را نیز تغییر دهید:

**قبل:**
```tsx
localStorage.setItem('welcome_popup_shown', 'true');
```

**بعد:**
```tsx
localStorage.setItem('welcome_popup_shown_v2', 'true');
```

---

## 🎭 تغییر ایموجی‌ها

ایموجی‌های مختلف در پاپ‌آپ استفاده شده‌اند:

| مکان | ایموجی فعلی | خط |
|------|------------|-----|
| عنوان اصلی | 👋 | ۱۳۳ |
| پیام عذرخواهی | 🙏 | ۱۴۵ |
| پیام قول | 💪 | ۱۴۹ |
| بخش نظرت مهمه | 🗣️ | ۱۵۹ |
| پیام‌رسان | 💬 | ۱۷۳ |
| خبر خوب | 🎉 | ۱۹۷ |

**برای تغییر:** فقط کافیست ایموجی مورد نظر را جایگزین کنید.

**مثال:**
```tsx
<span className="text-3xl">👋</span>
```
را تغییر دهید به:
```tsx
<span className="text-3xl">🎉</span>
```

---

## 📐 تغییر اندازه و موقعیت پاپ‌آپ

فایل `/components/WelcomePopup.tsx` را باز کنید و خط ۱۱۷ را پیدا کنید:

**تنظیمات فعلی:**
```tsx
<div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto animate-in slide-in-from-bottom-5 duration-300">
```

### تغییر عرض پاپ‌آپ:
- **کوچک‌تر:** `max-w-md` (۴۴۸px)
- **متوسط:** `max-w-lg` (۵۱۲px)
- **فعلی:** `max-w-xl` (۵۷۶px)
- **بزرگ‌تر:** `max-w-2xl` (۶۷۲px)
- **خیلی بزرگ:** `max-w-3xl` (۷۶۸px)

### تغییر گوشه‌های پاپ‌آپ:
- **گرد کمتر:** `rounded-xl`
- **فعلی:** `rounded-3xl`
- **مربعی:** `rounded-none`

### تغییر سایه:
- **سایه کمتر:** `shadow-lg`
- **فعلی:** `shadow-2xl`
- **بدون سایه:** حذف `shadow-2xl`

---

## 🔒 نمایش چند بار پاپ‌آپ

**پیش‌فرض:** پاپ‌آپ فقط یکبار نمایش داده می‌شود.

### برای نمایش در هر بازدید:

فایل `/components/WelcomePopup.tsx` را باز کنید و خطوط ۱۲-۱۶ را کامنت کنید:

```tsx
// const hasSeenPopup = localStorage.getItem('welcome_popup_shown');
// if (hasSeenPopup) {
//   return; // اگر قبلاً دیده شده، دیگر نمایش نده
// }
```

و خطوط ۳۲-۳۳ را نیز کامنت کنید:

```tsx
// // ذخیره وضعیت نمایش در localStorage
// localStorage.setItem('welcome_popup_shown', 'true');
```

---

## 📊 Google Analytics Events

پاپ‌آپ سه event برای Google Analytics ارسال می‌کند:

1. **`welcome_popup_shown`** - زمان نمایش پاپ‌آپ
2. **`welcome_popup_closed`** - زمان بستن پاپ‌آپ
3. **`welcome_popup_cta_click`** - زمان کلیک روی دکمه‌ها

اگر می‌خواهید این eventها را غیرفعال کنید، خطوط زیر را کامنت کنید:

- خطوط ۳۶-۴۱ (نمایش پاپ‌آپ)
- خطوط ۷۳-۷۷ (بستن پاپ‌آپ)
- خطوط ۸۲-۸۷ (کلیک دکمه مشاوره)
- خطوط ۹۴-۹۹ (کلیک دکمه ثبت‌نام)

---

## ⚠️ نکات مهم

1. **همیشه قبل از تغییر، یک نسخه پشتیبان از فایل بگیرید**
2. **بعد از هر تغییر، صفحه را تست کنید**
3. **برای دیدن تغییرات، مرورگر را رفرش کنید (Ctrl+F5)**
4. **اگر خطایی رخ داد، فایل اصلی را از نسخه پشتیبان بازیابی کنید**
5. **تغییرات در مرورگرهای مختلف تست شوند**

---

## 🆘 پشتیبانی

اگر در انجام تغییرات به مشکل خوردید:

1. **فایل اصلی را از نسخه پشتیبان بازگردانید**
2. **کنسول مرورگر را چک کنید (F12 > Console) برای دیدن خطاها**
3. **مطمئن شوید که تمام براکت‌ها `{ }` و پرانتزها `( )` بسته شده‌اند**
4. **مطمئن شوید که تمام رشته‌های متنی داخل `" "` یا `' '` قرار دارند**

---

## 📋 چک‌لیست قبل از انتشار

- [ ] نسخه پشتیبان از فایل اصلی گرفته شده است
- [ ] تغییرات در محیط تست آزمایش شده است
- [ ] در مرورگرهای Chrome, Firefox, Safari تست شده است
- [ ] در موبایل و دسکتاپ تست شده است
- [ ] تمام لینک‌ها کار می‌کنند
- [ ] شماره تلفن صحیح است
- [ ] متن‌ها املا و دستوری درست هستند
- [ ] رنگ‌ها با برند سایت هماهنگ هستند

---

**تاریخ ایجاد سند:** ۱۴۰۳/۱۰/۰۷  
**آخرین بروزرسانی:** ۱۴۰۳/۱۰/۰۷  
**نسخه:** 1.0.0
