-- ====================================================================
-- SQL Commands for Score Field Optimization
-- فایل بهینه‌سازی برای فیلد Score در جدول Products
-- ====================================================================

-- ====================================================================
-- 1. ایجاد Index برای بهبود عملکرد مرتب‌سازی
-- ====================================================================

-- Index اصلی برای score (با در نظر گرفتن NULL values)
CREATE INDEX IF NOT EXISTS idx_products_score 
ON products(score DESC NULLS LAST);

-- Index ترکیبی برای score و created_at (برای مرتب‌سازی دوگانه)
CREATE INDEX IF NOT EXISTS idx_products_score_created 
ON products(score DESC NULLS LAST, created_at DESC);

-- Index برای category + score (برای محصولات مرتبط)
CREATE INDEX IF NOT EXISTS idx_products_category_score 
ON products(category_id, score DESC NULLS LAST);

-- کامنت‌ها برای مستندسازی
COMMENT ON INDEX idx_products_score IS 'Index برای مرتب‌سازی سریع محصولات بر اساس امتیاز';
COMMENT ON INDEX idx_products_score_created IS 'Index ترکیبی برای مرتب‌سازی بر اساس امتیاز و تاریخ';
COMMENT ON INDEX idx_products_category_score IS 'Index برای دریافت سریع محصولات مرتبط در یک دسته';

-- ====================================================================
-- 2. تنظیم مقادیر پیش‌فرض برای محصولات موجود
-- ====================================================================

-- تنظیم score = 0 برای محصولاتی که score ندارند (اختیاری)
-- این را فقط اگر می‌خواهید تمام محصولات score داشته باشند اجرا کنید
-- UPDATE products 
-- SET score = 0 
-- WHERE score IS NULL;

-- یا می‌توانید بر اساس تاریخ ایجاد، امتیاز اولیه بدهید
-- UPDATE products 
-- SET score = CASE 
--   WHEN created_at > NOW() - INTERVAL '30 days' THEN 50
--   WHEN created_at > NOW() - INTERVAL '90 days' THEN 30
--   ELSE 10
-- END
-- WHERE score IS NULL;

-- ====================================================================
-- 3. کامنت برای ستون score
-- ====================================================================

COMMENT ON COLUMN products.score IS 'امتیاز محصول برای مرتب‌سازی (هرچه بالاتر، رتبه بهتر)';

-- ====================================================================
-- 4. Function برای محاسبه خودکار score (پیشرفته - اختیاری)
-- ====================================================================

-- اگر فیلدهای sales_count و view_count دارید، می‌توانید از این استفاده کنید
CREATE OR REPLACE FUNCTION calculate_product_score(
  product_sales_count INTEGER DEFAULT 0,
  product_view_count INTEGER DEFAULT 0,
  product_rating DECIMAL DEFAULT 0
)
RETURNS INTEGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- فرمول امتیازدهی:
  -- score = (sales_count * 10) + (view_count * 0.1) + (rating * 5)
  RETURN (
    (COALESCE(product_sales_count, 0) * 10) +
    (COALESCE(product_view_count, 0) * 0.1)::INTEGER +
    (COALESCE(product_rating, 0) * 5)::INTEGER
  );
END;
$$;

-- مثال استفاده:
-- UPDATE products 
-- SET score = calculate_product_score(sales_count, view_count, rating)
-- WHERE id = 'PRODUCT_ID';

-- ====================================================================
-- 5. Trigger برای به‌روزرسانی خودکار score (پیشرفته - اختیاری)
-- ====================================================================

-- اگر می‌خواهید score به صورت خودکار بر اساس سایر فیلدها محاسبه شود
/*
CREATE OR REPLACE FUNCTION auto_update_product_score()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- فقط اگر فیلدهای sales_count یا view_count تغییر کرده باشند
  IF (TG_OP = 'UPDATE' AND (
    OLD.sales_count IS DISTINCT FROM NEW.sales_count OR
    OLD.view_count IS DISTINCT FROM NEW.view_count
  )) OR TG_OP = 'INSERT' THEN
    NEW.score := calculate_product_score(
      NEW.sales_count,
      NEW.view_count,
      0
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- ایجاد Trigger
CREATE TRIGGER trigger_auto_update_product_score
BEFORE INSERT OR UPDATE ON products
FOR EACH ROW
EXECUTE FUNCTION auto_update_product_score();
*/

-- ====================================================================
-- 6. View برای محصولات پرامتیاز (اختیاری)
-- ====================================================================

CREATE OR REPLACE VIEW top_scored_products AS
SELECT 
  id,
  slug,
  product_name,
  price,
  score,
  created_at
FROM products
WHERE score IS NOT NULL
ORDER BY score DESC, created_at DESC
LIMIT 20;

-- کامنت برای view
COMMENT ON VIEW top_scored_products IS 'نمای ۲۰ محصول برتر بر اساس امتیاز';

-- ====================================================================
-- 7. Function برای دریافت آمار score
-- ====================================================================

CREATE OR REPLACE FUNCTION get_score_statistics()
RETURNS TABLE(
  total_products BIGINT,
  products_with_score BIGINT,
  products_without_score BIGINT,
  average_score NUMERIC,
  max_score NUMERIC,
  min_score NUMERIC
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*) AS total_products,
    COUNT(score) AS products_with_score,
    COUNT(*) - COUNT(score) AS products_without_score,
    AVG(score) AS average_score,
    MAX(score) AS max_score,
    MIN(score) AS min_score
  FROM products;
END;
$$;

-- مثال استفاده:
-- SELECT * FROM get_score_statistics();

-- ====================================================================
-- 8. Query های مفید برای مدیریت score
-- ====================================================================

-- نمایش محصولاتی که score ندارند
-- SELECT id, slug, product_name, created_at
-- FROM products
-- WHERE score IS NULL
-- ORDER BY created_at DESC;

-- نمایش توزیع score
-- SELECT 
--   CASE 
--     WHEN score IS NULL THEN 'بدون امتیاز'
--     WHEN score >= 90 THEN 'عالی (90-100)'
--     WHEN score >= 70 THEN 'خوب (70-89)'
--     WHEN score >= 50 THEN 'متوسط (50-69)'
--     ELSE 'ضعیف (<50)'
--   END AS score_range,
--   COUNT(*) AS product_count
-- FROM products
-- GROUP BY score_range
-- ORDER BY score_range;

-- نمایش ۱۰ محصول برتر
-- SELECT id, slug, product_name, score, created_at
-- FROM products
-- WHERE score IS NOT NULL
-- ORDER BY score DESC, created_at DESC
-- LIMIT 10;

-- ====================================================================
-- 9. بک‌آپ و بازیابی
-- ====================================================================

-- بک‌آپ از score های فعلی (به جدول موقت)
-- CREATE TEMP TABLE products_score_backup AS
-- SELECT id, score FROM products WHERE score IS NOT NULL;

-- بازیابی از بک‌آپ
-- UPDATE products p
-- SET score = b.score
-- FROM products_score_backup b
-- WHERE p.id = b.id;

-- ====================================================================
-- 10. RLS (Row Level Security) - اگر نیاز باشد
-- ====================================================================

-- اجازه خواندن score برای همه کاربران
-- ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- CREATE POLICY "Allow read score for all users"
-- ON products FOR SELECT
-- USING (true);

-- فقط ادمین‌ها می‌توانند score را تغییر دهند
-- CREATE POLICY "Allow update score for admins only"
-- ON products FOR UPDATE
-- USING (auth.jwt() ->> 'role' = 'admin')
-- WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- ====================================================================
-- نکات مهم:
-- ====================================================================
-- 1. قبل از اجرای هر command، حتماً بک‌آپ بگیرید
-- 2. Index های ایجاد شده حجم دیتابیس را کمی افزایش می‌دهند اما سرعت را بسیار بهبود می‌بخشند
-- 3. Trigger های خودکار باید با دقت استفاده شوند تا performance را خراب نکنند
-- 4. برای پروژه‌های بزرگ، از VACUUM ANALYZE بعد از ایجاد index استفاده کنید
-- 5. Monitor کنید که Index ها واقعاً استفاده می‌شوند (با EXPLAIN ANALYZE)
-- ====================================================================

-- تاریخ ایجاد: ۱۴۰۳/۱۰/۰۷
-- نسخه: 1.0.0
