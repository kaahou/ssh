# راهنمای راه‌اندازی Google Tag Manager برای Oil Global

## ✅ وضعیت فعلی

Google Tag Manager با موفقیت در پروژه شما پیاده‌سازی شده است!

**GTM Container ID:** `GTM-MWPHTW6B`

## 🎯 ویژگی‌های پیاده‌سازی شده

### 1. کامپوننت GoogleTagManager
- بارگذاری خودکار اسکریپت GTM
- راه‌اندازی `dataLayer` برای ردیابی رویدادها
- پشتیبانی از `noscript` برای کاربران بدون JavaScript
- یکپارچگی کامل با Google Analytics 4 موجود

### 2. مزایای GTM

✨ **مدیریت آسان تگ‌ها**: بدون نیاز به تغییر کد، تگ‌های جدید اضافه کنید
📊 **ردیابی رویدادها**: تمام ۱۲۲ رویداد GA4 موجود را می‌توانید از طریق GTM مدیریت کنید
🔄 **یکپارچگی**: اتصال به ابزارهای دیگر مانند Facebook Pixel، Google Ads، Hotjar و...
⚡ **سرعت بالا**: بارگذاری غیرهمزمان برای عدم کاهش سرعت سایت

## 📋 مراحل راه‌اندازی در GTM Console

### مرحله 1: دسترسی به GTM Container

1. به [Google Tag Manager](https://tagmanager.google.com/) بروید
2. Container شما با ID `GTM-MWPHTW6B` را باز کنید

### مرحله 2: اتصال Google Analytics 4

اگر می‌خواهید GA4 را از طریق GTM مدیریت کنید:

1. در GTM، به **Tags** → **New** بروید
2. نام تگ: `GA4 - Configuration`
3. Tag Configuration:
   - نوع: **Google Analytics: GA4 Configuration**
   - Measurement ID: `G-XXXXXXXXXX` (شناسه GA4 خود را وارد کنید)
4. Triggering:
   - **All Pages**
5. Save و Publish کنید

### مرحله 3: راه‌اندازی رویدادهای E-commerce

برای ردیابی خریدها و تراکنش‌ها:

```javascript
// نمونه Event برای خرید موفق
dataLayer.push({
  'event': 'purchase',
  'ecommerce': {
    'transaction_id': '12345',
    'value': 250000,
    'currency': 'IRR',
    'items': [{
      'item_name': 'روغن آرگان اصل',
      'item_id': 'ARG-001',
      'price': 250000,
      'quantity': 1
    }]
  }
});
```

**در GTM:**
1. Tags → New
2. نام: `GA4 - Purchase Event`
3. Tag Type: `Google Analytics: GA4 Event`
4. Event Name: `purchase`
5. Trigger: Custom Event با نام `purchase`

### مرحله 4: پیکربندی Variables

Variables مفید برای Oil Global:

1. **Page Path** - مسیر صفحه
2. **Click Element** - عنصر کلیک شده
3. **Form ID** - شناسه فرم ارسال شده
4. **Data Layer Variables**:
   - `ecommerce.transaction_id`
   - `ecommerce.value`
   - `user_id`

### مرحله 5: راه‌اندازی Triggers

Triggers پیشنهادی:

| Trigger | نوع | شرایط |
|---------|-----|--------|
| All Pages | Page View | همه صفحات |
| Form Submission | Form Submission | همه فرم‌ها |
| Add to Cart Click | Click | دکمه افزودن به سبد |
| Purchase Complete | Custom Event | event = purchase |
| Consultation Start | Custom Event | event = consultation_start |

### مرحله 6: افزودن Facebook Pixel (اختیاری)

1. Tags → New
2. نام: `Facebook Pixel - Base Code`
3. Tag Type: **Custom HTML**
4. کد:
```html
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', 'YOUR_PIXEL_ID');
fbq('track', 'PageView');
</script>
<!-- End Facebook Pixel Code -->
```
5. Trigger: All Pages

## 🔧 ادغام با Google Analytics 4 موجود

پروژه شما از قبل سیستم کامل GA4 با ۱۲۲ رویداد دارد که در فایل‌های زیر پیاده‌سازی شده:

- `/utils/analytics.ts` - تابع اصلی `trackEvent`
- `/utils/analyticsConstants.ts` - ثابت‌های رویدادها
- `/utils/useAnalytics.ts` - Hook برای استفاده در کامپوننت‌ها

**این رویدادها به صورت خودکار به `dataLayer` GTM ارسال می‌شوند!**

## 📊 مثال‌های کاربردی

### 1. ردیابی کلیک روی محصول

```typescript
// در GTM
Tag Type: GA4 Event
Event Name: select_item
Parameters:
  - item_id: {{Click Element - data-product-id}}
  - item_name: {{Click Element - data-product-name}}

Trigger: Click - Link Click با class="product-card"
```

### 2. ردیابی تکمیل فرم تماس

```typescript
// در GTM
Tag Type: GA4 Event  
Event Name: form_submit
Parameters:
  - form_name: contact_form

Trigger: Form Submission با Form ID = "contact-form"
```

### 3. ردیابی اسکرول صفحه

```typescript
// در GTM
Tag Type: GA4 Event
Event Name: scroll_depth
Parameters:
  - scroll_percentage: {{Scroll Depth Threshold}}

Trigger: Scroll Depth (25%, 50%, 75%, 90%)
```

## 🚀 بهینه‌سازی و توصیه‌های SEO

### 1. راه‌اندازی Enhanced E-commerce

برای ردیابی کامل مسیر خرید:
- مشاهده محصول (view_item)
- افزودن به سبد (add_to_cart)
- شروع پرداخت (begin_checkout)
- خرید موفق (purchase)

### 2. ردیابی User Engagement

```javascript
// نمونه رویداد Engagement
dataLayer.push({
  'event': 'user_engagement',
  'engagement_time_msec': 30000
});
```

### 3. تست و Debug

**مرحله 1: حالت Preview**
1. در GTM روی **Preview** کلیک کنید
2. URL سایت خود را وارد کنید
3. تمام رویدادها را تست کنید

**مرحله 2: Chrome Extension**
- نصب [Google Tag Assistant](https://chrome.google.com/webstore/detail/tag-assistant-legacy-by-g/kejbdjndbnbjgmefkgdddjlbokphdefk)
- بررسی صحت Firing تگ‌ها

**مرحله 3: Real-time Reports**
- در GA4 → Realtime → Events
- بررسی رویدادهای زنده

## 📈 KPIs پیشنهادی برای Oil Global

| متریک | توضیح | اهمیت |
|-------|-------|-------|
| Conversion Rate | نرخ تبدیل بازدید به خرید | بالا ⭐⭐⭐ |
| Cart Abandonment | رها کردن سبد خرید | بالا ⭐⭐⭐ |
| Average Order Value | میانگین ارزش سفارش | متوسط ⭐⭐ |
| Product Views | تعداد مشاهده محصولات | متوسط ⭐⭐ |
| Consultation Requests | درخواست‌های مشاوره | بالا ⭐⭐⭐ |
| Newsletter Signups | ثبت‌نام خبرنامه | پایین ⭐ |

## 🔒 امنیت و حریم خصوصی

### GDPR & Privacy Compliance

اگر کاربران اروپایی دارید:

1. در GTM Settings → Container Settings
2. فعال کردن **Enable consent overview**
3. اضافه کردن Consent Banner به سایت
4. تنظیم Consent Triggers

### IP Anonymization

در GA4 Configuration Tag:
```javascript
gtag('config', 'G-XXXXXXXXXX', {
  'anonymize_ip': true
});
```

## 📝 Checklist نهایی

- [x] GTM Container ID (`GTM-MWPHTW6B`) در `/App.tsx` قرار گرفته
- [x] کامپوننت `GoogleTagManager` ایجاد شده
- [ ] GA4 Configuration Tag در GTM ساخته شود
- [ ] E-commerce Tracking تنظیم شود
- [ ] Facebook Pixel (در صورت نیاز) اضافه شود
- [ ] حالت Preview تست شود
- [ ] Container منتشر شود (Publish)
- [ ] Real-time Events در GA4 بررسی شود

## 🆘 پشتیبانی و منابع

- [مستندات رسمی GTM](https://developers.google.com/tag-platform/tag-manager)
- [راهنمای GA4 E-commerce](https://developers.google.com/analytics/devguides/collection/ga4/ecommerce)
- [GTM Community](https://www.en.advertisercommunity.com/t5/Google-Tag-Manager/ct-p/Google-Tag-Manager)

---

**نکته مهم:** پس از هر تغییر در GTM، حتماً Container را **Publish** کنید تا تغییرات روی سایت اعمال شود!

## 🎉 پیام موفقیت

تبریک! Google Tag Manager شما آماده است. حالا می‌توانید:

✅ تمام تگ‌های مارکتینگ را از یک مکان مدیریت کنید  
✅ رویدادهای سفارشی بسازید  
✅ کمپین‌های تبلیغاتی را ردیابی کنید  
✅ تست A/B انجام دهید  
✅ بدون تغییر کد، تگ جدید اضافه کنید

**موفق باشید! 🚀**
