# 🏗️ معماری لایه‌ای کامل فروشگاه nursaa.ir

> **نسخه:** 3.0  
> **تاریخ:** دی ۱۴۰۳  
> **معمار:** تیم فنی Oil Global  

---

## 📑 فهرست مطالب

1. [نمای کلی سیستم](#1-نمای-کلی-سیستم)
2. [معماری لایه‌ای](#2-معماری-لایه‌ای)
3. [ساختار پوشه‌ها](#3-ساختار-پوشه‌ها)
4. [طراحی دیتابیس](#4-طراحی-دیتابیس)
5. [لایه سرویس‌ها](#5-لایه-سرویس‌ها)
6. [لایه API](#6-لایه-api)
7. [سرویس‌های خارجی](#7-سرویس‌های-خارجی)
8. [صف پیام و Workers](#8-صف-پیام-و-workers)
9. [پشته فناوری](#9-پشته-فناوری)
10. [نقشه راه پیاده‌سازی](#10-نقشه-راه-پیاده‌سازی)

---

## 1️⃣ نمای کلی سیستم

### 1.1 دیاگرام معماری کلی

```
┌─────────────────────────────────────────────────────────────────────┐
│                         PRESENTATION LAYER                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │   Web App    │  │  Admin Panel │  │  Mobile App  │             │
│  │   (React)    │  │   (React)    │  │   (Future)   │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
└────────────────────────────┬────────────────────────────────────────┘
                             │ HTTPS/REST/GraphQL
┌────────────────────────────▼────────────────────────────────────────┐
│                          API GATEWAY LAYER                          │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │  Edge Function (Hono.js)                                      │ │
│  │  - Rate Limiting & Throttling                                 │ │
│  │  - Authentication & Authorization (JWT)                       │ │
│  │  - Request Validation (Zod)                                   │ │
│  │  - Request Routing                                            │ │
│  │  - Response Transformation                                    │ │
│  │  - Error Handling & Logging                                   │ │
│  │  - API Versioning (v1, v2)                                    │ │
│  └───────────────────────────────────────────────────────────────┘ │
└────────────────────────────┬────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│                      SERVICE ORCHESTRATION LAYER                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │   Core       │  │  E-commerce  │  │   AI/ML      │             │
│  │  Services    │  │   Services   │  │  Services    │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
└────────────────────────────┬────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│                         BUSINESS LOGIC LAYER                        │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐     │
│  │Product  │ │ Order   │ │Customer │ │Consult  │ │Content  │     │
│  │Service  │ │Service  │ │Service  │ │Service  │ │Service  │     │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘     │
│                                                                     │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐     │
│  │Payment  │ │Discount │ │Recommend│ │Ticket   │ │Chat     │     │
│  │Service  │ │Service  │ │Service  │ │Service  │ │Service  │     │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘     │
│                                                                     │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐     │
│  │SMS      │ │Email    │ │Search   │ │Media    │ │Affiliate│     │
│  │Service  │ │Service  │ │Service  │ │Service  │ │Service  │     │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘     │
└────────────────────────────┬────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│                      DATA ACCESS LAYER (DAL)                        │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐     │
│  │Product  │ │ Order   │ │Customer │ │Consult  │ │Content  │     │
│  │Repo     │ │Repo     │ │Repo     │ │Repo     │ │Repo     │     │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘     │
└────────────────────────────┬────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│                      INFRASTRUCTURE LAYER                           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐│
│  │Postgres  │ │ Redis    │ │ S3/Blob  │ │  Queue   │ │   CDN    ││
│  │Database  │ │  Cache   │ │ Storage  │ │(BullMQ)  │ │(CF/AWS)  ││
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘│
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                      EXTERNAL SERVICES LAYER                        │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐│
│  │Zarinpal  │ │Niazpardaz│ │  OpenAI  │ │ Sentry   │ │Analytics ││
│  │ Payment  │ │   SMS    │ │   API    │ │ Logging  │ │   (GA4)  ││
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘│
└─────────────────────────────────────────────────────────────────────┘
```

---

## 2️⃣ معماری لایه‌ای

### 2.1 Presentation Layer (لایه نمایش)

**مسئولیت‌ها:**
- رندر کردن UI
- مدیریت state کلاینت (React Query + Zustand)
- Validation سمت کلاینت
- Error Handling و نمایش
- Analytics tracking

**تکنولوژی:**
- React 18+ با TypeScript
- React Router v6 برای routing
- React Query برای server state
- Zustand برای client state
- Tailwind CSS برای styling

### 2.2 API Gateway Layer (لایه دروازه API)

**مسئولیت‌ها:**
- مدیریت تمام درخواست‌های HTTP/HTTPS
- Authentication و Authorization
- Rate limiting و throttling
- Request/Response transformation
- API versioning
- Logging و monitoring

**پیاده‌سازی:**
```typescript
// /api-gateway/middleware/auth.ts
import { Context, Next } from 'npm:hono';
import { verify } from 'npm:jsonwebtoken';

export async function authMiddleware(c: Context, next: Next) {
  const token = c.req.header('Authorization')?.replace('Bearer ', '');
  
  if (!token) {
    return c.json({ error: 'Unauthorized' }, 401);
  }
  
  try {
    const decoded = verify(token, Deno.env.get('JWT_SECRET')!);
    c.set('user', decoded);
    await next();
  } catch (error) {
    return c.json({ error: 'Invalid token' }, 401);
  }
}

// /api-gateway/middleware/rateLimit.ts
import { RateLimiter } from 'npm:rate-limiter-flexible';

const rateLimiter = new RateLimiter({
  points: 100, // تعداد درخواست
  duration: 60, // در ۶۰ ثانیه
});

export async function rateLimitMiddleware(c: Context, next: Next) {
  const ip = c.req.header('x-forwarded-for') || 'unknown';
  
  try {
    await rateLimiter.consume(ip);
    await next();
  } catch (error) {
    return c.json({ error: 'Too many requests' }, 429);
  }
}
```

### 2.3 Service Orchestration Layer (لایه هماهنگی سرویس‌ها)

**مسئولیت‌ها:**
- هماهنگی بین سرویس‌های مختلف
- Transaction management
- Saga pattern برای distributed transactions
- Event-driven communication

**مثال:**
```typescript
// /services/orchestration/OrderOrchestrator.ts
export class OrderOrchestrator {
  constructor(
    private orderService: OrderService,
    private paymentService: PaymentService,
    private inventoryService: InventoryService,
    private notificationService: NotificationService,
    private recommendationService: RecommendationService
  ) {}

  async createOrder(orderData: CreateOrderDTO): Promise<Order> {
    // 1. Reserve inventory
    const reservation = await this.inventoryService.reserve(orderData.items);
    
    try {
      // 2. Create order
      const order = await this.orderService.create({
        ...orderData,
        reservationId: reservation.id
      });
      
      // 3. Process payment
      const payment = await this.paymentService.process({
        orderId: order.id,
        amount: order.total,
        method: orderData.paymentMethod
      });
      
      // 4. Confirm order
      await this.orderService.confirm(order.id, payment.id);
      
      // 5. Send notifications (async)
      this.notificationService.sendOrderConfirmation(order).catch(console.error);
      
      // 6. Update recommendations (async)
      this.recommendationService.trackPurchase(order).catch(console.error);
      
      return order;
    } catch (error) {
      // Rollback inventory
      await this.inventoryService.release(reservation.id);
      throw error;
    }
  }
}
```

### 2.4 Business Logic Layer (لایه منطق کسب‌وکار)

**ساختار سرویس‌ها:**

#### 2.4.1 Core Services (سرویس‌های اصلی)

**ProductService:**
```typescript
// /services/product/ProductService.ts
export class ProductService {
  constructor(
    private productRepo: ProductRepository,
    private cacheService: CacheService,
    private searchService: SearchService
  ) {}

  async getById(id: string): Promise<Product> {
    // Check cache first
    const cached = await this.cacheService.get(`product:${id}`);
    if (cached) return cached;
    
    // Fetch from DB
    const product = await this.productRepo.findById(id);
    
    // Cache for 5 minutes
    await this.cacheService.set(`product:${id}`, product, 300);
    
    return product;
  }

  async create(data: CreateProductDTO): Promise<Product> {
    // Validation
    this.validateProductData(data);
    
    // Create product
    const product = await this.productRepo.create(data);
    
    // Index for search
    await this.searchService.indexProduct(product);
    
    // Invalidate cache
    await this.cacheService.invalidate('products:*');
    
    return product;
  }

  async searchWithAI(query: string, context?: any): Promise<Product[]> {
    // Use AI-powered search
    const searchResults = await this.searchService.aiSearch(query, context);
    return searchResults;
  }
}
```

**OrderService:**
```typescript
// /services/order/OrderService.ts
export class OrderService {
  constructor(
    private orderRepo: OrderRepository,
    private discountService: DiscountService,
    private shippingService: ShippingService
  ) {}

  async create(data: CreateOrderDTO): Promise<Order> {
    // Calculate subtotal
    const subtotal = this.calculateSubtotal(data.items);
    
    // Apply discounts
    const discount = await this.discountService.apply(
      data.discountCode,
      subtotal,
      data.customerId
    );
    
    // Calculate shipping
    const shipping = await this.shippingService.calculate(
      data.address,
      data.items
    );
    
    // Create order
    const order = await this.orderRepo.create({
      ...data,
      subtotal,
      discount: discount.amount,
      shipping: shipping.cost,
      total: subtotal - discount.amount + shipping.cost,
      status: 'pending'
    });
    
    return order;
  }
}
```

**ConsultationService:**
```typescript
// /services/consultation/ConsultationService.ts
export class ConsultationService {
  constructor(
    private consultationRepo: ConsultationRepository,
    private aiService: AIService,
    private recommendationService: RecommendationService,
    private notificationService: NotificationService
  ) {}

  async create(data: CreateConsultationDTO): Promise<Consultation> {
    const consultation = await this.consultationRepo.create({
      ...data,
      status: 'pending'
    });
    
    // Generate AI recommendations asynchronously
    this.generateAIRecommendations(consultation.id).catch(console.error);
    
    return consultation;
  }

  async generateAIRecommendations(consultationId: string): Promise<void> {
    const consultation = await this.consultationRepo.findById(consultationId);
    
    // Use AI to analyze consultation data
    const analysis = await this.aiService.analyzeConsultation(consultation);
    
    // Get product recommendations
    const recommendations = await this.recommendationService
      .getConsultationBasedRecommendations(analysis);
    
    // Update consultation with recommendations
    await this.consultationRepo.update(consultationId, {
      ai_analysis: analysis,
      recommended_products: recommendations,
      status: 'analyzed'
    });
    
    // Notify customer
    await this.notificationService.sendConsultationReady(consultation);
  }

  async submitResult(
    consultationId: string,
    result: string,
    expertId: string
  ): Promise<void> {
    await this.consultationRepo.update(consultationId, {
      consultation_result: result,
      expert_id: expertId,
      status: 'completed',
      completed_at: new Date()
    });
    
    // Send notification
    const consultation = await this.consultationRepo.findById(consultationId);
    await this.notificationService.sendConsultationResult(consultation);
  }
}
```

#### 2.4.2 E-commerce Services

**DiscountService:**
```typescript
// /services/discount/DiscountService.ts
export class DiscountService {
  constructor(
    private discountRepo: DiscountRepository,
    private usageRepo: DiscountUsageRepository
  ) {}

  async apply(
    code: string,
    subtotal: number,
    customerId?: string
  ): Promise<DiscountResult> {
    const discount = await this.discountRepo.findByCode(code);
    
    if (!discount) {
      throw new Error('کد تخفیف معتبر نیست');
    }
    
    // Validate discount
    this.validateDiscount(discount, subtotal, customerId);
    
    // Calculate discount amount
    const amount = this.calculateDiscountAmount(discount, subtotal);
    
    // Record usage
    if (customerId) {
      await this.usageRepo.create({
        discount_id: discount.id,
        customer_id: customerId,
        amount,
        used_at: new Date()
      });
    }
    
    return {
      code: discount.code,
      amount,
      type: discount.type,
      description: discount.description
    };
  }

  private validateDiscount(
    discount: Discount,
    subtotal: number,
    customerId?: string
  ): void {
    // Check expiration
    if (discount.expires_at && new Date() > discount.expires_at) {
      throw new Error('کد تخفیف منقضی شده است');
    }
    
    // Check minimum purchase
    if (discount.min_purchase && subtotal < discount.min_purchase) {
      throw new Error(`حداقل خرید ${discount.min_purchase} تومان است`);
    }
    
    // Check usage limit
    if (discount.max_uses && discount.usage_count >= discount.max_uses) {
      throw new Error('تعداد استفاده از این کد به حد مجاز رسیده است');
    }
    
    // Check per-user limit
    if (customerId && discount.max_uses_per_user) {
      const userUsage = await this.usageRepo.countByCustomer(
        discount.id,
        customerId
      );
      if (userUsage >= discount.max_uses_per_user) {
        throw new Error('شما قبلاً از این کد استفاده کرده‌اید');
      }
    }
  }
}
```

**AffiliateService:**
```typescript
// /services/affiliate/AffiliateService.ts
export class AffiliateService {
  constructor(
    private affiliateRepo: AffiliateRepository,
    private commissionRepo: CommissionRepository,
    private paymentService: PaymentService
  ) {}

  async registerAffiliate(userId: string, data: RegisterAffiliateDTO): Promise<Affiliate> {
    // Generate unique referral code
    const referralCode = await this.generateUniqueCode();
    
    const affiliate = await this.affiliateRepo.create({
      user_id: userId,
      referral_code: referralCode,
      commission_rate: data.commission_rate || 0.1, // 10% default
      status: 'active',
      ...data
    });
    
    return affiliate;
  }

  async trackReferral(
    referralCode: string,
    orderId: string
  ): Promise<void> {
    const affiliate = await this.affiliateRepo.findByCode(referralCode);
    
    if (!affiliate || affiliate.status !== 'active') {
      return;
    }
    
    const order = await this.orderRepo.findById(orderId);
    
    // Calculate commission
    const commission = order.total * affiliate.commission_rate;
    
    // Record commission
    await this.commissionRepo.create({
      affiliate_id: affiliate.id,
      order_id: orderId,
      amount: commission,
      status: 'pending',
      created_at: new Date()
    });
  }

  async processPayouts(): Promise<void> {
    const pendingCommissions = await this.commissionRepo.findPending();
    
    for (const commission of pendingCommissions) {
      try {
        await this.paymentService.payoutAffiliate(commission);
        await this.commissionRepo.update(commission.id, {
          status: 'paid',
          paid_at: new Date()
        });
      } catch (error) {
        console.error(`Failed to payout commission ${commission.id}:`, error);
      }
    }
  }
}
```

#### 2.4.3 AI/ML Services

**RecommendationService:**
```typescript
// /services/recommendation/RecommendationService.ts
export class RecommendationService {
  constructor(
    private behaviorRepo: CustomerBehaviorRepository,
    private productRepo: ProductRepository,
    private aiService: AIService,
    private cacheService: CacheService
  ) {}

  /**
   * پیشنهاد محصول بر اساس رفتار مشتری
   */
  async getBehaviorBasedRecommendations(
    customerId: string,
    limit: number = 10
  ): Promise<Product[]> {
    // Check cache
    const cacheKey = `recommendations:behavior:${customerId}`;
    const cached = await this.cacheService.get(cacheKey);
    if (cached) return cached;
    
    // Get customer behavior
    const behavior = await this.behaviorRepo.getByCustomer(customerId);
    
    // Collaborative filtering + Content-based filtering
    const recommendations = await this.aiService.getRecommendations({
      customerId,
      viewedProducts: behavior.viewed_products,
      purchasedProducts: behavior.purchased_products,
      searchHistory: behavior.search_history,
      cartItems: behavior.cart_items,
      limit
    });
    
    // Get full product details
    const products = await this.productRepo.findByIds(
      recommendations.map(r => r.productId)
    );
    
    // Cache for 1 hour
    await this.cacheService.set(cacheKey, products, 3600);
    
    return products;
  }

  /**
   * پیشنهاد محصول بر اساس مشاوره
   */
  async getConsultationBasedRecommendations(
    consultationAnalysis: ConsultationAnalysis
  ): Promise<Product[]> {
    const recommendations = await this.aiService.analyzeAndRecommend({
      skinType: consultationAnalysis.skinType,
      hairType: consultationAnalysis.hairType,
      concerns: consultationAnalysis.concerns,
      preferences: consultationAnalysis.preferences,
      medicalHistory: consultationAnalysis.medicalHistory
    });
    
    return await this.productRepo.findByIds(
      recommendations.map(r => r.productId)
    );
  }

  /**
   * ثبت رفتار کاربر برای یادگیری
   */
  async trackBehavior(
    customerId: string,
    event: BehaviorEvent
  ): Promise<void> {
    await this.behaviorRepo.record({
      customer_id: customerId,
      event_type: event.type,
      event_data: event.data,
      timestamp: new Date()
    });
    
    // Invalidate cache
    await this.cacheService.invalidate(`recommendations:behavior:${customerId}`);
  }
}
```

**AIContentService:**
```typescript
// /services/ai/AIContentService.ts
export class AIContentService {
  constructor(
    private openaiClient: OpenAIClient,
    private stableDiffusionClient: StableDiffusionClient,
    private contentRepo: ContentRepository,
    private mediaService: MediaService
  ) {}

  /**
   * تولید مقاله بر اساس محصول
   */
  async generateArticleForProduct(
    productId: string,
    options?: GenerateArticleOptions
  ): Promise<Article> {
    const product = await this.productRepo.findById(productId);
    
    const prompt = `
      نام محصول: ${product.title}
      دسته‌بندی: ${product.category}
      مواد تشکیل‌دهنده: ${product.ingredients?.join('، ')}
      خواص: ${product.properties?.join('، ')}
      
      یک مقاله جامع و آموزشی با موضوعات زیر بنویس:
      1. معرفی محصول
      2. خواص و مزایا
      3. نحوه استفاده
      4. نکات ایمنی
      5. پاسخ به سوالات متداول
      
      مقاله باید حداقل ${options?.minWords || 1000} کلمه باشد.
    `;
    
    const content = await this.openaiClient.generateText({
      model: 'gpt-4',
      prompt,
      maxTokens: 3000,
      temperature: 0.7
    });
    
    // Generate SEO-friendly slug
    const slug = this.generateSlug(product.title);
    
    // Save article
    const article = await this.contentRepo.create({
      title: `راهنمای جامع ${product.title}`,
      slug,
      content: content.text,
      product_id: productId,
      author: 'AI',
      status: 'draft', // نیاز به بررسی توسط ادمین
      seo_title: `${product.title} - خواص، مزایا و نحوه استفاده`,
      seo_description: content.text.substring(0, 160),
      created_at: new Date()
    });
    
    return article;
  }

  /**
   * تولید تصویر محصول با AI
   */
  async generateProductImage(
    productId: string,
    style: 'realistic' | 'artistic' | 'minimal' = 'realistic'
  ): Promise<string> {
    const product = await this.productRepo.findById(productId);
    
    const prompt = `
      Professional product photography of ${product.title},
      ${style} style, high quality, clean background,
      studio lighting, 4k resolution
    `;
    
    const image = await this.stableDiffusionClient.generateImage({
      prompt,
      negativePrompt: 'blurry, low quality, distorted',
      width: 1024,
      height: 1024,
      steps: 50
    });
    
    // Upload to storage
    const imageUrl = await this.mediaService.upload({
      data: image.buffer,
      filename: `product-${productId}-ai-${Date.now()}.png`,
      contentType: 'image/png',
      folder: 'products/ai-generated'
    });
    
    return imageUrl;
  }

  /**
   * تولید ویدیو تبلیغاتی محصول
   */
  async generateProductVideo(
    productId: string,
    duration: number = 30 // seconds
  ): Promise<string> {
    const product = await this.productRepo.findById(productId);
    
    // Generate script
    const script = await this.openaiClient.generateText({
      model: 'gpt-4',
      prompt: `
        یک اسکریپت ${duration} ثانیه‌ای برای ویدیو تبلیغاتی محصول ${product.title} بنویس.
        ویدیو باید جذاب، اطلاعاتی و متقاعدکننده باشد.
      `,
      maxTokens: 500
    });
    
    // Generate voiceover
    const voiceover = await this.openaiClient.textToSpeech({
      text: script.text,
      voice: 'nova', // Persian voice
      speed: 1.0
    });
    
    // Generate video frames with D-ID or similar
    const videoUrl = await this.mediaService.generateVideo({
      script: script.text,
      audio: voiceover.url,
      images: product.images,
      duration
    });
    
    return videoUrl;
  }
}
```

**AISearchService:**
```typescript
// /services/search/AISearchService.ts
export class AISearchService {
  constructor(
    private vectorDB: VectorDatabase, // Pinecone or similar
    private openaiClient: OpenAIClient,
    private productRepo: ProductRepository
  ) {}

  /**
   * جستجوی هوشمند با درک معنایی
   */
  async semanticSearch(
    query: string,
    options?: SearchOptions
  ): Promise<SearchResult[]> {
    // Generate embedding for query
    const queryEmbedding = await this.openaiClient.createEmbedding({
      model: 'text-embedding-ada-002',
      input: query
    });
    
    // Search in vector database
    const similarProducts = await this.vectorDB.search({
      vector: queryEmbedding.data[0].embedding,
      topK: options?.limit || 20,
      filter: options?.filters
    });
    
    // Get full product details
    const products = await this.productRepo.findByIds(
      similarProducts.map(p => p.id)
    );
    
    // Enhance with AI understanding
    const enhancedResults = await this.enhanceSearchResults(
      query,
      products
    );
    
    return enhancedResults;
  }

  /**
   * جستجوی گفتگویی (مثل ChatGPT)
   */
  async conversationalSearch(
    query: string,
    conversationHistory?: Message[]
  ): Promise<ConversationalSearchResult> {
    const messages = [
      {
        role: 'system',
        content: `تو یک دستیار فروش متخصص در فروشگاه محصولات طبیعی هستی.
        وظیفه‌ات کمک به مشتری برای یافتن محصول مناسب است.
        محصولات موجود را از دیتابیس جستجو کن و بهترین پیشنهاد را بده.`
      },
      ...(conversationHistory || []),
      {
        role: 'user',
        content: query
      }
    ];
    
    const response = await this.openaiClient.chat({
      model: 'gpt-4',
      messages,
      functions: [
        {
          name: 'search_products',
          description: 'Search for products based on criteria',
          parameters: {
            type: 'object',
            properties: {
              keywords: { type: 'array', items: { type: 'string' } },
              category: { type: 'string' },
              priceRange: { 
                type: 'object',
                properties: {
                  min: { type: 'number' },
                  max: { type: 'number' }
                }
              }
            }
          }
        }
      ],
      functionCall: 'auto'
    });
    
    // If AI decided to call search function
    if (response.functionCall) {
      const searchParams = JSON.parse(response.functionCall.arguments);
      const products = await this.productRepo.search(searchParams);
      
      return {
        response: response.message.content,
        products,
        suggestedQuestions: this.generateSuggestedQuestions(products)
      };
    }
    
    return {
      response: response.message.content,
      products: [],
      suggestedQuestions: []
    };
  }

  /**
   * ایندکس کردن محصولات برای جستجوی برداری
   */
  async indexProduct(product: Product): Promise<void> {
    // Create text representation of product
    const productText = `
      ${product.title}
      ${product.description}
      ${product.category}
      ${product.tags?.join(' ')}
      ${product.ingredients?.join(' ')}
    `;
    
    // Generate embedding
    const embedding = await this.openaiClient.createEmbedding({
      model: 'text-embedding-ada-002',
      input: productText
    });
    
    // Store in vector database
    await this.vectorDB.upsert({
      id: product.id,
      vector: embedding.data[0].embedding,
      metadata: {
        title: product.title,
        category: product.category,
        price: product.price,
        inStock: product.stock > 0
      }
    });
  }
}
```

#### 2.4.4 Communication Services

**SMSService:**
```typescript
// /services/sms/SMSService.ts
export class SMSService {
  constructor(
    private niazpardazClient: NiazpardazClient,
    private smsRepo: SMSRepository,
    private templateRepo: SMSTemplateRepository,
    private queueService: QueueService
  ) {}

  /**
   * ارسال پیامک تبلیغاتی
   */
  async sendBulkMarketing(
    campaignId: string,
    recipients: string[],
    templateId: string,
    variables?: Record<string, any>
  ): Promise<void> {
    const template = await this.templateRepo.findById(templateId);
    
    // Process in batches to avoid rate limiting
    const batches = this.chunk(recipients, 100);
    
    for (const batch of batches) {
      // Add to queue for background processing
      await this.queueService.add('sms:bulk', {
        campaignId,
        recipients: batch,
        template: template.content,
        variables
      });
    }
  }

  /**
   * ارسال پیامک اطلاع‌رسانی (وضعیت سفارش، مشاوره، و غیره)
   */
  async sendNotification(
    phone: string,
    type: NotificationType,
    data: Record<string, any>
  ): Promise<void> {
    const template = await this.templateRepo.findByType(type);
    const message = this.renderTemplate(template.content, data);
    
    // Send immediately
    await this.send(phone, message, { priority: 'high' });
  }

  /**
   * ارسال پیامک دستی
   */
  async sendManual(
    recipients: string[],
    message: string,
    scheduledAt?: Date
  ): Promise<void> {
    if (scheduledAt && scheduledAt > new Date()) {
      // Schedule for later
      await this.queueService.add('sms:scheduled', {
        recipients,
        message,
        scheduledAt
      });
    } else {
      // Send immediately
      for (const phone of recipients) {
        await this.send(phone, message);
      }
    }
  }

  private async send(
    phone: string,
    message: string,
    options?: SendOptions
  ): Promise<SMSResult> {
    try {
      const result = await this.niazpardazClient.send({
        to: phone,
        text: message,
        from: Deno.env.get('SMS_FROM_NUMBER')!
      });
      
      // Log to database
      await this.smsRepo.create({
        phone,
        message,
        status: 'sent',
        provider_id: result.messageId,
        cost: result.cost,
        sent_at: new Date()
      });
      
      return { success: true, messageId: result.messageId };
    } catch (error) {
      // Log failure
      await this.smsRepo.create({
        phone,
        message,
        status: 'failed',
        error: error.message,
        sent_at: new Date()
      });
      
      throw error;
    }
  }
}
```

**EmailService:**
```typescript
// /services/email/EmailService.ts
export class EmailService {
  constructor(
    private emailProvider: EmailProvider, // Resend, SendGrid, etc.
    private emailRepo: EmailRepository,
    private templateEngine: TemplateEngine,
    private queueService: QueueService
  ) {}

  /**
   * ارسال ایمیل تأیید سفارش
   */
  async sendOrderConfirmation(order: Order): Promise<void> {
    const html = await this.templateEngine.render('order-confirmation', {
      order,
      customer: order.customer,
      items: order.items
    });
    
    await this.send({
      to: order.customer.email,
      subject: `تأیید سفارش #${order.order_number}`,
      html,
      attachments: [
        {
          filename: `invoice-${order.order_number}.pdf`,
          content: await this.generateInvoicePDF(order)
        }
      ]
    });
  }

  /**
   * ارسال خبرنامه
   */
  async sendNewsletter(
    campaignId: string,
    subscribers: string[],
    subject: string,
    content: string
  ): Promise<void> {
    // Process in batches
    const batches = this.chunk(subscribers, 100);
    
    for (const batch of batches) {
      await this.queueService.add('email:newsletter', {
        campaignId,
        recipients: batch,
        subject,
        content
      });
    }
  }

  /**
   * ارسال ایمیل با فایل پیوست
   */
  async send(options: EmailOptions): Promise<void> {
    try {
      const result = await this.emailProvider.send({
        from: Deno.env.get('EMAIL_FROM')!,
        to: options.to,
        subject: options.subject,
        html: options.html,
        attachments: options.attachments
      });
      
      // Log to database
      await this.emailRepo.create({
        to: options.to,
        subject: options.subject,
        status: 'sent',
        provider_id: result.id,
        sent_at: new Date()
      });
    } catch (error) {
      await this.emailRepo.create({
        to: options.to,
        subject: options.subject,
        status: 'failed',
        error: error.message,
        sent_at: new Date()
      });
      
      throw error;
    }
  }
}
```

#### 2.4.5 Support Services

**TicketService:**
```typescript
// /services/ticket/TicketService.ts
export class TicketService {
  constructor(
    private ticketRepo: TicketRepository,
    private messageRepo: TicketMessageRepository,
    private notificationService: NotificationService,
    private aiService: AIService
  ) {}

  async createTicket(data: CreateTicketDTO): Promise<Ticket> {
    // Auto-categorize using AI
    const category = await this.aiService.categorizeTicket(data.subject, data.message);
    
    // Auto-assign priority
    const priority = await this.aiService.determinePriority(data.message);
    
    const ticket = await this.ticketRepo.create({
      ...data,
      category: category.name,
      priority,
      status: 'open',
      created_at: new Date()
    });
    
    // Create initial message
    await this.messageRepo.create({
      ticket_id: ticket.id,
      sender_id: data.customer_id,
      sender_type: 'customer',
      message: data.message,
      created_at: new Date()
    });
    
    // Notify support team
    await this.notificationService.notifyNewTicket(ticket);
    
    // Auto-suggest solutions using AI
    const suggestions = await this.aiService.suggestSolutions(
      data.subject,
      data.message
    );
    
    if (suggestions.length > 0) {
      // Send auto-response with suggestions
      await this.messageRepo.create({
        ticket_id: ticket.id,
        sender_type: 'system',
        message: `پیشنهادات سیستم:\n${suggestions.join('\n')}`,
        created_at: new Date()
      });
    }
    
    return ticket;
  }

  async reply(
    ticketId: string,
    message: string,
    senderId: string,
    senderType: 'customer' | 'admin'
  ): Promise<void> {
    await this.messageRepo.create({
      ticket_id: ticketId,
      sender_id: senderId,
      sender_type: senderType,
      message,
      created_at: new Date()
    });
    
    // Update ticket
    await this.ticketRepo.update(ticketId, {
      last_reply_at: new Date(),
      last_reply_by: senderType
    });
    
    // Notify other party
    const ticket = await this.ticketRepo.findById(ticketId);
    if (senderType === 'admin') {
      await this.notificationService.notifyCustomerTicketReply(ticket);
    } else {
      await this.notificationService.notifyAdminTicketReply(ticket);
    }
  }
}
```

**ChatService:**
```typescript
// /services/chat/ChatService.ts
export class ChatService {
  constructor(
    private chatRepo: ChatRepository,
    private messageRepo: ChatMessageRepository,
    private websocketService: WebSocketService,
    private aiChatbot: AIChatbot
  ) {}

  async startChat(customerId: string): Promise<Chat> {
    const chat = await this.chatRepo.create({
      customer_id: customerId,
      status: 'waiting',
      started_at: new Date()
    });
    
    // Try to assign to available agent
    const agent = await this.findAvailableAgent();
    
    if (agent) {
      await this.assignToAgent(chat.id, agent.id);
    } else {
      // Start with AI chatbot
      await this.chatRepo.update(chat.id, {
        assigned_to: 'ai-bot',
        status: 'active'
      });
      
      // Send welcome message
      await this.sendBotMessage(
        chat.id,
        'سلام! چطور می‌تونم کمکتون کنم؟'
      );
    }
    
    return chat;
  }

  async sendMessage(
    chatId: string,
    senderId: string,
    message: string,
    senderType: 'customer' | 'agent' | 'bot'
  ): Promise<void> {
    // Save message
    const msg = await this.messageRepo.create({
      chat_id: chatId,
      sender_id: senderId,
      sender_type: senderType,
      message,
      sent_at: new Date()
    });
    
    // Send via WebSocket
    await this.websocketService.sendToChatRoom(chatId, {
      type: 'new_message',
      data: msg
    });
    
    // If customer sent message and chat is with bot, generate response
    if (senderType === 'customer') {
      const chat = await this.chatRepo.findById(chatId);
      
      if (chat.assigned_to === 'ai-bot') {
        const response = await this.aiChatbot.generateResponse(
          message,
          await this.getConversationHistory(chatId)
        );
        
        await this.sendBotMessage(chatId, response);
      }
    }
  }

  private async sendBotMessage(chatId: string, message: string): Promise<void> {
    const msg = await this.messageRepo.create({
      chat_id: chatId,
      sender_id: 'ai-bot',
      sender_type: 'bot',
      message,
      sent_at: new Date()
    });
    
    await this.websocketService.sendToChatRoom(chatId, {
      type: 'new_message',
      data: msg
    });
  }
}
```

---

## 3️⃣ ساختار پوشه‌ها

```
nursaa/
├── apps/
│   ├── web/                          # Frontend web app
│   │   ├── src/
│   │   │   ├── features/             # Feature modules
│   │   │   │   ├── products/
│   │   │   │   │   ├── components/
│   │   │   │   │   ├── hooks/
│   │   │   │   │   ├── services/
│   │   │   │   │   ├── types/
│   │   │   │   │   └── utils/
│   │   │   │   ├── cart/
│   │   │   │   ├── checkout/
│   │   │   │   ├── consultation/
│   │   │   │   ├── admin/
│   │   │   │   ├── chat/
│   │   │   │   ├── tickets/
│   │   │   │   └── affiliate/
│   │   │   ├── shared/               # Shared components
│   │   │   │   ├── components/
│   │   │   │   ├── hooks/
│   │   │   │   └── utils/
│   │   │   ├── core/                 # Core utilities
│   │   │   │   ├── api/
│   │   │   │   ├── auth/
│   │   │   │   ├── config/
│   │   │   │   └── types/
│   │   │   └── App.tsx
│   │   └── tests/
│   │
│   └── mobile/                       # Future mobile app
│
├── supabase/
│   ├── functions/
│   │   └── api/                      # Main API
│   │       ├── index.ts              # Entry point
│   │       ├── routes/               # API routes
│   │       │   ├── v1/
│   │       │   │   ├── products.ts
│   │       │   │   ├── orders.ts
│   │       │   │   ├── consultations.ts
│   │       │   │   ├── discounts.ts
│   │       │   │   ├── tickets.ts
│   │       │   │   ├── chat.ts
│   │       │   │   ├── affiliate.ts
│   │       │   │   ├── recommendations.ts
│   │       │   │   └── ai.ts
│   │       │   └── v2/
│   │       │
│   │       ├── services/             # Business logic
│   │       │   ├── core/
│   │       │   │   ├── ProductService.ts
│   │       │   │   ├── OrderService.ts
│   │       │   │   ├── CustomerService.ts
│   │       │   │   └── ConsultationService.ts
│   │       │   ├── ecommerce/
│   │       │   │   ├── DiscountService.ts
│   │       │   │   ├── PaymentService.ts
│   │       │   │   ├── ShippingService.ts
│   │       │   │   └── AffiliateService.ts
│   │       │   ├── ai/
│   │       │   │   ├── RecommendationService.ts
│   │       │   │   ├── AIContentService.ts
│   │       │   │   ├── AISearchService.ts
│   │       │   │   └── AIChatbot.ts
│   │       │   ├── communication/
│   │       │   │   ├── SMSService.ts
│   │       │   │   ├── EmailService.ts
│   │       │   │   └── NotificationService.ts
│   │       │   └── support/
│   │       │       ├── TicketService.ts
│   │       │       ├── ChatService.ts
│   │       │       └── FAQService.ts
│   │       │
│   │       ├── repositories/         # Data access layer
│   │       │   ├── ProductRepository.ts
│   │       │   ├── OrderRepository.ts
│   │       │   ├── CustomerRepository.ts
│   │       │   ├── DiscountRepository.ts
│   │       │   ├── TicketRepository.ts
│   │       │   ├── ChatRepository.ts
│   │       │   └── AffiliateRepository.ts
│   │       │
│   │       ├── middleware/           # API middleware
│   │       │   ├── auth.ts
│   │       │   ├── validation.ts
│   │       │   ├── rateLimit.ts
│   │       │   ├── errorHandler.ts
│   │       │   └── logger.ts
│   │       │
│   │       ├── validators/           # Zod schemas
│   │       │   ├── product.ts
│   │       │   ├── order.ts
│   │       │   ├── discount.ts
│   │       │   └── ticket.ts
│   │       │
│   │       ├── types/                # TypeScript types
│   │       │   ├── entities/
│   │       │   ├── dtos/
│   │       │   └── responses/
│   │       │
│   │       └── utils/                # Utilities
│   │           ├── cache.ts
│   │           ├── encryption.ts
│   │           ├── helpers.ts
│   │           └── constants.ts
│   │
│   └── migrations/                   # Database migrations
│       ├── 001_initial_schema.sql
│       ├── 002_add_discounts.sql
│       ├── 003_add_tickets.sql
│       ├── 004_add_chat.sql
│       ├── 005_add_affiliate.sql
│       └── 006_add_ai_features.sql
│
├── workers/                          # Background workers
│   ├── sms-worker/
│   │   └── index.ts
│   ├── email-worker/
│   │   └── index.ts
│   ├── recommendation-worker/
│   │   └── index.ts
│   └── media-generation-worker/
│       └── index.ts
│
├── scripts/                          # Utility scripts
│   ├── seed-database.ts
│   ├── migrate-data.ts
│   └── test-integrations.ts
│
├── docs/                             # Documentation
│   ├── api/
│   ├── architecture/
│   ├── deployment/
│   └── guides/
│
├── shared/                           # Shared code
│   ├── types/
│   ├── utils/
│   └── constants/
│
└── tests/                            # Tests
    ├── unit/
    ├── integration/
    └── e2e/
```

---

## 4️⃣ طراحی دیتابیس

### 4.1 جداول اصلی (Core Tables)

```sql
-- Categories
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID REFERENCES categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  image_url TEXT,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_categories_slug ON categories(slug);

-- Products
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES categories(id),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  long_description TEXT,
  price DECIMAL(12, 2) NOT NULL,
  compare_at_price DECIMAL(12, 2),
  cost DECIMAL(12, 2),
  stock INTEGER NOT NULL DEFAULT 0,
  sku TEXT UNIQUE,
  images TEXT[] DEFAULT '{}',
  ingredients TEXT[],
  properties TEXT[],
  tags TEXT[],
  weight DECIMAL(10, 2),
  dimensions JSONB, -- {width, height, length, unit}
  is_featured BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  meta_title TEXT,
  meta_description TEXT,
  meta_keywords TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_slug ON products(slug);
CREATE INDEX idx_products_sku ON products(sku);
CREATE INDEX idx_products_featured ON products(is_featured) WHERE is_featured = true;

-- Product Variants (برای محصولات با سایز/رنگ مختلف)
CREATE TABLE product_variants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  sku TEXT UNIQUE,
  price DECIMAL(12, 2),
  stock INTEGER DEFAULT 0,
  options JSONB, -- {size: "250ml", color: "blue"}
  image_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_variants_product ON product_variants(product_id);
```

### 4.2 جداول سفارش (Order Tables)

```sql
-- Orders
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT UNIQUE NOT NULL,
  customer_id UUID REFERENCES customers(id),
  
  -- Order totals
  subtotal DECIMAL(12, 2) NOT NULL,
  discount_amount DECIMAL(12, 2) DEFAULT 0,
  shipping_cost DECIMAL(12, 2) DEFAULT 0,
  tax_amount DECIMAL(12, 2) DEFAULT 0,
  total DECIMAL(12, 2) NOT NULL,
  
  -- Status
  status order_status DEFAULT 'pending',
  payment_status payment_status DEFAULT 'pending',
  fulfillment_status fulfillment_status DEFAULT 'unfulfilled',
  
  -- Customer info
  customer_name TEXT NOT NULL,
  customer_email TEXT,
  customer_mobile TEXT NOT NULL,
  
  -- Shipping address
  shipping_address JSONB NOT NULL,
  
  -- Billing address (optional, defaults to shipping)
  billing_address JSONB,
  
  -- Payment
  payment_method TEXT, -- zarinpal, card_to_card, cash_on_delivery
  payment_info JSONB,
  
  -- Discount
  discount_code TEXT,
  discount_id UUID REFERENCES discounts(id),
  
  -- Affiliate
  affiliate_id UUID REFERENCES affiliates(id),
  referral_code TEXT,
  
  -- Notes
  customer_note TEXT,
  admin_note TEXT,
  
  -- Tracking
  tracking_number TEXT,
  tracking_url TEXT,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  paid_at TIMESTAMPTZ,
  shipped_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ
);

CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at DESC);

-- Order Items
CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id),
  variant_id UUID REFERENCES product_variants(id),
  
  title TEXT NOT NULL,
  variant_title TEXT,
  sku TEXT,
  price DECIMAL(12, 2) NOT NULL,
  quantity INTEGER NOT NULL,
  subtotal DECIMAL(12, 2) NOT NULL,
  
  -- Snapshot of product at time of purchase
  product_snapshot JSONB,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);

-- Order Status History
CREATE TABLE order_status_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status order_status NOT NULL,
  comment TEXT,
  notify_customer BOOLEAN DEFAULT false,
  created_by UUID, -- admin user id
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_order_history_order ON order_status_history(order_id);
```

### 4.3 جداول کد تخفیف (Discount Tables)

```sql
-- Discounts
CREATE TABLE discounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  description TEXT,
  
  -- Type
  discount_type discount_type NOT NULL, -- percentage, fixed_amount, free_shipping
  value DECIMAL(12, 2) NOT NULL, -- percentage (0-100) or fixed amount
  
  -- Conditions
  min_purchase DECIMAL(12, 2), -- Minimum purchase amount
  max_discount DECIMAL(12, 2), -- Maximum discount amount (for percentage)
  
  -- Applicable to
  applies_to applies_to_type DEFAULT 'all', -- all, specific_products, specific_categories
  product_ids UUID[],
  category_ids UUID[],
  
  -- Usage limits
  max_uses INTEGER, -- Total uses allowed
  max_uses_per_customer INTEGER DEFAULT 1,
  usage_count INTEGER DEFAULT 0,
  
  -- Customer restrictions
  customer_eligibility customer_eligibility DEFAULT 'all', -- all, specific_customers, customer_groups
  eligible_customer_ids UUID[],
  
  -- Date restrictions
  starts_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID -- admin user id
);

CREATE INDEX idx_discounts_code ON discounts(code);
CREATE INDEX idx_discounts_active ON discounts(is_active) WHERE is_active = true;

-- Discount Usage
CREATE TABLE discount_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discount_id UUID NOT NULL REFERENCES discounts(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES customers(id),
  order_id UUID REFERENCES orders(id),
  amount DECIMAL(12, 2) NOT NULL,
  used_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_discount_usage_discount ON discount_usage(discount_id);
CREATE INDEX idx_discount_usage_customer ON discount_usage(customer_id);
```

### 4.4 جداول پشتیبانی (Support Tables)

```sql
-- Tickets
CREATE TABLE tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number TEXT UNIQUE NOT NULL,
  customer_id UUID REFERENCES customers(id),
  
  -- Ticket info
  subject TEXT NOT NULL,
  category ticket_category,
  priority ticket_priority DEFAULT 'normal',
  status ticket_status DEFAULT 'open',
  
  -- Assignment
  assigned_to UUID, -- admin user id
  assigned_at TIMESTAMPTZ,
  
  -- Metadata
  tags TEXT[],
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  closed_at TIMESTAMPTZ,
  last_reply_at TIMESTAMPTZ,
  last_reply_by TEXT -- 'customer' or 'admin'
);

CREATE INDEX idx_tickets_customer ON tickets(customer_id);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_assigned ON tickets(assigned_to);

-- Ticket Messages
CREATE TABLE ticket_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  sender_id UUID,
  sender_type sender_type NOT NULL, -- customer, admin, system
  message TEXT NOT NULL,
  attachments TEXT[],
  is_internal BOOLEAN DEFAULT false, -- Internal note, not visible to customer
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_ticket_messages_ticket ON ticket_messages(ticket_id);

-- Chats
CREATE TABLE chats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES customers(id),
  assigned_to UUID, -- admin user id or 'ai-bot'
  status chat_status DEFAULT 'waiting',
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  rating INTEGER, -- 1-5
  feedback TEXT
);

CREATE INDEX idx_chats_customer ON chats(customer_id);
CREATE INDEX idx_chats_status ON chats(status);

-- Chat Messages
CREATE TABLE chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id UUID,
  sender_type sender_type NOT NULL, -- customer, agent, bot
  message TEXT NOT NULL,
  metadata JSONB, -- For rich content
  sent_at TIMESTAMPTZ DEFAULT NOW(),
  read_at TIMESTAMPTZ
);

CREATE INDEX idx_chat_messages_chat ON chat_messages(chat_id);
```

### 4.5 جداول همکاری در فروش (Affiliate Tables)

```sql
-- Affiliates
CREATE TABLE affiliates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES customers(id),
  referral_code TEXT UNIQUE NOT NULL,
  commission_rate DECIMAL(5, 4) NOT NULL DEFAULT 0.1, -- 10%
  
  -- Status
  status affiliate_status DEFAULT 'active',
  
  -- Payment info
  payment_method TEXT, -- bank_transfer, wallet
  bank_info JSONB,
  
  -- Stats
  total_referrals INTEGER DEFAULT 0,
  total_sales DECIMAL(12, 2) DEFAULT 0,
  total_commission DECIMAL(12, 2) DEFAULT 0,
  paid_commission DECIMAL(12, 2) DEFAULT 0,
  pending_commission DECIMAL(12, 2) DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_affiliates_user ON affiliates(user_id);
CREATE INDEX idx_affiliates_code ON affiliates(referral_code);

-- Affiliate Commissions
CREATE TABLE affiliate_commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_id UUID NOT NULL REFERENCES affiliates(id) ON DELETE CASCADE,
  order_id UUID NOT NULL REFERENCES orders(id),
  
  amount DECIMAL(12, 2) NOT NULL,
  commission_rate DECIMAL(5, 4) NOT NULL,
  
  status commission_status DEFAULT 'pending',
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  paid_at TIMESTAMPTZ
);

CREATE INDEX idx_commissions_affiliate ON affiliate_commissions(affiliate_id);
CREATE INDEX idx_commissions_order ON affiliate_commissions(order_id);
CREATE INDEX idx_commissions_status ON affiliate_commissions(status);
```

### 4.6 جداول هوش مصنوعی (AI Tables)

```sql
-- Customer Behavior (for recommendations)
CREATE TABLE customer_behavior (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  event_type behavior_event_type NOT NULL,
  event_data JSONB NOT NULL,
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_behavior_customer ON customer_behavior(customer_id);
CREATE INDEX idx_behavior_type ON customer_behavior(event_type);
CREATE INDEX idx_behavior_timestamp ON customer_behavior(timestamp DESC);

-- AI Generated Content
CREATE TABLE ai_generated_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_type ai_content_type NOT NULL,
  related_entity_type TEXT, -- product, consultation, etc.
  related_entity_id UUID,
  
  prompt TEXT NOT NULL,
  generated_content TEXT NOT NULL,
  model_used TEXT, -- gpt-4, gpt-3.5-turbo, etc.
  tokens_used INTEGER,
  
  status content_status DEFAULT 'draft',
  
  reviewed_by UUID, -- admin user id
  published_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_ai_content_entity ON ai_generated_content(related_entity_type, related_entity_id);
CREATE INDEX idx_ai_content_status ON ai_generated_content(status);

-- Product Recommendations
CREATE TABLE product_recommendations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  recommended_product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  
  recommendation_type recommendation_type NOT NULL,
  score DECIMAL(5, 4), -- 0-1 confidence score
  
  -- Context
  based_on JSONB, -- What this recommendation is based on
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(product_id, recommended_product_id, recommendation_type)
);

CREATE INDEX idx_recommendations_product ON product_recommendations(product_id);
CREATE INDEX idx_recommendations_type ON product_recommendations(recommendation_type);
```

### 4.7 جداول ارتباطات (Communication Tables)

```sql
-- SMS Logs
CREATE TABLE sms_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone TEXT NOT NULL,
  message TEXT NOT NULL,
  
  type sms_type NOT NULL, -- otp, notification, marketing, manual
  related_entity_type TEXT,
  related_entity_id UUID,
  
  status sms_status DEFAULT 'pending',
  provider_id TEXT, -- ID from SMS provider
  cost DECIMAL(10, 2),
  error TEXT,
  
  sent_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sms_phone ON sms_logs(phone);
CREATE INDEX idx_sms_status ON sms_logs(status);
CREATE INDEX idx_sms_type ON sms_logs(type);

-- SMS Templates
CREATE TABLE sms_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL,
  type sms_type NOT NULL,
  content TEXT NOT NULL,
  variables TEXT[], -- List of variables in template
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Email Logs
CREATE TABLE email_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  to_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  
  type email_type NOT NULL,
  related_entity_type TEXT,
  related_entity_id UUID,
  
  status email_status DEFAULT 'pending',
  provider_id TEXT,
  error TEXT,
  
  sent_at TIMESTAMPTZ,
  opened_at TIMESTAMPTZ,
  clicked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_email_to ON email_logs(to_email);
CREATE INDEX idx_email_status ON email_logs(status);
CREATE INDEX idx_email_type ON email_logs(type);

-- Email Templates
CREATE TABLE email_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL,
  type email_type NOT NULL,
  subject TEXT NOT NULL,
  html_content TEXT NOT NULL,
  text_content TEXT,
  variables TEXT[],
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 4.8 Enums

```sql
-- Order statuses
CREATE TYPE order_status AS ENUM (
  'pending',
  'processing',
  'shipped',
  'delivered',
  'cancelled',
  'refunded'
);

CREATE TYPE payment_status AS ENUM (
  'pending',
  'paid',
  'failed',
  'refunded',
  'partially_refunded'
);

CREATE TYPE fulfillment_status AS ENUM (
  'unfulfilled',
  'partially_fulfilled',
  'fulfilled',
  'restocked'
);

-- Discount types
CREATE TYPE discount_type AS ENUM (
  'percentage',
  'fixed_amount',
  'free_shipping'
);

CREATE TYPE applies_to_type AS ENUM (
  'all',
  'specific_products',
  'specific_categories'
);

CREATE TYPE customer_eligibility AS ENUM (
  'all',
  'specific_customers',
  'customer_groups'
);

-- Support
CREATE TYPE ticket_category AS ENUM (
  'product_inquiry',
  'order_issue',
  'shipping',
  'payment',
  'return_refund',
  'technical',
  'other'
);

CREATE TYPE ticket_priority AS ENUM (
  'low',
  'normal',
  'high',
  'urgent'
);

CREATE TYPE ticket_status AS ENUM (
  'open',
  'in_progress',
  'waiting_customer',
  'resolved',
  'closed'
);

CREATE TYPE chat_status AS ENUM (
  'waiting',
  'active',
  'ended'
);

CREATE TYPE sender_type AS ENUM (
  'customer',
  'admin',
  'agent',
  'bot',
  'system'
);

-- Affiliate
CREATE TYPE affiliate_status AS ENUM (
  'pending',
  'active',
  'suspended',
  'terminated'
);

CREATE TYPE commission_status AS ENUM (
  'pending',
  'approved',
  'paid',
  'cancelled'
);

-- AI & Behavior
CREATE TYPE behavior_event_type AS ENUM (
  'view_product',
  'add_to_cart',
  'remove_from_cart',
  'purchase',
  'search',
  'view_category',
  'like',
  'review'
);

CREATE TYPE ai_content_type AS ENUM (
  'article',
  'product_description',
  'email',
  'sms',
  'social_media_post'
);

CREATE TYPE content_status AS ENUM (
  'draft',
  'reviewed',
  'published',
  'archived'
);

CREATE TYPE recommendation_type AS ENUM (
  'frequently_bought_together',
  'similar_products',
  'based_on_view_history',
  'based_on_purchase_history',
  'consultation_based',
  'trending',
  'personalized'
);

-- Communication
CREATE TYPE sms_type AS ENUM (
  'otp',
  'notification',
  'marketing',
  'manual',
  'transactional'
);

CREATE TYPE sms_status AS ENUM (
  'pending',
  'sent',
  'delivered',
  'failed'
);

CREATE TYPE email_type AS ENUM (
  'order_confirmation',
  'shipping_notification',
  'newsletter',
  'marketing',
  'transactional',
  'password_reset'
);

CREATE TYPE email_status AS ENUM (
  'pending',
  'sent',
  'delivered',
  'opened',
  'clicked',
  'bounced',
  'failed'
);
```

---

## 5️⃣ لایه سرویس‌ها

[بخش قبلی را ببینید - همه سرویس‌ها شرح داده شده‌اند]

---

## 6️⃣ لایه API

### 6.1 API Versioning Strategy

```typescript
// /api-gateway/routes/index.ts
import { Hono } from 'npm:hono';
import v1Routes from './v1/index.ts';
import v2Routes from './v2/index.ts';

const api = new Hono();

// Version 1 (current)
api.route('/v1', v1Routes);

// Version 2 (future)
api.route('/v2', v2Routes);

// Default to latest version
api.route('/', v1Routes);

export default api;
```

### 6.2 Rate Limiting Strategy

```typescript
// Different rate limits for different endpoints
const rateLimits = {
  '/products': { points: 100, duration: 60 },
  '/search': { points: 20, duration: 60 },
  '/ai/generate': { points: 5, duration: 60 },
  '/admin/*': { points: 1000, duration: 60 },
};
```

---

## 7️⃣ سرویس‌های خارجی

### 7.1 OpenAI Integration

```typescript
// /services/ai/OpenAIClient.ts
import OpenAI from 'npm:openai';

export class OpenAIClient {
  private client: OpenAI;

  constructor() {
    this.client = new OpenAI({
      apiKey: Deno.env.get('OPENAI_API_KEY'),
    });
  }

  async generateText(options: GenerateTextOptions): Promise<TextResponse> {
    const completion = await this.client.chat.completions.create({
      model: options.model || 'gpt-4',
      messages: [{ role: 'user', content: options.prompt }],
      max_tokens: options.maxTokens,
      temperature: options.temperature || 0.7,
    });

    return {
      text: completion.choices[0].message.content,
      usage: completion.usage,
    };
  }

  async createEmbedding(options: CreateEmbeddingOptions): Promise<EmbeddingResponse> {
    const response = await this.client.embeddings.create({
      model: options.model || 'text-embedding-ada-002',
      input: options.input,
    });

    return response;
  }

  async generateImage(options: GenerateImageOptions): Promise<ImageResponse> {
    const response = await this.client.images.generate({
      prompt: options.prompt,
      n: 1,
      size: '1024x1024',
    });

    return {
      url: response.data[0].url,
    };
  }
}
```

### 7.2 Payment Gateways

```typescript
// /services/payment/PaymentGateway.ts
export interface PaymentGateway {
  createPayment(amount: number, orderId: string): Promise<PaymentResult>;
  verifyPayment(authority: string): Promise<VerificationResult>;
}

// Zarinpal
export class ZarinpalGateway implements PaymentGateway {
  async createPayment(amount: number, orderId: string): Promise<PaymentResult> {
    // Implementation
  }
  
  async verifyPayment(authority: string): Promise<VerificationResult> {
    // Implementation
  }
}

// Strategy pattern for multiple gateways
export class PaymentService {
  private gateways: Map<string, PaymentGateway>;

  constructor() {
    this.gateways = new Map([
      ['zarinpal', new ZarinpalGateway()],
      // Add more gateways as needed
    ]);
  }

  async processPayment(
    method: string,
    amount: number,
    orderId: string
  ): Promise<PaymentResult> {
    const gateway = this.gateways.get(method);
    if (!gateway) {
      throw new Error(`Payment gateway ${method} not supported`);
    }
    
    return await gateway.createPayment(amount, orderId);
  }
}
```

---

## 8️⃣ صف پیام و Workers

### 8.1 Queue Architecture

```typescript
// /workers/queue/QueueService.ts
import { Queue, Worker } from 'npm:bullmq';
import Redis from 'npm:ioredis';

const redis = new Redis(Deno.env.get('REDIS_URL')!);

// Define queues
export const queues = {
  sms: new Queue('sms', { connection: redis }),
  email: new Queue('email', { connection: redis }),
  recommendations: new Queue('recommendations', { connection: redis }),
  mediaGeneration: new Queue('media-generation', { connection: redis }),
};

// SMS Worker
const smsWorker = new Worker(
  'sms',
  async (job) => {
    const { phone, message, type } = job.data;
    // Process SMS
    await smsService.send(phone, message);
  },
  { connection: redis, concurrency: 10 }
);

// Email Worker
const emailWorker = new Worker(
  'email',
  async (job) => {
    const { to, subject, html } = job.data;
    // Process email
    await emailService.send({ to, subject, html });
  },
  { connection: redis, concurrency: 5 }
);

// Recommendations Worker
const recommendationsWorker = new Worker(
  'recommendations',
  async (job) => {
    const { customerId } = job.data;
    // Update recommendations
    await recommendationService.updateForCustomer(customerId);
  },
  { connection: redis, concurrency: 2 }
);

// Media Generation Worker
const mediaWorker = new Worker(
  'media-generation',
  async (job) => {
    const { type, productId } = job.data;
    
    if (type === 'image') {
      await aiContentService.generateProductImage(productId);
    } else if (type === 'article') {
      await aiContentService.generateArticleForProduct(productId);
    } else if (type === 'video') {
      await aiContentService.generateProductVideo(productId);
    }
  },
  { connection: redis, concurrency: 1 } // Limit AI jobs
);
```

---

## 9️⃣ پشته فناوری

### 9.1 Frontend Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| React | 18.3+ | UI Framework |
| TypeScript | 5.3+ | Type Safety |
| Vite | 5.0+ | Build Tool |
| React Query | 5.0+ | Server State |
| Zustand | 4.4+ | Client State |
| React Router | 6.20+ | Routing |
| Tailwind CSS | 3.4+ | Styling |
| React Hook Form | 7.55+ | Forms |
| Zod | 3.22+ | Validation |
| Socket.io Client | 4.6+ | Real-time (Chat) |

### 9.2 Backend Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| Deno | Latest | Runtime |
| Hono.js | 4.0+ | Web Framework |
| Supabase | Latest | BaaS Platform |
| PostgreSQL | 15+ | Database |
| Redis | 7.0+ | Cache & Queue |
| BullMQ | 5.0+ | Job Queue |

### 9.3 AI/ML Stack

| Technology | Purpose |
|-----------|---------|
| OpenAI GPT-4 | Text Generation |
| OpenAI Ada-002 | Embeddings |
| Stable Diffusion | Image Generation |
| Pinecone | Vector Database |

### 9.4 External Services

| Service | Purpose |
|---------|---------|
| Zarinpal | Payment Gateway |
| Niazpardaz | SMS Provider |
| Resend/SendGrid | Email Provider |
| Cloudflare | CDN & Security |
| Sentry | Error Tracking |
| Google Analytics 4 | Analytics |

---

## 🔟 نقشه راه پیاده‌سازی

### Phase 1: Foundation (هفته‌های 1-2)

**وزن:** 15%

✅ تکمیل شده:
- ✅ ساختار پوشه‌ها و معماری پایه
- ✅ تنظیم TypeScript و ESLint
- ✅ راه‌اندازی Supabase
- ✅ ساخت جداول اصلی (products, orders, customers)

⬜️ باقیمانده:
- ⬜️ ساخت جداول جدید (discounts, tickets, chat, affiliate)
- ⬜️ راه‌اندازی Redis
- ⬜️ راه‌اندازی Queue System (BullMQ)
- ⬜️ پیاده‌سازی Authentication & Authorization

### Phase 2: Core Features Enhancement (هفته‌های 3-4)

**وزن:** 20%

- ⬜️ سیستم کد تخفیف کامل
  - ⬜️ Backend: DiscountService + Repository
  - ⬜️ Frontend: صفحه مدیریت کدهای تخفیف
  - ⬜️ Validation و Testing

- ⬜️ بهبود سیستم سفارش
  - ⬜️ وضعیت‌های پیشرفته
  - ⬜️ Tracking سفارش
  - ⬜️ مدیریت مرجوعی

### Phase 3: AI Features - Part 1 (هفته‌های 5-6)

**وزن:** 25%

- ⬜️ سیستم توصیه محصول
  - ⬜️ RecommendationService
  - ⬜️ ثبت رفتار کاربر
  - ⬜️ الگوریتم‌های توصیه (Collaborative + Content-based)
  - ⬜️ نمایش در frontend

- ⬜️ جستجوی هوشمند
  - ⬜️ AISearchService
  - ⬜️ راه‌اندازی Vector Database (Pinecone)
  - ⬜️ Semantic Search
  - ⬜️ Conversational Search

### Phase 4: Support Systems (هفته‌های 7-8)

**وزن:** 20%

- ⬜️ سیستم تیکت
  - ⬜️ TicketService + Repository
  - ⬜️ صفحه تیکت‌های کاربر
  - ⬜️ پنل مدیریت تیکت‌ها
  - ⬜️ اعلان‌رسانی

- ⬜️ سیستم چت آنلاین
  - ⬜️ ChatService
  - ⬜️ WebSocket Integration
  - ⬜️ AI Chatbot (پاسخ‌گوی خودکار)
  - ⬜️ انتقال به کارشناس

### Phase 5: AI Features - Part 2 (هفته‌های 9-10)

**وزن:** 30%

- ⬜️ تولید محتوا با AI
  - ⬜️ AIContentService
  - ⬜️ تولید مقاله از روی محصول
  - ⬜️ تولید توضیحات محصول
  - ⬜️ بهبود SEO با AI

- ⬜️ تولید رسانه با AI
  - ⬜️ تولید تصویر محصول
  - ⬜️ تولید ویدیو تبلیغاتی
  - ⬜️ تولید محتوای شبکه‌های اجتماعی

### Phase 6: Marketing & Affiliate (هفته‌های 11-12)

**وزن:** 15%

- ⬜️ سیستم همکاری در فروش
  - ⬜️ AffiliateService
  - ⬜️ صفحه ثبت‌نام همکار
  - ⬜️ داشبورد همکار
  - ⬜️ محاسبه و پرداخت کمیسیون

- ⬜️ سیستم پیامک و ایمیل پیشرفته
  - ⬜️ Template Management
  - ⬜️ Campaign Management
  - ⬜️ Scheduling
  - ⬜️ Analytics

### Phase 7: Testing & Optimization (هفته‌های 13-14)

**وزن:** 10%

- ⬜️ Unit Tests (80%+ coverage)
- ⬜️ Integration Tests
- ⬜️ E2E Tests
- ⬜️ Performance Optimization
- ⬜️ Security Audit
- ⬜️ Load Testing

### Phase 8: Documentation & Deployment (هفته 15)

**وزن:** 5%

- ⬜️ API Documentation (OpenAPI/Swagger)
- ⬜️ Architecture Documentation
- ⬜️ Deployment Guide
- ⬜️ User Manual
- ⬜️ Admin Manual

---

## 📊 تخمین زمان کلی

```
┌──────────────────────────────────────────────────┐
│  مجموع زمان پیاده‌سازی: 15 هفته (3.5 ماه)      │
│  تیم پیشنهادی:                                   │
│    - 2 Frontend Developer                        │
│    - 2 Backend Developer                         │
│    - 1 DevOps Engineer (part-time)               │
│    - 1 QA Engineer                               │
│    - 1 Product Manager                           │
│    - 1 UI/UX Designer (part-time)                │
└──────────────────────────────────────────────────┘
```

---

## 🎯 اولویت‌بندی Features

### Must Have (ضروری - Phase 1-4)
1. ✅ سیستم محصول و سفارش (موجود)
2. ⬜️ سیستم کد تخفیف
3. ⬜️ سیستم تیکت و پشتیبانی
4. ⬜️ توصیه محصول (پایه)

### Should Have (مهم - Phase 5-6)
1. ⬜️ چت آنلاین
2. ⬜️ سیستم همکاری در فروش
3. ⬜️ جستجوی هوشمند
4. ⬜️ تولید محتوا با AI (مقاله)

### Nice to Have (مفید - Phase 6-7)
1. ⬜️ تولید تصویر با AI
2. ⬜️ تولید ویدیو با AI
3. ⬜️ پیامک و ایمیل پیشرفته
4. ⬜️ Conversational Search

---

## 🔐 Security Considerations

1. **Authentication:**
   - JWT با refresh token
   - MFA برای admin panel
   - Rate limiting برای login attempts

2. **Authorization:**
   - Role-based access control (RBAC)
   - Row-level security در Supabase

3. **Data Protection:**
   - Encryption at rest
   - Encryption in transit (HTTPS)
   - حذف ایمن داده‌های حساس

4. **API Security:**
   - CORS configuration
   - API key rotation
   - Input validation (Zod)
   - SQL injection prevention
   - XSS prevention

5. **Compliance:**
   - GDPR compliance
   - PCI DSS (برای پرداخت)
   - لاگ audit trail

---

## 📈 Monitoring & Analytics

1. **Application Monitoring:**
   - Sentry for error tracking
   - Performance monitoring
   - Uptime monitoring

2. **Business Analytics:**
   - Google Analytics 4
   - Custom event tracking
   - Conversion funnel analysis

3. **Infrastructure Monitoring:**
   - Database performance
   - API response times
   - Queue health
   - Cache hit rates

---

## 💡 نکات مهم

1. **Scalability:**
   - طراحی برای 10,000+ کاربر همزمان
   - Horizontal scaling برای API
   - Database replication
   - CDN برای static assets

2. **Maintainability:**
   - Clean Code principles
   - SOLID principles
   - Comprehensive documentation
   - Automated testing

3. **Performance:**
   - Caching strategy (Redis)
   - Database indexing
   - Lazy loading
   - Image optimization
   - Code splitting

4. **Cost Optimization:**
   - API call caching
   - Efficient queue processing
   - Database query optimization
   - CDN usage optimization

---

**تهیه شده توسط:** تیم فنی Oil Global  
**آخرین بروزرسانی:** دی ۱۴۰۳  
**نسخه:** 3.0
