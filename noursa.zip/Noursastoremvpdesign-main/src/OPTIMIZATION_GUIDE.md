# 🚀 راهنمای جامع بهینه‌سازی فروشگاه Nursaa

> **آخرین به‌روزرسانی**: دسامبر 2025  
> **وضعیت فعلی**: Production-Ready  
> **اولویت**: بهینه‌سازی مستمر برای افزایش سرعت و کاهش هزینه‌ها

---

## 📋 فهرست مطالب

1. [خلاصه اجرایی](#-خلاصه-اجرایی)
2. [بهینه‌سازی Frontend](#-بهینه-سازی-frontend)
3. [بهینه‌سازی Backend](#-بهینه-سازی-backend)
4. [بهینه‌سازی Database](#-بهینه-سازی-database)
5. [بهینه‌سازی Assets و Media](#-بهینه-سازی-assets-و-media)
6. [استراتژی‌های Caching](#-استراتژی-های-caching)
7. [بهبود SEO و Performance](#-بهبود-seo-و-performance)
8. [امنیت و Best Practices](#-امنیت-و-best-practices)
9. [Monitoring و Analytics](#-monitoring-و-analytics)
10. [پلن اجرایی](#-پلن-اجرایی)

---

## 🎯 خلاصه اجرایی

### وضعیت فعلی
- ✅ **ساختار کد**: مرتب و قابل نگهداری
- ✅ **Performance**: خوب (اما قابل بهبود)
- ⚠️ **Bundle Size**: قابل کاهش (~30% بهینه‌سازی ممکن است)
- ⚠️ **Caching**: نیازمند بهبود
- ⚠️ **Database Queries**: نیاز به optimization

### اهداف بهینه‌سازی
| شاخص | فعلی | هدف | بهبود |
|------|------|-----|-------|
| First Contentful Paint (FCP) | ~1.8s | <1.2s | 33% ⬇️ |
| Largest Contentful Paint (LCP) | ~2.5s | <2.0s | 20% ⬇️ |
| Time to Interactive (TTI) | ~3.2s | <2.5s | 22% ⬇️ |
| Bundle Size (gzipped) | ~180KB | <120KB | 33% ⬇️ |
| API Response Time | ~300ms | <150ms | 50% ⬇️ |

---

## 🎨 بهینه‌سازی Frontend

### 1. کاهش حجم Bundle (Priority: HIGH 🔴)

#### 1.1 Code Splitting
**مشکل فعلی**: تمام کد در یک bundle بارگذاری می‌شود

**راه‌حل**:
```tsx
// ❌ قبل - همه کامپوننت‌ها eager load می‌شوند
import { ProductsPage } from './components/pages/ProductsPage';
import { AdminDashboard } from './components/admin/AdminDashboard';

// ✅ بعد - lazy loading برای صفحات بزرگ
import { lazy, Suspense } from 'react';

const ProductsPage = lazy(() => import('./components/pages/ProductsPage'));
const AdminDashboard = lazy(() => import('./components/admin/AdminDashboard'));
const ConsultationForm = lazy(() => import('./components/ConsultationForm'));
const ArticlePage = lazy(() => import('./components/pages/ArticlePage'));

// در App.tsx
<Suspense fallback={<LoadingSpinner />}>
  <Route path="/products" element={<ProductsPage />} />
</Suspense>
```

**تاثیر**: کاهش 40-50KB از initial bundle

---

#### 1.2 Tree Shaking برای کتابخانه‌ها
**مشکل**: import کامل کتابخانه‌های بزرگ

**راه‌حل**:
```tsx
// ❌ قبل
import _ from 'lodash';

// ✅ بعد
import debounce from 'lodash/debounce';
import throttle from 'lodash/throttle';

// یا بهتر: از ابزارهای native استفاده کنید
const debounce = (fn, delay) => {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), delay);
  };
};
```

**کتابخانه‌های قابل بهینه‌سازی**:
- `lucide-react`: فقط آیکون‌های مورد استفاده را import کنید ✅ (قبلاً اعمال شده)
- `recharts`: استفاده نکنید مگر واقعاً نیاز باشد
- `date-fns`: فقط توابع مورد نیاز

**تاثیر**: کاهش 20-30KB

---

#### 1.3 حذف کدهای تکراری (Code Deduplication)

**فایل‌های تکراری که باید یکی شوند**:

```typescript
// ❌ تکراری - ADMIN_PHONES در 5 فایل مختلف تعریف شده
// /components/Header.tsx
// /components/admin/AdminLayout.tsx  
// /components/admin/AdminTopBar.tsx
// /components/admin/ProtectedAdminRoute.tsx
// /supabase/functions/server/constants.ts

// ✅ راه‌حل: یک فایل مشترک
// /src/constants/admin.ts
export const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
] as const;

export type AdminPhone = typeof ADMIN_PHONES[number];

export const isAdminPhone = (phone: string): phone is AdminPhone => {
  return ADMIN_PHONES.includes(phone as AdminPhone);
};
```

**تاثیر**: کاهش 2-3KB + بهبود maintainability

---

### 2. بهینه‌سازی Re-renders (Priority: HIGH 🔴)

#### 2.1 استفاده از React.memo برای کامپوننت‌های سنگین

```tsx
// ❌ قبل - ProductCard در هر تغییر parent re-render می‌شود
export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (...)
}

// ✅ بعد
export const ProductCard = React.memo(({ 
  product, 
  onAddToCart 
}: ProductCardProps) => {
  return (...)
}, (prevProps, nextProps) => {
  // فقط اگر product یا onAddToCart تغییر کرد، re-render کن
  return prevProps.product.product_id === nextProps.product.product_id &&
         prevProps.onAddToCart === nextProps.onAddToCart;
});
```

**کامپوننت‌های نیازمند memo**:
- `ProductCard` ✅ (اولویت بالا)
- `CategoryCard`
- `CartItem`
- `ArticleCard`
- `OrderRow` (در پنل ادمین)

**تاثیر**: کاهش 50-70% re-renders غیرضروری

---

#### 2.2 استفاده از useCallback برای event handlers

```tsx
// ❌ قبل - هر render یک function جدید ساخته می‌شود
const handleAddToCart = (product) => {
  addItem(product);
  toast.success('محصول اضافه شد');
};

// ✅ بعد
const handleAddToCart = useCallback((product: Product) => {
  addItem(product);
  toast.success('محصول اضافه شد');
}, [addItem]); // فقط وقتی addItem تغییر کند، function جدید بساز
```

**تاثیر**: بهبود performance در لیست‌های بزرگ

---

#### 2.3 استفاده از useMemo برای محاسبات سنگین

```tsx
// فایل: /components/pages/ProductsPage.tsx

// ✅ خوب - قبلاً از useMemo استفاده شده
const sortedAndFilteredProducts = useMemo(() => {
  let result = [...products];
  
  if (selectedCategory) {
    result = result.filter(p => p.category_id === selectedCategory);
  }
  
  if (searchQuery) {
    result = result.filter(p => 
      p.product_name.includes(searchQuery) ||
      p.short_description?.includes(searchQuery)
    );
  }
  
  return result.sort((a, b) => b.score - a.score);
}, [products, selectedCategory, searchQuery, sortBy]);
```

**موارد دیگر برای useMemo**:
- محاسبات قیمت در `CartContext`
- فیلتر کردن مقالات در `ArticlesPage`
- محاسبات آماری در پنل ادمین

---

### 3. بهینه‌سازی Context API (Priority: MEDIUM 🟡)

#### 3.1 تقسیم Context‌های بزرگ

```tsx
// ❌ مشکل فعلی - CartContext شامل همه چیز است
// هر تغییر کوچک باعث re-render همه consumer ها می‌شود

// ✅ راه‌حل: تقسیم به context های کوچکتر
// /contexts/CartItemsContext.tsx
const CartItemsContext = createContext<CartItem[]>([]);

// /contexts/CartActionsContext.tsx  
const CartActionsContext = createContext<{
  addItem: (product: Product) => void;
  removeItem: (id: number) => void;
  updateQuantity: (id: number, qty: number) => void;
}>({} as any);

// /contexts/CartTotalsContext.tsx
const CartTotalsContext = createContext<{
  subtotal: number;
  shipping: number;
  total: number;
}>({} as any);

// کامپوننتی که فقط به actions نیاز دارد، re-render نمی‌شود وقتی items تغییر می‌کند
function AddToCartButton() {
  const { addItem } = useContext(CartActionsContext); // ✅ فقط این context
  // ...
}
```

**تاثیر**: کاهش 60-80% re-renders غیرضروری در کامپوننت‌های سبد خرید

---

### 4. بهینه‌سازی Images (Priority: HIGH 🔴)

#### 4.1 استفاده از WebP و srcset

```tsx
// فایل جدید: /components/ResponsiveImage.tsx
interface ResponsiveImageProps {
  src: string;
  alt: string;
  className?: string;
  sizes?: string;
  priority?: boolean;
}

export function ResponsiveImage({ 
  src, 
  alt, 
  className,
  sizes = "100vw",
  priority = false 
}: ResponsiveImageProps) {
  // تبدیل URL به فرمت WebP (اگر Supabase پشتیبانی می‌کند)
  const webpSrc = src.replace(/\.(jpg|jpeg|png)$/, '.webp');
  
  return (
    <picture>
      <source 
        type="image/webp" 
        srcSet={`
          ${webpSrc}?w=400 400w,
          ${webpSrc}?w=800 800w,
          ${webpSrc}?w=1200 1200w
        `}
        sizes={sizes}
      />
      <img 
        src={src} 
        alt={alt} 
        className={className}
        loading={priority ? "eager" : "lazy"}
        decoding={priority ? "sync" : "async"}
      />
    </picture>
  );
}
```

**استفاده**:
```tsx
// ❌ قبل
<img src={product.image_urls[0]} alt={product.product_name} />

// ✅ بعد
<ResponsiveImage 
  src={product.image_urls[0]} 
  alt={product.product_name}
  sizes="(max-width: 768px) 100vw, 33vw"
/>
```

**تاثیر**: کاهش 50-70% حجم تصاویر

---

#### 4.2 Lazy Loading برای تصاویر پایین صفحه

```tsx
// ✅ قبلاً در OptimizedImage.tsx پیاده‌سازی شده
// اما باید برای همه تصاویر به جز hero استفاده شود

// Hero images (above fold)
<OptimizedImage src="..." priority={true} loading="eager" />

// تصاویر محصولات (below fold)
<OptimizedImage src="..." loading="lazy" />
```

**تاثیر**: کاهش 40-60% initial page load time

---

### 5. حذف کدهای غیرضروری (Dead Code Elimination)

#### 5.1 حذف console.log ها در production

```typescript
// فایل: /src/utils/logger.ts
export const logger = {
  log: (...args: any[]) => {
    if (import.meta.env.DEV) {
      console.log(...args);
    }
  },
  error: (...args: any[]) => {
    if (import.meta.env.DEV) {
      console.error(...args);
    }
  },
  warn: (...args: any[]) => {
    if (import.meta.env.DEV) {
      console.warn(...args);
    }
  }
};

// استفاده در کل پروژه
// ❌ قبل
console.log('🛒 Adding product to cart:', product);

// ✅ بعد
logger.log('🛒 Adding product to cart:', product);
```

**تاثیر**: کاهش 5-10KB bundle size

---

#### 5.2 شناسایی کدهای استفاده نشده

**ابزارها**:
```bash
# نصب و اجرای bundle analyzer
npm install --save-dev @rollup/plugin-visualizer

# در vite.config.ts
import { visualizer } from 'rollup-plugin-visualizer';

export default {
  plugins: [
    visualizer({
      open: true,
      gzipSize: true,
      brotliSize: true,
    })
  ]
}
```

**کامپوننت‌های احتمالی برای حذف**:
- کامپوننت‌های demo یا test
- فایل‌های `.md` در production build
- توابع helper استفاده نشده

---

### 6. Font Optimization (Priority: MEDIUM 🟡)

#### 6.1 استفاده از font-display: swap

```css
/* فایل: /styles/globals.css */

@font-face {
  font-family: 'IranSans';
  src: url('/fonts/IranSans.woff2') format('woff2');
  font-weight: normal;
  font-style: normal;
  font-display: swap; /* ✅ نمایش فوری با fallback font */
}
```

#### 6.2 Preload Critical Fonts

```tsx
// در SEOHead.tsx
<link 
  rel="preload" 
  href="/fonts/IranSans.woff2" 
  as="font" 
  type="font/woff2" 
  crossOrigin="anonymous"
/>
```

**تاثیر**: کاهش 0.5-1s در FCP

---

## ⚙️ بهینه‌سازی Backend

### 1. Database Query Optimization (Priority: HIGH 🔴)

#### 1.1 اضافه کردن Indexes

```sql
-- فایل: RECOMMENDED_INDEXES.sql

-- برای محصولات
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_score ON products(score DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_products_slug ON products(slug);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON products(created_at DESC);

-- ترکیبی برای فیلتر و مرتب‌سازی
CREATE INDEX IF NOT EXISTS idx_products_category_score 
ON products(category_id, score DESC NULLS LAST);

-- برای سفارشات
CREATE INDEX IF NOT EXISTS idx_orders_user_phone ON orders(user_phone);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);

-- ترکیبی برای پنل ادمین
CREATE INDEX IF NOT EXISTS idx_orders_status_created 
ON orders(status, created_at DESC);

-- برای مقالات
CREATE INDEX IF NOT EXISTS idx_articles_slug ON articles(slug);
CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at DESC);

-- برای consultation
CREATE INDEX IF NOT EXISTS idx_consultations_phone ON consultations(phone);
CREATE INDEX IF NOT EXISTS idx_consultations_created ON consultations(created_at DESC);
```

**تاثیر**: کاهش 50-80% query time

---

#### 1.2 بهینه‌سازی Query های موجود

```typescript
// ❌ قبل - N+1 query problem
// فایل: /supabase/functions/server/order_routes.ts
const orders = await supabase.from('orders').select('*');
for (const order of orders) {
  const user = await supabase.from('users').select('*').eq('phone', order.user_phone);
  // ...
}

// ✅ بعد - یک query با JOIN
const { data: orders } = await supabase
  .from('orders')
  .select(`
    *,
    users!inner(phone, first_name, last_name)
  `)
  .order('created_at', { ascending: false });
```

**تاثیر**: کاهش 90% تعداد queries

---

#### 1.3 محدود کردن Select Fields

```typescript
// ❌ قبل - دریافت تمام فیلدها
const { data } = await supabase
  .from('products')
  .select('*');

// ✅ بعد - فقط فیلدهای مورد نیاز
const { data } = await supabase
  .from('products')
  .select('id, product_name, slug, price, image_urls, score');
```

**تاثیر**: کاهش 30-50% حجم داده

---

### 2. API Response Optimization (Priority: HIGH 🔴)

#### 2.1 اضافه کردن Compression

```typescript
// فایل: /supabase/functions/server/index.tsx
import { Hono } from 'npm:hono';
import { compress } from 'npm:hono/compress';

const app = new Hono();

// ✅ فعال‌سازی gzip compression
app.use('*', compress({
  encoding: 'gzip',
}));
```

**تاثیر**: کاهش 60-80% حجم response

---

#### 2.2 Pagination برای لیست‌های بزرگ

```typescript
// ✅ قبلاً پیاده‌سازی شده در /products
// اما باید برای endpoint های دیگر هم اضافه شود

// /supabase/functions/server/order_routes.ts
app.get('/admin/orders', async (c) => {
  const page = parseInt(c.req.query('page') || '1');
  const limit = parseInt(c.req.query('limit') || '20');
  const offset = (page - 1) * limit;
  
  const { data, error, count } = await supabase
    .from('orders')
    .select('*', { count: 'exact' })
    .range(offset, offset + limit - 1)
    .order('created_at', { ascending: false });
    
  return c.json({
    orders: data,
    pagination: {
      page,
      limit,
      total: count,
      totalPages: Math.ceil(count / limit)
    }
  });
});
```

**تاثیر**: کاهش 70-90% response time برای لیست‌های بزرگ

---

#### 2.3 Response Caching

```typescript
// فایل: /supabase/functions/server/cache_middleware.ts
import type { Context, Next } from 'npm:hono';

const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

export function cacheMiddleware(ttl: number = CACHE_TTL) {
  return async (c: Context, next: Next) => {
    const key = c.req.url;
    const cached = cache.get(key);
    
    if (cached && Date.now() - cached.timestamp < ttl) {
      console.log(`✅ Cache HIT: ${key}`);
      return c.json(cached.data);
    }
    
    await next();
    
    // Cache the response
    const response = await c.res.clone().json();
    cache.set(key, { data: response, timestamp: Date.now() });
    console.log(`💾 Cache MISS: ${key} - Cached for ${ttl}ms`);
  };
}

// استفاده
app.get('/categories', cacheMiddleware(10 * 60 * 1000), async (c) => {
  // این endpoint برای 10 دقیقه cache می‌شود
  const categories = await fetchCategories();
  return c.json({ categories });
});
```

**تاثیر**: کاهش 95% load روی database برای داده‌های استاتیک

---

### 3. کاهش Round Trips (Priority: MEDIUM 🟡)

#### 3.1 ترکیب چند API call

```typescript
// ❌ قبل - 3 درخواست جداگانه
const products = await fetch('/api/products');
const categories = await fetch('/api/categories');
const featured = await fetch('/api/products/featured');

// ✅ بعد - یک endpoint ترکیبی
// /supabase/functions/server/index.tsx
app.get('/initial-data', cacheMiddleware(5 * 60 * 1000), async (c) => {
  const [products, categories, featured] = await Promise.all([
    fetchProducts(),
    fetchCategories(),
    fetchFeaturedProducts()
  ]);
  
  return c.json({
    products,
    categories,
    featured,
    timestamp: Date.now()
  });
});

// در frontend
const { products, categories, featured } = await fetch('/api/initial-data').then(r => r.json());
```

**تاثیر**: کاهش 66% تعداد درخواست‌ها

---

## 💾 بهینه‌سازی Database

### 1. KV Store Optimization (Priority: MEDIUM 🟡)

#### 1.1 اضافه کردن TTL برای داده‌های موقت

```typescript
// فایل: /supabase/functions/server/kv_store.tsx

export async function setWithTTL(
  key: string, 
  value: any, 
  ttlSeconds: number
): Promise<void> {
  const expiresAt = Date.now() + (ttlSeconds * 1000);
  
  await supabase
    .from('kv_store_fbc72c25')
    .upsert({
      key,
      value: {
        ...value,
        __ttl: expiresAt
      }
    });
}

export async function get(key: string): Promise<any> {
  const { data } = await supabase
    .from('kv_store_fbc72c25')
    .select('value')
    .eq('key', key)
    .single();
    
  if (!data?.value) return null;
  
  // بررسی TTL
  if (data.value.__ttl && Date.now() > data.value.__ttl) {
    await del(key);
    return null;
  }
  
  return data.value;
}

// استفاده برای OTP
await setWithTTL(`otp:${phone}`, { code: otpCode }, 2 * 60); // 2 دقیقه
```

**تاثیر**: کاهش 30-40% حجم database

---

#### 1.2 پاکسازی خودکار داده‌های منقضی شده

```typescript
// فایل: /supabase/functions/server/cleanup_job.ts

export async function cleanupExpiredData() {
  console.log('🧹 Starting cleanup job...');
  
  // پاکسازی OTP های منقضی شده
  const expiredOTPs = await getByPrefix('otp:');
  const now = Date.now();
  
  for (const otp of expiredOTPs) {
    if (otp.expiresAt && now > otp.expiresAt) {
      await del(otp.key);
      console.log(`🗑️ Deleted expired OTP: ${otp.key}`);
    }
  }
  
  console.log('✅ Cleanup job completed');
}

// اجرای هر ساعت
setInterval(cleanupExpiredData, 60 * 60 * 1000);
```

---

### 2. حذف Duplicate Data (Priority: LOW 🟢)

```typescript
// مشکل فعلی: محصولات هم در Postgres و هم در KV Store ذخیره می‌شوند
// راه‌حل: فقط از Postgres استفاده کنید

// ❌ حذف کنید
await kv.set(`product:${productId}`, productData);

// ✅ فقط Postgres
await supabase.from('products').insert(productData);
```

**تاثیر**: کاهش 50% استفاده از KV Store

---

## 🖼️ بهینه‌سازی Assets و Media

### 1. تنظیمات Supabase Storage (Priority: MEDIUM 🟡)

#### 1.1 فعال‌سازی CDN

```typescript
// در Supabase Dashboard:
// Storage > Settings > Enable CDN

// تغییر URL ها
// ❌ قبل
const imageUrl = `${supabaseUrl}/storage/v1/object/public/products/${filename}`;

// ✅ بعد
const imageUrl = `${cdnUrl}/storage/v1/object/public/products/${filename}`;
```

**تاثیر**: کاهش 40-60% latency برای تصاویر

---

#### 1.2 تنظیم Cache Headers

```typescript
// در upload images
const { data, error } = await supabase.storage
  .from('make-fbc72c25-consultation-photos')
  .upload(filename, file, {
    cacheControl: '3600', // 1 ساعت
    upsert: false
  });
```

---

### 2. فشرده‌سازی تصاویر قبل از آپلود

```typescript
// فایل: /utils/imageCompression.ts
export async function compressImage(
  file: File, 
  maxWidth: number = 1200,
  quality: number = 0.8
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    
    img.onload = () => {
      let width = img.width;
      let height = img.height;
      
      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      ctx.drawImage(img, 0, 0, width, height);
      
      canvas.toBlob(
        (blob) => blob ? resolve(blob) : reject(new Error('Compression failed')),
        'image/jpeg',
        quality
      );
    };
    
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

// استفاده در ConsultationForm
const compressedBlob = await compressImage(file);
const base64 = await blobToBase64(compressedBlob);
```

**تاثیر**: کاهش 60-80% حجم تصاویر آپلودی

---

## 🚀 استراتژی‌های Caching

### 1. Browser Caching (Priority: HIGH 🔴)

#### 1.1 Service Worker برای Offline Support

```typescript
// فایل: /public/sw.js
const CACHE_NAME = 'nursaa-v1.0.0';
const urlsToCache = [
  '/',
  '/styles/globals.css',
  '/fonts/IranSans.woff2',
  '/favicon.ico'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then(response => response || fetch(event.request))
  );
});
```

```typescript
// ثبت service worker در main.tsx
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js')
    .then(() => console.log('✅ Service Worker registered'))
    .catch(err => console.error('❌ Service Worker registration failed:', err));
}
```

**تاثیر**: بهبود 80-90% سرعت بارگذاری مجدد

---

### 2. API Response Caching (Priority: HIGH 🔴)

#### 2.1 بهبود cachedFetch موجود

```typescript
// فایل: /src/utils/cachedFetch.ts

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  etag?: string;
}

const cache = new Map<string, CacheEntry<any>>();

export async function cachedFetch<T>(
  url: string,
  options: RequestInit = {},
  ttl: number = 5 * 60 * 1000, // 5 دقیقه
  staleWhileRevalidate: boolean = true
): Promise<T> {
  const cacheKey = `${url}:${JSON.stringify(options)}`;
  const cached = cache.get(cacheKey);
  const now = Date.now();
  
  // اگر cache معتبر است، برگردان
  if (cached && now - cached.timestamp < ttl) {
    console.log(`✅ Cache HIT: ${url}`);
    
    // استراتژی stale-while-revalidate
    if (staleWhileRevalidate && now - cached.timestamp > ttl / 2) {
      console.log(`🔄 Revalidating in background: ${url}`);
      fetch(url, options)
        .then(r => r.json())
        .then(data => {
          cache.set(cacheKey, {
            data,
            timestamp: Date.now(),
          });
        })
        .catch(err => console.warn('Background revalidation failed:', err));
    }
    
    return cached.data;
  }
  
  // درخواست جدید
  console.log(`💾 Cache MISS: ${url}`);
  const response = await fetch(url, options);
  const data = await response.json();
  
  cache.set(cacheKey, {
    data,
    timestamp: now,
    etag: response.headers.get('etag') || undefined
  });
  
  return data;
}

// پاکسازی cache های قدیمی
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of cache.entries()) {
    if (now - entry.timestamp > 30 * 60 * 1000) { // 30 دقیقه
      cache.delete(key);
    }
  }
}, 5 * 60 * 1000); // هر 5 دقیقه
```

**تاثیر**: کاهش 70-90% درخواست‌های تکراری

---

### 3. LocalStorage Caching برای داده‌های استاتیک

```typescript
// فایل: /src/utils/persistentCache.ts

export const persistentCache = {
  set(key: string, data: any, ttl: number) {
    const item = {
      data,
      expiresAt: Date.now() + ttl
    };
    localStorage.setItem(key, JSON.stringify(item));
  },
  
  get<T>(key: string): T | null {
    const item = localStorage.getItem(key);
    if (!item) return null;
    
    const { data, expiresAt } = JSON.parse(item);
    
    if (Date.now() > expiresAt) {
      localStorage.removeItem(key);
      return null;
    }
    
    return data;
  },
  
  clear(prefix?: string) {
    if (!prefix) {
      localStorage.clear();
      return;
    }
    
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith(prefix)) {
        localStorage.removeItem(key);
      }
    });
  }
};

// استفاده برای categories
const categories = persistentCache.get<Category[]>('categories');
if (!categories) {
  const fetchedCategories = await fetch('/api/categories').then(r => r.json());
  persistentCache.set('categories', fetchedCategories, 24 * 60 * 60 * 1000); // 24 ساعت
}
```

**تاثیر**: کاهش 100% درخواست‌های تکراری برای داده‌های استاتیک

---

## 📊 بهبود SEO و Performance

### 1. Meta Tags و Structured Data (Priority: MEDIUM 🟡)

#### 1.1 بهبود SEOHead برای صفحات محصول

```tsx
// فایل: /components/SEOHead.tsx

export function createProductStructuredData(product: Product) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": product.product_name,
    "description": product.short_description,
    "image": product.image_urls,
    "brand": {
      "@type": "Brand",
      "name": "نورسا"
    },
    "offers": {
      "@type": "Offer",
      "url": `https://nursaa.ir/products/${product.slug}`,
      "priceCurrency": "IRR",
      "price": product.price,
      "priceValidUntil": new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      "availability": "https://schema.org/InStock",
      "seller": {
        "@type": "Organization",
        "name": "نورسا"
      }
    },
    "aggregateRating": product.score ? {
      "@type": "AggregateRating",
      "ratingValue": product.score / 20, // تبدیل score 0-100 به 0-5
      "bestRating": "5",
      "worstRating": "1",
      "ratingCount": "50" // باید از database بیاید
    } : undefined
  };
}

// در ProductDetailWrapper.tsx
<SEOHead
  title={`${product.product_name} - خرید آنلاین`}
  description={product.short_description}
  keywords={`${product.product_name}, خرید ${product.product_name}, روغن طبیعی`}
  image={product.image_urls[0]}
  structuredData={createProductStructuredData(product)}
/>
```

---

#### 1.2 اضافه کردن Breadcrumb Structured Data

```tsx
export function createBreadcrumbStructuredData(items: Array<{name: string, url: string}>) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": items.map((item, index) => ({
      "@type": "ListItem",
      "position": index + 1,
      "name": item.name,
      "item": item.url
    }))
  };
}

// در ProductsPage.tsx
const breadcrumbs = [
  { name: "خانه", url: "https://nursaa.ir" },
  { name: "محصولات", url: "https://nursaa.ir/products" },
  { name: category?.name || "همه محصولات", url: `https://nursaa.ir/products?category=${category?.slug}` }
];

<SEOHead structuredData={createBreadcrumbStructuredData(breadcrumbs)} />
```

---

### 2. Core Web Vitals Optimization

#### 2.1 اندازه‌گیری و Monitoring

```typescript
// فایل: /src/utils/webVitals.ts
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

export function initWebVitals() {
  getCLS(metric => sendToAnalytics('CLS', metric.value));
  getFID(metric => sendToAnalytics('FID', metric.value));
  getFCP(metric => sendToAnalytics('FCP', metric.value));
  getLCP(metric => sendToAnalytics('LCP', metric.value));
  getTTFB(metric => sendToAnalytics('TTFB', metric.value));
}

function sendToAnalytics(metric: string, value: number) {
  if (window.gtag) {
    window.gtag('event', metric, {
      value: Math.round(value),
      metric_id: `${metric}-${Date.now()}`,
      metric_value: value,
      metric_delta: value,
    });
  }
  
  console.log(`📊 ${metric}:`, value);
}

// در main.tsx
import { initWebVitals } from './utils/webVitals';
initWebVitals();
```

---

## 🔒 امنیت و Best Practices

### 1. Environment Variables (Priority: HIGH 🔴)

```typescript
// ❌ مشکل فعلی - hardcoded values
const apiUrl = 'https://jqxhriqljtpsateawvmb.supabase.co';

// ✅ راه‌حل
// فایل: .env.production
VITE_SUPABASE_URL=https://jqxhriqljtpsateawvmb.supabase.co
VITE_SUPABASE_ANON_KEY=your-key-here
VITE_API_URL=https://jqxhriqljtpsateawvmb.supabase.co/functions/v1/make-server-fbc72c25
VITE_GA_MEASUREMENT_ID=G-XXXXXXXXXX

// در کد
const apiUrl = import.meta.env.VITE_API_URL;
```

---

### 2. Input Validation و Sanitization

```typescript
// فایل: /src/utils/validation.ts

export const validators = {
  phone: (phone: string): boolean => {
    return /^09\d{9}$/.test(phone);
  },
  
  email: (email: string): boolean => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },
  
  price: (price: number): boolean => {
    return price > 0 && price < 100000000;
  },
  
  sanitizeString: (str: string): string => {
    return str
      .trim()
      .replace(/[<>]/g, '') // حذف HTML tags
      .slice(0, 1000); // محدودیت طول
  }
};

// استفاده
const sanitizedName = validators.sanitizeString(formData.first_name);
if (!validators.phone(phone)) {
  throw new Error('شماره تلفن معتبر نیست');
}
```

---

### 3. Rate Limiting (Priority: MEDIUM 🟡)

```typescript
// فایل: /supabase/functions/server/rate_limiter.ts
import type { Context, Next } from 'npm:hono';

const requests = new Map<string, number[]>();
const WINDOW_MS = 60 * 1000; // 1 دقیقه
const MAX_REQUESTS = 60; // 60 درخواست در دقیقه

export function rateLimiter(limit: number = MAX_REQUESTS) {
  return async (c: Context, next: Next) => {
    const ip = c.req.header('x-forwarded-for') || 'unknown';
    const now = Date.now();
    
    const userRequests = requests.get(ip) || [];
    const recentRequests = userRequests.filter(time => now - time < WINDOW_MS);
    
    if (recentRequests.length >= limit) {
      return c.json({ 
        error: 'تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً چند لحظه صبر کنید.' 
      }, 429);
    }
    
    recentRequests.push(now);
    requests.set(ip, recentRequests);
    
    await next();
  };
}

// استفاده
app.post('/send-otp', rateLimiter(5), async (c) => {
  // محدودیت 5 درخواست در دقیقه برای OTP
});

app.post('/verify-otp', rateLimiter(10), async (c) => {
  // محدودیت 10 درخواست در دقیقه برای تایید
});
```

---

## 📈 Monitoring و Analytics

### 1. Error Tracking (Priority: HIGH 🔴)

```typescript
// فایل: /src/utils/errorTracking.ts

export class ErrorTracker {
  static log(error: Error, context?: any) {
    // لاگ در console
    console.error('❌ Error:', error.message, context);
    
    // ارسال به Google Analytics
    if (window.gtag) {
      window.gtag('event', 'exception', {
        description: error.message,
        fatal: false,
        context: JSON.stringify(context)
      });
    }
    
    // ذخیره در localStorage برای دیباگ
    const errors = this.getStoredErrors();
    errors.push({
      message: error.message,
      stack: error.stack,
      context,
      timestamp: new Date().toISOString(),
      url: window.location.href,
      userAgent: navigator.userAgent
    });
    
    // فقط 50 خطای اخیر را نگه دار
    if (errors.length > 50) {
      errors.shift();
    }
    
    localStorage.setItem('error_log', JSON.stringify(errors));
  }
  
  static getStoredErrors() {
    try {
      return JSON.parse(localStorage.getItem('error_log') || '[]');
    } catch {
      return [];
    }
  }
  
  static clearErrors() {
    localStorage.removeItem('error_log');
  }
}

// استفاده
try {
  await fetchProducts();
} catch (error) {
  ErrorTracker.log(error as Error, { 
    action: 'fetchProducts',
    userId: user?.phone 
  });
  toast.error('خطا در دریافت محصولات');
}
```

---

### 2. Performance Monitoring

```typescript
// فایل: /src/utils/performanceMonitoring.ts

export class PerformanceMonitor {
  private static marks = new Map<string, number>();
  
  static mark(name: string) {
    this.marks.set(name, performance.now());
    performance.mark(name);
  }
  
  static measure(name: string, startMark: string, endMark?: string) {
    const start = this.marks.get(startMark);
    const end = endMark ? this.marks.get(endMark) : performance.now();
    
    if (!start) {
      console.warn(`Start mark "${startMark}" not found`);
      return;
    }
    
    const duration = (end || performance.now()) - start;
    
    console.log(`⏱️ ${name}: ${duration.toFixed(2)}ms`);
    
    // ارسال به Google Analytics
    if (window.gtag) {
      window.gtag('event', 'timing_complete', {
        name,
        value: Math.round(duration),
        event_category: 'Performance'
      });
    }
    
    return duration;
  }
}

// استفاده
// در App.tsx
PerformanceMonitor.mark('app-start');

// بعد از fetch محصولات
PerformanceMonitor.mark('products-fetched');
PerformanceMonitor.measure('Initial Data Load', 'app-start', 'products-fetched');
```

---

## 🎯 پلن اجرایی

### فاز 1: بهینه‌سازی‌های سریع (هفته 1-2)
**زمان: 10-15 ساعت | تاثیر: 40-50% بهبود**

- [ ] افزودن React.memo به ProductCard
- [ ] افزودن useCallback به event handlers
- [ ] حذف console.log ها با logger utility
- [ ] افزودن compression به backend
- [ ] افزودن database indexes
- [ ] بهبود cachedFetch با stale-while-revalidate

**نتیجه مورد انتظار**:
- ✅ کاهش 30-40% initial bundle size
- ✅ کاهش 50% re-renders غیرضروری
- ✅ کاهش 60% API response time

---

### فاز 2: بهینه‌سازی‌های متوسط (هفته 3-4)
**زمان: 15-20 ساعت | تاثیر: 30-40% بهبود اضافی**

- [ ] پیاده‌سازی code splitting با React.lazy
- [ ] تقسیم CartContext به contexts کوچکتر
- [ ] افزودن service worker برای offline support
- [ ] بهینه‌سازی تصاویر با WebP و srcset
- [ ] افزودن rate limiting
- [ ] پیاده‌سازی error tracking

**نتیجه مورد انتظار**:
- ✅ کاهش 40-50% initial load time
- ✅ بهبود 80% سرعت بارگذاری مجدد
- ✅ پشتیبانی offline

---

### فاز 3: بهینه‌سازی‌های پیشرفته (هفته 5-6)
**زمان: 20-25 ساعت | تاثیر: 20-30% بهبود اضافی**

- [ ] ایجاد endpoint های ترکیبی برای کاهش round trips
- [ ] پیاده‌سازی image compression قبل از آپلود
- [ ] افزودن CDN برای Supabase Storage
- [ ] بهبود structured data برای SEO
- [ ] پیاده‌سازی web vitals monitoring
- [ ] بهینه‌سازی query های N+1

**نتیجه مورد انتظار**:
- ✅ کاهش 70% حجم تصاویر آپلودی
- ✅ کاهش 90% N+1 queries
- ✅ بهبود SEO ranking

---

### فاز 4: Monitoring و Maintenance (مداوم)
**زمان: 5-10 ساعت/ماه | تاثیر: حفظ performance**

- [ ] بررسی هفتگی error logs
- [ ] بررسی ماهانه bundle size
- [ ] بررسی ماهانه database performance
- [ ] به‌روزرسانی dependencies
- [ ] پاکسازی cache های قدیمی
- [ ] بررسی Core Web Vitals در Google Search Console

---

## 📊 Checklist بهینه‌سازی

### Frontend

#### Code Quality
- [ ] حذف کدهای استفاده نشده
- [ ] یکسان‌سازی ADMIN_PHONES در یک فایل
- [ ] افزودن TypeScript strict mode
- [ ] افزودن ESLint rules برای performance
- [ ] حذف console.log ها در production

#### Performance
- [x] استفاده از useMemo برای محاسبات سنگین (قبلاً اعمال شده)
- [ ] استفاده از React.memo برای کامپوننت‌های سنگین
- [ ] استفاده از useCallback برای event handlers
- [ ] Code splitting با React.lazy
- [ ] Tree shaking برای کتابخانه‌ها

#### Images
- [ ] تبدیل به WebP
- [ ] افزودن srcset و sizes
- [ ] Lazy loading برای تصاویر پایین صفحه
- [ ] Compression قبل از آپلود
- [ ] Preload برای hero images

#### Caching
- [ ] Service Worker برای offline support
- [ ] LocalStorage برای داده‌های استاتیک
- [ ] Stale-while-revalidate strategy
- [ ] Cache busting برای assets

---

### Backend

#### Database
- [ ] افزودن indexes به جداول
- [ ] بهینه‌سازی query های N+1
- [ ] محدود کردن select fields
- [ ] Pagination برای لیست‌های بزرگ
- [ ] پاکسازی خودکار داده‌های منقضی شده

#### API
- [ ] افزودن compression (gzip)
- [ ] افزودن response caching
- [ ] ترکیب endpoint های مرتبط
- [ ] افزودن rate limiting
- [ ] بهبود error handling

#### Security
- [ ] Input validation و sanitization
- [ ] Rate limiting برای OTP
- [ ] استفاده از environment variables
- [ ] افزودن CORS headers
- [ ] افزودن request logging

---

### Monitoring

#### Analytics
- [ ] Google Analytics 4 events
- [ ] Web Vitals tracking
- [ ] Error tracking
- [ ] Performance monitoring
- [ ] Conversion tracking

#### Debugging
- [ ] Structured logging
- [ ] Error boundaries در React
- [ ] Source maps برای production
- [ ] Network request monitoring

---

## 🔧 ابزارهای توصیه شده

### Development
- **Vite Plugin Visualizer**: تحلیل bundle size
- **React DevTools Profiler**: شناسایی performance bottlenecks
- **Lighthouse CI**: اتوماسیون performance testing

### Monitoring
- **Google Analytics 4**: event tracking
- **Google Search Console**: SEO monitoring
- **Supabase Dashboard**: database performance

### Testing
- **Chrome DevTools**: Performance tab
- **WebPageTest**: detailed performance analysis
- **GTmetrix**: performance scoring

---

## 📞 پشتیبانی

برای سوالات یا پیشنهادات بیشتر:
- **ایمیل**: be@nursaa.ir
- **تلفن**: 09219675992

---

**یادداشت نهایی**: این سند باید هر 3 ماه یکبار به‌روزرسانی شود تا با تغییرات پروژه همگام بماند.

---

*آخرین به‌روزرسانی: دسامبر 2025*
