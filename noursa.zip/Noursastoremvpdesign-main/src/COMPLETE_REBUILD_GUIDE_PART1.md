# 📘 راهنمای جامع بازسازی پروژه Oil Global (nursaa.ir) - بخش 1

> **نسخه:** 2.0  
> **تاریخ:** دی ۱۴۰۳  
> **نویسنده:** تیم فنی Oil Global  
> **وضعیت:** پیش‌نویس نهایی

---

## 📑 فهرست مطالب

1. [مقدمه و خلاصه اجرایی](#1-مقدمه-و-خلاصه-اجرایی)
2. [تحلیل وضعیت فعلی](#2-تحلیل-وضعیت-فعلی)
3. [معماری و طراحی سیستم](#3-معماری-و-طراحی-سیستم)
4. [پشته فناوری](#4-پشته-فناوری)
5. [طراحی پایگاه داده](#5-طراحی-پایگاه-داده)

---

## 1️⃣ مقدمه و خلاصه اجرایی

### 1.1 درباره این سند

این سند یک راهنمای جامع برای بازسازی کامل پلتفرم فروشگاه آنلاین nursaa.ir است که توسط یک تیم متشکل از متخصصان Full-Stack، DevOps، و مدیریت محصول تهیه شده است.

**هدف اصلی:** ایجاد یک سیستم مقیاس‌پذیر، قابل نگهداری، امن، و استاندارد صنعتی که بتواند نیازهای کسب‌وکار را برای ۳-۵ سال آینده برآورده کند.

### 1.2 مخاطبان این سند

- **توسعه‌دهندگان:** برای درک معماری و پیاده‌سازی
- **DevOps Engineers:** برای راه‌اندازی زیرساخت
- **مدیران فنی:** برای تصمیم‌گیری‌های استراتژیک
- **مالکان محصول:** برای درک امکانات و محدودیت‌ها
- **QA Engineers:** برای استراتژی تست

### 1.3 خلاصه تغییرات کلیدی

| حوزه | وضعیت فعلی | وضعیت پیشنهادی | تأثیر |
|------|-----------|----------------|-------|
| **زبان برنامه‌نویسی** | JavaScript | TypeScript | 🟢 کاهش ۹۰٪ باگ‌های runtime |
| **State Management** | Context API پراکنده | React Query + Zustand | 🟢 سادگی ۵۰٪ بیشتر |
| **Backend Architecture** | Monolithic file | Layered (Service/Repository) | 🟢 قابلیت نگهداری ۳۰۰٪ |
| **Database** | KV Store + Postgres | Postgres Pure | 🟢 Performance ۲۰۰٪ |
| **Testing** | Manual | Automated (80% coverage) | 🟢 اعتماد ۱۰۰٪ |
| **CI/CD** | Manual deploy | Automated pipeline | 🟢 زمان deploy از ۳۰ دقیقه به ۵ دقیقه |
| **Monitoring** | Console logs | Sentry + Structured logs | 🟢 MTTR کاهش ۷۰٪ |
| **Security** | Basic | Multi-layer security | 🟢 ریسک کاهش ۹۰٪ |

### 1.4 ROI تخمینی

```
💰 هزینه توسعه: 400-600 ساعت کاری (2-3 ماه)
📈 بازگشت سرمایه:
  - کاهش ۵۰٪ زمان debug: +100 ساعت/سال
  - کاهش ۷۰٪ باگ‌های production: +50 ساعت/سال
  - افزایش ۲۰٪ سرعت توسعه features جدید: +150 ساعت/سال
  - کاهش ۸۰٪ downtime: +30 ساعت/سال
  
✅ ROI: 330 ساعت/سال = بازگشت سرمایه در 6 ماه
```

---

## 2️⃣ تحلیل وضعیت فعلی

### 2.1 Technical Debt Analysis

#### 🔴 مشکلات Critical

**1. عدم Type Safety**
```javascript
// ❌ مشکل فعلی: Runtime errors
function calculateTotal(items) {
  return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

// اگر item.price undefined باشد، NaN برمی‌گردد
// اگر items null باشد، crash می‌کند
```

**تأثیر:** 
- ~30 باگ/ماه مربوط به type mismatch
- ساعت‌ها debug برای یافتن منشأ
- تجربه کاربری ضعیف

**2. Monolithic Backend**
```typescript
// ❌ وضعیت فعلی: 2000+ خطوط در یک فایل
// /supabase/functions/server/index.tsx

app.post('/products', async (c) => {
  // Validation logic
  // Business logic
  // Database queries
  // Payment integration
  // SMS sending
  // Email sending
  // همه در یک تابع!
});
```

**تأثیر:**
- Merge conflicts مداوم
- Test کردن غیرممکن
- Reusability صفر
- Onboarding توسعه‌دهنده جدید: ۲ هفته+

**3. N+1 Query Problem**
```typescript
// ❌ وضعیت فعلی
const orders = await fetchOrders(); // 1 query
for (const order of orders) {
  order.items = await fetchOrderItems(order.id); // N queries
  order.customer = await fetchCustomer(order.user_id); // N queries
}
// برای 100 سفارش: 1 + 100 + 100 = 201 query!
```

**تأثیر:**
- صفحه لیست سفارشات: ۵-۸ ثانیه load time
- هزینه database connection pool
- User frustration

### 2.2 Code Quality Metrics

```bash
# Run analysis
npm install -g @eslint/js typescript-eslint
npm install -g jscpd  # Copy-paste detector

# Results:
✗ Type coverage: 0%
✗ Test coverage: 0%
✗ Cyclomatic complexity: Avg 15 (should be <10)
✗ Code duplication: 25% (should be <5%)
✗ Function length: Avg 80 lines (should be <50)
✗ File length: Max 2000+ lines (should be <300)
```

### 2.3 Performance Baseline

```javascript
// Lighthouse Score (فعلی)
Performance:  62/100 ❌
Accessibility: 85/100 ⚠️
Best Practices: 71/100 ⚠️
SEO: 90/100 ✅

// Core Web Vitals
LCP: 3.8s ❌ (should be <2.5s)
FID: 180ms ⚠️ (should be <100ms)
CLS: 0.18 ⚠️ (should be <0.1)

// API Response Times (p95)
GET /products: 850ms ❌
GET /orders: 2.3s ❌
POST /consultation: 5.8s ❌ (timeout issues)
```

---

## 3️⃣ معماری و طراحی سیستم

### 3.1 معماری Macro

```
┌──────────────────────────────────────────────────────────────┐
│                        PRESENTATION LAYER                     │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐            │
│  │   Web App  │  │  Admin     │  │  Mobile    │            │
│  │   (React)  │  │  Panel     │  │  App (TBD) │            │
│  └────────────┘  └────────────┘  └────────────┘            │
└────────────────────────────┬─────────────────────────────────┘
                             │ HTTPS/REST API
┌────────────────────────────▼─────────────────────────────────┐
│                     API GATEWAY LAYER                         │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Edge Functions (Hono.js)                           │    │
│  │  - Rate Limiting                                     │    │
│  │  - Authentication/Authorization                      │    │
│  │  - Request Validation (Zod)                          │    │
│  │  - Error Handling                                    │    │
│  │  - Logging & Metrics                                 │    │
│  └─────────────────────────────────────────────────────┘    │
└────────────────────────────┬─────────────────────────────────┘
                             │
┌────────────────────────────▼─────────────────────────────────┐
│                     SERVICE LAYER (Business Logic)            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Product  │  │  Order   │  │Consultation│ │  Auth   │   │
│  │ Service  │  │ Service  │  │  Service   │ │ Service │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
└────────────────────────────┬─────────────────────────────────┘
                             │
┌────────────────────────────▼─────────────────────────────────┐
│                     DATA ACCESS LAYER                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Product  │  │  Order   │  │ Customer │  │   Post   │   │
│  │Repository│  │Repository│  │Repository│  │Repository│   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
└────────────────────────────┬─────────────────────────────────┘
                             │
┌────────────────────────────▼─────────────────────────────────┐
│                     INFRASTRUCTURE LAYER                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Supabase │  │ Storage  │  │  Queue   │  │   CDN    │   │
│  │ Postgres │  │ (S3-like)│  │ (BullMQ) │  │(Cloudflare│  │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
└──────────────────────────────────────────────────────────────┘
```

### 3.2 ساختار Folder (خلاصه)

```
nursaa/
├── apps/
│   └── web/                    # Main web app
│       ├── src/
│       │   ├── features/       # Feature modules
│       │   │   ├── products/
│       │   │   ├── orders/
│       │   │   ├── cart/
│       │   │   └── admin/
│       │   ├── shared/         # Shared components
│       │   └── services/       # External services
│       └── tests/
├── supabase/
│   ├── functions/
│   │   └── api/
│   │       ├── routes/
│   │       ├── services/
│   │       ├── repositories/
│   │       └── middleware/
│   └── migrations/
└── docs/
```

---

## 4️⃣ پشته فناوری

### 4.1 Frontend Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| **React** | 18.3+ | UI Framework |
| **TypeScript** | 5.3+ | Type Safety |
| **Vite** | 5.0+ | Build Tool |
| **React Query** | 5.0+ | Server State |
| **Zustand** | 4.4+ | Client State |
| **Tailwind CSS** | 3.4+ | Styling |
| **React Hook Form** | 7.55+ | Forms |
| **Zod** | 3.22+ | Validation |

### 4.2 Backend Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| **Deno** | Latest | Runtime |
| **Hono.js** | 4.0+ | Web Framework |
| **Supabase** | Latest | BaaS |
| **PostgreSQL** | 15+ | Database |

---

## 5️⃣ طراحی پایگاه داده

### 5.1 جداول اصلی

```sql
-- Categories
CREATE TABLE categories (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  parent_id UUID REFERENCES categories(id),
  is_active BOOLEAN DEFAULT true
);

-- Products
CREATE TABLE products (
  id UUID PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  price DECIMAL(12, 2) NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  category_id UUID REFERENCES categories(id),
  images TEXT[] NOT NULL DEFAULT '{}',
  is_active BOOLEAN DEFAULT true
);

-- Orders
CREATE TABLE orders (
  id UUID PRIMARY KEY,
  order_number TEXT UNIQUE NOT NULL,
  user_id UUID REFERENCES auth.users(id),
  status order_status NOT NULL DEFAULT 'pending',
  subtotal DECIMAL(12, 2) NOT NULL,
  shipping_cost DECIMAL(12, 2) NOT NULL,
  total DECIMAL(12, 2) NOT NULL,
  customer_name TEXT NOT NULL,
  customer_mobile TEXT NOT NULL,
  payment_status payment_status NOT NULL DEFAULT 'pending'
);

-- Order Items
CREATE TABLE order_items (
  id UUID PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES orders(id),
  product_id UUID REFERENCES products(id),
  title TEXT NOT NULL,
  price DECIMAL(12, 2) NOT NULL,
  quantity INTEGER NOT NULL,
  subtotal DECIMAL(12, 2) NOT NULL
);
```

### 5.2 Enums

```sql
CREATE TYPE order_status AS ENUM (
  'pending',
  'processing',
  'shipped',
  'delivered',
  'cancelled'
);

CREATE TYPE payment_status AS ENUM (
  'pending',
  'paid',
  'failed',
  'refunded'
);
```

---

**ادامه در بخش 2...**
