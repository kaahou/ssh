# 🗑️ راهنمای پاک کردن Cache

## 📋 مشکل

محصولات در صفحه اول (HomePage) بر اساس score مرتب نیستند، در حالی که در صفحه محصولات (ProductListPage) به درستی مرتب هستند.

**علت:** Cache در frontend که برای ۵ دقیقه نگه داشته می‌شود.

---

## ✅ راه‌حل: پاک کردن Cache

### روش ۱: Hard Reload (سریع‌ترین)

#### در Chrome/Edge:
```
Ctrl + Shift + R
یا
Ctrl + F5
```

#### در Firefox:
```
Ctrl + Shift + R
یا
Ctrl + F5
```

#### در Safari:
```
Cmd + Option + R
```

---

### روش ۲: پاک کردن کامل Cache مرورگر

#### Chrome/Edge:
1. `F12` یا کلیک راست > Inspect
2. کلیک راست روی دکمه Refresh (کنار آدرس بار)
3. انتخاب "Empty Cache and Hard Reload"

یا:
1. `Ctrl + Shift + Delete`
2. انتخاب "Cached images and files"
3. کلیک "Clear data"

#### Firefox:
1. `Ctrl + Shift + Delete`
2. انتخاب "Cache"
3. کلیک "Clear Now"

---

### روش ۳: پاک کردن Cache از Developer Tools

1. `F12` برای باز کردن Developer Tools
2. تب **Application** (Chrome) یا **Storage** (Firefox)
3. در سمت چپ: **Storage** > **Cache Storage**
4. کلیک راست روی cache > **Delete**

---

### روش ۴: Disable Cache موقت (برای تست)

1. `F12` برای باز کردن Developer Tools
2. تب **Network**
3. چک کردن گزینه **"Disable cache"**
4. Refresh صفحه

⚠️ **توجه:** این گزینه فقط تا زمانی که DevTools باز است فعال است.

---

### روش ۵: پاک کردن Cache از Console

1. `F12` برای باز کردن Developer Tools
2. تب **Console**
3. اجرای این کد:

```javascript
// پاک کردن تمام Cache ها
caches.keys().then(keys => {
  keys.forEach(key => caches.delete(key));
  console.log('✅ All caches cleared!');
});

// Reload صفحه
location.reload(true);
```

---

## 🔍 بررسی کردن Cache فعلی

### چک کردن Cache API:

```javascript
// در Console اجرا کنید
caches.keys().then(keys => {
  console.log('Cache keys:', keys);
  
  // نمایش محتوای یک cache
  keys.forEach(key => {
    caches.open(key).then(cache => {
      cache.keys().then(requests => {
        console.log(`Cache "${key}" has ${requests.length} entries`);
        requests.forEach(req => console.log('  -', req.url));
      });
    });
  });
});
```

### چک کردن localStorage و sessionStorage:

```javascript
// در Console
console.log('localStorage:', localStorage);
console.log('sessionStorage:', sessionStorage);

// پاک کردن
localStorage.clear();
sessionStorage.clear();
```

---

## 🧪 تست کردن بعد از پاک کردن Cache

### ۱. بررسی لاگ‌های Console

بعد از Hard Reload، در Console باید ببینید:

```
📡 API call: GET:https://...supabase.co/.../products/featured
✅ Returned 8 featured products
📊 Products with scores:
  1. محصول A - Score: 95
  2. محصول B - Score: 90
  3. محصول C - Score: 85
  ...
```

اگر این لاگ را ندیدید، یعنی هنوز از cache استفاده می‌کند:
```
✅ Cache hit: GET:https://...
```

### ۲. بررسی Network Tab

1. `F12` > تب **Network**
2. Refresh صفحه
3. فیلتر کردن با "featured"
4. کلیک روی request `/products/featured`
5. بررسی:
   - **Status:** باید `200 OK` باشد
   - **Size:** باید حجم واقعی باشد (نه "from cache")
   - **Time:** باید زمان واقعی request باشد

---

## 🔧 تغییر مدت Cache (برای توسعه‌دهندگان)

اگر می‌خواهید مدت cache را کاهش دهید:

### در `/App.tsx`:

```typescript
// پیدا کنید این خط:
cachedFetch<any>(
  `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/featured`,
  { headers: { Authorization: `Bearer ${publicAnonKey}` } },
  5 * 60 * 1000,  // ⬅️ این را تغییر دهید
)

// تغییر به (برای تست):
5 * 1000,  // فقط ۵ ثانیه
// یا
0,  // بدون cache
```

⚠️ **توجه:** این فقط برای تست است. در production از cache استفاده کنید.

---

## 📊 بررسی Ordering در Backend

### تست مستقیم API:

```bash
# تست endpoint featured
curl -H "Authorization: Bearer YOUR_ANON_KEY" \
  https://YOUR_PROJECT.supabase.co/functions/v1/make-server-fbc72c25/products/featured

# انتظار: محصولات به ترتیب score (بالا به پایین)
```

### بررسی لاگ‌های Backend:

1. Supabase Dashboard
2. Edge Functions > `make-server-fbc72c25`
3. Logs
4. دنبال این پیام‌ها بگردید:

```
📦 Fetching featured products...
✅ Returned 8 featured products
📊 Products with scores:
  1. محصول A - Score: 95
  2. محصول B - Score: 90
  ...
```

---

## 🎯 خلاصه برای رفع مشکل شما

### گام ۱: Deploy Backend
```bash
# اگر هنوز deploy نکرده‌اید
supabase functions deploy make-server-fbc72c25
```

### گام ۲: پاک کردن Cache مرورگر
```
Ctrl + Shift + R
یا
Ctrl + F5
```

### گام ۳: بررسی Console
- باید `📡 API call:` را ببینید (نه `✅ Cache hit:`)
- باید `📊 Products with scores:` را ببینید با امتیازها

### گام ۴: بررسی HomePage
- محصولات باید بر اساس score مرتب شده باشند
- محصول با بالاترین score باید اول باشد

---

## 💡 نکات مهم

### ✅ انجام دهید:
1. همیشه بعد از deploy backend، cache را پاک کنید
2. در حین توسعه، "Disable cache" را فعال کنید
3. بعد از تغییر در دیتابیس، Hard Reload کنید

### ❌ انجام ندهید:
1. فکر نکنید که refresh معمولی cache را پاک می‌کند
2. از Incognito/Private Window برای تست cache استفاده نکنید (ممکن است گمراه‌کننده باشد)
3. cache را در production غیرفعال نکنید

---

## 🚨 اگر هنوز کار نکرد

### چک‌لیست نهایی:

- [ ] Backend deploy شده است؟
- [ ] ستون `score` در دیتابیس وجود دارد؟
- [ ] محصولات امتیاز دارند (score != NULL)?
- [ ] Cache کاملاً پاک شده است؟
- [ ] از لاگ‌های Backend محصولات به ترتیب score هستند؟
- [ ] Network Tab نشان می‌دهد request جدید ارسال شده (نه از cache)?

اگر همه موارد بله هستند ولی هنوز کار نمی‌کند:
1. لاگ‌های کامل Console و Network Tab را ببینید
2. لاگ‌های Backend را در Supabase بررسی کنید
3. SQL Query زیر را اجرا کنید:

```sql
SELECT id, product_name, score 
FROM products 
ORDER BY score DESC NULLS LAST 
LIMIT 10;
```

---

**تاریخ:** ۱۴۰۳/۱۰/۰۸  
**وضعیت:** ✅ آماده استفاده  
**نسخه:** 1.0.0
