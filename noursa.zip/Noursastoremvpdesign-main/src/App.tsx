import React, { useState, useEffect } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useNavigate,
  useParams,
  useLocation,
} from "react-router-dom";
import { logger } from "./src/utils/logger";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { FloatingContactButton } from "./components/FloatingContactButton";
import { ScrollToTop } from "./components/ScrollToTop";
import { HomePage } from "./components/pages/HomePage";
import { ProductListPage } from "./components/pages/ProductListPage";
import { ProductDetailPage } from "./components/pages/ProductDetailPage";
import { CheckoutPage } from "./components/pages/CheckoutPage";
import { PaymentCallbackPage } from "./components/pages/PaymentCallbackPage";
import { ContactPage } from "./components/pages/ContactPage";
import { LoginPage } from "./components/pages/LoginPage";
import { BlogListPage } from "./components/pages/BlogListPage";
import { BlogArticlePage } from "./components/pages/BlogArticlePage";
import { SearchPage } from "./components/pages/SearchPage";
import { DBStatusPage } from "./components/pages/DBStatusPage";
import { AboutPage } from "./components/pages/AboutPage";
import { TermsPage } from "./components/pages/TermsPage";
import { PrivacyPage } from "./components/pages/PrivacyPage";
import { OrderTrackingPage } from "./components/pages/OrderTrackingPage";
import { ShippingGuidePage } from "./components/pages/ShippingGuidePage";
import { ReturnPolicyPage } from "./components/pages/ReturnPolicyPage";
import { FAQPage } from "./components/pages/FAQPage";
import { SiteMapPage } from "./components/pages/SiteMapPage";
import { MoneyBackGuaranteePage } from "./components/pages/MoneyBackGuaranteePage";
import { UserProfileHome } from "./components/pages/UserProfileHome";
import { MyConsultations } from "./components/pages/MyConsultations";
import { MyOrders } from "./components/pages/MyOrders";
import { WalletPage } from "./components/pages/WalletPage";
import { AccountSettings } from "./components/pages/AccountSettings";
import { AffiliatePage } from "./components/pages/AffiliatePage";
import { ProfileLayout } from "./components/ProfileLayout";
import { AdminDashboard } from "./components/admin/pages/AdminDashboard";
import { AdminProducts } from "./components/admin/pages/AdminProducts";
import { AdminProductAdd } from "./components/admin/pages/AdminProductAdd";
import { AdminOrders } from "./components/admin/pages/AdminOrders";
import { AdminUsers } from "./components/admin/pages/AdminUsers";
import { AdminArticles } from "./components/admin/pages/AdminArticles";
import { AdminArticleAdd } from "./components/admin/pages/AdminArticleAdd";
import { AdminArticleEdit } from "./components/admin/pages/AdminArticleEdit";
import { AdminConsultations } from "./components/admin/pages/AdminConsultations";
import { AdminConsultationDetail } from "./components/admin/pages/AdminConsultationDetail";
import { AdminContactMessages } from "./components/admin/AdminContactMessages";
import { DebugSchema } from "./components/admin/DebugSchema";
import { AdminTopBar } from "./components/admin/AdminTopBar";
import { AdminLayout as AdminLayoutComponent } from "./components/admin/AdminLayout";
import { SitemapXmlRedirect } from "./components/SitemapXmlRedirect";
import { ProtectedAdminRoute } from "./components/admin/ProtectedAdminRoute";
import { PrintInvoice } from "./components/admin/orders/PrintInvoice";
import { PrintAddress } from "./components/admin/orders/PrintAddress";
import { BulkPrintInvoices } from "./components/admin/orders/BulkPrintInvoices";
import { BulkPrintLabels } from "./components/admin/orders/BulkPrintLabels";
import { ConsultationWizard } from "./components/ConsultationWizard";
import { ConsultationSuccessPage } from "./components/pages/ConsultationSuccessPage";
import { ConsultationDetail } from "./components/pages/ConsultationDetail";
import { OrderDetails } from "./components/pages/OrderDetails";
import { WelcomePopup } from "./components/WelcomePopup";
import {
  CartProvider,
  useCart,
}
from "./components/CartContext";
import { UserProvider } from "./components/UserContext";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { Toaster } from "./components/ui/sonner";
import { Product } from "./utils/product";
import {
  projectId,
  publicAnonKey,
} from "./utils/supabase/info";
import { GoogleTagManager } from "./components/GoogleTagManager";
import { initPerformanceMonitoring } from "./utils/performanceMonitor";
import { ResourceHints } from "./components/ResourceHints";
import { cachedFetch } from "./utils/apiCache";

// Set favicon
const setFavicon = () => {
  const link =
    document.querySelector("link[rel*='icon']") ||
    document.createElement("link");
  link.type = "image/png";
  link.rel = "icon";
  link.href =
    "https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/favicon_green.png";
  document.head.appendChild(link);
};

// Wrapper for ProductList to use State
const ProductListWrapper = ({
  products,
}: {
  products: Product[];
}) => {
  return <ProductListPage products={products} />;
};

// Wrapper for ProductList with Category Slug
const CategoryProductListWrapper = ({
  products,
}: {
  products: Product[];
}) => {
  const { categorySlug } = useParams();
  return (
    <ProductListPage
      products={products}
      categorySlug={categorySlug}
    />
  );
};

// Legacy URL redirector for old category URLs
const LegacyCategoryRedirect = () => {
  const { oldSlug } = useParams();
  const navigate = useNavigate();

  // Map old slugs to new slugs
  // این mapping باید با slug‌های واقعی دیتابیس شما هماهنگ باشد
  const legacySlugMap: Record<string, string> = {
    "hair-care-oils": "hair-care-oils",
    "therapeutic-oils": "therapeutic-oils",
    "beauty-oils": "beauty-oils",
    "skin-hair-care-tools": "skin-hair-care-tools",
    "hair-treatment-packages": "hair-treatment-packages",
    "essential-oils-extracts": "essential-oils-extracts",
    "edible-oils-guide": "edible-oils-guide",
  };

  useEffect(() => {
    const newSlug = oldSlug ? legacySlugMap[oldSlug] : null;
    if (newSlug) {
      // Redirect to new category URL
      navigate(`/category/${newSlug}`, { replace: true });
    } else {
      // If no mapping found, go to all products
      navigate("/products", { replace: true });
    }
  }, [oldSlug]); // ✅ فقط oldSlug - navigate stable است

  return (
    <div className="min-h-[50vh] flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-muted-foreground">
          در حال انتقال...
        </p>
      </div>
    </div>
  );
};

// Generic URL redirector for legacy URLs
const GenericRedirect = ({ to }: { to: string }) => {
  const navigate = useNavigate();

  useEffect(() => {
    navigate(to, { replace: true });
  }, [to, navigate]);

  return (
    <div className="min-h-[50vh] flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-muted-foreground">
          در حال انتقال...
        </p>
      </div>
    </div>
  );
};

// Category slug redirector (for URLs without /products or /category prefix)
const DirectCategoryRedirect = () => {
  const { slug } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (slug) {
      navigate(`/category/${slug}`, { replace: true });
    } else {
      navigate("/products", { replace: true });
    }
  }, [slug, navigate]);

  return (
    <div className="min-h-[50vh] flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-muted-foreground">
          در حال انتقال...
        </p>
      </div>
    </div>
  );
};

// Wrapper for ProductDetail to use Params
const ProductDetailWrapper = ({
  products,
}: {
  products: Product[];
}) => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [fullProduct, setFullProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Find product from list to get ID
  const listProduct = products.find((p) => {
    // Try matching by slug first
    if (p.slug === slug) return true;

    // Fallback to matching by ID (string conversion)
    const productIdStr = String(p.product_id || p.id);
    return productIdStr === slug;
  });

  // Fetch full product details from backend
  useEffect(() => {
    async function fetchFullProduct() {
      if (!listProduct) {
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        const productId = listProduct.product_id || listProduct.id;
        logger.log('Fetching full product details for ID:', productId);
        
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/${productId}`,
          {
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
          }
        );

        if (!response.ok) {
          logger.error('Failed to fetch product details');
          setFullProduct(listProduct); // Fallback to list product
          setIsLoading(false);
          return;
        }

        const data = await response.json();
        logger.success('Full product fetched:', data.product);
        setFullProduct(data.product || listProduct);
      } catch (error) {
        logger.error('Error fetching product details:', error);
        setFullProduct(listProduct); // Fallback to list product
      } finally {
        setIsLoading(false);
      }
    }

    fetchFullProduct();
  }, [slug, products]);

  if (isLoading || !products.length) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  if (!listProduct || !fullProduct) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold mb-4">
          محصول یافت نشد
        </h2>
        <button
          onClick={() => navigate("/products")}
          className="px-4 py-2 bg-primary text-white rounded-lg"
        >
          بازگشت به محصولات
        </button>
      </div>
    );
  }

  const relatedProducts = products
    .filter((p) => {
      const currentFamily = fullProduct.product_family;
      const pFamily = p.product_family;
      const currentProdId = String(
        fullProduct.product_id || fullProduct.id,
      );
      const pId = String(p.product_id || p.id);
      return (
        currentFamily &&
        pFamily === currentFamily &&
        pId !== currentProdId
      );
    })
    .slice(0, 4);

  return (
    <ProductDetailPage
      product={fullProduct}
      relatedProducts={relatedProducts}
      onBack={() => navigate(-1)}
    />
  );
};

// Wrapper for Admin Views
const AdminLayout = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  return (
    <>
      <AdminTopBar />
      {children}
    </>
  );
};

function AppContent() {
  const { getTotalItems } = useCart();
  const navigate = useNavigate();
  const location = useLocation();

  const [products, setProducts] = useState<Product[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<
    Product[]
  >([]);
  const [loading, setLoading] = useState(true);

  // Map path to page ID for Header highlighting
  const getPageId = (pathname: string) => {
    if (pathname === "/") return "home";
    if (
      pathname.startsWith("/products") ||
      pathname.startsWith("/product/")
    )
      return "products";
    if (pathname.startsWith("/blog")) return "blog";
    if (pathname.startsWith("/consultation"))
      return "consultation";
    if (pathname === "/contact") return "contact";
    return "";
  };

  // Fetch products
  useEffect(() => {
    setFavicon();

    async function fetchProducts() {
      try {
        // Parallel fetch for better performance with caching
        const [productsData, featuredData] = await Promise.all([
          cachedFetch<any>(
            `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products`,
            {
              headers: {
                Authorization: `Bearer ${publicAnonKey}`,
              },
            },
            5 * 60 * 1000, // Cache for 5 minutes
          ).catch((error) => {
            logger.error("Failed to fetch products:", error);
            logger.error("Error details:", error.message, error.stack);
            return { products: [] };
          }),
          cachedFetch<any>(
            `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/featured`,
            {
              headers: {
                Authorization: `Bearer ${publicAnonKey}`,
              },
            },
            5 * 60 * 1000, // Cache for 5 minutes
          ).catch((error) => {
            logger.error("Failed to fetch featured products:", error);
            logger.error("Error details:", error.message, error.stack);
            return { products: [] };
          }), // Gracefully handle featured products failure
        ]);

        logger.log('Featured products received from backend:', featuredData.products?.slice(0, 5).map((p: any) => ({
          name: p.product_name,
          score: p.score,
          created_at: p.created_at
        })));

        setProducts(productsData.products || []);
        setFeaturedProducts(featuredData.products || []);
      } catch (error) {
        logger.error("Error fetching products:", error);
        // Set empty arrays so app continues to work
        setProducts([]);
        setFeaturedProducts([]);
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">
            در حال بارگذاری...
          </p>
        </div>
      </div>
    );
  }

  const isPrintView =
    location.pathname.includes("/admin/print-");
  const isAdminView = location.pathname.startsWith("/admin");

  if (isPrintView) {
    return (
      <ProtectedAdminRoute>
        <Routes>
          <Route
            path="/admin/print-invoice/:id"
            element={
              <div className="relative">
                <button
                  onClick={() => navigate("/admin/orders")}
                  className="fixed top-4 left-4 z-50 px-4 py-2 bg-gray-900 text-white rounded-lg shadow-lg hover:bg-black transition-colors print:hidden flex items-center gap-2"
                >
                  بازگشت به سفارشات
                </button>
                <PrintWrapper type="invoice" />
              </div>
            }
          />
          <Route
            path="/admin/print-address/:id"
            element={
              <div className="relative">
                <button
                  onClick={() => navigate("/admin/orders")}
                  className="fixed top-4 left-4 z-50 px-4 py-2 bg-gray-900 text-white rounded-lg shadow-lg hover:bg-black transition-colors print:hidden flex items-center gap-2"
                >
                  بازگشت به سفارشات
                </button>
                <PrintWrapper type="address" />
              </div>
            }
          />
          <Route
            path="/admin/print-invoices/:orderIds"
            element={
              <div className="relative">
                <button
                  onClick={() => navigate("/admin/orders")}
                  className="fixed top-4 left-4 z-50 px-4 py-2 bg-gray-900 text-white rounded-lg shadow-lg hover:bg-black transition-colors print:hidden flex items-center gap-2"
                >
                  بازگشت به سفارشات
                </button>
                <BulkPrintInvoices />
              </div>
            }
          />
          <Route
            path="/admin/print-labels/:orderIds"
            element={
              <div className="relative">
                <button
                  onClick={() => navigate("/admin/orders")}
                  className="fixed top-4 left-4 z-50 px-4 py-2 bg-gray-900 text-white rounded-lg shadow-lg hover:bg-black transition-colors print:hidden flex items-center gap-2"
                >
                  بازگشت به سفارشات
                </button>
                <BulkPrintLabels />
              </div>
            }
          />
        </Routes>
      </ProtectedAdminRoute>
    );
  }

  if (isAdminView) {
    return (
      <ProtectedAdminRoute>
        <AdminLayoutComponent>
          <Routes>
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/debug-schema" element={<DebugSchema />} />
            <Route
              path="/admin/products"
              element={<AdminProducts />}
            />
            <Route
              path="/admin/product/add"
              element={<AdminProductAdd />}
            />
            <Route
              path="/admin/orders"
              element={<AdminOrders />}
            />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route
              path="/admin/blog"
              element={<AdminArticles />}
            />
            <Route
              path="/admin/article/add"
              element={<AdminArticleAdd />}
            />
            <Route
              path="/admin/blog/edit/:id"
              element={<AdminArticleEdit />}
            />
            <Route
              path="/admin/consultations"
              element={<AdminConsultations />}
            />
            <Route
              path="/admin-consultation-detail/:id"
              element={<AdminConsultationDetail />}
            />
            <Route
              path="/admin/contact-messages"
              element={<AdminContactMessages />}
            />
            <Route path="*" element={<Navigate to="/admin" />} />
          </Routes>
          <Toaster position="top-left" dir="rtl" />
        </AdminLayoutComponent>
      </ProtectedAdminRoute>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col bg-background"
      dir="rtl"
    >
      <Header
        cartItemCount={getTotalItems()}
        currentPage={getPageId(location.pathname)}
        onNavigate={() => {}} // Legacy prop kept for now but unused by Header
      />

      <main className="flex-1">
        <Routes>
          <Route
            path="/"
            element={
              <HomePage featuredProducts={featuredProducts} />
            }
          />

          {/* Products & Categories */}
          <Route
            path="/products"
            element={<ProductListWrapper products={products} />}
          />
          <Route
            path="/category/:categorySlug"
            element={
              <CategoryProductListWrapper products={products} />
            }
          />
          <Route
            path="/product/:slug"
            element={
              <ProductDetailWrapper products={products} />
            }
          />

          {/* Legacy redirects for old category URLs with /products prefix */}
          <Route
            path="/products/:oldSlug"
            element={<LegacyCategoryRedirect />}
          />

          {/* Direct category URLs (without /products or /category prefix) */}
          <Route
            path="/hair-care-oils"
            element={
              <GenericRedirect to="/category/hair-care-oils" />
            }
          />
          <Route
            path="/hair-care-oils/hair-treatment-packages"
            element={
              <GenericRedirect to="/category/hair-treatment-packages" />
            }
          />
          <Route
            path="/therapeutic-oils"
            element={
              <GenericRedirect to="/category/therapeutic-oils" />
            }
          />
          <Route
            path="/beauty-oils"
            element={
              <GenericRedirect to="/category/beauty-oils" />
            }
          />
          <Route
            path="/skin-hair-care-tools"
            element={
              <GenericRedirect to="/category/skin-hair-care-tools" />
            }
          />
          <Route
            path="/essential-oils-extracts"
            element={
              <GenericRedirect to="/category/essential-oils-extracts" />
            }
          />

          {/* Consultation redirects */}
          <Route
            path="/smart-oil-consultation"
            element={<GenericRedirect to="/consultation" />}
          />
          <Route
            path="/consultation"
            element={<ConsultationWizard />}
          />
          <Route
            path="/consultation/success/:id"
            element={<ConsultationSuccessWrapper />}
          />

          {/* Customer Services redirects */}
          <Route
            path="/customer-services"
            element={<GenericRedirect to="/faq" />}
          />
          <Route
            path="/customer-services/buying-shipping-guide"
            element={<GenericRedirect to="/shipping-guide" />}
          />
          <Route
            path="/customer-services/bazgasht-kala"
            element={<GenericRedirect to="/return-policy" />}
          />
          <Route
            path="/customer-services/policy"
            element={<GenericRedirect to="/terms" />}
          />
          <Route
            path="/customer-services/privacy-policy"
            element={<GenericRedirect to="/privacy" />}
          />

          {/* Money back guarantee redirect */}
          <Route
            path="/100-money-back-guarantee-policy"
            element={
              <GenericRedirect to="/money-back-guarantee" />
            }
          />

          {/* Blog/Educational Articles redirects */}
          <Route
            path="/educational-articles"
            element={<GenericRedirect to="/blog" />}
          />
          <Route
            path="/educational-articles/care-and-beauty"
            element={<GenericRedirect to="/blog" />}
          />
          <Route
            path="/educational-articles/natural-remedies"
            element={<GenericRedirect to="/blog" />}
          />
          <Route
            path="/educational-articles/makeup-tips-guides"
            element={<GenericRedirect to="/blog" />}
          />
          <Route
            path="/educational-articles/body-joint-care"
            element={<GenericRedirect to="/blog" />}
          />
          <Route
            path="/educational-articles/organic-products"
            element={<GenericRedirect to="/blog" />}
          />
          <Route
            path="/educational-articles/properties-of-vegetable-oils"
            element={<GenericRedirect to="/blog" />}
          />

          {/* Brands & Tags redirects */}
          <Route
            path="/brands"
            element={<GenericRedirect to="/products" />}
          />
          <Route
            path="/brands/oilglobal"
            element={<GenericRedirect to="/about" />}
          />
          <Route
            path="/brands/nursaa"
            element={<GenericRedirect to="/about" />}
          />
          <Route
            path="/tags"
            element={<GenericRedirect to="/products" />}
          />

          {/* About & Contact redirects */}
          <Route
            path="/about-us"
            element={<GenericRedirect to="/about" />}
          />
          <Route
            path="/sitemap"
            element={<GenericRedirect to="/site-map" />}
          />
          <Route
            path="/sitemap.xml"
            element={<SitemapXmlRedirect />}
          />

          {/* Main pages */}
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route
            path="/payment/callback"
            element={<PaymentCallbackPage />}
          />
          <Route path="/contact" element={<ContactPage />} />
          <Route
            path="/login"
            element={<LoginPage onBack={() => navigate(-1)} />}
          />
          <Route path="/blog" element={<BlogListPage />} />
          <Route
            path="/read/:slug"
            element={<BlogArticlePage />}
          />
          <Route
            path="/search"
            element={<SearchPageWrapper />}
          />
          <Route path="/db-status" element={<DBStatusPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route
            path="/order-tracking"
            element={<OrderTrackingPage />}
          />
          <Route
            path="/shipping-guide"
            element={<ShippingGuidePage />}
          />
          <Route
            path="/return-policy"
            element={<ReturnPolicyPage />}
          />
          <Route
            path="/money-back-guarantee"
            element={<MoneyBackGuaranteePage />}
          />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/site-map" element={<SiteMapPage />} />

          {/* Profile Routes */}
          <Route
            path="/profile"
            element={
              <ProfileLayout activePage="home">
                <UserProfileHome />
              </ProfileLayout>
            }
          />
          <Route
            path="/profile/consultations"
            element={
              <ProfileLayout activePage="consultations">
                <MyConsultations />
              </ProfileLayout>
            }
          />
          <Route
            path="/profile/consultations/:id"
            element={
              <ProfileLayout activePage="consultations">
                <ConsultationDetail />
              </ProfileLayout>
            }
          />
          <Route
            path="/profile/orders"
            element={
              <ProfileLayout activePage="orders">
                <MyOrders />
              </ProfileLayout>
            }
          />
          <Route
            path="/profile/orders/:id"
            element={
              <ProfileLayout activePage="orders">
                <OrderDetails />
              </ProfileLayout>
            }
          />
          <Route
            path="/profile/wallet"
            element={
              <ProfileLayout activePage="wallet">
                <WalletPage />
              </ProfileLayout>
            }
          />
          <Route
            path="/profile/settings"
            element={
              <ProfileLayout activePage="settings">
                <AccountSettings />
              </ProfileLayout>
            }
          />
          <Route
            path="/profile/affiliate"
            element={
              <ProfileLayout activePage="affiliate">
                <AffiliatePage />
              </ProfileLayout>
            }
          />

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>

      <Footer />
      <FloatingContactButton />
      <WelcomePopup />
      <Toaster
        position="top-center"
        dir="rtl"
        style={{ top: "70px" }}
      />
    </div>
  );
}

// Helpers
const PrintWrapper = ({
  type,
}: {
  type: "invoice" | "address";
}) => {
  const { id } = useParams();
  if (type === "invoice") return <PrintInvoice orderId={id!} />;
  return <PrintAddress orderId={id!} />;
};

const ConsultationSuccessWrapper = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  return (
    <ConsultationSuccessPage
      consultationId={id}
      onNavigate={(path: string) => navigate(path)}
    />
  );
};

const SearchPageWrapper = () => {
  const [query] = useState(
    new URLSearchParams(window.location.search).get("q") || "",
  );
  return <SearchPage initialQuery={query} />;
};

export default function App() {
  // Initialize performance monitoring on mount
  useEffect(() => {
    initPerformanceMonitoring();
  }, []);

  return (
    <BrowserRouter>
      <ScrollToTop />
      <GoogleTagManager gtmId="GTM-MWPHTW6B" />
      <ResourceHints />
      <ErrorBoundary>
        <CartProvider>
          <UserProvider>
            <AppContent />
          </UserProvider>
        </CartProvider>
      </ErrorBoundary>
    </BrowserRouter>
  );
}