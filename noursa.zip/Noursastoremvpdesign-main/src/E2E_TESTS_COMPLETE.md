# 🧪 تست‌های End-to-End کامل - فروشگاه nursaa.ir

> **نسخه:** 1.0  
> **تاریخ:** دی ۱۴۰۳  
> **Framework:** Playwright + TypeScript  

---

## 📑 فهرست مطالب

1. [راه‌اندازی محیط تست](#1-راه‌اندازی-محیط-تست)
2. [ساختار پروژه تست](#2-ساختار-پروژه-تست)
3. [تست‌های فروشگاه](#3-تست‌های-فروشگاه)
4. [تست‌های مشاوره](#4-تست‌های-مشاوره)
5. [تست‌های کد تخفیف](#5-تست‌های-کد-تخفیف)
6. [تست‌های پشتیبانی](#6-تست‌های-پشتیبانی)
7. [تست‌های همکاری در فروش](#7-تست‌های-همکاری-در-فروش)
8. [تست‌های AI](#8-تست‌های-ai)
9. [تست‌های ارتباطات](#9-تست‌های-ارتباطات)
10. [تست‌های پنل ادمین](#10-تست‌های-پنل-ادمین)
11. [تست‌های امنیتی](#11-تست‌های-امنیتی)
12. [تست‌های Performance](#12-تست‌های-performance)

---

## 1️⃣ راه‌اندازی محیط تست

### 1.1 نصب Dependencies

```bash
npm install -D @playwright/test
npm install -D @faker-js/faker
npm install -D dotenv
```

### 1.2 تنظیمات Playwright

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html'],
    ['json', { outputFile: 'test-results/results.json' }],
    ['junit', { outputFile: 'test-results/junit.xml' }],
  ],
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:5173',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 12'] },
    },
  ],
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:5173',
    reuseExistingServer: !process.env.CI,
  },
});
```

### 1.3 Environment Variables

```bash
# .env.test
BASE_URL=http://localhost:5173
API_URL=https://test-project.supabase.co/functions/v1/make-server-fbc72c25
ADMIN_PHONE=09219675992
ADMIN_PASSWORD=TestPassword123!
TEST_PHONE=09123456789
TEST_EMAIL=test@example.com
ZARINPAL_TEST_MODE=true
```

---

## 2️⃣ ساختار پروژه تست

```
tests/
├── e2e/
│   ├── shop/
│   │   ├── product-browsing.spec.ts
│   │   ├── cart.spec.ts
│   │   ├── checkout.spec.ts
│   │   └── order-tracking.spec.ts
│   │
│   ├── consultation/
│   │   ├── consultation-form.spec.ts
│   │   ├── consultation-tracking.spec.ts
│   │   └── consultation-results.spec.ts
│   │
│   ├── discount/
│   │   ├── discount-codes.spec.ts
│   │   └── discount-validation.spec.ts
│   │
│   ├── support/
│   │   ├── tickets.spec.ts
│   │   └── chat.spec.ts
│   │
│   ├── affiliate/
│   │   ├── registration.spec.ts
│   │   ├── referrals.spec.ts
│   │   └── commissions.spec.ts
│   │
│   ├── ai/
│   │   ├── recommendations.spec.ts
│   │   ├── ai-search.spec.ts
│   │   └── content-generation.spec.ts
│   │
│   ├── communication/
│   │   ├── sms.spec.ts
│   │   └── email.spec.ts
│   │
│   ├── admin/
│   │   ├── admin-login.spec.ts
│   │   ├── product-management.spec.ts
│   │   ├── order-management.spec.ts
│   │   ├── consultation-management.spec.ts
│   │   ├── discount-management.spec.ts
│   │   ├── ticket-management.spec.ts
│   │   └── analytics.spec.ts
│   │
│   ├── security/
│   │   ├── authentication.spec.ts
│   │   ├── authorization.spec.ts
│   │   └── csrf.spec.ts
│   │
│   └── performance/
│       ├── page-load.spec.ts
│       └── api-response.spec.ts
│
├── fixtures/
│   ├── auth.fixture.ts
│   ├── products.fixture.ts
│   ├── orders.fixture.ts
│   └── users.fixture.ts
│
├── helpers/
│   ├── api.helper.ts
│   ├── database.helper.ts
│   ├── faker.helper.ts
│   └── screenshot.helper.ts
│
└── utils/
    ├── test-data.ts
    ├── assertions.ts
    └── constants.ts
```

---

## 3️⃣ تست‌های فروشگاه

### 3.1 Product Browsing Tests

```typescript
// tests/e2e/shop/product-browsing.spec.ts
import { test, expect } from '@playwright/test';
import { faker } from '@faker-js/faker';

test.describe('جستجو و مرور محصولات', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('TC-SHOP-001: نمایش صفحه اصلی با محصولات ویژه', async ({ page }) => {
    // Check page title
    await expect(page).toHaveTitle(/Oil Global|nursaa/i);
    
    // Check featured products section
    const featuredSection = page.locator('[data-testid="featured-products"]');
    await expect(featuredSection).toBeVisible();
    
    // Check at least 4 products are displayed
    const productCards = page.locator('[data-testid="product-card"]');
    await expect(productCards).toHaveCount(await productCards.count(), { 
      timeout: 5000 
    });
    expect(await productCards.count()).toBeGreaterThanOrEqual(4);
  });

  test('TC-SHOP-002: جستجوی محصول', async ({ page }) => {
    const searchTerm = 'روغن زیتون';
    
    // Enter search term
    await page.fill('[data-testid="search-input"]', searchTerm);
    await page.press('[data-testid="search-input"]', 'Enter');
    
    // Wait for search results
    await page.waitForURL(/.*search.*/);
    await page.waitForLoadState('networkidle');
    
    // Check results
    const results = page.locator('[data-testid="search-results"]');
    await expect(results).toBeVisible();
    
    // Verify results contain search term
    const productTitles = await page.locator('[data-testid="product-title"]').allTextContents();
    expect(productTitles.length).toBeGreaterThan(0);
  });

  test('TC-SHOP-003: فیلتر محصولات بر اساس دسته‌بندی', async ({ page }) => {
    // Click on a category
    await page.click('[data-testid="category-link"]:has-text("روغن‌های طبیعی")');
    
    // Wait for category page
    await page.waitForURL(/.*category.*/);
    
    // Check URL contains category slug
    expect(page.url()).toContain('category');
    
    // Check products are displayed
    const products = page.locator('[data-testid="product-card"]');
    await expect(products.first()).toBeVisible({ timeout: 5000 });
  });

  test('TC-SHOP-004: مرتب‌سازی محصولات', async ({ page }) => {
    await page.goto('/products');
    
    // Select sort option
    await page.selectOption('[data-testid="sort-select"]', 'price-asc');
    
    // Wait for products to reload
    await page.waitForLoadState('networkidle');
    
    // Get all prices
    const prices = await page.locator('[data-testid="product-price"]').allTextContents();
    const numericPrices = prices.map(p => 
      parseInt(p.replace(/[^\d]/g, ''))
    );
    
    // Verify ascending order
    for (let i = 1; i < numericPrices.length; i++) {
      expect(numericPrices[i]).toBeGreaterThanOrEqual(numericPrices[i - 1]);
    }
  });

  test('TC-SHOP-005: نمایش جزئیات محصول', async ({ page }) => {
    // Click on first product
    await page.click('[data-testid="product-card"]', { timeout: 5000 });
    
    // Wait for product detail page
    await page.waitForURL(/.*\/product\/.*/);
    
    // Check essential elements
    await expect(page.locator('[data-testid="product-title"]')).toBeVisible();
    await expect(page.locator('[data-testid="product-price"]')).toBeVisible();
    await expect(page.locator('[data-testid="product-description"]')).toBeVisible();
    await expect(page.locator('[data-testid="add-to-cart-btn"]')).toBeVisible();
    await expect(page.locator('[data-testid="product-images"]')).toBeVisible();
  });

  test('TC-SHOP-006: گالری تصاویر محصول', async ({ page }) => {
    await page.goto('/product/test-product-1');
    
    // Check main image
    const mainImage = page.locator('[data-testid="main-product-image"]');
    await expect(mainImage).toBeVisible();
    
    // Click on thumbnail
    const thumbnails = page.locator('[data-testid="product-thumbnail"]');
    if (await thumbnails.count() > 1) {
      await thumbnails.nth(1).click();
      
      // Wait for image to change
      await page.waitForTimeout(500);
      
      // Verify image changed
      const newSrc = await mainImage.getAttribute('src');
      expect(newSrc).toBeTruthy();
    }
  });
});
```

### 3.2 Cart Tests

```typescript
// tests/e2e/shop/cart.spec.ts
import { test, expect } from '@playwright/test';

test.describe('سبد خرید', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('TC-CART-001: افزودن محصول به سبد خرید', async ({ page }) => {
    // Go to product page
    await page.click('[data-testid="product-card"]');
    await page.waitForURL(/.*\/product\/.*/);
    
    // Get product details
    const productTitle = await page.locator('[data-testid="product-title"]').textContent();
    const productPrice = await page.locator('[data-testid="product-price"]').textContent();
    
    // Get cart count before
    const cartCountBefore = await page.locator('[data-testid="cart-count"]').textContent();
    
    // Add to cart
    await page.click('[data-testid="add-to-cart-btn"]');
    
    // Check success message
    await expect(page.locator('[data-testid="toast-success"]')).toBeVisible({ timeout: 3000 });
    
    // Check cart count increased
    const cartCountAfter = await page.locator('[data-testid="cart-count"]').textContent();
    expect(parseInt(cartCountAfter || '0')).toBe(parseInt(cartCountBefore || '0') + 1);
    
    // Go to cart
    await page.click('[data-testid="cart-icon"]');
    
    // Verify product in cart
    const cartItems = page.locator('[data-testid="cart-item"]');
    await expect(cartItems).toHaveCount(1);
    await expect(page.locator(`text=${productTitle}`)).toBeVisible();
  });

  test('TC-CART-002: تغییر تعداد محصول در سبد خرید', async ({ page }) => {
    // Add product to cart first
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    
    // Go to cart
    await page.goto('/cart');
    
    // Get initial quantity
    const quantityInput = page.locator('[data-testid="quantity-input"]').first();
    const initialQuantity = await quantityInput.inputValue();
    
    // Increase quantity
    await page.click('[data-testid="quantity-increase"]');
    
    // Wait for update
    await page.waitForTimeout(500);
    
    // Check quantity increased
    const newQuantity = await quantityInput.inputValue();
    expect(parseInt(newQuantity)).toBe(parseInt(initialQuantity) + 1);
    
    // Check total price updated
    await expect(page.locator('[data-testid="cart-total"]')).toBeVisible();
  });

  test('TC-CART-003: حذف محصول از سبد خرید', async ({ page }) => {
    // Add product to cart
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    
    // Go to cart
    await page.goto('/cart');
    
    // Get cart items count
    const itemsCountBefore = await page.locator('[data-testid="cart-item"]').count();
    
    // Remove item
    await page.click('[data-testid="remove-item-btn"]');
    
    // Confirm removal if needed
    const confirmBtn = page.locator('[data-testid="confirm-remove"]');
    if (await confirmBtn.isVisible({ timeout: 1000 })) {
      await confirmBtn.click();
    }
    
    // Wait for item to be removed
    await page.waitForTimeout(500);
    
    // Check item removed
    const itemsCountAfter = await page.locator('[data-testid="cart-item"]').count();
    expect(itemsCountAfter).toBe(itemsCountBefore - 1);
  });

  test('TC-CART-004: محاسبه صحیح مجموع سبد خرید', async ({ page }) => {
    // Add multiple products
    const productCards = page.locator('[data-testid="product-card"]');
    const count = Math.min(await productCards.count(), 3);
    
    for (let i = 0; i < count; i++) {
      await productCards.nth(i).click();
      await page.click('[data-testid="add-to-cart-btn"]');
      await page.goBack();
      await page.waitForLoadState('networkidle');
    }
    
    // Go to cart
    await page.goto('/cart');
    
    // Calculate expected total
    const prices = await page.locator('[data-testid="item-price"]').allTextContents();
    const quantities = await page.locator('[data-testid="quantity-input"]').all();
    
    let expectedTotal = 0;
    for (let i = 0; i < prices.length; i++) {
      const price = parseInt(prices[i].replace(/[^\d]/g, ''));
      const quantity = parseInt(await quantities[i].inputValue());
      expectedTotal += price * quantity;
    }
    
    // Get displayed total
    const displayedTotal = await page.locator('[data-testid="cart-subtotal"]').textContent();
    const actualTotal = parseInt(displayedTotal?.replace(/[^\d]/g, '') || '0');
    
    // Verify totals match
    expect(actualTotal).toBe(expectedTotal);
  });

  test('TC-CART-005: خالی کردن کامل سبد خرید', async ({ page }) => {
    // Add products
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    
    // Go to cart
    await page.goto('/cart');
    
    // Clear cart
    await page.click('[data-testid="clear-cart-btn"]');
    
    // Confirm
    await page.click('[data-testid="confirm-clear-cart"]');
    
    // Wait for cart to clear
    await page.waitForTimeout(500);
    
    // Check empty state
    await expect(page.locator('[data-testid="empty-cart-message"]')).toBeVisible();
    
    // Check cart count is 0
    const cartCount = await page.locator('[data-testid="cart-count"]').textContent();
    expect(cartCount).toBe('0');
  });
});
```

### 3.3 Checkout Tests

```typescript
// tests/e2e/shop/checkout.spec.ts
import { test, expect } from '@playwright/test';
import { faker } from '@faker-js/faker';

test.describe('فرآیند خرید', () => {
  const testCustomer = {
    name: faker.person.fullName(),
    phone: '09123456789',
    email: faker.internet.email(),
    address: faker.location.streetAddress(),
    city: 'تهران',
    postalCode: '1234567890',
  };

  test.beforeEach(async ({ page }) => {
    // Add product to cart
    await page.goto('/');
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    await page.goto('/cart');
  });

  test('TC-CHECKOUT-001: تکمیل فرآیند خرید با موفقیت', async ({ page }) => {
    // Click checkout
    await page.click('[data-testid="checkout-btn"]');
    
    // Wait for checkout page
    await page.waitForURL(/.*\/checkout.*/);
    
    // Fill customer information
    await page.fill('[data-testid="customer-name"]', testCustomer.name);
    await page.fill('[data-testid="customer-phone"]', testCustomer.phone);
    await page.fill('[data-testid="customer-email"]', testCustomer.email);
    
    // Fill shipping address
    await page.fill('[data-testid="shipping-address"]', testCustomer.address);
    await page.fill('[data-testid="shipping-city"]', testCustomer.city);
    await page.fill('[data-testid="shipping-postal-code"]', testCustomer.postalCode);
    
    // Select payment method
    await page.click('[data-testid="payment-zarinpal"]');
    
    // Submit order
    await page.click('[data-testid="submit-order-btn"]');
    
    // Wait for redirect to payment gateway or success page
    await page.waitForURL(/.*\/(payment|order-success).*/, { timeout: 10000 });
    
    // If redirected to Zarinpal (test mode), complete payment
    if (page.url().includes('zarinpal')) {
      // In test mode, just confirm
      await page.click('[data-testid="confirm-payment"]');
    }
    
    // Wait for success page
    await page.waitForURL(/.*\/order-success.*/, { timeout: 10000 });
    
    // Check success message
    await expect(page.locator('[data-testid="order-success-message"]')).toBeVisible();
    
    // Check order number is displayed
    const orderNumber = page.locator('[data-testid="order-number"]');
    await expect(orderNumber).toBeVisible();
    expect(await orderNumber.textContent()).toMatch(/\d{6,}/);
  });

  test('TC-CHECKOUT-002: اعتبارسنجی فرم اطلاعات', async ({ page }) => {
    await page.click('[data-testid="checkout-btn"]');
    
    // Try to submit empty form
    await page.click('[data-testid="submit-order-btn"]');
    
    // Check validation errors
    await expect(page.locator('text=نام و نام خانوادگی الزامی است')).toBeVisible();
    await expect(page.locator('text=شماره موبایل الزامی است')).toBeVisible();
    await expect(page.locator('text=آدرس الزامی است')).toBeVisible();
  });

  test('TC-CHECKOUT-003: اعتبارسنجی شماره موبایل', async ({ page }) => {
    await page.click('[data-testid="checkout-btn"]');
    
    // Fill invalid phone
    await page.fill('[data-testid="customer-phone"]', '123456');
    await page.blur('[data-testid="customer-phone"]');
    
    // Check error message
    await expect(page.locator('text=شماره موبایل معتبر نیست')).toBeVisible();
    
    // Fill valid phone
    await page.fill('[data-testid="customer-phone"]', '09123456789');
    await page.blur('[data-testid="customer-phone"]');
    
    // Error should disappear
    await expect(page.locator('text=شماره موبایل معتبر نیست')).not.toBeVisible();
  });

  test('TC-CHECKOUT-004: محاسبه هزینه ارسال', async ({ page }) => {
    await page.click('[data-testid="checkout-btn"]');
    
    // Fill address
    await page.fill('[data-testid="shipping-city"]', 'تهران');
    await page.blur('[data-testid="shipping-city"]');
    
    // Wait for shipping calculation
    await page.waitForTimeout(1000);
    
    // Check shipping cost is displayed
    const shippingCost = page.locator('[data-testid="shipping-cost"]');
    await expect(shippingCost).toBeVisible();
    
    // Verify it's a number
    const cost = await shippingCost.textContent();
    expect(cost).toMatch(/\d+/);
  });

  test('TC-CHECKOUT-005: بررسی خلاصه سفارش', async ({ page }) => {
    await page.click('[data-testid="checkout-btn"]');
    
    // Check order summary
    await expect(page.locator('[data-testid="order-summary"]')).toBeVisible();
    
    // Check items are listed
    const items = page.locator('[data-testid="summary-item"]');
    expect(await items.count()).toBeGreaterThan(0);
    
    // Check totals
    await expect(page.locator('[data-testid="summary-subtotal"]')).toBeVisible();
    await expect(page.locator('[data-testid="summary-shipping"]')).toBeVisible();
    await expect(page.locator('[data-testid="summary-total"]')).toBeVisible();
  });

  test('TC-CHECKOUT-006: استفاده از کد تخفیف در فرآیند خرید', async ({ page }) => {
    await page.click('[data-testid="checkout-btn"]');
    
    // Get total before discount
    const totalBefore = await page.locator('[data-testid="summary-total"]').textContent();
    
    // Apply discount code
    await page.fill('[data-testid="discount-code-input"]', 'TEST10');
    await page.click('[data-testid="apply-discount-btn"]');
    
    // Wait for discount to apply
    await page.waitForTimeout(1000);
    
    // Check discount is applied
    await expect(page.locator('[data-testid="discount-amount"]')).toBeVisible();
    
    // Check total is reduced
    const totalAfter = await page.locator('[data-testid="summary-total"]').textContent();
    const before = parseInt(totalBefore?.replace(/[^\d]/g, '') || '0');
    const after = parseInt(totalAfter?.replace(/[^\d]/g, '') || '0');
    expect(after).toBeLessThan(before);
  });
});
```

### 3.4 Order Tracking Tests

```typescript
// tests/e2e/shop/order-tracking.spec.ts
import { test, expect } from '@playwright/test';

test.describe('پیگیری سفارش', () => {
  const testOrderNumber = '123456'; // Should be set from previous order or fixture

  test('TC-ORDER-001: جستجوی سفارش با شماره سفارش', async ({ page }) => {
    await page.goto('/track-order');
    
    // Enter order number
    await page.fill('[data-testid="order-number-input"]', testOrderNumber);
    await page.fill('[data-testid="phone-input"]', '09123456789');
    
    // Submit
    await page.click('[data-testid="track-order-btn"]');
    
    // Wait for results
    await page.waitForLoadState('networkidle');
    
    // Check order details are displayed
    await expect(page.locator('[data-testid="order-details"]')).toBeVisible();
    await expect(page.locator('[data-testid="order-status"]')).toBeVisible();
  });

  test('TC-ORDER-002: نمایش تاریخچه وضعیت سفارش', async ({ page }) => {
    await page.goto(`/order/${testOrderNumber}`);
    
    // Check status timeline
    const timeline = page.locator('[data-testid="order-timeline"]');
    await expect(timeline).toBeVisible();
    
    // Check at least one status exists
    const statuses = page.locator('[data-testid="timeline-status"]');
    expect(await statuses.count()).toBeGreaterThan(0);
  });

  test('TC-ORDER-003: دانلود فاکتور', async ({ page }) => {
    await page.goto(`/order/${testOrderNumber}`);
    
    // Click download invoice
    const [download] = await Promise.all([
      page.waitForEvent('download'),
      page.click('[data-testid="download-invoice-btn"]')
    ]);
    
    // Check file is downloaded
    expect(download.suggestedFilename()).toContain('invoice');
    expect(download.suggestedFilename()).toContain('.pdf');
  });
});
```

---

## 4️⃣ تست‌های مشاوره

```typescript
// tests/e2e/consultation/consultation-form.spec.ts
import { test, expect } from '@playwright/test';
import { faker } from '@faker-js/faker';
import path from 'path';

test.describe('فرم مشاوره', () => {
  const testData = {
    name: faker.person.fullName(),
    phone: '09123456789',
    age: '25',
    gender: 'female',
  };

  test.beforeEach(async ({ page }) => {
    await page.goto('/consultation');
  });

  test('TC-CONSULT-001: ارسال فرم مشاوره کامل', async ({ page }) => {
    // Fill basic info
    await page.fill('[data-testid="consult-name"]', testData.name);
    await page.fill('[data-testid="consult-phone"]', testData.phone);
    await page.fill('[data-testid="consult-age"]', testData.age);
    await page.click(`[data-testid="consult-gender-${testData.gender}"]`);
    
    // Fill skin type
    await page.click('[data-testid="skin-type-dry"]');
    
    // Fill concerns
    await page.check('[data-testid="concern-acne"]');
    await page.check('[data-testid="concern-wrinkles"]');
    
    // Upload photo
    const filePath = path.join(__dirname, '../../fixtures/test-image.jpg');
    await page.setInputFiles('[data-testid="photo-upload"]', filePath);
    
    // Wait for upload
    await page.waitForSelector('[data-testid="upload-success"]', { timeout: 5000 });
    
    // Fill additional info
    await page.fill('[data-testid="additional-info"]', 'اطلاعات تکمیلی تست');
    
    // Submit
    await page.click('[data-testid="submit-consultation"]');
    
    // Wait for success
    await expect(page.locator('[data-testid="consultation-success"]')).toBeVisible({ 
      timeout: 10000 
    });
    
    // Check reference number
    const refNumber = page.locator('[data-testid="consultation-ref-number"]');
    await expect(refNumber).toBeVisible();
  });

  test('TC-CONSULT-002: اعتبارسنجی فیلدهای الزامی', async ({ page }) => {
    // Try to submit empty form
    await page.click('[data-testid="submit-consultation"]');
    
    // Check validation errors
    await expect(page.locator('text=نام و نام خانوادگی الزامی است')).toBeVisible();
    await expect(page.locator('text=شماره موبایل الزامی است')).toBeVisible();
    await expect(page.locator('text=نوع پوست را انتخاب کنید')).toBeVisible();
  });

  test('TC-CONSULT-003: آپلود چند عکس', async ({ page }) => {
    const files = [
      path.join(__dirname, '../../fixtures/test-image-1.jpg'),
      path.join(__dirname, '../../fixtures/test-image-2.jpg'),
      path.join(__dirname, '../../fixtures/test-image-3.jpg'),
    ];
    
    await page.setInputFiles('[data-testid="photo-upload"]', files);
    
    // Wait for all uploads
    await page.waitForSelector('[data-testid="uploaded-image"]', { timeout: 10000 });
    
    // Check all images are shown
    const uploadedImages = page.locator('[data-testid="uploaded-image"]');
    expect(await uploadedImages.count()).toBe(3);
  });

  test('TC-CONSULT-004: حذف عکس آپلود شده', async ({ page }) => {
    // Upload image
    const filePath = path.join(__dirname, '../../fixtures/test-image.jpg');
    await page.setInputFiles('[data-testid="photo-upload"]', filePath);
    await page.waitForSelector('[data-testid="uploaded-image"]');
    
    // Remove image
    await page.click('[data-testid="remove-image-btn"]');
    
    // Check image is removed
    await expect(page.locator('[data-testid="uploaded-image"]')).not.toBeVisible();
  });

  test('TC-CONSULT-005: پیشنهاد محصول بر اساس مشاوره', async ({ page }) => {
    // Submit consultation
    await page.fill('[data-testid="consult-name"]', testData.name);
    await page.fill('[data-testid="consult-phone"]', testData.phone);
    await page.click('[data-testid="skin-type-oily"]');
    await page.check('[data-testid="concern-acne"]');
    await page.click('[data-testid="submit-consultation"]');
    
    // Wait for AI recommendations
    await page.waitForSelector('[data-testid="ai-recommendations"]', { 
      timeout: 15000 
    });
    
    // Check recommendations are displayed
    const recommendations = page.locator('[data-testid="recommended-product"]');
    expect(await recommendations.count()).toBeGreaterThan(0);
    
    // Check each recommendation has essential info
    const firstRecommendation = recommendations.first();
    await expect(firstRecommendation.locator('[data-testid="product-title"]')).toBeVisible();
    await expect(firstRecommendation.locator('[data-testid="recommendation-reason"]')).toBeVisible();
  });
});
```

---

## 5️⃣ تست‌های کد تخفیف

```typescript
// tests/e2e/discount/discount-codes.spec.ts
import { test, expect } from '@playwright/test';

test.describe('کدهای تخفیف', () => {
  test('TC-DISCOUNT-001: اعمال کد تخفیف درصدی', async ({ page }) => {
    // Add product and go to cart
    await page.goto('/');
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    await page.goto('/cart');
    
    // Get subtotal
    const subtotalText = await page.locator('[data-testid="cart-subtotal"]').textContent();
    const subtotal = parseInt(subtotalText?.replace(/[^\d]/g, '') || '0');
    
    // Apply 10% discount code
    await page.fill('[data-testid="discount-code-input"]', 'WELCOME10');
    await page.click('[data-testid="apply-discount-btn"]');
    
    // Wait for discount to apply
    await page.waitForTimeout(1000);
    
    // Check discount message
    await expect(page.locator('[data-testid="discount-success"]')).toBeVisible();
    
    // Check discount amount (10% of subtotal)
    const discountText = await page.locator('[data-testid="discount-amount"]').textContent();
    const discount = parseInt(discountText?.replace(/[^\d]/g, '') || '0');
    expect(discount).toBe(Math.floor(subtotal * 0.1));
    
    // Check total
    const totalText = await page.locator('[data-testid="cart-total"]').textContent();
    const total = parseInt(totalText?.replace(/[^\d]/g, '') || '0');
    expect(total).toBe(subtotal - discount);
  });

  test('TC-DISCOUNT-002: اعمال کد تخفیف مقدار ثابت', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    await page.goto('/cart');
    
    const subtotalText = await page.locator('[data-testid="cart-subtotal"]').textContent();
    const subtotal = parseInt(subtotalText?.replace(/[^\d]/g, '') || '0');
    
    // Apply 50,000 Toman discount
    await page.fill('[data-testid="discount-code-input"]', 'FIXED50K');
    await page.click('[data-testid="apply-discount-btn"]');
    
    await page.waitForTimeout(1000);
    
    // Check discount is exactly 50,000
    const discountText = await page.locator('[data-testid="discount-amount"]').textContent();
    const discount = parseInt(discountText?.replace(/[^\d]/g, '') || '0');
    expect(discount).toBe(50000);
  });

  test('TC-DISCOUNT-003: کد تخفیف نامعتبر', async ({ page }) => {
    await page.goto('/cart');
    
    // Try invalid code
    await page.fill('[data-testid="discount-code-input"]', 'INVALID123');
    await page.click('[data-testid="apply-discount-btn"]');
    
    // Check error message
    await expect(page.locator('[data-testid="discount-error"]')).toBeVisible();
    await expect(page.locator('text=کد تخفیف معتبر نیست')).toBeVisible();
  });

  test('TC-DISCOUNT-004: کد تخفیف منقضی شده', async ({ page }) => {
    await page.goto('/cart');
    
    await page.fill('[data-testid="discount-code-input"]', 'EXPIRED');
    await page.click('[data-testid="apply-discount-btn"]');
    
    await expect(page.locator('text=کد تخفیف منقضی شده است')).toBeVisible();
  });

  test('TC-DISCOUNT-005: حداقل مبلغ خرید برای کد تخفیف', async ({ page }) => {
    await page.goto('/');
    
    // Add cheap product
    await page.click('[data-testid="product-card"]:has-text("10000")');
    await page.click('[data-testid="add-to-cart-btn"]');
    await page.goto('/cart');
    
    // Try code with min purchase 100,000
    await page.fill('[data-testid="discount-code-input"]', 'MIN100K');
    await page.click('[data-testid="apply-discount-btn"]');
    
    await expect(page.locator('text=حداقل خرید')).toBeVisible();
  });

  test('TC-DISCOUNT-006: حذف کد تخفیف', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    await page.goto('/cart');
    
    // Apply discount
    await page.fill('[data-testid="discount-code-input"]', 'WELCOME10');
    await page.click('[data-testid="apply-discount-btn"]');
    await page.waitForTimeout(1000);
    
    // Get total with discount
    const totalWithDiscount = await page.locator('[data-testid="cart-total"]').textContent();
    
    // Remove discount
    await page.click('[data-testid="remove-discount-btn"]');
    await page.waitForTimeout(500);
    
    // Check total increased
    const totalWithoutDiscount = await page.locator('[data-testid="cart-total"]').textContent();
    const with_ = parseInt(totalWithDiscount?.replace(/[^\d]/g, '') || '0');
    const without = parseInt(totalWithoutDiscount?.replace(/[^\d]/g, '') || '0');
    expect(without).toBeGreaterThan(with_);
  });
});
```

---

## 6️⃣ تست‌های پشتیبانی

### 6.1 Ticket Tests

```typescript
// tests/e2e/support/tickets.spec.ts
import { test, expect } from '@playwright/test';
import { faker } from '@faker-js/faker';

test.describe('سیستم تیکت', () => {
  const testTicket = {
    subject: 'مشکل در پرداخت',
    message: faker.lorem.paragraph(),
    email: faker.internet.email(),
    phone: '09123456789',
  };

  test('TC-TICKET-001: ایجاد تیکت جدید', async ({ page }) => {
    await page.goto('/support/tickets');
    
    // Click create ticket
    await page.click('[data-testid="create-ticket-btn"]');
    
    // Fill form
    await page.fill('[data-testid="ticket-subject"]', testTicket.subject);
    await page.fill('[data-testid="ticket-message"]', testTicket.message);
    await page.fill('[data-testid="ticket-email"]', testTicket.email);
    await page.fill('[data-testid="ticket-phone"]', testTicket.phone);
    
    // Select category
    await page.selectOption('[data-testid="ticket-category"]', 'payment');
    
    // Submit
    await page.click('[data-testid="submit-ticket-btn"]');
    
    // Wait for success
    await expect(page.locator('[data-testid="ticket-success"]')).toBeVisible({ 
      timeout: 5000 
    });
    
    // Check ticket number
    const ticketNumber = page.locator('[data-testid="ticket-number"]');
    await expect(ticketNumber).toBeVisible();
  });

  test('TC-TICKET-002: مشاهده تیکت‌ها', async ({ page }) => {
    await page.goto('/support/my-tickets');
    
    // Check tickets list
    const ticketsList = page.locator('[data-testid="tickets-list"]');
    await expect(ticketsList).toBeVisible();
    
    // Check at least one ticket or empty state
    const tickets = page.locator('[data-testid="ticket-item"]');
    const emptyState = page.locator('[data-testid="no-tickets"]');
    
    const hasTickets = await tickets.count() > 0;
    const isEmpty = await emptyState.isVisible();
    
    expect(hasTickets || isEmpty).toBe(true);
  });

  test('TC-TICKET-003: پاسخ به تیکت', async ({ page }) => {
    // Assume we have a ticket
    await page.goto('/support/tickets/TEST-123');
    
    // Check ticket details
    await expect(page.locator('[data-testid="ticket-subject"]')).toBeVisible();
    await expect(page.locator('[data-testid="ticket-messages"]')).toBeVisible();
    
    // Reply to ticket
    const replyText = faker.lorem.paragraph();
    await page.fill('[data-testid="ticket-reply-input"]', replyText);
    await page.click('[data-testid="send-reply-btn"]');
    
    // Wait for reply to appear
    await page.waitForTimeout(1000);
    
    // Check reply is in messages
    await expect(page.locator(`text=${replyText}`)).toBeVisible();
  });

  test('TC-TICKET-004: فیلتر تیکت‌ها بر اساس وضعیت', async ({ page }) => {
    await page.goto('/support/my-tickets');
    
    // Filter by open tickets
    await page.click('[data-testid="filter-status-open"]');
    await page.waitForTimeout(500);
    
    // Check all displayed tickets are open
    const tickets = page.locator('[data-testid="ticket-status"]');
    const count = await tickets.count();
    
    for (let i = 0; i < count; i++) {
      const status = await tickets.nth(i).textContent();
      expect(status).toContain('باز');
    }
  });

  test('TC-TICKET-005: جستجو در تیکت‌ها', async ({ page }) => {
    await page.goto('/support/my-tickets');
    
    const searchTerm = 'پرداخت';
    await page.fill('[data-testid="search-tickets"]', searchTerm);
    await page.press('[data-testid="search-tickets"]', 'Enter');
    
    await page.waitForTimeout(500);
    
    // Check results contain search term
    const subjects = await page.locator('[data-testid="ticket-subject"]').allTextContents();
    const hasMatch = subjects.some(s => s.includes(searchTerm));
    expect(hasMatch).toBe(true);
  });
});
```

### 6.2 Chat Tests

```typescript
// tests/e2e/support/chat.spec.ts
import { test, expect } from '@playwright/test';

test.describe('چت آنلاین', () => {
  test('TC-CHAT-001: شروع چت', async ({ page }) => {
    await page.goto('/');
    
    // Click chat button
    await page.click('[data-testid="chat-button"]');
    
    // Wait for chat window
    await expect(page.locator('[data-testid="chat-window"]')).toBeVisible({ 
      timeout: 3000 
    });
    
    // Check welcome message from bot
    await expect(page.locator('[data-testid="bot-message"]').first()).toBeVisible();
  });

  test('TC-CHAT-002: ارسال پیام در چت', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-testid="chat-button"]');
    
    // Type message
    const testMessage = 'سلام، سوال دارم';
    await page.fill('[data-testid="chat-input"]', testMessage);
    await page.click('[data-testid="chat-send-btn"]');
    
    // Check message appears
    await expect(page.locator(`[data-testid="user-message"]:has-text("${testMessage}")`))
      .toBeVisible({ timeout: 2000 });
    
    // Wait for bot response
    await expect(page.locator('[data-testid="bot-message"]').last())
      .toBeVisible({ timeout: 10000 });
  });

  test('TC-CHAT-003: انتقال به کارشناس', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-testid="chat-button"]');
    
    // Request human agent
    await page.click('[data-testid="request-agent-btn"]');
    
    // Check waiting message
    await expect(page.locator('text=در انتظار اتصال به کارشناس')).toBeVisible();
  });

  test('TC-CHAT-004: بستن چت', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-testid="chat-button"]');
    
    // Close chat
    await page.click('[data-testid="close-chat-btn"]');
    
    // Check chat is closed
    await expect(page.locator('[data-testid="chat-window"]')).not.toBeVisible();
  });

  test('TC-CHAT-005: ارسال فایل در چت', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-testid="chat-button"]');
    
    // Upload file
    const filePath = path.join(__dirname, '../../fixtures/test-document.pdf');
    await page.setInputFiles('[data-testid="chat-file-upload"]', filePath);
    
    // Check file is uploaded
    await expect(page.locator('[data-testid="uploaded-file"]')).toBeVisible({ 
      timeout: 5000 
    });
  });
});
```

---

## 7️⃣ تست‌های همکاری در فروش

```typescript
// tests/e2e/affiliate/registration.spec.ts
import { test, expect } from '@playwright/test';
import { faker } from '@faker-js/faker';

test.describe('سیستم همکاری در فروش', () => {
  const affiliateData = {
    name: faker.person.fullName(),
    phone: '09123456789',
    email: faker.internet.email(),
    nationalId: '1234567890',
    bankAccount: '1234567890123456',
  };

  test('TC-AFFILIATE-001: ثبت‌نام همکار فروش', async ({ page }) => {
    await page.goto('/affiliate/register');
    
    // Fill registration form
    await page.fill('[data-testid="affiliate-name"]', affiliateData.name);
    await page.fill('[data-testid="affiliate-phone"]', affiliateData.phone);
    await page.fill('[data-testid="affiliate-email"]', affiliateData.email);
    await page.fill('[data-testid="affiliate-national-id"]', affiliateData.nationalId);
    await page.fill('[data-testid="affiliate-bank-account"]', affiliateData.bankAccount);
    
    // Accept terms
    await page.check('[data-testid="accept-terms"]');
    
    // Submit
    await page.click('[data-testid="submit-affiliate-registration"]');
    
    // Wait for success
    await expect(page.locator('[data-testid="registration-success"]')).toBeVisible({ 
      timeout: 5000 
    });
    
    // Check referral code is generated
    const referralCode = page.locator('[data-testid="referral-code"]');
    await expect(referralCode).toBeVisible();
    expect(await referralCode.textContent()).toMatch(/[A-Z0-9]{6,}/);
  });

  test('TC-AFFILIATE-002: مشاهده داشبورد همکار', async ({ page, context }) => {
    // Login as affiliate
    await context.addCookies([{
      name: 'affiliate_token',
      value: 'test_token',
      domain: 'localhost',
      path: '/',
    }]);
    
    await page.goto('/affiliate/dashboard');
    
    // Check dashboard elements
    await expect(page.locator('[data-testid="affiliate-stats"]')).toBeVisible();
    await expect(page.locator('[data-testid="total-referrals"]')).toBeVisible();
    await expect(page.locator('[data-testid="total-commission"]')).toBeVisible();
    await expect(page.locator('[data-testid="pending-commission"]')).toBeVisible();
  });

  test('TC-AFFILIATE-003: کپی لینک معرف', async ({ page }) => {
    await page.goto('/affiliate/dashboard');
    
    // Click copy link
    await page.click('[data-testid="copy-referral-link"]');
    
    // Check success message
    await expect(page.locator('text=لینک کپی شد')).toBeVisible();
  });

  test('TC-AFFILIATE-004: مشاهده لیست ارجاعات', async ({ page }) => {
    await page.goto('/affiliate/referrals');
    
    // Check referrals list
    const referralsList = page.locator('[data-testid="referrals-list"]');
    await expect(referralsList).toBeVisible();
    
    // Check columns
    await expect(page.locator('th:has-text("تاریخ")')).toBeVisible();
    await expect(page.locator('th:has-text("مبلغ سفارش")')).toBeVisible();
    await expect(page.locator('th:has-text("کمیسیون")')).toBeVisible();
    await expect(page.locator('th:has-text("وضعیت")')).toBeVisible();
  });

  test('TC-AFFILIATE-005: درخواست برداشت کمیسیون', async ({ page }) => {
    await page.goto('/affiliate/dashboard');
    
    // Check pending commission is enough
    const pendingText = await page.locator('[data-testid="pending-commission"]').textContent();
    const pending = parseInt(pendingText?.replace(/[^\d]/g, '') || '0');
    
    if (pending >= 100000) { // Minimum payout
      // Click withdraw
      await page.click('[data-testid="request-payout-btn"]');
      
      // Fill payout form
      await page.fill('[data-testid="payout-amount"]', '100000');
      await page.click('[data-testid="confirm-payout"]');
      
      // Check success
      await expect(page.locator('[data-testid="payout-success"]')).toBeVisible();
    }
  });
});
```

---

## 8️⃣ تست‌های AI

### 8.1 Recommendations Tests

```typescript
// tests/e2e/ai/recommendations.spec.ts
import { test, expect } from '@playwright/test';

test.describe('توصیه محصولات هوشمند', () => {
  test('TC-AI-REC-001: نمایش محصولات پیشنهادی در صفحه اصلی', async ({ page }) => {
    await page.goto('/');
    
    // Check recommendations section
    const recommendationsSection = page.locator('[data-testid="recommended-for-you"]');
    await expect(recommendationsSection).toBeVisible();
    
    // Check products are displayed
    const products = page.locator('[data-testid="recommended-product"]');
    expect(await products.count()).toBeGreaterThan(0);
  });

  test('TC-AI-REC-002: محصولات مرتبط در صفحه محصول', async ({ page }) => {
    await page.goto('/product/test-product-1');
    
    // Scroll to related products
    await page.locator('[data-testid="related-products"]').scrollIntoViewIfNeeded();
    
    // Check related products
    const relatedProducts = page.locator('[data-testid="related-product"]');
    await expect(relatedProducts.first()).toBeVisible();
    expect(await relatedProducts.count()).toBeGreaterThanOrEqual(3);
  });

  test('TC-AI-REC-003: محصولات پرفروش', async ({ page }) => {
    await page.goto('/');
    
    const bestSellers = page.locator('[data-testid="best-sellers"]');
    await expect(bestSellers).toBeVisible();
    
    const products = page.locator('[data-testid="best-seller-product"]');
    expect(await products.count()).toBeGreaterThan(0);
  });

  test('TC-AI-REC-004: پیشنهاد بر اساس سبد خرید', async ({ page }) => {
    // Add product to cart
    await page.goto('/');
    await page.click('[data-testid="product-card"]');
    await page.click('[data-testid="add-to-cart-btn"]');
    
    // Go to cart
    await page.goto('/cart');
    
    // Check recommendations
    const cartRecommendations = page.locator('[data-testid="cart-recommendations"]');
    await expect(cartRecommendations).toBeVisible();
    
    const products = page.locator('[data-testid="cart-recommended-product"]');
    expect(await products.count()).toBeGreaterThan(0);
  });

  test('TC-AI-REC-005: به‌روزرسانی توصیه‌ها بر اساس رفتار', async ({ page }) => {
    // View multiple products
    await page.goto('/');
    
    const productCards = page.locator('[data-testid="product-card"]');
    const count = Math.min(await productCards.count(), 5);
    
    for (let i = 0; i < count; i++) {
      await productCards.nth(i).click();
      await page.waitForTimeout(1000);
      await page.goBack();
    }
    
    // Go back to home
    await page.goto('/');
    
    // Check recommendations updated
    const recommendations = page.locator('[data-testid="recommended-product"]');
    await expect(recommendations.first()).toBeVisible();
  });
});
```

### 8.2 AI Search Tests

```typescript
// tests/e2e/ai/ai-search.spec.ts
import { test, expect } from '@playwright/test';

test.describe('جستجوی هوشمند', () => {
  test('TC-AI-SEARCH-001: جستجوی معنایی', async ({ page }) => {
    await page.goto('/');
    
    // Search with semantic query
    await page.fill('[data-testid="search-input"]', 'محصولی برای پوست خشک');
    await page.press('[data-testid="search-input"]', 'Enter');
    
    // Wait for AI search results
    await page.waitForSelector('[data-testid="ai-search-results"]', { timeout: 10000 });
    
    // Check results are relevant
    const results = page.locator('[data-testid="search-result"]');
    expect(await results.count()).toBeGreaterThan(0);
    
    // Check AI explanation
    await expect(page.locator('[data-testid="search-explanation"]')).toBeVisible();
  });

  test('TC-AI-SEARCH-002: جستجوی گفتگویی', async ({ page }) => {
    await page.goto('/search/ai');
    
    // Start conversation
    const query1 = 'دنبال محصولی برای مراقبت از پوست هستم';
    await page.fill('[data-testid="ai-search-input"]', query1);
    await page.click('[data-testid="ai-search-submit"]');
    
    // Wait for response
    await page.waitForSelector('[data-testid="ai-response"]', { timeout: 15000 });
    
    // Check response
    await expect(page.locator('[data-testid="ai-response"]')).toBeVisible();
    
    // Follow-up question
    const query2 = 'برای پوست چرب چطور؟';
    await page.fill('[data-testid="ai-search-input"]', query2);
    await page.click('[data-testid="ai-search-submit"]');
    
    // Check conversation continues
    await page.waitForSelector('[data-testid="ai-response"]:nth-child(2)', { 
      timeout: 15000 
    });
  });

  test('TC-AI-SEARCH-003: پیشنهاد سوالات مرتبط', async ({ page }) => {
    await page.goto('/');
    
    await page.fill('[data-testid="search-input"]', 'روغن زیتون');
    await page.press('[data-testid="search-input"]', 'Enter');
    
    await page.waitForLoadState('networkidle');
    
    // Check suggested questions
    const suggestions = page.locator('[data-testid="suggested-question"]');
    expect(await suggestions.count()).toBeGreaterThan(0);
  });

  test('TC-AI-SEARCH-004: جستجوی تصویری (اگر پیاده شده)', async ({ page }) => {
    await page.goto('/search');
    
    // Upload image
    const imagePath = path.join(__dirname, '../../fixtures/product-image.jpg');
    await page.setInputFiles('[data-testid="image-search-input"]', imagePath);
    
    // Wait for AI to process
    await page.waitForSelector('[data-testid="image-search-results"]', { 
      timeout: 20000 
    });
    
    // Check similar products
    const results = page.locator('[data-testid="similar-product"]');
    expect(await results.count()).toBeGreaterThan(0);
  });
});
```

### 8.3 Content Generation Tests

```typescript
// tests/e2e/ai/content-generation.spec.ts
import { test, expect } from '@playwright/test';

test.describe('تولید محتوا با AI', () => {
  test('TC-AI-CONTENT-001: تولید مقاله برای محصول', async ({ page, context }) => {
    // Login as admin
    await context.addCookies([{
      name: 'admin_token',
      value: 'admin_test_token',
      domain: 'localhost',
      path: '/',
    }]);
    
    await page.goto('/admin/products/test-product-1');
    
    // Click generate article
    await page.click('[data-testid="generate-article-btn"]');
    
    // Wait for AI generation
    await page.waitForSelector('[data-testid="generated-article"]', { 
      timeout: 30000 
    });
    
    // Check article content
    const article = page.locator('[data-testid="generated-article"]');
    const content = await article.textContent();
    expect(content?.length).toBeGreaterThan(500);
    
    // Check has proper sections
    await expect(article.locator('h2')).toHaveCount(await article.locator('h2').count());
    expect(await article.locator('h2').count()).toBeGreaterThan(2);
  });

  test('TC-AI-CONTENT-002: تولید توضیحات محصول', async ({ page }) => {
    await page.goto('/admin/products/new');
    
    // Fill basic info
    await page.fill('[data-testid="product-title"]', 'روغن زیتون ارگانیک');
    await page.fill('[data-testid="product-category"]', 'روغن‌های طبیعی');
    
    // Generate description
    await page.click('[data-testid="generate-description-btn"]');
    
    // Wait for AI
    await page.waitForSelector('[data-testid="generated-description"]', { 
      timeout: 15000 
    });
    
    // Check description
    const description = await page.locator('[data-testid="generated-description"]').textContent();
    expect(description?.length).toBeGreaterThan(100);
  });

  test('TC-AI-CONTENT-003: تولید تصویر محصول', async ({ page }) => {
    await page.goto('/admin/products/test-product-1');
    
    // Click generate image
    await page.click('[data-testid="generate-image-btn"]');
    
    // Select style
    await page.click('[data-testid="image-style-realistic"]');
    
    // Confirm
    await page.click('[data-testid="confirm-generate-image"]');
    
    // Wait for image generation (this can take a while)
    await page.waitForSelector('[data-testid="generated-image"]', { 
      timeout: 60000 
    });
    
    // Check image is displayed
    const image = page.locator('[data-testid="generated-image"]');
    await expect(image).toBeVisible();
    
    // Check image has src
    const src = await image.getAttribute('src');
    expect(src).toBeTruthy();
  });
});
```

---

## 9️⃣ تست‌های ارتباطات

```typescript
// tests/e2e/communication/sms.spec.ts
import { test, expect } from '@playwright/test';

test.describe('سیستم پیامک', () => {
  test('TC-SMS-001: ارسال پیامک تبلیغاتی', async ({ page, context }) => {
    // Login as admin
    await context.addCookies([{
      name: 'admin_token',
      value: 'admin_test_token',
      domain: 'localhost',
      path: '/',
    }]);
    
    await page.goto('/admin/sms/campaigns');
    
    // Create new campaign
    await page.click('[data-testid="new-campaign-btn"]');
    
    // Fill campaign details
    await page.fill('[data-testid="campaign-name"]', 'تست کمپین');
    await page.fill('[data-testid="campaign-message"]', 'پیام تبلیغاتی تست');
    
    // Select template
    await page.selectOption('[data-testid="sms-template"]', 'marketing');
    
    // Add recipients
    await page.fill('[data-testid="recipients"]', '09123456789,09987654321');
    
    // Schedule
    await page.click('[data-testid="send-now"]');
    
    // Submit
    await page.click('[data-testid="submit-campaign"]');
    
    // Check success
    await expect(page.locator('[data-testid="campaign-success"]')).toBeVisible();
  });

  test('TC-SMS-002: مشاهده تاریخچه پیامک‌ها', async ({ page }) => {
    await page.goto('/admin/sms/history');
    
    // Check table
    await expect(page.locator('[data-testid="sms-history-table"]')).toBeVisible();
    
    // Check columns
    await expect(page.locator('th:has-text("شماره")')).toBeVisible();
    await expect(page.locator('th:has-text("پیام")')).toBeVisible();
    await expect(page.locator('th:has-text("وضعیت")')).toBeVisible();
    await expect(page.locator('th:has-text("تاریخ")')).toBeVisible();
  });
});

// tests/e2e/communication/email.spec.ts
test.describe('سیستم ایمیل', () => {
  test('TC-EMAIL-001: ارسال خبرنامه', async ({ page }) => {
    await page.goto('/admin/email/newsletters');
    
    // Create newsletter
    await page.click('[data-testid="new-newsletter-btn"]');
    
    // Fill details
    await page.fill('[data-testid="newsletter-subject"]', 'خبرنامه تست');
    await page.fill('[data-testid="newsletter-content"]', 'محتوای خبرنامه تست');
    
    // Select subscribers
    await page.check('[data-testid="select-all-subscribers"]');
    
    // Send
    await page.click('[data-testid="send-newsletter"]');
    
    // Confirm
    await page.click('[data-testid="confirm-send"]');
    
    // Check success
    await expect(page.locator('text=خبرنامه با موفقیت ارسال شد')).toBeVisible();
  });
});
```

---

## 🔟 تست‌های پنل ادمین

```typescript
// tests/e2e/admin/admin-login.spec.ts
import { test, expect } from '@playwright/test';

test.describe('ورود به پنل ادمین', () => {
  test('TC-ADMIN-001: ورود با شماره موبایل مجاز', async ({ page }) => {
    await page.goto('/admin/login');
    
    // Fill phone
    await page.fill('[data-testid="admin-phone"]', '09219675992');
    await page.fill('[data-testid="admin-password"]', 'TestPassword123!');
    
    // Submit
    await page.click('[data-testid="admin-login-btn"]');
    
    // Check redirect to admin dashboard
    await page.waitForURL(/.*\/admin\/dashboard.*/);
    
    // Check dashboard elements
    await expect(page.locator('[data-testid="admin-dashboard"]')).toBeVisible();
  });

  test('TC-ADMIN-002: ورود با شماره غیرمجاز', async ({ page }) => {
    await page.goto('/admin/login');
    
    await page.fill('[data-testid="admin-phone"]', '09123456789');
    await page.fill('[data-testid="admin-password"]', 'SomePassword123!');
    
    await page.click('[data-testid="admin-login-btn"]');
    
    // Check error
    await expect(page.locator('text=دسترسی غیرمجاز')).toBeVisible();
  });
});

// tests/e2e/admin/product-management.spec.ts
test.describe('مدیریت محصولات', () => {
  test('TC-ADMIN-PRODUCT-001: افزودن محصول جدید', async ({ page }) => {
    await page.goto('/admin/products/new');
    
    // Fill product form
    await page.fill('[data-testid="product-title"]', 'محصول تست ' + Date.now());
    await page.fill('[data-testid="product-price"]', '150000');
    await page.fill('[data-testid="product-stock"]', '10');
    await page.selectOption('[data-testid="product-category"]', 'oils');
    
    // Upload image
    const imagePath = path.join(__dirname, '../../fixtures/product-image.jpg');
    await page.setInputFiles('[data-testid="product-images"]', imagePath);
    
    // Fill description
    await page.fill('[data-testid="product-description"]', 'توضیحات محصول تست');
    
    // Submit
    await page.click('[data-testid="save-product-btn"]');
    
    // Check success
    await expect(page.locator('text=محصول با موفقیت ایجاد شد')).toBeVisible();
  });

  test('TC-ADMIN-PRODUCT-002: ویرایش محصول', async ({ page }) => {
    await page.goto('/admin/products');
    
    // Click edit on first product
    await page.click('[data-testid="edit-product-btn"]');
    
    // Update price
    await page.fill('[data-testid="product-price"]', '200000');
    
    // Save
    await page.click('[data-testid="save-product-btn"]');
    
    // Check success
    await expect(page.locator('text=محصول به‌روزرسانی شد')).toBeVisible();
  });

  test('TC-ADMIN-PRODUCT-003: حذف محصول', async ({ page }) => {
    await page.goto('/admin/products');
    
    // Click delete
    await page.click('[data-testid="delete-product-btn"]');
    
    // Confirm
    await page.click('[data-testid="confirm-delete"]');
    
    // Check success
    await expect(page.locator('text=محصول حذف شد')).toBeVisible();
  });
});
```

---

## 1️⃣1️⃣ تست‌های امنیتی

```typescript
// tests/e2e/security/authentication.spec.ts
import { test, expect } from '@playwright/test';

test.describe('امنیت احراز هویت', () => {
  test('TC-SEC-001: جلوگیری از SQL Injection', async ({ page }) => {
    await page.goto('/admin/login');
    
    // Try SQL injection
    await page.fill('[data-testid="admin-phone"]', "' OR '1'='1");
    await page.fill('[data-testid="admin-password"]', "' OR '1'='1");
    await page.click('[data-testid="admin-login-btn"]');
    
    // Should fail
    await expect(page.locator('text=خطا در ورود')).toBeVisible();
    expect(page.url()).not.toContain('/admin/dashboard');
  });

  test('TC-SEC-002: جلوگیری از XSS', async ({ page }) => {
    await page.goto('/admin/products/new');
    
    // Try XSS in product title
    const xssScript = '<script>alert("XSS")</script>';
    await page.fill('[data-testid="product-title"]', xssScript);
    await page.click('[data-testid="save-product-btn"]');
    
    // Check script is escaped
    await page.goto('/products');
    const titleElement = await page.locator('[data-testid="product-title"]').first();
    const title = await titleElement.textContent();
    expect(title).not.toContain('<script>');
  });

  test('TC-SEC-003: Rate Limiting', async ({ page }) => {
    const attempts = [];
    
    // Try 20 login attempts
    for (let i = 0; i < 20; i++) {
      attempts.push(
        page.goto('/admin/login').then(() =>
          page.fill('[data-testid="admin-phone"]', '09123456789')
        ).then(() =>
          page.click('[data-testid="admin-login-btn"]')
        )
      );
    }
    
    await Promise.all(attempts);
    
    // Should be rate limited
    await expect(page.locator('text=تعداد درخواست‌ها بیش از حد مجاز')).toBeVisible();
  });

  test('TC-SEC-004: CSRF Protection', async ({ page, request }) => {
    // Try to make request without CSRF token
    const response = await request.post('/api/v1/products', {
      data: {
        title: 'Test Product',
        price: 100000,
      },
    });
    
    // Should fail
    expect(response.status()).toBe(403);
  });
});
```

---

## 1️⃣2️⃣ تست‌های Performance

```typescript
// tests/e2e/performance/page-load.spec.ts
import { test, expect } from '@playwright/test';

test.describe('عملکرد صفحات', () => {
  test('TC-PERF-001: زمان بارگذاری صفحه اصلی', async ({ page }) => {
    const startTime = Date.now();
    
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    
    const loadTime = Date.now() - startTime;
    
    // Should load in less than 3 seconds
    expect(loadTime).toBeLessThan(3000);
    
    console.log(`صفحه اصلی در ${loadTime}ms بارگذاری شد`);
  });

  test('TC-PERF-002: Core Web Vitals', async ({ page }) => {
    await page.goto('/');
    
    const metrics = await page.evaluate(() => {
      return new Promise((resolve) => {
        new PerformanceObserver((list) => {
          const entries = list.getEntries();
          const metrics = {};
          
          entries.forEach((entry) => {
            if (entry.name === 'largest-contentful-paint') {
              metrics.lcp = entry.startTime;
            }
          });
          
          resolve(metrics);
        }).observe({ entryTypes: ['largest-contentful-paint'] });
        
        // Timeout after 10 seconds
        setTimeout(() => resolve({}), 10000);
      });
    });
    
    // LCP should be less than 2.5 seconds
    if (metrics.lcp) {
      expect(metrics.lcp).toBeLessThan(2500);
    }
  });

  test('TC-PERF-003: حجم صفحه', async ({ page }) => {
    const response = await page.goto('/');
    const size = parseInt(response?.headers()['content-length'] || '0');
    
    // Page should be less than 1MB
    expect(size).toBeLessThan(1024 * 1024);
    
    console.log(`حجم صفحه: ${(size / 1024).toFixed(2)} KB`);
  });
});
```

---

## 🔧 Helper Functions

```typescript
// tests/helpers/api.helper.ts
export class APIHelper {
  constructor(private baseURL: string) {}

  async createProduct(data: any) {
    const response = await fetch(`${this.baseURL}/api/v1/products`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ADMIN_TOKEN}`,
      },
      body: JSON.stringify(data),
    });
    
    return response.json();
  }

  async createOrder(data: any) {
    const response = await fetch(`${this.baseURL}/api/v1/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    
    return response.json();
  }

  async createDiscount(code: string, data: any) {
    const response = await fetch(`${this.baseURL}/api/v1/discounts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ADMIN_TOKEN}`,
      },
      body: JSON.stringify({ code, ...data }),
    });
    
    return response.json();
  }
}

// tests/helpers/database.helper.ts
export class DatabaseHelper {
  async cleanupTestData() {
    // Clean up test orders, products, etc.
    // This should connect to the test database
  }

  async seedTestData() {
    // Seed required test data
  }
}

// tests/helpers/faker.helper.ts
import { faker } from '@faker-js/faker/locale/fa';

export function generateProduct() {
  return {
    title: faker.commerce.productName(),
    price: faker.number.int({ min: 10000, max: 500000 }),
    stock: faker.number.int({ min: 0, max: 100 }),
    description: faker.lorem.paragraph(),
  };
}

export function generateCustomer() {
  return {
    name: faker.person.fullName(),
    phone: `09${faker.number.int({ min: 100000000, max: 999999999 })}`,
    email: faker.internet.email(),
    address: faker.location.streetAddress(),
  };
}
```

---

## 📊 تست Coverage

### مجموع تست‌ها بر اساس بخش:

| بخش | تعداد تست | اولویت |
|-----|-----------|--------|
| فروشگاه (Shop) | 15 | بالا |
| مشاوره (Consultation) | 5 | بالا |
| کد تخفیف (Discount) | 6 | متوسط |
| پشتیبانی (Support) | 10 | بالا |
| همکاری در فروش (Affiliate) | 5 | متوسط |
| AI | 12 | بالا |
| ارتباطات (Communication) | 3 | پایین |
| پنل ادمین | 10 | بالا |
| امنیت (Security) | 4 | بالا |
| Performance | 3 | متوسط |

**مجموع: 73 تست E2E**

---

## 🚀 اجرای تست‌ها

```bash
# اجرای همه تست‌ها
npm run test:e2e

# اجرای تست‌های یک بخش خاص
npm run test:e2e -- tests/e2e/shop/

# اجرای در حالت UI
npm run test:e2e -- --ui

# اجرای در یک مرورگر خاص
npm run test:e2e -- --project=chromium

# اجرای با debug
npm run test:e2e -- --debug

# تولید گزارش
npm run test:e2e -- --reporter=html
```

---

## 📝 CI/CD Integration

```yaml
# .github/workflows/e2e-tests.yml
name: E2E Tests

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Install Playwright
        run: npx playwright install --with-deps
      
      - name: Run E2E tests
        run: npm run test:e2e
        env:
          BASE_URL: ${{ secrets.TEST_BASE_URL }}
          ADMIN_TOKEN: ${{ secrets.TEST_ADMIN_TOKEN }}
      
      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 30
```

---

**تهیه شده توسط:** تیم QA Oil Global  
**آخرین بروزرسانی:** دی ۱۴۰۳  
**Framework:** Playwright 1.40+  
**Coverage:** 73 E2E Tests
