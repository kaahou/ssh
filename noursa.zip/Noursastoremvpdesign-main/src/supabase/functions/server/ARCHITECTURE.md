# 🏗️ معماری Backend - فروشگاه نورسا

## 📋 مرور کلی

این backend با استفاده از **Hono Framework** در **Deno runtime** ساخته شده و از معماری **ماژولار و لایه‌ای** پیروی می‌کند.

## 🎯 اصول معماری

### 1. **Separation of Concerns** (جداسازی مسئولیت‌ها)
- هر فایل یک مسئولیت مشخص دارد
- Business logic از routing جدا است
- Database access از business logic جدا است

### 2. **Modularity** (ماژولار بودن)
- کد به ماژول‌های کوچک و قابل استفاده مجدد تقسیم شده
- هر ماژول مستقل و قابل تست است
- وابستگی‌ها واضح و مشخص هستند

### 3. **Scalability** (مقیاس‌پذیری)
- امکان اضافه کردن route و feature جدید بدون تغییر کد موجود
- Service layer به راحتی قابل گسترش است
- کد قابل نگهداری و توسعه است

## 📂 ساختار فایل‌ها

```
/supabase/functions/server/
│
├── 📄 index.tsx                    # Entry point اصلی
│
├── 🔧 Core Files
│   ├── db.ts                       # Supabase client
│   ├── kv_store.tsx                # KV storage utilities
│   ├── types.ts                    # TypeScript types
│   ├── constants.ts                # Application constants
│   └── middleware.ts               # Shared middleware
│
├── 🛣️ Route Modules
│   ├── product_routes.ts           # Product endpoints
│   ├── order_routes.ts             # Order endpoints
│   ├── consultation_routes.ts      # Consultation endpoints
│   ├── auth_routes.ts              # Authentication endpoints
│   ├── user_routes.ts              # User endpoints
│   ├── article_routes.ts           # Article endpoints
│   ├── category_routes.ts          # Category endpoints
│   ├── search_routes.ts            # Search endpoints
│   ├── payment_routes.ts           # Payment endpoints
│   ├── sitemap_routes.ts           # Sitemap endpoints
│   ├── admin_routes.ts             # Admin endpoints
│   └── debug_routes.ts             # Debug endpoints
│
├── 💼 Service Layer
│   ├── product_service.ts          # Product business logic
│   ├── order_service.ts            # Order business logic
│   ├── consultation_service.ts     # Consultation business logic
│   └── storage_service.ts          # File storage logic
│
├── 🔨 Utilities
│   ├── validators.ts               # Input validation
│   ├── formatters.ts               # Data formatting
│   ├── zarinpal.ts                 # Zarinpal payment gateway
│   ├── consultation_sms.ts         # SMS queue & sending
│   └── sitemap.ts                  # Sitemap generation
│
└── 📚 Documentation
    ├── ARCHITECTURE.md             # This file
    ├── README.md                   # API documentation
    └── CHANGELOG.md                # Change history
```

## 🏛️ لایه‌های معماری

### 1️⃣ **Routing Layer** (لایه مسیریابی)
**فایل‌ها:** `*_routes.ts`

**مسئولیت:**
- دریافت و پردازش HTTP requests
- اعتبارسنجی اولیه ورودی‌ها
- فراخوانی service layer
- بازگشت HTTP responses

**مثال:**
```typescript
// product_routes.ts
productRoutes.get("/products", async (c) => {
  const { page, limit, categoryId } = c.req.query();
  
  const result = await getProducts({ page, limit, categoryId });
  
  if (!result.success) {
    return c.json({ error: result.error }, 400);
  }
  
  return c.json({ products: result.products });
});
```

### 2️⃣ **Service Layer** (لایه منطق کسب‌وکار)
**فایل‌ها:** `*_service.ts`

**مسئولیت:**
- پیاده‌سازی منطق کسب‌وکار
- ارتباط با database
- اعتبارسنجی پیچیده
- هماهنگی بین چند عملیات

**مثال:**
```typescript
// product_service.ts
export async function createProduct(data: Product) {
  // Validate
  const validation = validateProductData(data);
  if (!validation.valid) {
    return { success: false, error: validation.error };
  }
  
  // Business logic
  const product = await supabase
    .from('products')
    .insert(data)
    .select()
    .single();
  
  // Return result
  return { success: true, product };
}
```

### 3️⃣ **Data Access Layer** (لایه دسترسی به داده)
**فایل‌ها:** `db.ts`, `kv_store.tsx`, `storage_service.ts`

**مسئولیت:**
- ارتباط مستقیم با database
- مدیریت storage
- کش و KV store

### 4️⃣ **Utilities Layer** (لایه ابزارها)
**فایل‌ها:** `validators.ts`, `formatters.ts`, `middleware.ts`

**مسئولیت:**
- توابع کمکی قابل استفاده مجدد
- اعتبارسنجی ورودی‌ها
- فرمت‌دهی داده‌ها
- Middleware های مشترک

## 🔄 جریان درخواست (Request Flow)

```
1. Client Request
   ↓
2. Hono Router → Route Handler (*_routes.ts)
   ↓
3. Middleware (auth, validation, logging)
   ↓
4. Service Layer (*_service.ts)
   ↓
5. Validators & Formatters
   ↓
6. Data Access (Supabase, KV, Storage)
   ↓
7. Response Formatting
   ↓
8. HTTP Response to Client
```

## 📊 مثال کامل: ثبت سفارش

```typescript
// 1️⃣ CLIENT REQUEST
POST /make-server-fbc72c25/orders
{
  customerName: "علی احمدی",
  phone: "09123456789",
  items: [...]
}

// 2️⃣ ROUTE HANDLER (order_routes.ts)
orderRoutes.post("/orders", async (c) => {
  const body = await c.req.json();
  
  // Call service layer
  const result = await createOrder(body);
  
  if (!result.success) {
    return c.json({ error: result.error }, 400);
  }
  
  return c.json({ orderId: result.orderId });
});

// 3️⃣ SERVICE LAYER (order_service.ts)
export async function createOrder(data: CreateOrderRequest) {
  // Validate
  const validation = validateOrderRequest(data);
  if (!validation.valid) {
    return { success: false, error: validation.error };
  }
  
  // Calculate totals
  const subtotal = calculateSubtotal(data.items);
  const total = subtotal + FIXED_SHIPPING_COST;
  
  // Insert to database
  const { data: order, error } = await supabase
    .from('orders')
    .insert({ ...prepareOrderData(data, total) })
    .select()
    .single();
  
  if (error) {
    return { success: false, error: "خطا در ثبت سفارش" };
  }
  
  // Insert order items
  await insertOrderItems(order.id, data.items);
  
  return { success: true, orderId: order.id };
}

// 4️⃣ VALIDATORS (validators.ts)
export function validateOrderRequest(data) {
  if (!isValidPhone(data.phone)) {
    return { valid: false, error: "شماره موبایل نامعتبر" };
  }
  // ... more validations
  return { valid: true };
}

// 5️⃣ DATABASE ACCESS (db.ts)
await supabase.from('orders').insert(...)
```

## 🛡️ امنیت

### Admin Authentication
- فقط شماره `09219675992` دسترسی به پنل ادمین دارد
- Middleware `requireAdmin` در `middleware.ts`

### Input Validation
- تمام ورودی‌ها در `validators.ts` اعتبارسنجی می‌شوند
- SQL injection از طریق Supabase client جلوگیری می‌شود

### Error Handling
- تمام خطاها به صورت مناسب مدیریت می‌شوند
- اطلاعات حساس در error messages نمایش داده نمی‌شود

## 🚀 بهترین روش‌ها (Best Practices)

### 1. استفاده از Service Layer
```typescript
// ❌ BAD: Business logic در route handler
orderRoutes.post("/orders", async (c) => {
  const body = await c.req.json();
  const total = body.items.reduce(...);
  const order = await supabase.from('orders').insert(...);
  // ...
});

// ✅ GOOD: استفاده از service
orderRoutes.post("/orders", async (c) => {
  const body = await c.req.json();
  const result = await createOrder(body);
  return c.json(result);
});
```

### 2. استفاده از Types
```typescript
// ✅ GOOD: استفاده از types از types.ts
import type { Order, CreateOrderRequest } from './types.ts';

export async function createOrder(data: CreateOrderRequest): Promise<{
  success: boolean;
  orderId?: number;
  error?: string;
}> {
  // ...
}
```

### 3. استفاده از Constants
```typescript
// ❌ BAD: Magic numbers
const shipping = 80000;

// ✅ GOOD: استفاده از constants
import { FIXED_SHIPPING_COST } from './constants.ts';
const shipping = FIXED_SHIPPING_COST;
```

### 4. Error Handling
```typescript
// ✅ GOOD: Proper error handling
try {
  const result = await someOperation();
  if (!result.success) {
    return { success: false, error: result.error };
  }
  return { success: true, data: result.data };
} catch (error) {
  console.error("❌ Exception:", error);
  return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
}
```

## 📝 راهنمای توسعه

### اضافه کردن Feature جدید

1. **تعریف Types** در `types.ts`
2. **اضافه کردن Constants** در `constants.ts`
3. **ساخت Service** در `*_service.ts`
4. **اضافه کردن Validators** در `validators.ts`
5. **ساخت Routes** در `*_routes.ts`
6. **ثبت Routes** در `index.tsx`

### مثال: اضافه کردن سیستم کامنت

```typescript
// 1. types.ts
export interface Comment {
  id?: number;
  product_id: number;
  user_id: number;
  text: string;
  rating: number;
  created_at?: string;
}

// 2. constants.ts
export const MAX_COMMENT_LENGTH = 500;

// 3. comment_service.ts
export async function createComment(data: Comment) {
  // Business logic
}

// 4. validators.ts
export function validateComment(data: Comment) {
  if (data.text.length > MAX_COMMENT_LENGTH) {
    return { valid: false, error: "متن خیلی طولانی است" };
  }
  return { valid: true };
}

// 5. comment_routes.ts
const commentRoutes = new Hono();
commentRoutes.post("/comments", async (c) => {
  const result = await createComment(await c.req.json());
  return c.json(result);
});
export default commentRoutes;

// 6. index.tsx
import commentRoutes from "./comment_routes.ts";
api.route("/", commentRoutes);
```

## 🔍 Debugging

### Logging
```typescript
console.log("✅ Success message");
console.error("❌ Error message");
console.log("📦 Product:", product);
console.log("🔍 Debug:", data);
```

### Error Tracking
تمام خطاها در console لاگ می‌شوند:
```typescript
console.error("❌ Failed to create order:", error);
console.error("Stack:", error.stack);
```

## 📚 مراجع

- [Hono Documentation](https://hono.dev/)
- [Deno Documentation](https://deno.land/)
- [Supabase Documentation](https://supabase.com/docs)
