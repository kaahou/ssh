import { Hono } from "npm:hono";
import { supabase } from "./db.ts";

const searchRoutes = new Hono();

// Search endpoint
searchRoutes.get("/search", async (c) => {
  try {
    const query = c.req.query("q");
    
    if (!query) {
      return c.json({ products: [], articles: [] });
    }
    
    console.log(`Searching for: ${query}`);
    
    // Search products
    // Note: description column might not exist, using short_description instead
    const { data: products, error: productsError } = await supabase
      .from('products')
      .select('*')
      .or(`product_name.ilike.%${query}%,variant_name.ilike.%${query}%,short_description.ilike.%${query}%`)
      .limit(12);
      
    if (productsError) {
      console.error("Error searching products:", productsError);
    }
    
    // Search articles (contents)
    const { data: articles, error: articlesError } = await supabase
      .from('contents')
      .select('*')
      .or(`title.ilike.%${query}%,content.ilike.%${query}%`)
      .limit(12);
      
    if (articlesError) {
      console.error("Error searching articles:", articlesError);
    }
    
    return c.json({
      products: products || [],
      articles: articles || [],
    });
  } catch (error) {
    console.error("Error in search endpoint:", error);
    return c.json({ error: "Search failed" }, 500);
  }
});

export default searchRoutes;
