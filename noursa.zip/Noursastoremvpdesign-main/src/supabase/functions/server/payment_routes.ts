import { Hono } from "npm:hono";
import { supabase } from "./db.ts";
import * as zarinpal from "./zarinpal.ts";

const paymentRoutes = new Hono();

// Payment Request (Zarinpal)
paymentRoutes.post("/payment/zarinpal/request", async (c) => {
  try {
    const body = await c.req.json();
    const { amount, description, callback_url, mobile, email, orderId } = body;
    const merchant_id = Deno.env.get("ZARINPAL_MERCHANT_ID");

    if (!merchant_id) {
        return c.json({ error: "Zarinpal Merchant ID not configured" }, 500);
    }

    if (!amount || !description || !callback_url) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    const response = await zarinpal.requestPayment({
      merchant_id,
      amount: Number(amount),
      description,
      callback_url,
      metadata: {
        mobile,
        email,
        orderId
      }
    });

    if (response.success) {
      return c.json(response);
    } else {
      return c.json({ error: "Zarinpal request failed", details: response }, 400);
    }
  } catch (error) {
    console.error("Payment request error:", error);
    return c.json({ error: "Payment request failed" }, 500);
  }
});

// Payment Verify (Zarinpal)
paymentRoutes.post("/payment/zarinpal/verify", async (c) => {
  try {
    const body = await c.req.json();
    const { authority, amount, orderId } = body;
    const merchant_id = Deno.env.get("ZARINPAL_MERCHANT_ID");

    if (!merchant_id) {
        return c.json({ error: "Zarinpal Merchant ID not configured" }, 500);
    }

    if (!authority || !amount) {
      return c.json({ error: "Missing authority or amount" }, 400);
    }

    console.log(`🔍 Verifying payment - Authority: ${authority}, Amount: ${amount}, OrderId: ${orderId}`);

    const response = await zarinpal.verifyPayment({
      merchant_id,
      amount: Number(amount),
      authority
    });

    console.log(`📦 Verification response:`, response);

    // ✅ اگر پرداخت موفق بود، وضعیت سفارش را آپدیت کن
    if (response && response.success === true && orderId) {
      try {
        console.log(`✅ Payment verified successfully for order ${orderId}, updating status to paid_zarinpal`);
        
        // دریافت اطلاعات فعلی سفارش
        const { data: currentOrder, error: selectError } = await supabase
          .from('orders')
          .select('payment_info')
          .eq('id', orderId)
          .single();
        
        if (selectError) {
          console.error('Error fetching order:', selectError);
        } else if (currentOrder) {
          let parsedPaymentInfo = {};
          try {
            parsedPaymentInfo = typeof currentOrder.payment_info === 'string' 
              ? JSON.parse(currentOrder.payment_info) 
              : (currentOrder.payment_info || {});
          } catch (parseError) {
            console.error('Error parsing payment_info:', parseError);
            parsedPaymentInfo = {};
          }
          
          // آپدیت payment_info با وضعیت جدید و کد رهگیری
          const updatedPaymentInfo = {
            ...parsedPaymentInfo,
            status: 'paid',
            zarinpal_authority: authority,
            zarinpal_ref_id: response.ref_id,
            verified_at: new Date().toISOString(),
            payment_status: 'paid_zarinpal' // ✅ Store inside JSON
          };
          
          const { error: updateError } = await supabase
            .from('orders')
            .update({
              payment_info: JSON.stringify(updatedPaymentInfo)
            })
            .eq('id', orderId);
          
          if (updateError) {
            console.error('❌ Error updating order payment status:', updateError);
          } else {
            console.log(`✅ Order ${orderId} payment status updated to paid_zarinpal`);
          }
        }
      } catch (updateErr) {
        console.error('❌ Exception while updating order:', updateErr);
      }
    }

    return c.json(response);
  } catch (error) {
    console.error("❌ Payment verify error:", error);
    return c.json({ error: "Payment verify failed", message: error instanceof Error ? error.message : String(error) }, 500);
  }
});

export default paymentRoutes;