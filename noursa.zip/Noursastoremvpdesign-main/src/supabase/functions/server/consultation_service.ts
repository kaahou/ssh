// Consultation Business Logic Service

import { supabase } from './db.ts';
import * as kv from './kv_store.tsx';
import type { Consultation, ConsultationFormData } from './types.ts';
import { ERROR_MESSAGES, STORAGE_BUCKETS, OTP_EXPIRY_MS, OTP_LENGTH } from './constants.ts';
import { validateConsultationData, isValidPhone } from './validators.ts';
import { uploadMultipleBase64Images } from './storage_service.ts';
import { sendConsultationConfirmation } from './consultation_sms.ts';

// ==================== OTP Management ====================
/**
 * Generate a random OTP code
 */
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Store OTP in KV store
 */
export async function storeOTP(phone: string, code: string): Promise<boolean> {
  try {
    const otpData = {
      code,
      expiresAt: Date.now() + OTP_EXPIRY_MS,
      createdAt: Date.now(),
    };
    
    await kv.set(`otp:${phone}`, otpData);
    console.log(`✅ OTP stored for ${phone}`);
    return true;
  } catch (error) {
    console.error("❌ Failed to store OTP:", error);
    return false;
  }
}

/**
 * Verify OTP code
 */
export async function verifyOTP(phone: string, code: string): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    const storedOtpData = await kv.get(`otp:${phone}`);
    
    if (!storedOtpData) {
      return { success: false, error: ERROR_MESSAGES.OTP_EXPIRED };
    }
    
    // Check if OTP is expired
    if (Date.now() > storedOtpData.expiresAt) {
      await kv.del(`otp:${phone}`);
      return { success: false, error: ERROR_MESSAGES.OTP_EXPIRED };
    }
    
    // Verify OTP
    if (storedOtpData.code !== code) {
      return { success: false, error: ERROR_MESSAGES.OTP_INVALID };
    }
    
    // OTP is valid, delete it
    await kv.del(`otp:${phone}`);
    
    return { success: true };
  } catch (error) {
    console.error("❌ Exception in verifyOTP:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== User Management ====================
/**
 * Get or create user
 */
export async function getOrCreateUser(
  phone: string,
  firstName?: string,
  lastName?: string
): Promise<{ success: boolean; user?: any; error?: string }> {
  try {
    // Check if user exists in KV
    let user = await kv.get(`user:${phone}`);
    
    if (!user) {
      // Create new user
      user = {
        phone: phone,
        first_name: firstName || null,
        last_name: lastName || null,
        created_at: new Date().toISOString(),
      };
      
      await kv.set(`user:${phone}`, user);
      console.log(`✅ New user created: ${phone}`);
    } else {
      console.log(`✅ Existing user found: ${phone}`);
    }
    
    return { success: true, user };
  } catch (error) {
    console.error("❌ Exception in getOrCreateUser:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Consultation Creation ====================
/**
 * Create a new consultation
 */
export async function createConsultation(
  phone: string,
  formData: ConsultationFormData
): Promise<{ success: boolean; consultationId?: number; error?: string }> {
  try {
    // Validate consultation data
    const validation = validateConsultationData(formData);
    if (!validation.valid) {
      return { success: false, error: validation.error };
    }
    
    console.log("📋 Creating new consultation for:", phone);
    
    // Get or create user
    const userResult = await getOrCreateUser(
      phone,
      formData.first_name,
      formData.last_name
    );
    
    if (!userResult.success) {
      return { success: false, error: "خطا در ایجاد کاربر" };
    }
    
    // Upload photos if provided
    let photoUrls: string[] = [];
    
    if (formData.user_photos && formData.user_photos.length > 0) {
      console.log(`📸 Uploading ${formData.user_photos.length} photos...`);
      
      const uploadResult = await uploadMultipleBase64Images(
        STORAGE_BUCKETS.CONSULTATIONS,
        formData.user_photos
      );
      
      if (uploadResult.success && uploadResult.urls) {
        photoUrls = uploadResult.urls;
        console.log(`✅ ${photoUrls.length} photos uploaded successfully`);
      } else {
        console.error("❌ Photo upload failed:", uploadResult.errors);
        // Continue anyway, photos are optional
      }
    }
    
    // Generate consultation ID
    const consultationId = Date.now();
    
    // Prepare consultation data
    const consultationData: Partial<Consultation> = {
      phone,
      first_name: formData.first_name,
      last_name: formData.last_name,
      national_code: formData.national_code,
      birth_year: formData.birth_year,
      gender: formData.gender,
      weight: formData.weight,
      height: formData.height,
      body_type: formData.body_type,
      skin_color: formData.skin_color,
      city: formData.city,
      has_disease: formData.has_disease,
      diseases: formData.diseases || null,
      medications: formData.medications || null,
      pregnancy_status: formData.pregnancy_status || null,
      user_photos: photoUrls.length > 0 ? JSON.stringify(photoUrls) : null,
      skin_issues: formData.skin_issues || null,
      previous_treatments: formData.previous_treatments || null,
      skin_type: formData.skin_type || null,
      skin_sensitivity: formData.skin_sensitivity || null,
      sun_exposure: formData.sun_exposure || null,
      skincare_routine: formData.skincare_routine || null,
      additional_notes: formData.additional_notes || null,
      status: 'pending',
    };
    
    // Insert into database
    const { data: consultation, error } = await supabase
      .from('consultations')
      .insert({
        id: consultationId,
        ...consultationData
      })
      .select()
      .single();
    
    if (error) {
      console.error("❌ Failed to insert consultation:", error);
      return { success: false, error: "خطا در ثبت مشاوره" };
    }
    
    console.log(`✅ Consultation ${consultationId} created successfully`);
    
    // Send confirmation SMS (async, don't wait)
    sendConsultationConfirmation(phone, consultationId);
    
    return { success: true, consultationId };
  } catch (error) {
    console.error("❌ Exception in createConsultation:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Consultation Retrieval ====================
/**
 * Get consultation by ID
 */
export async function getConsultationById(id: number): Promise<{
  success: boolean;
  consultation?: Consultation;
  error?: string;
}> {
  try {
    const { data: consultation, error } = await supabase
      .from('consultations')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error || !consultation) {
      console.error("❌ Consultation not found:", error);
      return { success: false, error: ERROR_MESSAGES.NOT_FOUND };
    }
    
    // Parse photos JSON
    if (consultation.user_photos && typeof consultation.user_photos === 'string') {
      try {
        consultation.user_photos = JSON.parse(consultation.user_photos);
      } catch (e) {
        console.error("❌ Failed to parse photos:", e);
      }
    }
    
    return { success: true, consultation };
  } catch (error) {
    console.error("❌ Exception in getConsultationById:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Get consultations by phone
 */
export async function getConsultationsByPhone(phone: string): Promise<{
  success: boolean;
  consultations?: Consultation[];
  error?: string;
}> {
  try {
    const { data: consultations, error } = await supabase
      .from('consultations')
      .select('*')
      .eq('phone', phone)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error("❌ Failed to fetch consultations:", error);
      return { success: false, error: "خطا در دریافت مشاوره‌ها" };
    }
    
    // Parse photos for each consultation
    const parsedConsultations = consultations?.map(c => {
      if (c.user_photos && typeof c.user_photos === 'string') {
        try {
          c.user_photos = JSON.parse(c.user_photos);
        } catch (e) {
          console.error("❌ Failed to parse photos:", e);
        }
      }
      return c;
    });
    
    return { success: true, consultations: parsedConsultations || [] };
  } catch (error) {
    console.error("❌ Exception in getConsultationsByPhone:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Get all consultations with optional filtering
 */
export async function getConsultations(options: {
  page?: number;
  limit?: number;
  status?: string;
}): Promise<{
  success: boolean;
  consultations?: Consultation[];
  total?: number;
  error?: string;
}> {
  try {
    const { page = 1, limit = 20, status } = options;
    const offset = (page - 1) * limit;
    
    let query = supabase
      .from('consultations')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (status) {
      query = query.eq('status', status);
    }
    
    const { data: consultations, error, count } = await query;
    
    if (error) {
      console.error("❌ Failed to fetch consultations:", error);
      return { success: false, error: "خطا در دریافت مشاوره‌ها" };
    }
    
    // Parse photos for each consultation
    const parsedConsultations = consultations?.map(c => {
      if (c.user_photos && typeof c.user_photos === 'string') {
        try {
          c.user_photos = JSON.parse(c.user_photos);
        } catch (e) {
          console.error("❌ Failed to parse photos:", e);
        }
      }
      return c;
    });
    
    return {
      success: true,
      consultations: parsedConsultations || [],
      total: count || 0
    };
  } catch (error) {
    console.error("❌ Exception in getConsultations:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Consultation Update ====================
/**
 * Update consultation result
 */
export async function updateConsultationResult(
  id: number,
  result: string,
  status: string = 'completed'
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('consultations')
      .update({
        result,
        status
      })
      .eq('id', id);
    
    if (error) {
      console.error("❌ Failed to update consultation:", error);
      return { success: false, error: "خطا در بروزرسانی مشاوره" };
    }
    
    console.log(`✅ Consultation ${id} updated successfully`);
    return { success: true };
  } catch (error) {
    console.error("❌ Exception in updateConsultationResult:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Update consultation status
 */
export async function updateConsultationStatus(
  id: number,
  status: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('consultations')
      .update({
        status
      })
      .eq('id', id);
    
    if (error) {
      console.error("❌ Failed to update consultation status:", error);
      return { success: false, error: "خطا در بروزرسانی وضعیت مشاوره" };
    }
    
    console.log(`✅ Consultation ${id} status updated to ${status}`);
    return { success: true };
  } catch (error) {
    console.error("❌ Exception in updateConsultationStatus:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}
