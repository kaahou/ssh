# 📖 راهنمای استفاده از Service Layer

## 🎯 چرا Service Layer؟

Service layer یک لایه میانی بین route handlers و database است که مزایای زیر را دارد:

- ✅ **Reusability**: کد قابل استفاده مجدد در چند route
- ✅ **Testability**: امکان تست منطق کسب‌وکار به صورت مستقل
- ✅ **Maintainability**: تغییرات فقط در یک جا
- ✅ **Separation of Concerns**: جداسازی routing از business logic
- ✅ **Clean Code**: route handlers ساده و خوانا

## 📚 Service های موجود

### 1️⃣ Product Service (`product_service.ts`)

#### دریافت محصولات
```typescript
import { getProducts } from './product_service.ts';

const result = await getProducts({
  page: 1,
  limit: 12,
  categoryId: 5,
  search: 'کرم'
});

if (result.success) {
  console.log(`Found ${result.products.length} products`);
  console.log(`Total: ${result.total}`);
}
```

#### دریافت محصول با slug
```typescript
import { getProductBySlug } from './product_service.ts';

const result = await getProductBySlug('moisturizer-cream');

if (result.success && result.product) {
  console.log('Product:', result.product.name);
}
```

#### محصولات ویژه
```typescript
import { getFeaturedProducts } from './product_service.ts';

const result = await getFeaturedProducts(8);
```

#### ایجاد محصول جدید
```typescript
import { createProduct } from './product_service.ts';

const result = await createProduct({
  name: 'کرم مرطوب‌کننده',
  slug: 'moisturizer-cream',
  price: 250000,
  description: 'کرم مرطوب‌کننده پوست',
  category_id: 5,
  stock: 100
});

if (result.success) {
  console.log('Product created:', result.product.id);
}
```

#### بروزرسانی محصول
```typescript
import { updateProduct } from './product_service.ts';

const result = await updateProduct(123, {
  price: 280000,
  stock: 50
});
```

#### حذف محصول
```typescript
import { deleteProduct } from './product_service.ts';

const result = await deleteProduct(123);
```

#### مدیریت موجودی
```typescript
import { updateProductStock } from './product_service.ts';

// Set exact stock
await updateProductStock(123, 100, 'set');

// Add to stock
await updateProductStock(123, 10, 'add');

// Subtract from stock (for sales)
await updateProductStock(123, 5, 'subtract');
```

#### محصولات مرتبط
```typescript
import { getRelatedProducts } from './product_service.ts';

const result = await getRelatedProducts(123, 4);
```

---

### 2️⃣ Order Service (`order_service.ts`)

#### ثبت سفارش
```typescript
import { createOrder } from './order_service.ts';

const result = await createOrder({
  customerName: 'علی احمدی',
  phone: '09123456789',
  email: 'ali@example.com',
  state: 'تهران',
  city: 'تهران',
  street: 'خیابان ولیعصر، پلاک 123',
  postalCode: '1234567890',
  paymentMethod: 'zarinpal',
  items: [
    {
      product_id: 1,
      slug: 'product-1',
      name: 'محصول 1',
      price: 100000,
      quantity: 2,
      image: 'image.jpg'
    }
  ],
  totalAmount: 280000
});

if (result.success) {
  console.log('Order ID:', result.orderId);
}
```

#### دریافت سفارش
```typescript
import { getOrderById } from './order_service.ts';

const result = await getOrderById(1234567890);

if (result.success && result.order) {
  console.log('Order total:', result.order.total_amount);
  console.log('Items:', result.order.items);
}
```

#### لیست سفارشات
```typescript
import { getOrders } from './order_service.ts';

const result = await getOrders({
  page: 1,
  limit: 20,
  status: 'pending',
  paymentStatus: 'paid_zarinpal'
});

if (result.success) {
  console.log(`Found ${result.orders.length} orders`);
  console.log(`Total: ${result.total}`);
}
```

#### بروزرسانی وضعیت پرداخت
```typescript
import { updateOrderPaymentStatus } from './order_service.ts';

const result = await updateOrderPaymentStatus(
  1234567890,
  'paid_zarinpal',
  {
    authority: 'A00000000000000000000000000123456',
    ref_id: '123456789',
    card_pan: '123456******1234'
  }
);
```

#### بروزرسانی وضعیت سفارش
```typescript
import { updateOrderStatus } from './order_service.ts';

await updateOrderStatus(1234567890, 'shipped');
```

#### آمار سفارشات
```typescript
import { getOrderStats } from './order_service.ts';

const result = await getOrderStats();

if (result.success && result.stats) {
  console.log('Total Orders:', result.stats.totalOrders);
  console.log('Total Revenue:', result.stats.totalRevenue);
  console.log('Today Orders:', result.stats.todayOrders);
}
```

---

### 3️⃣ Consultation Service (`consultation_service.ts`)

#### ذخیره OTP
```typescript
import { storeOTP } from './consultation_service.ts';

const success = await storeOTP('09123456789', '123456');
```

#### تایید OTP
```typescript
import { verifyOTP } from './consultation_service.ts';

const result = await verifyOTP('09123456789', '123456');

if (result.success) {
  console.log('OTP verified successfully');
} else {
  console.log('Error:', result.error);
}
```

#### ایجاد/دریافت کاربر
```typescript
import { getOrCreateUser } from './consultation_service.ts';

const result = await getOrCreateUser(
  '09123456789',
  'علی',
  'احمدی'
);

if (result.success && result.user) {
  console.log('User:', result.user);
}
```

#### ثبت مشاوره
```typescript
import { createConsultation } from './consultation_service.ts';

const result = await createConsultation('09123456789', {
  first_name: 'علی',
  last_name: 'احمدی',
  national_code: '1234567890',
  birth_year: '1370',
  gender: 'male',
  weight: '75',
  height: '180',
  body_type: 'متوسط',
  skin_color: 'روشن',
  city: 'تهران',
  has_disease: false,
  user_photos: ['data:image/jpeg;base64,...'],
  skin_issues: 'خشکی پوست',
  // ... سایر فیلدها
});

if (result.success) {
  console.log('Consultation ID:', result.consultationId);
}
```

#### دریافت مشاوره
```typescript
import { getConsultationById } from './consultation_service.ts';

const result = await getConsultationById(1234567890);
```

#### مشاوره‌های کاربر
```typescript
import { getConsultationsByPhone } from './consultation_service.ts';

const result = await getConsultationsByPhone('09123456789');
```

#### لیست مشاوره‌ها
```typescript
import { getConsultations } from './consultation_service.ts';

const result = await getConsultations({
  page: 1,
  limit: 20,
  status: 'pending'
});
```

#### بروزرسانی نتیجه مشاوره
```typescript
import { updateConsultationResult } from './consultation_service.ts';

await updateConsultationResult(
  1234567890,
  'نتیجه مشاوره شما: ...',
  'completed'
);
```

---

### 4️⃣ Storage Service (`storage_service.ts`)

#### ایجاد bucket
```typescript
import { ensureBucketExists } from './storage_service.ts';

const success = await ensureBucketExists('my-bucket', false);
```

#### مقداردهی اولیه bucket ها
```typescript
import { initializeStorageBuckets } from './storage_service.ts';

await initializeStorageBuckets();
```

#### آپلود فایل
```typescript
import { uploadFile } from './storage_service.ts';

const result = await uploadFile(
  'my-bucket',
  'path/to/file.jpg',
  fileData,
  'image/jpeg'
);

if (result.success) {
  console.log('File path:', result.path);
}
```

#### آپلود تصویر Base64
```typescript
import { uploadBase64Image } from './storage_service.ts';

const result = await uploadBase64Image(
  'consultations',
  'data:image/jpeg;base64,...',
  'photo.jpg'
);

if (result.success) {
  console.log('Image URL:', result.url);
}
```

#### آپلود چند تصویر
```typescript
import { uploadMultipleBase64Images } from './storage_service.ts';

const result = await uploadMultipleBase64Images(
  'consultations',
  [
    'data:image/jpeg;base64,...',
    'data:image/jpeg;base64,...'
  ]
);

if (result.success && result.urls) {
  console.log('Uploaded:', result.urls.length, 'images');
}
```

#### دریافت signed URL
```typescript
import { getSignedUrl } from './storage_service.ts';

const result = await getSignedUrl(
  'consultations',
  'path/to/file.jpg',
  3600 // 1 hour
);

if (result.success) {
  console.log('URL:', result.url);
}
```

#### حذف فایل
```typescript
import { deleteFile } from './storage_service.ts';

await deleteFile('consultations', 'path/to/file.jpg');
```

---

## 🛠️ Utilities

### Validators (`validators.ts`)

```typescript
import {
  isValidPhone,
  isValidEmail,
  isValidNationalCode,
  validateOrderRequest,
  validateConsultationData,
  validateProductData
} from './validators.ts';

// Phone validation
if (isValidPhone('09123456789')) {
  console.log('Valid phone');
}

// Email validation
if (isValidEmail('user@example.com')) {
  console.log('Valid email');
}

// Order validation
const orderValidation = validateOrderRequest(orderData);
if (!orderValidation.valid) {
  console.error('Error:', orderValidation.error);
}
```

### Formatters (`formatters.ts`)

```typescript
import {
  formatPrice,
  formatPhoneDisplay,
  parseShippingInfo,
  parsePaymentInfo,
  isOrderPaid,
  getTodayRange,
  formatPaginationParams
} from './formatters.ts';

// Price formatting
const formatted = formatPrice(250000); // "250,000"

// Phone formatting
const phone = formatPhoneDisplay('09123456789'); // "0912 345 6789"

// Check if order is paid
if (isOrderPaid(order)) {
  console.log('Order is paid');
}

// Date range
const { start, end } = getTodayRange();

// Pagination
const { page, limit, offset } = formatPaginationParams(2, 20);
```

### Middleware (`middleware.ts`)

```typescript
import {
  requireAdmin,
  requireAuth,
  optionalAuth,
  rateLimit
} from './middleware.ts';

// در route files:
import { Hono } from 'npm:hono';
const routes = new Hono();

// Require admin access
routes.get('/admin/dashboard', requireAdmin, async (c) => {
  const phone = c.get('userPhone');
  // ...
});

// Require authentication
routes.get('/profile', requireAuth, async (c) => {
  const userId = c.get('userId');
  // ...
});

// Optional authentication
routes.get('/products', optionalAuth, async (c) => {
  const userId = c.get('userId'); // May be undefined
  // ...
});

// Rate limiting
routes.post('/send-otp', rateLimit(5, 60000), async (c) => {
  // Max 5 requests per minute
});
```

---

## 🎯 الگوهای استفاده

### الگوی 1: Route + Service
```typescript
// ❌ قبل: همه چیز در route
productRoutes.get("/products/:id", async (c) => {
  const id = c.req.param("id");
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .single();
  
  if (error) return c.json({ error: "Not found" }, 404);
  return c.json({ product: { ...data, product_id: data.id } });
});

// ✅ بعد: استفاده از service
productRoutes.get("/products/:id", async (c) => {
  const id = parseInt(c.req.param("id"));
  const result = await getProductById(id);
  
  if (!result.success) {
    return c.json({ error: result.error }, 404);
  }
  
  return c.json({ product: result.product });
});
```

### الگوی 2: استفاده از Validators
```typescript
// ✅ استفاده از validator
import { validateOrderRequest } from './validators.ts';

orderRoutes.post("/orders", async (c) => {
  const body = await c.req.json();
  
  const validation = validateOrderRequest(body);
  if (!validation.valid) {
    return c.json({ error: validation.error }, 400);
  }
  
  const result = await createOrder(body);
  return c.json(result);
});
```

### الگوی 3: استفاده از Constants
```typescript
// ✅ استفاده از constants
import { FIXED_SHIPPING_COST, ERROR_MESSAGES } from './constants.ts';

const total = subtotal + FIXED_SHIPPING_COST;

if (!user) {
  return c.json({ error: ERROR_MESSAGES.UNAUTHORIZED }, 401);
}
```

---

## 📊 نمونه کامل

```typescript
// new_feature_routes.ts
import { Hono } from "npm:hono";
import { requireAuth } from "./middleware.ts";
import { createFeature, getFeatures } from "./feature_service.ts";

const featureRoutes = new Hono();

// Create feature (authenticated)
featureRoutes.post("/features", requireAuth, async (c) => {
  const userId = c.get('userId');
  const body = await c.req.json();
  
  const result = await createFeature(userId, body);
  
  if (!result.success) {
    return c.json({ error: result.error }, 400);
  }
  
  return c.json({ feature: result.feature }, 201);
});

// List features
featureRoutes.get("/features", async (c) => {
  const { page, limit } = c.req.query();
  
  const result = await getFeatures({ page, limit });
  
  return c.json({
    features: result.features,
    total: result.total
  });
});

export default featureRoutes;
```

```typescript
// feature_service.ts
import { supabase } from './db.ts';
import { ERROR_MESSAGES } from './constants.ts';
import { validateFeatureData } from './validators.ts';

export async function createFeature(userId: number, data: any) {
  // Validate
  const validation = validateFeatureData(data);
  if (!validation.valid) {
    return { success: false, error: validation.error };
  }
  
  // Create
  const { data: feature, error } = await supabase
    .from('features')
    .insert({ ...data, user_id: userId })
    .select()
    .single();
  
  if (error) {
    console.error("❌ Failed to create feature:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
  
  return { success: true, feature };
}

export async function getFeatures(options: { page?: number; limit?: number }) {
  const { page = 1, limit = 20 } = options;
  const offset = (page - 1) * limit;
  
  const { data: features, error, count } = await supabase
    .from('features')
    .select('*', { count: 'exact' })
    .range(offset, offset + limit - 1);
  
  if (error) {
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
  
  return { success: true, features, total: count };
}
```

---

این راهنما نشان می‌دهد که چگونه از service layer و utilities استفاده کنید تا کد تمیز، قابل نگهداری و قابل تست داشته باشید. 🚀
