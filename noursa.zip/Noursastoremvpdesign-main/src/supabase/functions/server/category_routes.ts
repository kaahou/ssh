import { Hono } from "npm:hono";
import { supabase } from "./db.ts";

const categoryRoutes = new Hono();

// Get all categories
categoryRoutes.get("/categories", async (c) => {
  try {
    console.log("Fetching categories from Postgres database...");
    
    const { data: categories, error } = await supabase
      .from('categories')
      .select('*')
      .order('sort_order', { ascending: true });
    
    if (error) {
      console.error("Supabase error fetching categories:", error);
      return c.json({ error: "Failed to fetch categories from database" }, 500);
    }
    
    console.log(`Found ${categories?.length || 0} categories from database`);
    return c.json({ categories: categories || [] });
  } catch (error) {
    console.error("Error fetching categories:", error);
    return c.json({ error: "Failed to fetch categories" }, 500);
  }
});

export default categoryRoutes;
