// Storage RLS Policy Setup for Supabase Storage Buckets
// این فایل policies مورد نیاز برای آپلود فایل‌ها را تنظیم می‌کند

import { supabase } from './db.ts';

/**
 * Setup RLS policies for storage buckets using SQL
 * Note: This creates policies using the Supabase service role
 */
export async function setupStoragePolicies() {
  console.log('🔐 Setting up storage RLS policies...');
  
  const bucketName = 'make-fbc72c25-consultation-photos';
  
  try {
    // Policy 1: Allow anyone to upload files (INSERT)
    const insertPolicySQL = `
      INSERT INTO storage.policies (name, bucket_id, roles, definition, check_expression)
      SELECT 
        'Allow public uploads',
        '${bucketName}',
        '{authenticated, anon}',
        'true',
        'true'
      WHERE NOT EXISTS (
        SELECT 1 FROM storage.policies 
        WHERE bucket_id = '${bucketName}' AND name = 'Allow public uploads'
      );
    `;
    
    // Policy 2: Allow anyone to read files (SELECT)
    const selectPolicySQL = `
      INSERT INTO storage.policies (name, bucket_id, roles, definition, check_expression)
      SELECT 
        'Allow public reads',
        '${bucketName}',
        '{authenticated, anon}',
        'true',
        NULL
      WHERE NOT EXISTS (
        SELECT 1 FROM storage.policies 
        WHERE bucket_id = '${bucketName}' AND name = 'Allow public reads'
      );
    `;
    
    console.log('⚠️ Note: RLS policies cannot be created via Supabase client API.');
    console.log('📋 To fix the "new row violates row-level security policy" error:');
    console.log('');
    console.log('🔧 Please run these SQL commands in your Supabase SQL Editor:');
    console.log('');
    console.log('-- Allow uploads to consultation-photos bucket');
    console.log(`CREATE POLICY "Allow public uploads" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = '${bucketName}');`);
    console.log('');
    console.log('-- Allow reads from consultation-photos bucket');
    console.log(`CREATE POLICY "Allow public reads" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = '${bucketName}');`);
    console.log('');
    console.log('✅ After running these commands, the file upload will work!');
    
  } catch (error) {
    console.error('❌ Error setting up storage policies:', error);
  }
}
