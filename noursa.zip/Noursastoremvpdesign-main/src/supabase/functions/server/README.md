# Server Architecture - Modular Structure

این سرور با استفاده از معماری ماژولار و لایه‌ای (Service Layer) بازنویسی شده است تا خوانایی، نگهداری و توسعه‌پذیری بهتری داشته باشد.

## 🎯 معماری

این backend از **معماری سه‌لایه** پیروی می‌کند:

```
📱 Client
    ↓
🛣️ Routing Layer (Routes)
    ↓
💼 Service Layer (Business Logic)
    ↓
🗄️ Data Access Layer (Database/Storage)
```

### لایه‌های اصلی

1. **Routing Layer** (`*_routes.ts`): مدیریت HTTP requests/responses
2. **Service Layer** (`*_service.ts`): منطق کسب‌وکار و validation
3. **Data Access** (`db.ts`, `kv_store.tsx`, `storage_service.ts`): دسترسی به database
4. **Utilities** (`validators.ts`, `formatters.ts`, `middleware.ts`): توابع کمکی

## 📂 ساختار فایل‌ها

```
/supabase/functions/server/
│
├── 📄 index.tsx                    # Entry point اصلی (150 خط)
│
├── 🔧 Core Files
│   ├── db.ts                       # Supabase client
│   ├── kv_store.tsx                # KV storage utilities (محافظت شده)
│   ├── types.ts                    # TypeScript types & interfaces
│   ├── constants.ts                # Application constants
│   └── middleware.ts               # Shared middleware
│
├── 🛣️ Route Modules (13 ماژول)
│   ├── product_routes.ts           # محصولات
│   ├── order_routes.ts             # سفارشات
│   ├── consultation_routes.ts      # مشاوره
│   ├── auth_routes.ts              # احراز هویت
│   ├── user_routes.ts              # کاربران
│   ├── article_routes.ts           # مقالات
│   ├── category_routes.ts          # دسته‌بندی‌ها
│   ├── search_routes.ts            # جستجو
│   ├── payment_routes.ts           # پرداخت (Zarinpal)
│   ├── sitemap_routes.ts           # Sitemap
│   ├── admin_routes.ts             # پنل ادمین
│   └── debug_routes.ts             # Debugging
│
├── 💼 Service Layer (4 سرویس)
│   ├── product_service.ts          # منطق محصولات
│   ├── order_service.ts            # منطق سفارشات
│   ├── consultation_service.ts     # منطق مشاوره
│   └── storage_service.ts          # مدیریت فایل‌ها
│
├── 🔨 Utilities
│   ├── validators.ts               # اعتبارسنجی ورودی‌ها
│   ├── formatters.ts               # فرمت‌دهی داده‌ها
│   ├── zarinpal.ts                 # درگاه زرین‌پال
│   ├── consultation_sms.ts         # صف و ارسال SMS
│   └── sitemap.ts                  # تولید sitemap
│
└── 📚 Documentation
    ├── ARCHITECTURE.md             # مستندات کامل معماری
    ├── API_GUIDE.md                # راهنمای استفاده از Service Layer
    ├── README.md                   # این فایل
    ├── CHANGELOG.md                # تاریخچه تغییرات
    └── CONNECTION_FIX.md           # راهنمای رفع خطای connection closed
```

## ⚠️ رفع مشکل Connection Closed

اگر با خطای `"connection closed before message completed"` مواجه شدید:

1. 📖 **[CONNECTION_FIX.md](./CONNECTION_FIX.md)** را مطالعه کنید
2. 🧪 از `test-payment-endpoint.sh` برای تست استفاده کنید
3. 📊 لاگ‌های سرور را در Supabase Dashboard چک کنید

**نسخه فعلی سرور**: `connection-fix-v3` ✅

### تغییرات مهم v3:
- ✅ حذف `requestLogger` middleware
- ✅ Clone کردن response قبل از return
- ✅ بهبود error handling در همه middleware ها
- ✅ اضافه شدن error details برای debugging

## 🚀 شروع سریع

### استفاده از Service Layer

```typescript
// ✅ استفاده از service در route handler
import { getProducts, createProduct } from './product_service.ts';

productRoutes.get("/products", async (c) => {
  const { page, limit } = c.req.query();
  const result = await getProducts({ page, limit });
  
  if (!result.success) {
    return c.json({ error: result.error }, 400);
  }
  
  return c.json({ products: result.products });
});
```

### استفاده از Validators

```typescript
import { validateOrderRequest } from './validators.ts';

const validation = validateOrderRequest(orderData);
if (!validation.valid) {
  return c.json({ error: validation.error }, 400);
}
```

### استفاده از Constants

```typescript
import { FIXED_SHIPPING_COST, ERROR_MESSAGES } from './constants.ts';

const total = subtotal + FIXED_SHIPPING_COST;
return c.json({ error: ERROR_MESSAGES.UNAUTHORIZED }, 401);
```

## 📚 مستندات کامل

- **[ARCHITECTURE.md](./ARCHITECTURE.md)** - معماری کامل و اصول طراحی
- **[API_GUIDE.md](./API_GUIDE.md)** - راهنمای استفاده از Service Layer
- **[CHANGELOG.md](./CHANGELOG.md)** - تاریخچه تغییرات و نسخه‌ها

## ⭐ ویژگی‌های کلیدی

### ✅ Separation of Concerns
- جداسازی routing از business logic
- هر لایه یک مسئولیت مشخص دارد

### ✅ Type Safety
- استفاده از TypeScript types در همه جا
- 15+ interface و type تعریف شده

### ✅ Reusability
- 40+ تابع قابل استفاده مجدد
- کد DRY (Don't Repeat Yourself)

### ✅ Testability
- Business logic قابل تست مستقل از HTTP
- هر service به صورت جداگانه قابل تست

### ✅ Maintainability
- کد تمیز و خوانا
- نگهداری و توسعه آسان

## 🛣️ مستندات Routes

### فایل اصلی
- **`index.tsx`** - فایل اصلی که تمام ماژول‌ها را import و mount می‌کند

### ماژول‌های پایه
- **`db.ts`** - Supabase client و تنظیمات پایگاه داده
- **`kv_store.tsx`** - KV Store utilities (فایل محافظت شده)
- **`types.ts`** - TypeScript types & interfaces
- **`constants.ts`** - Application constants
- **`middleware.ts`** - Shared middleware

### ماژول‌های Routing

#### 1. **`debug_routes.ts`**
روت‌های debugging و health check:
- `GET /health` - Health check
- `GET /db-status` - بررسی وضعیت پایگاه داده
- `GET /debug/user/:phone` - بررسی کاربر با شماره تلفن

#### 2. **`product_routes.ts`**
روت‌های مربوط به محصولات:
- `GET /products` - دریافت همه محصولات
- `GET /products/featured` - دریافت محصولات ویژه
- `GET /products/:id` - دریافت یک محصول
- `POST /products` - ایجاد محصول جدید
- `PUT /products/:id` - بروزرسانی محصول
- `DELETE /products/:id` - حذف محصول

#### 3. **`order_routes.ts`**
روت‌های مربوط به سفارشات:
- `POST /orders` - ایجاد سفارش جدید
- `GET /orders` - دریافت همه سفارشات
- `GET /orders/:id` - دریافت جزئیات سفارش
- `DELETE /orders/:id` - حذف سفارش
- `PUT /orders/:id/status` - بروزرسانی وضعیت سفارش
- `POST /admin/orders` - ایجاد سفارش دستی (ادمین)

#### 4. **`consultation_routes.ts`**
روت‌های مربوط به مشاوره:
- `POST /verify-otp` - تایید OTP و ذخیره مشاوره
- `GET /consultations/by-phone/:phone` - دریافت مشاوره‌های یک کاربر
- `GET /consultations/:id` - دریافت جزئیات مشاوره
- `GET /admin/consultations` - دریافت همه مشاوره‌ها (ادمین)
- `GET /admin/consultations/:id` - دریافت جزئیات مشاوره (ادمین)
- `PUT /admin/consultations/:id` - بروزرسانی مشاوره (ادمین)

#### 5. **`auth_routes.ts`**
روت‌های احراز هویت:
- `POST /send-otp` - ارسال کد OTP
- `POST /verify-login-otp` - تایید OTP برای ورود/ثبت‌نام

#### 6. **`user_routes.ts`**
روت‌های مربوط به کاربران:
- `GET /user/:userId` - دریافت پروفایل کاربر
- `PUT /user/:userId` - بروزرسانی پروفایل کاربر
- `GET /users` - دریافت همه کاربران (ادمین)
- `DELETE /users/:userId` - حذف کاربر (ادمین)

#### 7. **`article_routes.ts`**
روت‌های مربوط به مقالات:
- `GET /articles` - دریافت همه مقالات
- `POST /articles` - ایجاد مقاله جدید
- `GET /articles/:slug` - دریافت مقاله با slug
- `DELETE /articles/:id` - حذف مقاله

#### 8. **`category_routes.ts`**
روت‌های مربوط به دسته‌بندی‌ها:
- `GET /categories` - دریافت همه دسته‌بندی‌ها

#### 9. **`search_routes.ts`**
روت‌های جستجو:
- `GET /search?q=...` - جستجو در محصولات و مقالات

#### 10. **`payment_routes.ts`**
روت‌های پرداخت:
- `POST /payment/zarinpal/request` - درخواست پرداخت زرین‌پال
- `POST /payment/zarinpal/verify` - تایید پرداخت زرین‌پال

#### 11. **`sitemap_routes.ts`**
روت‌های sitemap:
- `GET /sitemap.xml` - تولید XML Sitemap

#### 12. **`admin_routes.ts`**
روت‌های ادمین:
- `GET /admin/stats` - آمار داشبورد ادمین

## مزایای معماری جدید

### ✅ خوانایی بهتر
- هر فایل فقط مسئول یک بخش خاص است
- کدها سازماندهی شده و قابل فهم‌تر هستند
- پیدا کردن و اصلاح باگ‌ها راحت‌تر است

### ✅ نگهداری آسان‌تر
- تغییرات در یک بخش نیاز به تغییر فقط در یک فایل دارد
- کاهش احتمال conflict در Git
- تست‌نویسی راحت‌تر

### ✅ مقیاس‌پذیری
- افزودن route جدید به راحتی امکان‌پذیر است
- می‌توان به راحتی ماژول‌های جدید اضافه کرد
- قابلیت استفاده مجدد از کدها

### ✅ عملکرد بهتر
- کدهای تکراری و orphan حذف شدند
- فایل اصلی از 2596 خط به حدود 150 خط کاهش یافت
- زمان بارگذاری و compile سریع‌تر

## نکات مهم

1. **فایل‌های محافظت شده**: فایل `kv_store.tsx` محافظت شده است و نباید تغییر کند
2. **Import Path**: همه ماژول‌ها از `.ts` یا `.tsx` استفاده می‌کنند
3. **Error Handling**: همه روت‌ها error handling مناسب دارند
4. **CORS**: تنظیمات CORS در فایل اصلی index.tsx پیکربندی شده است
5. **Logging**: همه عملیات مهم لاگ می‌شوند

## نحوه اضافه کردن Route جدید

1. فایل جدید با نام `feature_routes.ts` ایجاد کنید
2. از template زیر استفاده کنید:

```typescript
import { Hono } from "npm:hono";
import { supabase } from "./db.ts";

const featureRoutes = new Hono();

// Add your routes here
featureRoutes.get("/feature", async (c) => {
  // Your code
});

export default featureRoutes;
```

3. در `index.tsx` import و mount کنید:

```typescript
import featureRoutes from "./feature_routes.ts";
// ...
api.route("/", featureRoutes);
```

## تغییرات نسبت به نسخه قبل

### حذف شده:
- ✅ کدهای orphan در خطوط 1094-1131 حذف شدند
- ✅ روت‌های duplicate حذف شدند
- ✅ کدهای تکراری یکپارچه شدند

### اضافه شده:
- ✅ ساختار ماژولار جدید
- ✅ فایل db.ts برای مدیریت Supabase client
- ✅ 12 ماژول route جداگانه
- ✅ این فایل README برای مستندات

## خطایابی

اگر خطایی رخ داد:
1. لاگ‌های console را بررسی کنید
2. مطمئن شوید تمام environment variables تنظیم شده‌اند
3. بررسی کنید که نام جداول در Postgres درست باشد
4. از route `/health` برای بررسی سلامت سرور استفاده کنید
5. از route `/db-status` برای بررسی اتصال به پایگاه داده استفاده کنید