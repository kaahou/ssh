// Order Business Logic Service

import { supabase } from './db.ts';
import type { 
  Order, 
  CreateOrderRequest, 
  OrderItem, 
  ShippingInfo, 
  PaymentInfo,
  PaymentStatus 
} from './types.ts';
import { 
  FIXED_SHIPPING_COST, 
  PAYMENT_METHODS, 
  PAYMENT_STATUSES,
  ERROR_MESSAGES 
} from './constants.ts';
import { validateOrderRequest } from './validators.ts';
import { splitFullName, parseShippingInfo, parsePaymentInfo } from './formatters.ts';

// ==================== Order Creation ====================
/**
 * Create a new order in the database
 */
export async function createOrder(
  orderData: CreateOrderRequest
): Promise<{ success: boolean; orderId?: number; error?: string }> {
  try {
    // Validate order data
    const validation = validateOrderRequest(orderData);
    if (!validation.valid) {
      return { success: false, error: validation.error };
    }
    
    const { 
      customerName, 
      phone, 
      email, 
      state, 
      city, 
      street, 
      postalCode, 
      paymentMethod, 
      trackingCode, 
      items, 
      totalAmount 
    } = orderData;
    
    // Calculate totals
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const postPrice = FIXED_SHIPPING_COST;
    const finalTotalAmount = totalAmount || (subtotal + postPrice);
    
    // Generate unique bigint ID for order
    const orderId = Date.now();
    
    // Split customer name
    const { firstName, lastName } = splitFullName(customerName);
    
    // Prepare shipping info JSON object
    const shippingInfo: ShippingInfo = {
      contact: {
        mobile: phone || "",
        email: email || ""
      },
      address: {
        first_name: firstName,
        last_name: lastName,
        state: state || "",
        city: city || "",
        street: street || "",
        postal_code: postalCode || ""
      }
    };
    
    // Prepare payment info JSON object
    const paymentInfo: PaymentInfo = {
      method: paymentMethod || PAYMENT_METHODS.ZARINPAL,
      status: "pending",
      tracking_code: trackingCode || ""
    };
    
    // Determine payment_status based on method and status
    let payment_status: PaymentStatus = PAYMENT_STATUSES.PENDING;
    
    if (paymentMethod === PAYMENT_METHODS.CARD && trackingCode) {
      payment_status = PAYMENT_STATUSES.PAID_CARD;
      paymentInfo.status = "paid";
    } else if (paymentMethod === PAYMENT_METHODS.MANUAL) {
      payment_status = PAYMENT_STATUSES.PAID_MANUAL;
      paymentInfo.status = "paid";
    }
    
    // Store payment_status inside payment_info JSON
    paymentInfo.payment_status = payment_status;
    
    // Insert order into Postgres
    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .insert({
        id: orderId,
        total_amount: finalTotalAmount,
        subtotal: subtotal,
        post_price: postPrice,
        shipping_info: shippingInfo,
        payment_info: paymentInfo,
        status: 'pending'
      })
      .select()
      .single();
    
    if (orderError) {
      console.error("❌ Failed to insert order:", orderError);
      return { success: false, error: "خطا در ثبت سفارش" };
    }
    
    console.log(`✅ Order ${orderId} created successfully`);
    
    // Insert order items
    const orderItemsData = items.map((item) => ({
      order_id: orderId,
      product_id: item.product_id,
      product_slug: item.slug,
      product_name: item.name,
      product_image: item.image || "",
      price: item.price,
      quantity: item.quantity,
      total: item.price * item.quantity
    }));
    
    const { error: itemsError } = await supabase
      .from('orderitems')
      .insert(orderItemsData);
    
    if (itemsError) {
      console.error("❌ Failed to insert order items:", itemsError);
      // Try to delete the order if items insertion failed
      await supabase.from('orders').delete().eq('id', orderId);
      return { success: false, error: "خطا در ثبت اقلام سفارش" };
    }
    
    console.log(`✅ Order items inserted for order ${orderId}`);
    
    return { success: true, orderId };
  } catch (error) {
    console.error("❌ Exception in createOrder:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Order Retrieval ====================
/**
 * Get order by ID with items
 */
export async function getOrderById(
  orderId: number
): Promise<{ success: boolean; order?: any; error?: string }> {
  try {
    // Get order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single();
    
    if (orderError || !order) {
      return { success: false, error: "سفارش یافت نشد" };
    }
    
    // Get order items
    const { data: items, error: itemsError } = await supabase
      .from('orderitems')
      .select('*')
      .eq('order_id', orderId);
    
    if (itemsError) {
      console.error("❌ Failed to fetch order items:", itemsError);
    }
    
    // Parse JSON fields
    const shippingInfo = parseShippingInfo(order.shipping_info);
    const paymentInfo = parsePaymentInfo(order.payment_info);
    
    return {
      success: true,
      order: {
        ...order,
        shipping_info: shippingInfo,
        payment_info: paymentInfo,
        items: items || []
      }
    };
  } catch (error) {
    console.error("❌ Exception in getOrderById:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Get all orders with optional filtering
 */
export async function getOrders(options: {
  page?: number;
  limit?: number;
  status?: string;
  paymentStatus?: PaymentStatus;
}): Promise<{ success: boolean; orders?: any[]; total?: number; error?: string }> {
  try {
    const { page = 1, limit = 20, status, paymentStatus } = options;
    
    let query = supabase
      .from('orders')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false });
    
    if (status) {
      query = query.eq('status', status);
    }
    
    // Note: We can't filter by paymentStatus in SQL since it's inside JSON
    // We'll filter after retrieving the data
    
    const { data: allOrders, error, count } = await query;
    
    if (error) {
      console.error("❌ Failed to fetch orders:", error);
      return { success: false, error: "خطا در دریافت سفارشات" };
    }
    
    // Parse JSON fields and filter by payment status if needed
    let parsedOrders = allOrders?.map(order => ({
      ...order,
      shipping_info: parseShippingInfo(order.shipping_info),
      payment_info: parsePaymentInfo(order.payment_info)
    })) || [];
    
    // Filter by payment status if specified
    if (paymentStatus) {
      parsedOrders = parsedOrders.filter(order => {
        const pStatus = order.payment_info?.payment_status || order.payment_info?.status;
        return pStatus === paymentStatus;
      });
    }
    
    // Apply pagination after filtering
    const offset = (page - 1) * limit;
    const paginatedOrders = parsedOrders.slice(offset, offset + limit);
    
    return {
      success: true,
      orders: paginatedOrders,
      total: parsedOrders.length
    };
  } catch (error) {
    console.error("❌ Exception in getOrders:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Order Update ====================
/**
 * Update order payment status
 */
export async function updateOrderPaymentStatus(
  orderId: number,
  paymentStatus: PaymentStatus,
  paymentInfo?: Partial<PaymentInfo>
): Promise<{ success: boolean; error?: string }> {
  try {
    // Get current order
    const { data: order, error: fetchError } = await supabase
      .from('orders')
      .select('payment_info')
      .eq('id', orderId)
      .single();
    
    if (fetchError || !order) {
      return { success: false, error: "سفارش یافت نشد" };
    }
    
    // Parse and update payment info
    const currentPaymentInfo = parsePaymentInfo(order.payment_info) || {
      method: PAYMENT_METHODS.ZARINPAL,
      status: 'pending'
    };
    
    const updatedPaymentInfo: PaymentInfo = {
      ...currentPaymentInfo,
      ...paymentInfo,
      payment_status: paymentStatus,
      status: paymentStatus.includes('paid') ? 'paid' : 
              paymentStatus === 'failed' ? 'failed' :
              paymentStatus === 'cancelled' ? 'cancelled' : 'pending'
    };
    
    // Update order
    const { error: updateError } = await supabase
      .from('orders')
      .update({
        payment_info: updatedPaymentInfo
      })
      .eq('id', orderId);
    
    if (updateError) {
      console.error("❌ Failed to update order payment status:", updateError);
      return { success: false, error: "خطا در بروزرسانی وضعیت پرداخت" };
    }
    
    console.log(`✅ Order ${orderId} payment status updated to ${paymentStatus}`);
    return { success: true };
  } catch (error) {
    console.error("❌ Exception in updateOrderPaymentStatus:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Update order status
 */
export async function updateOrderStatus(
  orderId: number,
  status: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('orders')
      .update({
        status
      })
      .eq('id', orderId);
    
    if (error) {
      console.error("❌ Failed to update order status:", error);
      return { success: false, error: "خطا در بروزرسانی وضعیت سفارش" };
    }
    
    console.log(`✅ Order ${orderId} status updated to ${status}`);
    return { success: true };
  } catch (error) {
    console.error("❌ Exception in updateOrderStatus:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Order Statistics ====================
/**
 * Get order statistics
 */
export async function getOrderStats(): Promise<{
  success: boolean;
  stats?: {
    totalOrders: number;
    paidOrders: number;
    totalRevenue: number;
    todayOrders: number;
  };
  error?: string;
}> {
  try {
    // Get all orders count
    const { count: totalOrders } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true });
    
    // Get all orders to check payment status from JSON
    const { data: allOrders } = await supabase
      .from('orders')
      .select('total_amount, payment_info');
    
    // Filter paid orders by checking payment_info JSON
    const paidOrdersData = allOrders?.filter(order => {
      const paymentInfo = parsePaymentInfo(order.payment_info);
      const paymentStatus = paymentInfo?.payment_status || paymentInfo?.status;
      return paymentStatus && (
        paymentStatus === PAYMENT_STATUSES.PAID_ZARINPAL ||
        paymentStatus === PAYMENT_STATUSES.PAID_CARD ||
        paymentStatus === PAYMENT_STATUSES.PAID_MANUAL ||
        paymentStatus === 'paid'
      );
    }) || [];
    
    const paidOrders = paidOrdersData.length;
    const totalRevenue = paidOrdersData.reduce((sum, order) => 
      sum + (order.total_amount || 0), 0
    );
    
    // Get today's orders
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const { count: todayOrders } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', today.toISOString());
    
    return {
      success: true,
      stats: {
        totalOrders: totalOrders || 0,
        paidOrders,
        totalRevenue,
        todayOrders: todayOrders || 0
      }
    };
  } catch (error) {
    console.error("❌ Exception in getOrderStats:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}