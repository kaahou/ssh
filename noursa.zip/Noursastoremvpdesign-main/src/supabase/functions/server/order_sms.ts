// Order SMS Handler
// این تابع برای ارسال پیامک‌های سیستم سفارش است

interface SMSQueueItem {
  phone: string;
  message: string;
  timestamp: number;
}

// صف پیامک‌های منتظر ارسال
const smsQueue: SMSQueueItem[] = [];
let isProcessing = false;

/**
 * اضافه کردن پیامک به صف ارسال
 */
export function queueOrderSMS(phone: string, message: string) {
  console.log(`📨 Adding order SMS to queue for ${phone}`);
  smsQueue.push({
    phone,
    message,
    timestamp: Date.now(),
  });

  // شروع پردازش صف اگر در حال اجرا نیست (non-blocking)
  if (!isProcessing) {
    processQueue().catch((error) => {
      console.error("❌ Error processing order SMS queue:", error);
    });
  }
}

/**
 * پردازش صف پیامک‌ها
 */
async function processQueue() {
  if (isProcessing || smsQueue.length === 0) {
    return;
  }

  isProcessing = true;

  while (smsQueue.length > 0) {
    const item = smsQueue.shift();
    if (!item) break;

    try {
      await sendOrderSMS(item.phone, item.message);
      // تاخیر 500ms بین ارسال پیامک‌ها
      await new Promise((resolve) => setTimeout(resolve, 500));
    } catch (error) {
      console.error(`❌ Failed to send order SMS to ${item.phone}:`, error);
    }
  }

  isProcessing = false;
}

/**
 * ارسال پیامک سفارش
 */
async function sendOrderSMS(
  phone: string,
  message: string
): Promise<boolean> {
  const username = Deno.env.get("NIAZPARDAZ_USERNAME");
  const password = Deno.env.get("NIAZPARDAZ_PASSWORD");
  const fromNumber = Deno.env.get("NIAZPARDAZ_FROM_NUMBER");

  if (!username || !password || !fromNumber) {
    console.error("❌ Niazpardaz credentials not configured");
    return false;
  }

  console.log(`📤 Sending order SMS to ${phone}...`);

  try {
    // روش 1: POST
    let smsResponse = await fetch(
      "https://panel.niazpardaz-sms.com/SMSInOutBox/Send",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          UserName: username,
          Password: password,
          From: fromNumber,
          To: phone,
          Message: message,
        }),
      }
    );

    // روش 2: GET (fallback)
    if (!smsResponse.ok && smsResponse.status !== 200) {
      console.log("⚠️ POST method failed, trying GET...");
      const smsUrl = `https://panel.niazpardaz-sms.com/SMSInOutBox/SendSms?username=${encodeURIComponent(
        username
      )}&password=${encodeURIComponent(
        password
      )}&from=${encodeURIComponent(fromNumber)}&to=${encodeURIComponent(
        phone
      )}&text=${encodeURIComponent(message)}`;
      smsResponse = await fetch(smsUrl);
    }

    if (smsResponse.ok || smsResponse.status === 200) {
      console.log(`✅ Order SMS sent successfully to ${phone}`);
      return true;
    } else {
      const responseText = await smsResponse.text();
      console.error(
        `❌ SMS API error: ${smsResponse.status} - ${responseText}`
      );
      return false;
    }
  } catch (error) {
    console.error(`❌ Error sending order SMS:`, error);
    return false;
  }
}

/**
 * ارسال پیامک تایید ثبت سفارش (کارت به کارت)
 */
export function sendCardToCardOrderConfirmation(
  phone: string,
  orderId: number | string
) {
  const message = `سفارش شما در نورسا ثبت شد، برای تایید تراکنش واریزی لطفا با شماره 09219675992 در تماس باشید.\nکد سفارش: ${orderId}`;
  queueOrderSMS(phone, message);
}

/**
 * ارسال پیامک تایید پرداخت آنلاین (زرین‌پال)
 */
export function sendOnlinePaymentConfirmation(
  phone: string,
  orderId: number | string
) {
  const message = `سفارش شما در نورسا با موفقیت ثبت و پرداخت شد.\nکد سفارش: ${orderId}\nبرای پیگیری با 09219675992 تماس بگیرید.\nnursaa.ir`;
  queueOrderSMS(phone, message);
}
