// Search endpoint
api.get("/search", async (c) => {
  try {
    const query = c.req.query("q");
    
    if (!query) {
      return c.json({ products: [], articles: [] });
    }
    
    console.log(`Searching for: ${query}`);
    
    // Search products
    const { data: products, error: productsError } = await supabase
      .from('products')
      .select('*')
      .or(`product_name.ilike.%${query}%,description.ilike.%${query}%`)
      .limit(12);
      
    if (productsError) {
      console.error("Error searching products:", productsError);
    }
    
    // Search articles (contents)
    const { data: articles, error: articlesError } = await supabase
      .from('contents')
      .select('*')
      .or(`title.ilike.%${query}%,content.ilike.%${query}%`)
      .limit(12);
      
    if (articlesError) {
      console.error("Error searching articles:", articlesError);
    }
    
    return c.json({
      products: products || [],
      articles: articles || [],
    });
  } catch (error) {
    console.error("Error in search endpoint:", error);
    return c.json({ error: "Search failed" }, 500);
  }
});