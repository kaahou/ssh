import { Hono } from "npm:hono";
import { supabase } from "./db.ts";
import * as kv from "./kv_store.tsx";
import * as consultationSMS from "./consultation_sms.ts";

const consultationRoutes = new Hono();

// Verify OTP and save consultation
consultationRoutes.post("/verify-otp", async (c) => {
  try {
    const body = await c.req.json();
    const { phone, otpCode, formData } = body;
    
    if (!phone || !otpCode || !formData) {
      return c.json({ error: "اطلاعات ناقص است" }, 400);
    }
    
    // Get stored OTP
    const storedOtpData = await kv.get(`otp:${phone}`);
    
    if (!storedOtpData) {
      return c.json({ error: "کد تایید منقضی شده است. لطفاً مجدداً درخواست دهید" }, 400);
    }
    
    // Check if OTP is expired
    if (Date.now() > storedOtpData.expiresAt) {
      await kv.del(`otp:${phone}`);
      return c.json({ error: "کد تایید منقضی شده است. لطفاً مجدداً درخواست دهید" }, 400);
    }
    
    // Verify OTP - Convert both to strings for comparison
    console.log(`🔍 OTP Verification Debug:`);
    console.log(`   Received OTP: "${otpCode}" (type: ${typeof otpCode})`);
    console.log(`   Stored OTP: "${storedOtpData.code}" (type: ${typeof storedOtpData.code})`);
    
    const receivedOtpStr = String(otpCode).trim();
    const storedOtpStr = String(storedOtpData.code).trim();
    
    if (storedOtpStr !== receivedOtpStr) {
      console.error(`❌ OTP mismatch: "${storedOtpStr}" !== "${receivedOtpStr}"`);
      return c.json({ error: "کد تایید اشتباه است" }, 400);
    }
    
    console.log(`✅ OTP verified successfully`);
    
    // OTP is valid, delete it
    await kv.del(`otp:${phone}`);
    
    // Check if user exists, if not create one
    let user = await kv.get(`user:${phone}`);
    
    if (!user) {
      user = {
        phone: phone,
        first_name: formData.first_name || null,
        last_name: formData.last_name || null,
        created_at: new Date().toISOString(),
      };
      await kv.set(`user:${phone}`, user);
      
      try {
        await supabase
          .from('users')
          .insert({
            phone: phone,
            first_name: formData.first_name || null,
            last_name: formData.last_name || null,
            created_at: new Date().toISOString(),
          });
      } catch (e) {
        console.warn("Users table might not exist:", e);
      }
    }
    
    // Save consultation to Supabase database
    const consultationId = Date.now();
    
    // ساختار ساده‌تر برای سازگاری با جدول موجود
    const consultationData = {
      id: consultationId,
      phone: phone,
      personal_info: {
        // Personal details
        first_name: formData.first_name || null,
        last_name: formData.last_name || null,
        age: formData.age || null,
        gender: formData.gender || null,
        
        // Photo URLs from upload
        photo_urls: formData.photo_urls || [],
        
        // Step 1: Hair & Scalp
        scalp_type: formData.scalp_type || null,
        scalp_temperament: formData.scalp_temperament || null,
        hair_state: formData.hair_state || null,
        hair_shaft: formData.hair_shaft || null,
        hair_length: formData.hair_length || null,
        main_problems: formData.main_problems || [],
        
        // Step 2: Lifestyle
        stress_level: formData.stress_level || null,
        wash_frequency: formData.wash_frequency || null,
        has_digestive_issues: formData.has_digestive_issues || false,
        uses_heat: formData.uses_heat || false,
        has_salon_history: formData.has_salon_history || false,
        salon_history_details: formData.salon_history_details || null,
        current_products: formData.current_products || null,
        medical_history: formData.medical_history || null,
        main_goals: formData.main_goals || [],
        environmental_conditions: formData.environmental_conditions || [],
        
        // Step 3: Additional
        additional_notes: formData.additional_notes || null,
      },
      status: 'pending',
      created_at: new Date().toISOString(),
    };
    
    console.log("💾 Attempting to save consultation to Supabase...");
    console.log("📊 Consultation ID:", consultationId);
    console.log("📊 Phone:", phone);
    console.log("📊 Data structure:", {
      id: consultationId,
      phone: phone,
      personal_info: "JSON object with all fields",
      status: 'pending',
      created_at: consultationData.created_at
    });
    
    const { data: consultation, error } = await supabase
      .from('consultations')
      .insert(consultationData)
      .select()
      .single();
    
    if (error) {
      console.error("❌❌❌ SUPABASE ERROR ❌❌❌");
      console.error("Error object:", JSON.stringify(error, null, 2));
      console.error("Error code:", error.code);
      console.error("Error message:", error.message);
      console.error("Error details:", error.details);
      console.error("Error hint:", error.hint);
      
      // Return detailed error to frontend
      return c.json({ 
        error: "خطا در ذخیره مشاوره", 
        debugInfo: {
          code: error.code,
          message: error.message,
          details: error.details,
          hint: error.hint
        }
      }, 500);
    }
    
    console.log("✅ Consultation saved successfully!");
    console.log("📊 Saved consultation ID:", consultation.id);
    
    // ارسال پیامک تایید ثبت مشاوره (به صف اضافه می‌شود تا timeout نشود)
    consultationSMS.sendConsultationConfirmation(phone, consultationId);
    
    return c.json({ 
      success: true, 
      consultationId,
      message: "مشاوره شما با موفقیت ثبت شد"
    });
  } catch (error) {
    console.error("Error verifying OTP:", error);
    return c.json({ error: "تایید کد با خطا مواجه شد", details: String(error) }, 500);
  }
});

// Get user consultations by phone
consultationRoutes.get("/consultations/by-phone/:phone", async (c) => {
  try {
    const phone = c.req.param("phone");
    
    const { data: consultations, error } = await supabase
      .from('consultations')
      .select('*')
      .eq('phone', phone)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error("Error fetching consultations by phone:", error);
      return c.json({ error: "Failed to fetch consultations" }, 500);
    }
    
    return c.json({ consultations: consultations || [] });
  } catch (error) {
    console.error("Error fetching consultations by phone:", error);
    return c.json({ error: "Failed to fetch consultations" }, 500);
  }
});

// User: Get single consultation detail
consultationRoutes.get("/consultations/:id", async (c) => {
  try {
    const id = c.req.param("id");
    console.log("📋 Fetching consultation detail for ID:", id);
    
    const { data: consultation, error } = await supabase
      .from('consultations')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error("❌ Error fetching consultation:", error);
      return c.json({ error: "Consultation not found" }, 404);
    }
    
    if (!consultation) {
      console.error("❌ Consultation not found for ID:", id);
      return c.json({ error: "Consultation not found" }, 404);
    }
    
    console.log("✅ Consultation found:", consultation.id, "Phone:", consultation.phone);
    return c.json({ consultation });
  } catch (error) {
    console.error("❌ Error fetching consultation:", error);
    return c.json({ error: "Failed to fetch consultation" }, 500);
  }
});

// Admin: Get all consultations
consultationRoutes.get("/admin/consultations", async (c) => {
  try {
    console.log("📋 Fetching all consultations...");
    
    // Try to get from Supabase first
    const { data: supabaseConsultations, error } = await supabase
      .from('consultations')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.warn("⚠️ Error fetching from Supabase, trying KV store:", error);
      
      // Fallback to KV store
      const kvConsultations = await kv.getByPrefix('consultation:');
      console.log(`✅ Found ${kvConsultations.length} consultations in KV store`);
      
      // Sort by created_at
      const sortedConsultations = kvConsultations.sort((a, b) => {
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      });
      
      return c.json({ consultations: sortedConsultations });
    }
    
    console.log(`✅ Found ${supabaseConsultations?.length || 0} consultations in Supabase`);
    return c.json({ consultations: supabaseConsultations || [] });
  } catch (error) {
    console.error("❌ Error fetching consultations:", error);
    
    // Final fallback to KV store
    try {
      const kvConsultations = await kv.getByPrefix('consultation:');
      return c.json({ consultations: kvConsultations });
    } catch (kvError) {
      console.error("❌ KV store also failed:", kvError);
      return c.json({ error: "Failed to fetch consultations" }, 500);
    }
  }
});

// Admin: Get consultation detail
consultationRoutes.get("/admin/consultations/:id", async (c) => {
  try {
    const id = c.req.param("id");
    console.log("📋 Admin fetching consultation detail for ID:", id);
    
    // Try Supabase first
    const { data: consultation, error } = await supabase
      .from('consultations')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.warn("⚠️ Error fetching from Supabase, trying KV store:", error);
      
      // Fallback to KV store
      const kvConsultation = await kv.get(`consultation:${id}`);
      if (kvConsultation) {
        console.log("✅ Consultation found in KV store:", id);
        return c.json({ consultation: kvConsultation });
      }
      
      console.error("❌ Consultation not found in both Supabase and KV store");
      return c.json({ error: "Consultation not found" }, 404);
    }
    
    if (!consultation) {
      // Try KV store
      const kvConsultation = await kv.get(`consultation:${id}`);
      if (kvConsultation) {
        console.log("✅ Consultation found in KV store:", id);
        return c.json({ consultation: kvConsultation });
      }
      
      console.error("❌ Consultation not found for ID:", id);
      return c.json({ error: "Consultation not found" }, 404);
    }
    
    console.log("✅ Admin consultation found:", consultation.id);
    return c.json({ consultation });
  } catch (error) {
    console.error("❌ Error fetching consultation detail:", error);
    
    // Final fallback to KV
    try {
      const id = c.req.param("id");
      const kvConsultation = await kv.get(`consultation:${id}`);
      if (kvConsultation) {
        return c.json({ consultation: kvConsultation });
      }
    } catch (kvError) {
      console.error("❌ KV fallback failed:", kvError);
    }
    
    return c.json({ error: "Failed to fetch consultation" }, 500);
  }
});

// Admin: Update consultation (add admin note)
consultationRoutes.put("/admin/consultations/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const body = await c.req.json();
    const { consultation_result } = body;
    
    console.log(`📝 Admin updating consultation ${id} with result`);
    
    if (!consultation_result || consultation_result.trim() === '') {
      console.error("❌ Consultation result is empty");
      return c.json({ error: "Consultation result is required" }, 400);
    }
    
    // Try to get from Supabase first
    const { data: consultation, error: fetchError } = await supabase
      .from('consultations')
      .select('*')
      .eq('id', id)
      .single();
    
    // If Supabase fails, try KV store
    if (fetchError || !consultation) {
      console.warn("⚠️ Consultation not in Supabase, checking KV store...");
      
      const kvConsultation = await kv.get(`consultation:${id}`);
      if (kvConsultation) {
        console.log(`✅ Consultation found in KV store: ID=${id}`);
        
        // Update in KV store
        const updatedConsultation = {
          ...kvConsultation,
          consultation_result,
          status: 'completed',
          updated_at: new Date().toISOString(),
        };
        
        await kv.set(`consultation:${id}`, updatedConsultation);
        console.log(`✅ Consultation updated in KV store: ID=${id}`);
        
        // Send SMS
        if (kvConsultation.phone) {
          console.log(`📤 Queueing consultation result SMS to ${kvConsultation.phone}...`);
          try {
            consultationSMS.sendConsultationResult(kvConsultation.phone, id);
            console.log(`✅ SMS queued successfully`);
          } catch (smsError) {
            console.error("⚠️ Error queueing SMS (non-critical):", smsError);
          }
        }
        
        return c.json({ success: true, consultation: updatedConsultation });
      }
      
      console.error("❌ Consultation not found in both Supabase and KV store");
      return c.json({ error: "Consultation not found", details: fetchError?.message }, 404);
    }
    
    console.log(`✅ Consultation found in Supabase: ID=${id}, Phone=${consultation.phone}`);
    
    // Update consultation in Supabase
    const updateData: any = {
      consultation_result,
      status: 'completed',
    };
    
    const { data, error } = await supabase
      .from('consultations')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error("❌ Error updating consultation:", error);
      return c.json({ error: "Failed to update consultation", details: error.message }, 500);
    }
    
    console.log(`✅ Consultation updated successfully in Supabase: ID=${id}`);
    
    // ⭐ ارسال پیامک با استفاده از consultation_sms service (non-blocking)
    if (consultation.phone) {
      console.log(`📤 Queueing consultation result SMS to ${consultation.phone}...`);
      try {
        consultationSMS.sendConsultationResult(consultation.phone, id);
        console.log(`✅ SMS queued successfully`);
      } catch (smsError) {
        console.error("⚠️ Error queueing SMS (non-critical):", smsError);
        // Don't fail the request if SMS queueing fails
      }
    } else {
      console.warn("⚠️ No phone number found for consultation");
    }
    
    return c.json({ success: true, consultation: data });
  } catch (error) {
    console.error("❌ Unexpected error updating consultation:", error);
    return c.json({ 
      error: "Failed to update consultation", 
      details: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

export default consultationRoutes;