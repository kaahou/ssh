// Consultation SMS Queue Handler
// این تابع برای ارسال پیامک‌های سیستم مشاوره است و در background اجرا می‌شود

interface SMSQueueItem {
  phone: string;
  message: string;
  timestamp: number;
}

// صف پیامک‌های منتظر ارسال
const smsQueue: SMSQueueItem[] = [];
let isProcessing = false;

/**
 * اضافه کردن پیامک به صف ارسال
 */
export function queueConsultationSMS(phone: string, message: string) {
  console.log(`📨 Adding SMS to queue for ${phone}`);
  smsQueue.push({
    phone,
    message,
    timestamp: Date.now(),
  });

  // شروع پردازش صف اگر در حال اجرا نیست (non-blocking)
  if (!isProcessing) {
    processQueue().catch((error) => {
      console.error("❌ Error processing SMS queue:", error);
    });
  }
}

/**
 * پردازش صف پیامک‌ها
 */
async function processQueue() {
  if (isProcessing || smsQueue.length === 0) {
    return;
  }

  isProcessing = true;

  while (smsQueue.length > 0) {
    const item = smsQueue.shift();
    if (!item) break;

    try {
      await sendConsultationSMS(item.phone, item.message);
      // تاخیر 500ms بین ارسال پیامک‌ها
      await new Promise((resolve) => setTimeout(resolve, 500));
    } catch (error) {
      console.error(`❌ Failed to send SMS to ${item.phone}:`, error);
      // در صورت خطا، پیامک را دوباره به انتهای صف اضافه نمی‌کنیم
      // چون نمی‌خواهیم پیامک تکراری ارسال شود
    }
  }

  isProcessing = false;
}

/**
 * ارسال پیامک مشاوره (از همان credentials استفاده می‌کند)
 */
async function sendConsultationSMS(
  phone: string,
  message: string
): Promise<boolean> {
  const username = Deno.env.get("NIAZPARDAZ_USERNAME");
  const password = Deno.env.get("NIAZPARDAZ_PASSWORD");
  const fromNumber = Deno.env.get("NIAZPARDAZ_FROM_NUMBER");

  if (!username || !password || !fromNumber) {
    console.error("❌ Niazpardaz credentials not configured");
    return false;
  }

  console.log(`📤 Sending consultation SMS to ${phone}...`);

  try {
    // روش 1: POST
    let smsResponse = await fetch(
      "https://panel.niazpardaz-sms.com/SMSInOutBox/Send",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          UserName: username,
          Password: password,
          From: fromNumber,
          To: phone,
          Message: message,
        }),
      }
    );

    // روش 2: GET (fallback)
    if (!smsResponse.ok && smsResponse.status !== 200) {
      console.log("⚠️ POST method failed, trying GET...");
      const smsUrl = `https://panel.niazpardaz-sms.com/SMSInOutBox/SendSms?username=${encodeURIComponent(
        username
      )}&password=${encodeURIComponent(
        password
      )}&from=${encodeURIComponent(fromNumber)}&to=${encodeURIComponent(
        phone
      )}&text=${encodeURIComponent(message)}`;
      smsResponse = await fetch(smsUrl);
    }

    if (smsResponse.ok || smsResponse.status === 200) {
      console.log(`✅ Consultation SMS sent successfully to ${phone}`);
      return true;
    } else {
      const responseText = await smsResponse.text();
      console.error(
        `❌ SMS API error: ${smsResponse.status} - ${responseText}`
      );
      return false;
    }
  } catch (error) {
    console.error(`❌ Error sending consultation SMS:`, error);
    return false;
  }
}

/**
 * ارسال پیامک تایید ثبت مشاوره
 */
export function sendConsultationConfirmation(
  phone: string,
  consultationId: number | string
) {
  const message = `مشاوره شما در نورسا با موفقیت ثبت شد.\nکد پیگیری: ${consultationId}\nنتیجه مشاوره حداکثر ظرف 24 ساعت برای شما ارسال می‌شود.`;
  queueConsultationSMS(phone, message);
}

/**
 * ارسال پیامک نتیجه مشاوره
 */
export function sendConsultationResult(phone: string, consultationId: number | string) {
  const message = `نورسا - نتیجه مشاوره شما آماده شد. لطفا برای مشاهده جزئیات به پروفایل خود مراجعه کنید. nursaa.ir`;
  queueConsultationSMS(phone, message);
}