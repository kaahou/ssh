import { Hono } from "npm:hono";
import { supabase } from "./db.ts";
import * as kv from "./kv_store.tsx";

const productRoutes = new Hono();

// IMPORTANT: Specific routes must come BEFORE parameterized routes
// Get featured products - MUST be before /products/:id
productRoutes.get("/products/featured", async (c) => {
  try {
    console.log("📦 Fetching featured products - TOP 8 by SCORE only...");
    
    // Fetch ALL products first (we need to sort in JavaScript since score might be NULL)
    const { data: allProducts, error } = await supabase
      .from('products')
      .select('id,product_name,variant_name,slug,price,old_price,category_id,image_urls,short_description,score,created_at');
    
    if (error) {
      console.error("Supabase error fetching products:", error);
      
      // Fallback to KV store
      try {
        const kvProducts = await kv.getByPrefix("product:");
        const limitedProducts = kvProducts.slice(0, 8);
        console.log(`✅ Returned ${limitedProducts.length} products from KV store (fallback)`);
        return c.json({ products: limitedProducts || [] });
      } catch (kvError) {
        console.error("KV fallback failed:", kvError);
        return c.json({ products: [] });
      }
    }
    
    if (!allProducts || allProducts.length === 0) {
      console.log("⚠️ No products found in database");
      return c.json({ products: [] });
    }
    
    // Sort in JavaScript: products with score > 0 first (by score DESC), then others
    const sortedProducts = [...allProducts].sort((a, b) => {
      const scoreA = a.score ?? 0;
      const scoreB = b.score ?? 0;
      
      // Both have scores > 0, sort by score descending
      if (scoreA > 0 && scoreB > 0) {
        return scoreB - scoreA;
      }
      
      // A has score, B doesn't - A comes first
      if (scoreA > 0 && scoreB === 0) {
        return -1;
      }
      
      // B has score, A doesn't - B comes first
      if (scoreA === 0 && scoreB > 0) {
        return 1;
      }
      
      // Both have no score, sort by created_at descending (newest first)
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });
    
    // Take top 8
    const topProducts = sortedProducts.slice(0, 8);
    
    // Map 'id' to 'product_id' for frontend compatibility
    const mappedProducts = topProducts.map(p => ({
      ...p,
      product_id: p.id,
      stock: 100 // مقدار پیش‌فرض
    }));
    
    // 🔍 لاگ برای دیباگ
    const productsWithScore = topProducts.filter(p => (p.score ?? 0) > 0);
    console.log(`✅ Returned ${mappedProducts.length} featured products`);
    console.log(`📊 Total products in DB: ${allProducts.length}`);
    console.log(`📊 Products with score > 0: ${productsWithScore.length}`);
    console.log("📊 Top 8 products with their scores:");
    mappedProducts.forEach((p, idx) => {
      console.log(`  ${idx + 1}. ${p.product_name} - Score: ${p.score ?? 0}`);
    });
    
    return c.json({ products: mappedProducts });
  } catch (error) {
    console.error("Exception in /products/featured endpoint:", error);
    
    // Ultimate fallback: try KV store
    try {
      const kvProducts = await kv.getByPrefix("product:");
      const limitedProducts = kvProducts.slice(0, 8);
      console.log(`✅ Returned ${limitedProducts.length} products from KV store (exception fallback)`);
      return c.json({ products: limitedProducts || [] });
    } catch (kvError) {
      console.error("KV fallback also failed:", kvError);
      return c.json({ products: [] });
    }
  }
});

// Get all products
productRoutes.get("/products", async (c) => {
  try {
    console.log("📦 Fetching all products...");
    
    // انتخاب فقط فیلدهای ضروری که مطمئناً در دیتابیس وجود دارند
    // حذف stock و category چون در دیتابیس وجود ندارند (فقط category_id هست)
    const selectFields = 'id,product_name,variant_name,slug,price,old_price,category_id,image_urls,short_description,score,created_at';
    
    // استراتژی جدید: دریافت به صورت Chunked برای جلوگیری از timeout
    const BATCH_SIZE = 100; // دریافت به صورت دسته‌ای
    let allProducts = [];
    let offset = 0;
    let hasMore = true;
    
    while (hasMore && allProducts.length < 1000) { // حداکثر 1000 محصول
      const { data: batch, error } = await supabase
        .from('products')
        .select(selectFields)
        .order('score', { ascending: false, nullsLast: true })
        .order('created_at', { ascending: false })
        .range(offset, offset + BATCH_SIZE - 1);
      
      if (error) {
        console.error("Supabase error fetching products batch:", error);
        console.error("Error code:", error.code);
        console.error("Error message:", error.message);
        
        // If score column doesn't exist, fallback to created_at only
        if (error.message?.includes('score') || error.code === '42703') {
          console.log("⚠️ Score column not found, falling back to created_at sorting...");
          const { data: fallbackBatch, error: fallbackError } = await supabase
            .from('products')
            .select(selectFields.replace(',score', ''))
            .order('created_at', { ascending: false })
            .range(offset, offset + BATCH_SIZE - 1);
          
          if (!fallbackError && fallbackBatch) {
            if (fallbackBatch.length === 0) {
              hasMore = false;
              break;
            }
            allProducts = allProducts.concat(fallbackBatch);
            offset += BATCH_SIZE;
            continue;
          }
        }
        
        // اگر ستون دیگری هم نبود، فیلدهای کمتری را امتحان کنید
        if (error.code === '42703') {
          console.log(`⚠️ Column error detected: ${error.message}, trying minimal fields...`);
          const { data: minimalBatch, error: minimalError } = await supabase
            .from('products')
            .select('id,product_name,slug,price')
            .order('created_at', { ascending: false })
            .range(offset, offset + BATCH_SIZE - 1);
          
          if (!minimalError && minimalBatch) {
            if (minimalBatch.length === 0) {
              hasMore = false;
              break;
            }
            // اضافه کردن فیلدهای پیش‌فرض برای سازگاری
            const enrichedBatch = minimalBatch.map(p => ({
              ...p,
              stock: 100,
              image_urls: null,
              variant_name: null,
              old_price: null,
              category_id: null,
              short_description: null
            }));
            allProducts = allProducts.concat(enrichedBatch);
            offset += BATCH_SIZE;
            continue;
          }
        }
        
        // If table doesn't exist, try KV store as fallback
        if (error.message?.includes('relation') || error.code === '42P01') {
          try {
            const kvProducts = await kv.getByPrefix("product:");
            console.log(`✅ Returned ${kvProducts.length} products from KV store`);
            return c.json({ products: kvProducts || [] });
          } catch (kvError) {
            console.error("KV fallback failed:", kvError);
            return c.json({ products: [] });
          }
        }
        
        // If any batch fails completely, return what we have so far
        console.log(`⚠️ Stopping batch fetch at offset ${offset}, returning ${allProducts.length} products`);
        break;
      }
      
      if (!batch || batch.length === 0) {
        hasMore = false;
        break;
      }
      
      allProducts = allProducts.concat(batch);
      offset += BATCH_SIZE;
      
      // اگر کمتر از BATCH_SIZE محصول برگشت، یعنی به آخر رسیدیم
      if (batch.length < BATCH_SIZE) {
        hasMore = false;
      }
    }
    
    // Map 'id' to 'product_id' for frontend compatibility and add default stock
    const mappedProducts = allProducts.map(p => ({
      ...p,
      product_id: p.id,
      stock: p.stock ?? 100 // اضافه کردن stock پیش‌فرض اگر نبود
    }));
    
    console.log(`✅ Returned ${mappedProducts.length} products`);
    return c.json({ products: mappedProducts });
  } catch (error) {
    console.error("Exception in /products endpoint:", error);
    
    // Ultimate fallback: try KV store
    try {
      const kvProducts = await kv.getByPrefix("product:");
      return c.json({ products: kvProducts || [] });
    } catch (kvError) {
      console.error("KV fallback also failed:", kvError);
      return c.json({ products: [] });
    }
  }
});

// Get product by ID - MUST be after specific routes like /products/featured
productRoutes.get("/products/:id", async (c) => {
  try {
    const id = c.req.param("id");
    
    // انتخاب فقط فیلدهای ضروری که مطمئناً در دیتابیس وجود دارند
    const selectFields = 'id,product_name,variant_name,slug,price,old_price,category_id,image_urls,short_description,full_description,score,created_at';
    
    const { data: product, error } = await supabase
      .from('products')
      .select(selectFields)
      .eq('id', id)
      .single();
    
    if (error) {
      console.error("Supabase error fetching product:", error);
      return c.json({ error: "Product not found" }, 404);
    }
    
    if (!product) {
      return c.json({ error: "Product not found" }, 404);
    }
    
    // Map 'id' to 'product_id' for frontend compatibility
    const mappedProduct = {
      ...product,
      product_id: product.id,
      stock: 100 // مقدار پیش‌فرض
    };
    
    return c.json({ product: mappedProduct });
  } catch (error) {
    console.error("Error fetching product:", error);
    return c.json({ error: "Failed to fetch product" }, 500);
  }
});

// Create product
productRoutes.post("/products", async (c) => {
  try {
    const body = await c.req.json();
    console.log("📦 Creating new product with body:", JSON.stringify(body, null, 2));

    // Basic validation
    if (!body.product_name || !body.price) {
      console.log("❌ Validation failed: missing product_name or price");
      return c.json({ error: "Product name and price are required" }, 400);
    }

    // Get next ID from sequence or generate manually
    // First, try to get the max ID
    const { data: maxIdResult, error: maxIdError } = await supabase
      .from('products')
      .select('id')
      .order('id', { ascending: false })
      .limit(1);

    let nextId = 1;
    if (!maxIdError && maxIdResult && maxIdResult.length > 0) {
      nextId = maxIdResult[0].id + 1;
      console.log(`📊 Next ID will be: ${nextId}`);
    } else {
      console.log("📊 No existing products, starting with ID 1");
    }

    // Prepare the product data with ID
    const productData = {
      ...body,
      id: nextId,
      created_at: new Date().toISOString(),
      // Map old_price if original_price was sent
      old_price: body.original_price || body.old_price || null,
      // Map image_url to image_urls if needed
      image_urls: body.image_urls || body.image_url || null,
    };

    // Remove fields that don't exist in schema
    delete productData.original_price;
    delete productData.image_url;

    console.log("✅ Validation passed, inserting into database with data:", JSON.stringify(productData, null, 2));
    
    const { data: product, error } = await supabase
      .from('products')
      .insert(productData)
      .select()
      .single();

    if (error) {
      console.error("❌ Supabase error creating product:", error);
      console.error("Error code:", error.code);
      console.error("Error message:", error.message);
      console.error("Error details:", error.details);
      console.error("Error hint:", error.hint);
      return c.json({ 
        error: "Failed to create product", 
        details: error.message,
        hint: error.hint,
        code: error.code 
      }, 500);
    }

    console.log("✅ Product created successfully:", product);
    return c.json({ success: true, product });
  } catch (error) {
    console.error("❌ Exception in create product endpoint:", error);
    return c.json({ 
      error: "Failed to create product",
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
});

// Update product
productRoutes.put("/products/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const body = await c.req.json();
    console.log(`📝 Updating product ${id} with data:`, JSON.stringify(body, null, 2));

    // Simple update - let Supabase handle schema validation
    const { data: product, error } = await supabase
      .from('products')
      .update(body)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error("❌ Supabase error updating product:", error);
      console.error("❌ Error code:", error.code);
      console.error("❌ Error message:", error.message);
      console.error("❌ Error details:", error.details);
      return c.json({ 
        error: "Failed to update product", 
        details: error.message,
        code: error.code 
      }, 500);
    }

    console.log("✅ Product updated successfully:", product);
    return c.json({ success: true, product });
  } catch (error) {
    console.error("❌ Error updating product:", error);
    return c.json({ 
      error: "Failed to update product", 
      details: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

// Delete product
productRoutes.delete("/products/:id", async (c) => {
  try {
    const id = c.req.param("id");
    console.log(`Deleting product ${id}...`);

    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);

    if (error) {
      console.error("Supabase error deleting product:", error);
      return c.json({ error: "Failed to delete product", details: error.message }, 500);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting product:", error);
    return c.json({ error: "Failed to delete product" }, 500);
  }
});

export default productRoutes;