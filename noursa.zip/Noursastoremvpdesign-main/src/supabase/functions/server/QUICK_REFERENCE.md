# 🚀 مرجع سریع - Backend Nursaa

## 📋 فهرست سریع

| بخش | فایل | توضیح مختصر |
|-----|------|-------------|
| 🎯 Entry Point | `index.tsx` | نقطه شروع سرور |
| 🗄️ Database | `db.ts` | Supabase client |
| 🔑 Types | `types.ts` | همه type definitions |
| ⚙️ Constants | `constants.ts` | ثابت‌های برنامه |
| 🛡️ Validators | `validators.ts` | اعتبارسنجی ورودی‌ها |
| 🎨 Formatters | `formatters.ts` | فرمت‌دهی داده‌ها |
| 🚦 Middleware | `middleware.ts` | Middleware های مشترک |

## 🔍 جستجوی سریع Function

### Products
```typescript
// در product_service.ts:
getProducts({ page, limit, categoryId, search })
getFeaturedProducts(limit)
getProductBySlug(slug)
getProductById(id)
createProduct(data)
updateProduct(id, data)
deleteProduct(id)
updateProductStock(id, quantity, 'add'|'subtract'|'set')
getRelatedProducts(productId, limit)
```

### Orders
```typescript
// در order_service.ts:
createOrder(orderData)
getOrderById(orderId)
getOrders({ page, limit, status, paymentStatus })
updateOrderPaymentStatus(orderId, status, paymentInfo)
updateOrderStatus(orderId, status)
getOrderStats()
```

### Consultations
```typescript
// در consultation_service.ts:
storeOTP(phone, code)
verifyOTP(phone, code)
getOrCreateUser(phone, firstName, lastName)
createConsultation(phone, formData)
getConsultationById(id)
getConsultationsByPhone(phone)
getConsultations({ page, limit, status })
updateConsultationResult(id, result, status)
updateConsultationStatus(id, status)
```

### Storage
```typescript
// در storage_service.ts:
ensureBucketExists(bucketName, isPublic)
initializeStorageBuckets()
uploadFile(bucket, path, data, contentType)
uploadBase64Image(bucket, base64, fileName)
uploadMultipleBase64Images(bucket, images)
getSignedUrl(bucket, path, expiresIn)
deleteFile(bucket, path)
```

### Validators
```typescript
// در validators.ts:
isValidPhone(phone)
isValidEmail(email)
isValidNationalCode(code)
validateOrderRequest(data)
validateConsultationData(data)
validateProductData(data)
isValidSlug(slug)
isValidPostalCode(code)
isValidAmount(amount)
```

### Formatters
```typescript
// در formatters.ts:
formatPrice(price)
formatPhoneDisplay(phone)
parseShippingInfo(data)
parsePaymentInfo(data)
isOrderPaid(order)
getTodayRange()
getThisMonthRange()
formatPaginationParams(page, limit)
splitFullName(name)
safeJsonParse(json, defaultValue)
```

## 🎯 الگوهای متداول

### 1. ساخت Route جدید
```typescript
// my_feature_routes.ts
import { Hono } from "npm:hono";
import { myFeatureService } from "./my_feature_service.ts";

const routes = new Hono();

routes.get("/my-feature", async (c) => {
  const result = await myFeatureService();
  return c.json(result);
});

export default routes;
```

### 2. ساخت Service جدید
```typescript
// my_feature_service.ts
import { supabase } from './db.ts';
import { ERROR_MESSAGES } from './constants.ts';

export async function myFeatureService() {
  try {
    const { data, error } = await supabase
      .from('my_table')
      .select('*');
    
    if (error) {
      return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
    }
    
    return { success: true, data };
  } catch (error) {
    console.error("❌ Error:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}
```

### 3. استفاده از Middleware
```typescript
import { requireAdmin, requireAuth } from './middleware.ts';

// Admin only
routes.get("/admin/data", requireAdmin, async (c) => {
  const phone = c.get('userPhone');
  // ...
});

// Authenticated users
routes.get("/profile", requireAuth, async (c) => {
  const userId = c.get('userId');
  // ...
});
```

### 4. Validation در Route
```typescript
import { validateOrderRequest } from './validators.ts';

routes.post("/orders", async (c) => {
  const body = await c.req.json();
  
  // Validate
  const validation = validateOrderRequest(body);
  if (!validation.valid) {
    return c.json({ error: validation.error }, 400);
  }
  
  // Process
  const result = await createOrder(body);
  return c.json(result);
});
```

## 📊 Constants سریع

```typescript
// از constants.ts
ADMIN_PHONE                // '09219675992'
FIXED_SHIPPING_COST        // 80000
OTP_EXPIRY_MS             // 600000 (10 min)
DEFAULT_PAGE_SIZE         // 12
ERROR_MESSAGES.UNAUTHORIZED
ERROR_MESSAGES.NOT_FOUND
SUCCESS_MESSAGES.ORDER_CREATED
STORAGE_BUCKETS.CONSULTATIONS
PAYMENT_STATUSES.PAID_ZARINPAL
```

## 🔧 Types سریع

```typescript
// از types.ts
Product
Category
Order
OrderItem
ShippingInfo
PaymentInfo
PaymentStatus
Consultation
ConsultationFormData
User
Article
ApiResponse<T>
PaginatedResponse<T>
ZarinpalRequest
ZarinpalVerify
AdminStats
```

## 📝 Response Pattern

```typescript
// Success Response
{
  success: true,
  data: {...},
  message?: "عملیات موفق"
}

// Error Response
{
  success: false,
  error: "پیام خطا"
}

// Paginated Response
{
  success: true,
  data: [...],
  total: 100,
  page: 1,
  limit: 12
}
```

## 🚨 خطاهای متداول و راه‌حل

### 1. Import Error
```typescript
// ❌ اشتباه
import { something } from './file'

// ✅ درست
import { something } from './file.ts'
```

### 2. Type Error
```typescript
// ❌ اشتباه
const result = await getProducts()

// ✅ درست
import type { Product } from './types.ts'
const result: { success: boolean; products?: Product[] } = await getProducts()
```

### 3. Validation Missing
```typescript
// ❌ اشتباه - بدون validation
const order = await createOrder(body);

// ✅ درست - با validation
const validation = validateOrderRequest(body);
if (!validation.valid) {
  return c.json({ error: validation.error }, 400);
}
const order = await createOrder(body);
```

## 🎨 Code Style

### Logging
```typescript
console.log("✅ Success:", data);
console.error("❌ Error:", error);
console.log("📦 Product:", product);
console.log("🔍 Debug:", info);
console.log("⚠️ Warning:", warning);
```

### Error Handling
```typescript
try {
  // Operation
} catch (error) {
  console.error("❌ Exception in functionName:", error);
  return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
}
```

### Function Naming
```typescript
// ✅ Good
getProducts()        // دریافت
createProduct()      // ایجاد
updateProduct()      // بروزرسانی
deleteProduct()      // حذف
validateProduct()    // اعتبارسنجی
formatProduct()      // فرمت‌دهی

// ❌ Bad
fetchProducts()      // از get استفاده کنید
saveProduct()        // از create یا update استفاده کنید
```

## 📚 منابع

- **[ARCHITECTURE.md](./ARCHITECTURE.md)** - معماری کامل
- **[API_GUIDE.md](./API_GUIDE.md)** - راهنمای API
- **[CHANGELOG.md](./CHANGELOG.md)** - تاریخچه تغییرات

## 🔗 لینک‌های مفید

### Supabase Queries
```typescript
// Select
const { data, error } = await supabase
  .from('table')
  .select('*')
  .eq('id', 123)
  .single();

// Insert
const { data, error } = await supabase
  .from('table')
  .insert({ ... })
  .select()
  .single();

// Update
const { error } = await supabase
  .from('table')
  .update({ ... })
  .eq('id', 123);

// Delete
const { error } = await supabase
  .from('table')
  .delete()
  .eq('id', 123);

// Pagination
const { data, count } = await supabase
  .from('table')
  .select('*', { count: 'exact' })
  .range(offset, offset + limit - 1);
```

### Storage Operations
```typescript
// Upload
await supabase.storage
  .from('bucket')
  .upload('path', file);

// Get Signed URL
await supabase.storage
  .from('bucket')
  .createSignedUrl('path', expiresIn);

// Delete
await supabase.storage
  .from('bucket')
  .remove(['path']);
```

## 💡 نکات سریع

1. **همیشه** از service layer استفاده کنید
2. **همیشه** ورودی‌ها را validate کنید
3. **همیشه** از constants استفاده کنید
4. **همیشه** error handling داشته باشید
5. **همیشه** log مناسب بگذارید
6. **همیشه** TypeScript types استفاده کنید
7. **همیشه** کد را DRY نگه دارید

---

**نکته**: این فایل یک مرجع سریع است. برای جزئیات بیشتر به فایل‌های مستندات کامل مراجعه کنید.
