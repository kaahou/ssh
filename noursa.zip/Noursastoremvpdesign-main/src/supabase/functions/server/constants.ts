// Application Constants

// ==================== Admin Security ====================
export const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
];

// ==================== Payment Constants ====================
export const FIXED_SHIPPING_COST = 80000; // تومان

export const PAYMENT_METHODS = {
  ZARINPAL: 'zarinpal',
  CARD: 'card',
  MANUAL: 'manual',
} as const;

export const PAYMENT_STATUSES = {
  PENDING: 'pending',
  PAID_ZARINPAL: 'paid_zarinpal',
  PAID_CARD: 'paid_card',
  PAID_MANUAL: 'paid_manual',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
} as const;

// ==================== OTP Constants ====================
export const OTP_EXPIRY_MS = 10 * 60 * 1000; // 10 minutes
export const OTP_LENGTH = 6;

// ==================== SMS Queue Constants ====================
export const SMS_QUEUE_DELAY_MS = 500; // تاخیر بین ارسال پیامک‌ها

// ==================== Storage Constants ====================
export const STORAGE_BUCKETS = {
  CONSULTATIONS: 'make-fbc72c25-consultations',
  CONSULTATION_PHOTOS: 'make-fbc72c25-consultation-photos',
  PRODUCTS: 'make-fbc72c25-products',
  ARTICLES: 'make-fbc72c25-articles',
} as const;

// ==================== Pagination Constants ====================
export const DEFAULT_PAGE_SIZE = 12;
export const MAX_PAGE_SIZE = 100;

// ==================== Order Status ====================
export const ORDER_STATUSES = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  SHIPPED: 'shipped',
  DELIVERED: 'delivered',
  CANCELLED: 'cancelled',
} as const;

// ==================== Consultation Status ====================
export const CONSULTATION_STATUSES = {
  PENDING: 'pending',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
} as const;

// ==================== Error Messages ====================
export const ERROR_MESSAGES = {
  UNAUTHORIZED: 'دسترسی غیرمجاز',
  NOT_FOUND: 'یافت نشد',
  INVALID_INPUT: 'اطلاعات نامعتبر است',
  SERVER_ERROR: 'خطای سرور',
  EMPTY_CART: 'سبد خرید خالی است',
  OTP_EXPIRED: 'کد تایید منقضی شده است',
  OTP_INVALID: 'کد تایید اشتباه است',
  PAYMENT_FAILED: 'پرداخت ناموفق بود',
  INCOMPLETE_DATA: 'اطلاعات ناقص است',
} as const;

// ==================== Success Messages ====================
export const SUCCESS_MESSAGES = {
  ORDER_CREATED: 'سفارش با موفقیت ثبت شد',
  PAYMENT_SUCCESS: 'پرداخت با موفقیت انجام شد',
  CONSULTATION_SUBMITTED: 'مشاوره با موفقیت ثبت شد',
  OTP_SENT: 'کد تایید ارسال شد',
  PRODUCT_CREATED: 'محصول با موفقیت ایجاد شد',
  PRODUCT_UPDATED: 'محصول با موفقیت بروزرسانی شد',
  PRODUCT_DELETED: 'محصول با موفقیت حذف شد',
} as const;

// ==================== Route Prefixes ====================
export const ROUTE_PREFIX = '/make-server-fbc72c25';

// ==================== Environment Variables ====================
export const ENV_VARS = {
  SUPABASE_URL: 'SUPABASE_URL',
  SUPABASE_SERVICE_ROLE_KEY: 'SUPABASE_SERVICE_ROLE_KEY',
  ZARINPAL_MERCHANT_ID: 'ZARINPAL_MERCHANT_ID',
  NIAZPARDAZ_USERNAME: 'NIAZPARDAZ_USERNAME',
  NIAZPARDAZ_PASSWORD: 'NIAZPARDAZ_PASSWORD',
  NIAZPARDAZ_FROM_NUMBER: 'NIAZPARDAZ_FROM_NUMBER',
} as const;