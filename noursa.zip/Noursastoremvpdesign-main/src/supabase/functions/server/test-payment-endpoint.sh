#!/bin/bash

# Test script for payment status endpoint
# Usage: ./test-payment-endpoint.sh [order_id] [action]

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Default values (replace with your actual values)
PROJECT_ID="your-project-id"
ORDER_ID="${1:-test-order-id}"
ACTION="${2:-approve}"  # approve or reject

# Supabase endpoint
ENDPOINT="https://${PROJECT_ID}.supabase.co/functions/v1/make-server-fbc72c25/admin/orders/${ORDER_ID}/payment-status"

echo -e "${YELLOW}Testing Payment Status Endpoint${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "Endpoint: ${GREEN}${ENDPOINT}${NC}"
echo -e "Order ID: ${GREEN}${ORDER_ID}${NC}"
echo -e "Action: ${GREEN}${ACTION}${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Test 1: OPTIONS request (CORS preflight)
echo -e "${YELLOW}Test 1: OPTIONS Request (CORS Preflight)${NC}"
RESPONSE=$(curl -s -w "\n%{http_code}" -X OPTIONS "$ENDPOINT" \
  -H "Content-Type: application/json" \
  -H "Origin: http://localhost:5173")

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | head -n-1)

if [ "$HTTP_CODE" == "200" ]; then
  echo -e "${GREEN}✅ CORS Preflight Success${NC}"
  echo "Response: $BODY"
else
  echo -e "${RED}❌ CORS Preflight Failed (HTTP $HTTP_CODE)${NC}"
  echo "Response: $BODY"
fi
echo ""

# Test 2: POST request with valid action
echo -e "${YELLOW}Test 2: POST Request with Action: ${ACTION}${NC}"
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "$ENDPOINT" \
  -H "Content-Type: application/json" \
  -d "{\"action\": \"${ACTION}\"}")

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | head -n-1)

echo "HTTP Code: $HTTP_CODE"
echo "Response Body:"
echo "$BODY" | python3 -m json.tool 2>/dev/null || echo "$BODY"

if [ "$HTTP_CODE" == "200" ]; then
  echo -e "${GREEN}✅ Payment Status Update Success${NC}"
elif [ "$HTTP_CODE" == "404" ]; then
  echo -e "${YELLOW}⚠️  Order Not Found (Expected if test order)${NC}"
elif [ "$HTTP_CODE" == "400" ]; then
  echo -e "${RED}❌ Bad Request${NC}"
else
  echo -e "${RED}❌ Request Failed${NC}"
fi
echo ""

# Test 3: POST request with invalid action
echo -e "${YELLOW}Test 3: POST Request with Invalid Action${NC}"
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "$ENDPOINT" \
  -H "Content-Type: application/json" \
  -d '{"action": "invalid"}')

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | head -n-1)

if [ "$HTTP_CODE" == "400" ]; then
  echo -e "${GREEN}✅ Validation Working - Rejected Invalid Action${NC}"
  echo "Response: $BODY"
else
  echo -e "${RED}❌ Validation Not Working (Expected 400, Got $HTTP_CODE)${NC}"
  echo "Response: $BODY"
fi
echo ""

# Test 4: POST request with missing body
echo -e "${YELLOW}Test 4: POST Request with Missing Body${NC}"
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "$ENDPOINT" \
  -H "Content-Type: application/json")

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | head -n-1)

if [ "$HTTP_CODE" == "400" ]; then
  echo -e "${GREEN}✅ Body Validation Working${NC}"
  echo "Response: $BODY"
else
  echo -e "${RED}❌ Body Validation Not Working (Expected 400, Got $HTTP_CODE)${NC}"
  echo "Response: $BODY"
fi
echo ""

# Summary
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${YELLOW}Test Summary${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ اگر همه تست‌ها موفق بودند، endpoint به درستی کار می‌کند"
echo "❌ اگر خطای 'connection closed' دیدید، مستندات CONNECTION_FIX.md را بخوانید"
echo ""
echo -e "${YELLOW}نکات مهم:${NC}"
echo "1. PROJECT_ID را در اول اسکریپت تنظیم کنید"
echo "2. برای تست با order واقعی، ID سفارش را به عنوان آرگومان اول بدهید"
echo "3. لاگ‌های سرور را در Supabase Dashboard > Functions > Logs چک کنید"
echo ""
