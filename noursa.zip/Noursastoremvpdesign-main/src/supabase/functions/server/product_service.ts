// Product Business Logic Service

import { supabase } from './db.ts';
import * as kv from './kv_store.tsx';
import type { Product } from './types.ts';
import { ERROR_MESSAGES } from './constants.ts';
import { validateProductData } from './validators.ts';
import { formatProductForResponse, formatProductsForResponse } from './formatters.ts';

// ==================== Product Retrieval ====================
/**
 * Get all products with optional filtering and pagination
 */
export async function getProducts(options: {
  page?: number;
  limit?: number;
  categoryId?: number;
  search?: string;
}): Promise<{ success: boolean; products?: Product[]; total?: number; error?: string }> {
  try {
    console.log("📦 Fetching products from Postgres database...");
    
    const { page = 1, limit = 12, categoryId, search } = options;
    const offset = (page - 1) * limit;
    
    // First try with score ordering
    let query = supabase
      .from('products')
      .select('*', { count: 'exact' })
      .order('score', { ascending: false, nullsLast: true })
      .order('created_at', { ascending: false });
    
    // Apply filters
    if (categoryId) {
      query = query.eq('category_id', categoryId);
    }
    
    if (search) {
      // Fixed: Use correct column names (product_name, short_description)
      query = query.or(`product_name.ilike.%${search}%,short_description.ilike.%${search}%`);
    }
    
    // Apply pagination
    query = query.range(offset, offset + limit - 1);
    
    const { data: products, error, count } = await query;
    
    if (error) {
      console.error("❌ Supabase error fetching products:", error);
      
      // If score column doesn't exist, retry without score
      if (error.message?.includes('score') || error.code === '42703') {
        console.log("⚠️ Score column not found, retrying without score ordering...");
        
        let fallbackQuery = supabase
          .from('products')
          .select('*', { count: 'exact' })
          .order('created_at', { ascending: false });
        
        if (categoryId) {
          fallbackQuery = fallbackQuery.eq('category_id', categoryId);
        }
        
        if (search) {
          fallbackQuery = fallbackQuery.or(`name.ilike.%${search}%,description.ilike.%${search}%`);
        }
        
        fallbackQuery = fallbackQuery.range(offset, offset + limit - 1);
        
        const { data: fallbackProducts, error: fallbackError, count: fallbackCount } = await fallbackQuery;
        
        if (!fallbackError && fallbackProducts) {
          const mappedProducts = formatProductsForResponse(fallbackProducts || []);
          console.log(`✅ Found ${mappedProducts.length} products (fallback)`);
          return { 
            success: true, 
            products: mappedProducts, 
            total: fallbackCount || 0 
          };
        }
      }
      
      // If table doesn't exist, try KV store as fallback
      if (error.message?.includes('relation') || error.code === '42P01') {
        console.log("🔄 Products table not found, using KV store fallback...");
        
        try {
          const kvProducts = await kv.getByPrefix("product:");
          console.log(`✅ Found ${kvProducts.length} products from KV store`);
          return { 
            success: true, 
            products: kvProducts || [], 
            total: kvProducts?.length || 0 
          };
        } catch (kvError) {
          console.error("❌ KV fallback failed:", kvError);
          return { success: true, products: [], total: 0 };
        }
      }
      
      return { success: true, products: [], total: 0 };
    }
    
    const mappedProducts = formatProductsForResponse(products || []);
    
    console.log(`✅ Found ${mappedProducts.length} products from database`);
    return { 
      success: true, 
      products: mappedProducts, 
      total: count || 0 
    };
  } catch (error) {
    console.error("❌ Exception in getProducts:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Get featured products
 */
export async function getFeaturedProducts(limit: number = 8): Promise<{
  success: boolean;
  products?: Product[];
  error?: string;
}> {
  try {
    console.log(`📦 Fetching ${limit} featured products...`);
    
    // Return products ordered by score (highest first)
    const { data: products, error } = await supabase
      .from('products')
      .select('*')
      .order('score', { ascending: false, nullsLast: true })
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) {
      console.error("❌ Error fetching featured products:", error);
      
      // If score column doesn't exist, retry without score
      if (error.message?.includes('score') || error.code === '42703') {
        console.log("⚠️ Score column not found, retrying without score ordering...");
        
        const { data: fallbackProducts, error: fallbackError } = await supabase
          .from('products')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(limit);
        
        if (!fallbackError && fallbackProducts) {
          const mappedProducts = formatProductsForResponse(fallbackProducts || []);
          console.log(`✅ Found ${mappedProducts.length} featured products (fallback)`);
          return { success: true, products: mappedProducts };
        }
      }
      
      // Try KV fallback
      if (error.message?.includes('relation') || error.code === '42P01') {
        try {
          const kvProducts = await kv.getByPrefix("product:");
          return { 
            success: true, 
            products: kvProducts?.slice(0, limit) || [] 
          };
        } catch (kvError) {
          return { success: true, products: [] };
        }
      }
      
      return { success: true, products: [] };
    }
    
    const mappedProducts = formatProductsForResponse(products || []);
    
    console.log(`✅ Found ${mappedProducts.length} featured products`);
    return { success: true, products: mappedProducts };
  } catch (error) {
    console.error("❌ Exception in getFeaturedProducts:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Get product by slug
 */
export async function getProductBySlug(slug: string): Promise<{
  success: boolean;
  product?: Product;
  error?: string;
}> {
  try {
    console.log(`📦 Fetching product with slug: ${slug}`);
    
    const { data: product, error } = await supabase
      .from('products')
      .select('*')
      .eq('slug', slug)
      .single();
    
    if (error) {
      console.error("❌ Error fetching product by slug:", error);
      
      // Try KV fallback
      if (error.message?.includes('relation') || error.code === '42P01') {
        try {
          const kvProduct = await kv.get(`product:${slug}`);
          return { success: true, product: kvProduct || undefined };
        } catch (kvError) {
          return { success: false, error: ERROR_MESSAGES.NOT_FOUND };
        }
      }
      
      return { success: false, error: ERROR_MESSAGES.NOT_FOUND };
    }
    
    const mappedProduct = formatProductForResponse(product);
    
    console.log(`✅ Found product: ${mappedProduct.product_name || mappedProduct.name || 'Unknown'}`);
    return { success: true, product: mappedProduct };
  } catch (error) {
    console.error("❌ Exception in getProductBySlug:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

/**
 * Get product by ID
 */
export async function getProductById(id: number): Promise<{
  success: boolean;
  product?: Product;
  error?: string;
}> {
  try {
    console.log(`📦 Fetching product ${id} from Postgres database...`);
    
    const { data: product, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error("❌ Error fetching product by id:", error);
      return { success: false, error: ERROR_MESSAGES.NOT_FOUND };
    }
    
    const mappedProduct = formatProductForResponse(product);
    
    console.log(`✅ Found product: ${mappedProduct.product_name || mappedProduct.name || 'Unknown'}`);
    return { success: true, product: mappedProduct };
  } catch (error) {
    console.error("❌ Exception in getProductById:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Product Creation ====================
/**
 * Create a new product
 */
export async function createProduct(productData: Partial<Product>): Promise<{
  success: boolean;
  product?: Product;
  error?: string;
}> {
  try {
    // Validate product data
    const validation = validateProductData(productData);
    if (!validation.valid) {
      return { success: false, error: validation.error };
    }
    
    console.log("📦 Creating new product:", productData.product_name || productData.name || 'Unknown');
    
    const { data: product, error } = await supabase
      .from('products')
      .insert(productData)
      .select()
      .single();
    
    if (error) {
      console.error("❌ Failed to create product:", error);
      return { success: false, error: "خطا در ایجاد محصول" };
    }
    
    const mappedProduct = formatProductForResponse(product);
    
    console.log(`✅ Product created with ID: ${product.id}`);
    return { success: true, product: mappedProduct };
  } catch (error) {
    console.error("❌ Exception in createProduct:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Product Update ====================
/**
 * Update an existing product
 */
export async function updateProduct(
  id: number, 
  productData: Partial<Product>
): Promise<{
  success: boolean;
  product?: Product;
  error?: string;
}> {
  try {
    console.log(`📦 Updating product ${id}`);
    
    // Don't validate all fields for update, only if provided
    // Support both 'name' and 'product_name' for backward compatibility
    const nameField = productData.product_name || productData.name;
    if (nameField || productData.price) {
      const validation = validateProductData({
        product_name: nameField || 'temp',
        name: nameField || 'temp',  // for backward compatibility
        slug: productData.slug || 'temp',
        price: productData.price || 1
      });
      
      if (!validation.valid) {
        return { success: false, error: validation.error };
      }
    }
    
    const { data: product, error } = await supabase
      .from('products')
      .update(productData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error("❌ Failed to update product:", error);
      return { success: false, error: "خطا در بروزرسانی محصول" };
    }
    
    const mappedProduct = formatProductForResponse(product);
    
    console.log(`✅ Product ${id} updated successfully`);
    return { success: true, product: mappedProduct };
  } catch (error) {
    console.error("❌ Exception in updateProduct:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Product Deletion ====================
/**
 * Delete a product
 */
export async function deleteProduct(id: number): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    console.log(`📦 Deleting product ${id}`);
    
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error("❌ Failed to delete product:", error);
      return { success: false, error: "خطا در حذف محصول" };
    }
    
    console.log(`✅ Product ${id} deleted successfully`);
    return { success: true };
  } catch (error) {
    console.error("❌ Exception in deleteProduct:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Product Stock Management ====================
/**
 * Update product stock
 */
export async function updateProductStock(
  id: number,
  quantity: number,
  operation: 'add' | 'subtract' | 'set' = 'set'
): Promise<{
  success: boolean;
  newStock?: number;
  error?: string;
}> {
  try {
    console.log(`📦 Updating stock for product ${id}: ${operation} ${quantity}`);
    
    // Get current stock
    const { data: product, error: fetchError } = await supabase
      .from('products')
      .select('stock')
      .eq('id', id)
      .single();
    
    if (fetchError || !product) {
      return { success: false, error: ERROR_MESSAGES.NOT_FOUND };
    }
    
    let newStock = quantity;
    
    if (operation === 'add') {
      newStock = (product.stock || 0) + quantity;
    } else if (operation === 'subtract') {
      newStock = Math.max(0, (product.stock || 0) - quantity);
    }
    
    // Update stock
    const { error: updateError } = await supabase
      .from('products')
      .update({ 
        stock: newStock
      })
      .eq('id', id);
    
    if (updateError) {
      console.error("❌ Failed to update stock:", updateError);
      return { success: false, error: "خطا در بروزرسانی موجودی" };
    }
    
    console.log(`✅ Stock updated for product ${id}: ${newStock}`);
    return { success: true, newStock };
  } catch (error) {
    console.error("❌ Exception in updateProductStock:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}

// ==================== Related Products ====================
/**
 * Get related products by category
 */
export async function getRelatedProducts(
  productId: number,
  limit: number = 4
): Promise<{
  success: boolean;
  products?: Product[];
  error?: string;
}> {
  try {
    // Get product category
    const { data: product } = await supabase
      .from('products')
      .select('category_id')
      .eq('id', productId)
      .single();
    
    if (!product?.category_id) {
      return { success: true, products: [] };
    }
    
    // Get related products from same category
    const { data: products, error } = await supabase
      .from('products')
      .select('*')
      .eq('category_id', product.category_id)
      .neq('id', productId)
      .order('score', { ascending: false, nullsLast: true })
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) {
      console.error("❌ Error fetching related products:", error);
      
      // If score column doesn't exist, retry without score
      if (error.message?.includes('score') || error.code === '42703') {
        console.log("⚠️ Score column not found for related products, retrying...");
        
        const { data: fallbackProducts, error: fallbackError } = await supabase
          .from('products')
          .select('*')
          .eq('category_id', product.category_id)
          .neq('id', productId)
          .order('created_at', { ascending: false })
          .limit(limit);
        
        if (!fallbackError && fallbackProducts) {
          const mappedProducts = formatProductsForResponse(fallbackProducts || []);
          return { success: true, products: mappedProducts };
        }
      }
      
      return { success: true, products: [] };
    }
    
    const mappedProducts = formatProductsForResponse(products || []);
    
    return { success: true, products: mappedProducts };
  } catch (error) {
    console.error("❌ Exception in getRelatedProducts:", error);
    return { success: false, error: ERROR_MESSAGES.SERVER_ERROR };
  }
}