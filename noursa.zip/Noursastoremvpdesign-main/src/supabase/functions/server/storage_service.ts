// Supabase Storage Service

import { supabase } from './db.ts';
import { STORAGE_BUCKETS } from './constants.ts';

// ==================== Bucket Management ====================
/**
 * Create a storage bucket if it doesn't exist
 */
export async function ensureBucketExists(bucketName: string, isPublic = false): Promise<boolean> {
  try {
    const { data: buckets, error: listError } = await supabase.storage.listBuckets();
    
    if (listError) {
      console.error(`❌ Failed to list buckets:`, listError);
      return false;
    }
    
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (bucketExists) {
      console.log(`✅ Bucket '${bucketName}' already exists`);
      return true;
    }
    
    console.log(`📦 Creating bucket '${bucketName}'...`);
    const { error: createError } = await supabase.storage.createBucket(bucketName, {
      public: isPublic,
      fileSizeLimit: 10485760, // 10MB
      allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/jpg', 'video/mp4', 'video/quicktime'],
    });
    
    if (createError) {
      // If error is 409 (conflict), bucket already exists - treat as success
      if (createError.statusCode === '409' || createError.message?.includes('already exists')) {
        console.log(`✅ [Supabase] Bucket '${bucketName}' already exists (409)`);
        return true;
      }
      
      console.error(`❌ [Supabase] ❌ Failed to create bucket '${bucketName}':`, createError);
      return false;
    }
    
    console.log(`✅ Bucket '${bucketName}' created successfully`);
    return true;
  } catch (error) {
    console.error(`❌ Error ensuring bucket exists:`, error);
    return false;
  }
}

/**
 * Initialize all required buckets
 */
export async function initializeStorageBuckets(): Promise<void> {
  console.log('📦 Initializing storage buckets...');
  
  await ensureBucketExists(STORAGE_BUCKETS.CONSULTATIONS, false);
  await ensureBucketExists(STORAGE_BUCKETS.CONSULTATION_PHOTOS, false);
  await ensureBucketExists(STORAGE_BUCKETS.PRODUCTS, true);
  await ensureBucketExists(STORAGE_BUCKETS.ARTICLES, true);
  
  console.log('✅ Storage buckets initialized');
}

// ==================== File Upload ====================
/**
 * Upload a file to a bucket
 */
export async function uploadFile(
  bucketName: string,
  filePath: string,
  fileData: Uint8Array | Blob,
  contentType: string
): Promise<{ success: boolean; path?: string; error?: string }> {
  try {
    const { data, error } = await supabase.storage
      .from(bucketName)
      .upload(filePath, fileData, {
        contentType,
        upsert: true,
      });
    
    if (error) {
      console.error(`❌ File upload failed:`, error);
      return { success: false, error: error.message };
    }
    
    console.log(`✅ File uploaded: ${data.path}`);
    return { success: true, path: data.path };
  } catch (error) {
    console.error(`❌ File upload exception:`, error);
    return { success: false, error: String(error) };
  }
}

/**
 * Upload base64 image to bucket
 */
export async function uploadBase64Image(
  bucketName: string,
  base64Data: string,
  fileName: string
): Promise<{ success: boolean; path?: string; url?: string; error?: string }> {
  try {
    // Ensure bucket exists
    await ensureBucketExists(bucketName, false);
    
    // Extract content type and data
    const matches = base64Data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return { success: false, error: 'Invalid base64 format' };
    }
    
    const contentType = matches[1];
    const base64Content = matches[2];
    
    // Convert base64 to Uint8Array
    const binaryString = atob(base64Content);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // Generate unique file path
    const timestamp = Date.now();
    const filePath = `${timestamp}-${fileName}`;
    
    // Upload file
    const uploadResult = await uploadFile(bucketName, filePath, bytes, contentType);
    
    if (!uploadResult.success || !uploadResult.path) {
      return uploadResult;
    }
    
    // Get signed URL (valid for 1 year)
    const { data: urlData, error: urlError } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(uploadResult.path, 31536000); // 1 year in seconds
    
    if (urlError || !urlData?.signedUrl) {
      console.error(`❌ Failed to create signed URL:`, urlError);
      return { success: false, error: 'Failed to generate signed URL' };
    }
    
    return {
      success: true,
      path: uploadResult.path,
      url: urlData.signedUrl,
    };
  } catch (error) {
    console.error(`❌ Base64 upload exception:`, error);
    return { success: false, error: String(error) };
  }
}

/**
 * Upload multiple base64 images
 */
export async function uploadMultipleBase64Images(
  bucketName: string,
  base64Images: string[]
): Promise<{ success: boolean; urls?: string[]; errors?: string[] }> {
  const results = await Promise.all(
    base64Images.map((image, index) =>
      uploadBase64Image(bucketName, image, `image-${index}.jpg`)
    )
  );
  
  const urls: string[] = [];
  const errors: string[] = [];
  
  results.forEach((result, index) => {
    if (result.success && result.url) {
      urls.push(result.url);
    } else {
      errors.push(`Image ${index}: ${result.error || 'Unknown error'}`);
    }
  });
  
  return {
    success: urls.length > 0,
    urls: urls.length > 0 ? urls : undefined,
    errors: errors.length > 0 ? errors : undefined,
  };
}

// ==================== File Retrieval ====================
/**
 * Get signed URL for a file
 */
export async function getSignedUrl(
  bucketName: string,
  filePath: string,
  expiresIn: number = 3600 // 1 hour default
): Promise<{ success: boolean; url?: string; error?: string }> {
  try {
    const { data, error } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(filePath, expiresIn);
    
    if (error) {
      console.error(`❌ Failed to create signed URL:`, error);
      return { success: false, error: error.message };
    }
    
    return { success: true, url: data.signedUrl };
  } catch (error) {
    console.error(`❌ Get signed URL exception:`, error);
    return { success: false, error: String(error) };
  }
}

/**
 * Get signed URLs for multiple files
 */
export async function getSignedUrls(
  bucketName: string,
  filePaths: string[],
  expiresIn: number = 3600
): Promise<{ success: boolean; urls?: string[]; errors?: string[] }> {
  const results = await Promise.all(
    filePaths.map(path => getSignedUrl(bucketName, path, expiresIn))
  );
  
  const urls: string[] = [];
  const errors: string[] = [];
  
  results.forEach((result, index) => {
    if (result.success && result.url) {
      urls.push(result.url);
    } else {
      errors.push(`File ${index}: ${result.error || 'Unknown error'}`);
    }
  });
  
  return {
    success: urls.length > 0,
    urls: urls.length > 0 ? urls : undefined,
    errors: errors.length > 0 ? errors : undefined,
  };
}

// ==================== File Deletion ====================
/**
 * Delete a file from a bucket
 */
export async function deleteFile(
  bucketName: string,
  filePath: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase.storage
      .from(bucketName)
      .remove([filePath]);
    
    if (error) {
      console.error(`❌ File deletion failed:`, error);
      return { success: false, error: error.message };
    }
    
    console.log(`✅ File deleted: ${filePath}`);
    return { success: true };
  } catch (error) {
    console.error(`❌ File deletion exception:`, error);
    return { success: false, error: String(error) };
  }
}

/**
 * Delete multiple files from a bucket
 */
export async function deleteFiles(
  bucketName: string,
  filePaths: string[]
): Promise<{ success: boolean; errors?: string[] }> {
  const results = await Promise.all(
    filePaths.map(path => deleteFile(bucketName, path))
  );
  
  const errors: string[] = [];
  
  results.forEach((result, index) => {
    if (!result.success) {
      errors.push(`File ${index}: ${result.error || 'Unknown error'}`);
    }
  });
  
  return {
    success: errors.length === 0,
    errors: errors.length > 0 ? errors : undefined,
  };
}