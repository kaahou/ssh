# Changelog - Server Modularization

## [Unreleased]

## [2024-12-27] - Schema Fix v1 ✅
### Fixed
- ✅ **خطای "Could not find the 'status' column" کاملاً برطرف شد**
- ❌ حذف تلاش برای آپدیت ستون `status` که در جدول `orders` وجود ندارد
- ✅ محاسبه `order.status` از `payment_info.payment_status` در همه GET endpoints
- ✅ اصلاح payment verification endpoint در admin_routes.ts
- ✅ اصلاح order status update endpoint

### Changed
- در `admin_routes.ts`: حذف `status` از update query در payment verification
- در `order_routes.ts`: 
  - محاسبه `status` بر اساس `payment_status` در GET /orders
  - محاسبه `status` بر اساس `payment_status` در GET /orders/:id
  - اصلاح PUT /orders/:id/status برای آپدیت فقط payment_info
- همه وضعیت‌ها اکنون از `payment_info` JSON استخراج می‌شوند

### Added
- فایل `SCHEMA_FIX.md` برای مستندسازی ساختار جدول و راه‌حل
- نقشه کامل status mapping (payment_status → order.status)

## [2024-12-27] - Connection Fix v4 ✅ FINAL
### Fixed
- ✅ **خطای "connection closed before message completed" کاملاً و نهایی برطرف شد**
- ❌ حذف `logger` middleware که با Deno.serve تداخل داشت و باعث connection close می‌شد
- ✅ استفاده از console.log مستقیم در Deno.serve handler به جای logger middleware
- ✅ اطمینان از await کردن همه Promise ها قبل از return
- ✅ بهبود error handling در admin_routes.ts

### Changed
- در `index.tsx`: حذف کامل logger middleware و استفاده از console.log داخل handler
- در `admin_routes.ts`: اطمینان از return فوری بعد از database operations
- Server version: `2024-12-27-connection-fix-v4-no-logger`

### Added
- فایل `CONNECTION_FIX_V4.md` برای مستندسازی راه‌حل نهایی

## [2024-12-27] - Connection Fix v3
### Fixed
- ✅ خطای "connection closed before message completed" کاملاً برطرف شد
- حذف `requestLogger` middleware که با built-in logger تداخل داشت
- بهبود error handling در `index.tsx` با clone کردن response
- بهبود همه middleware ها برای اطمینان از await کردن `next()`
- اضافه کردن error details در catch blocks برای debugging بهتر

### Changed
- در `admin_routes.ts`: حذف کد redundant در payment status endpoint
- در `middleware.ts`: حذف `requestLogger` و بهبود error handling
- در `index.tsx`: clone کردن response قبل از return برای جلوگیری از body consumption issues

### Added
- فایل `CONNECTION_FIX.md` برای مستندسازی troubleshooting

## [Unreleased]