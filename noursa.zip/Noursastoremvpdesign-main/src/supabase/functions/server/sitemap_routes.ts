import { Hono } from "npm:hono";
import { supabase } from "./db.ts";

const sitemapRoutes = new Hono();

// Generate XML Sitemap
sitemapRoutes.get("/sitemap.xml", async (c) => {
  try {
    console.log("📍 Generating sitemap.xml...");
    const baseUrl = "https://nursaa.ir";
    const currentDate = new Date().toISOString().split('T')[0];
    
    // Static pages with priority and changefreq
    const staticPages = [
      { url: '/', priority: '1.0', changefreq: 'daily' },
      { url: '/products', priority: '0.9', changefreq: 'daily' },
      { url: '/blog', priority: '0.8', changefreq: 'weekly' },
      { url: '/about', priority: '0.7', changefreq: 'monthly' },
      { url: '/contact', priority: '0.7', changefreq: 'monthly' },
      { url: '/consultation', priority: '0.8', changefreq: 'monthly' },
      { url: '/shipping-guide', priority: '0.6', changefreq: 'monthly' },
      { url: '/return-policy', priority: '0.6', changefreq: 'monthly' },
      { url: '/privacy-policy', priority: '0.6', changefreq: 'monthly' },
      { url: '/terms-of-service', priority: '0.6', changefreq: 'monthly' },
      { url: '/money-back-guarantee', priority: '0.6', changefreq: 'monthly' },
      { url: '/faq', priority: '0.7', changefreq: 'monthly' },
    ];
    
    // Fetch all products
    const { data: products, error: productsError } = await supabase
      .from('products')
      .select('slug, updated_at')
      .order('id', { ascending: false });
    
    if (productsError) {
      console.error("Error fetching products for sitemap:", productsError);
    }
    
    // Fetch all categories
    const { data: categories } = await supabase
      .from('categories')
      .select('slug')
      .order('id', { ascending: false });
    
    
    // Fetch all articles from contents table
    const { data: articles } = await supabase
      .from('contents')
      .select('slug, updated_at')
      .eq('status', 'published')
      .order('created_at', { ascending: false });
    
    if (!articles) {
      console.log("No published articles found for sitemap");
    } else {
      console.log(`Found ${articles.length} published articles for sitemap`);
    }
    
    // Build XML
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
    
    // Add static pages
    staticPages.forEach(page => {
      xml += '  <url>\n';
      xml += `    <loc>${baseUrl}${page.url}</loc>\n`;
      xml += `    <lastmod>${currentDate}</lastmod>\n`;
      xml += `    <changefreq>${page.changefreq}</changefreq>\n`;
      xml += `    <priority>${page.priority}</priority>\n`;
      xml += '  </url>\n';
    });
    
    // Add products
    if (products && products.length > 0) {
      products.forEach(product => {
        if (product.slug) {
          const lastmod = product.updated_at ? new Date(product.updated_at).toISOString().split('T')[0] : currentDate;
          xml += '  <url>\n';
          xml += `    <loc>${baseUrl}/product/${product.slug}</loc>\n`;
          xml += `    <lastmod>${lastmod}</lastmod>\n`;
          xml += `    <changefreq>weekly</changefreq>\n`;
          xml += `    <priority>0.8</priority>\n`;
          xml += '  </url>\n';
        }
      });
    }
    
    // Add categories
    if (categories && categories.length > 0) {
      categories.forEach(category => {
        if (category.slug) {
          xml += '  <url>\n';
          xml += `    <loc>${baseUrl}/category/${category.slug}</loc>\n`;
          xml += `    <lastmod>${currentDate}</lastmod>\n`;
          xml += `    <changefreq>weekly</changefreq>\n`;
          xml += `    <priority>0.7</priority>\n`;
          xml += '  </url>\n';
        }
      });
    }
    
    // Add articles
    if (articles && articles.length > 0) {
      articles.forEach(article => {
        if (article.slug) {
          const lastmod = article.updated_at ? new Date(article.updated_at).toISOString().split('T')[0] : currentDate;
          xml += '  <url>\n';
          xml += `    <loc>${baseUrl}/blog/${article.slug}</loc>\n`;
          xml += `    <lastmod>${lastmod}</lastmod>\n`;
          xml += `    <changefreq>monthly</changefreq>\n`;
          xml += `    <priority>0.6</priority>\n`;
          xml += '  </url>\n';
        }
      });
    }
    
    xml += '</urlset>';
    
    console.log(`✅ Sitemap generated with ${(products?.length || 0) + (categories?.length || 0) + (articles?.length || 0) + staticPages.length} URLs`);
    
    // Return XML with proper headers
    return new Response(xml, {
      status: 200,
      headers: {
        'Content-Type': 'application/xml; charset=utf-8',
        'Cache-Control': 'public, max-age=3600', // Cache for 1 hour
      },
    });
  } catch (error) {
    console.error("Error generating sitemap:", error);
    return c.text("Error generating sitemap", 500);
  }
});

export default sitemapRoutes;
