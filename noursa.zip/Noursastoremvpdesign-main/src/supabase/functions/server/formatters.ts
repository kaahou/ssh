// Data Formatting Utilities

import type { Product, Order, ShippingInfo, PaymentInfo } from './types.ts';

// ==================== Product Formatters ====================
export function formatProductForResponse(product: any): Product {
  return {
    ...product,
    product_id: product.id, // Map id to product_id for frontend compatibility
  };
}

export function formatProductsForResponse(products: any[]): Product[] {
  return products.map(formatProductForResponse);
}

// ==================== Order Formatters ====================
export function parseShippingInfo(shippingInfo: string | ShippingInfo): ShippingInfo | null {
  if (typeof shippingInfo === 'string') {
    try {
      return JSON.parse(shippingInfo);
    } catch (e) {
      console.error('Failed to parse shipping_info:', e);
      return null;
    }
  }
  return shippingInfo;
}

export function parsePaymentInfo(paymentInfo: string | PaymentInfo): PaymentInfo | null {
  if (typeof paymentInfo === 'string') {
    try {
      return JSON.parse(paymentInfo);
    } catch (e) {
      console.error('Failed to parse payment_info:', e);
      return null;
    }
  }
  return paymentInfo;
}

export function isOrderPaid(order: any, debug = false): boolean {
  if (debug) {
    console.log('🔍 Checking order:', {
      id: order.id,
      payment_info_type: typeof order.payment_info,
      payment_info_sample: typeof order.payment_info === 'string' 
        ? order.payment_info.substring(0, 100) 
        : order.payment_info
    });
  }
  
  // Check payment_info JSON
  let paymentInfo = order.payment_info;
  if (typeof paymentInfo === 'string') {
    try {
      paymentInfo = JSON.parse(paymentInfo);
      if (debug) console.log('✅ Parsed payment_info:', paymentInfo);
    } catch (e) {
      if (debug) console.log('❌ Failed to parse payment_info:', e);
      return false;
    }
  }
  
  // Check payment_status field inside JSON first (for new orders)
  if (paymentInfo?.payment_status) {
    const isPaid = ['paid_zarinpal', 'paid_card', 'paid_manual'].includes(paymentInfo.payment_status);
    if (debug) console.log('✅ Using payment_status from JSON:', paymentInfo.payment_status, isPaid);
    return isPaid;
  }
  
  // Fallback to status field (for compatibility)
  const isPaid = paymentInfo?.status === 'paid';
  if (debug) console.log('📊 Payment status from JSON:', paymentInfo?.status, '→ isPaid:', isPaid);
  return isPaid;
}

// ==================== Date Formatters ====================
export function formatDateForDB(date: Date): string {
  return date.toISOString();
}

export function getTodayRange(): { start: Date; end: Date } {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  
  const end = new Date();
  end.setHours(23, 59, 59, 999);
  
  return { start, end };
}

export function getThisMonthRange(): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  
  return { start, end };
}

// ==================== Price Formatters ====================
export function formatPrice(price: number): string {
  return new Intl.NumberFormat('fa-IR').format(price);
}

export function formatPriceWithCurrency(price: number): string {
  return `${formatPrice(price)} تومان`;
}

// ==================== Phone Formatters ====================
export function formatPhoneDisplay(phone: string): string {
  // Format: 0912 345 6789
  if (phone.length === 11 && phone.startsWith('09')) {
    return `${phone.slice(0, 4)} ${phone.slice(4, 7)} ${phone.slice(7)}`;
  }
  return phone;
}

// ==================== Name Formatters ====================
export function splitFullName(fullName: string): { firstName: string; lastName: string } {
  const parts = fullName.trim().split(/\s+/);
  return {
    firstName: parts[0] || '',
    lastName: parts.slice(1).join(' ') || '',
  };
}

export function combineFullName(firstName: string, lastName: string): string {
  return `${firstName} ${lastName}`.trim();
}

// ==================== JSON Formatters ====================
export function safeJsonParse<T>(json: string | T, defaultValue: T): T {
  if (typeof json === 'string') {
    try {
      return JSON.parse(json) as T;
    } catch (e) {
      console.error('Failed to parse JSON:', e);
      return defaultValue;
    }
  }
  return json;
}

export function safeJsonStringify(obj: any): string {
  try {
    return JSON.stringify(obj);
  } catch (e) {
    console.error('Failed to stringify JSON:', e);
    return '{}';
  }
}

// ==================== Array Formatters ====================
export function parseStringArray(value: string | string[]): string[] {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [value];
    } catch (e) {
      return value.split(',').map(s => s.trim()).filter(Boolean);
    }
  }
  return [];
}

// ==================== Pagination Formatters ====================
export function formatPaginationParams(page?: string | number, limit?: string | number) {
  const parsedPage = parseInt(String(page || '1'));
  const parsedLimit = parseInt(String(limit || '12'));
  
  const validPage = parsedPage > 0 ? parsedPage : 1;
  const validLimit = parsedLimit > 0 && parsedLimit <= 100 ? parsedLimit : 12;
  
  const offset = (validPage - 1) * validLimit;
  
  return {
    page: validPage,
    limit: validLimit,
    offset,
  };
}