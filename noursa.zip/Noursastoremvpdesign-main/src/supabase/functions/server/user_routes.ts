import { Hono } from "npm:hono";
import { supabase } from "./db.ts";

const userRoutes = new Hono();

// Get user profile
userRoutes.get("/user/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error) {
      console.error("Error fetching user:", error);
      return c.json({ error: "کاربر یافت نشد" }, 404);
    }
    
    return c.json({ user });
  } catch (error) {
    console.error("Error fetching user:", error);
    return c.json({ error: "خطا در بارگذاری اطلاعات کاربر" }, 500);
  }
});

// Update user profile
userRoutes.put("/user/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const updates = await c.req.json();
    
    // Update last_seen_at automatically
    updates.last_seen_at = new Date().toISOString();
    
    const { data: user, error } = await supabase
      .from('users')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) {
      console.error("Error updating user:", error);
      return c.json({ error: "خطا در بروزرسانی اطلاعات" }, 500);
    }
    
    return c.json({ user });
  } catch (error) {
    console.error("Error updating user:", error);
    return c.json({ error: "خطا در بروزرسانی اطلاعات" }, 500);
  }
});

// Get all users for admin panel
userRoutes.get("/users", async (c) => {
  try {
    console.log("Fetching users from Postgres database...");
    
    const { data: users, error } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error("Supabase error fetching users:", error);
      return c.json({ error: "Failed to fetch users from database" }, 500);
    }
    
    console.log(`Found ${users?.length || 0} users from database`);
    return c.json({ users: users || [] });
  } catch (error) {
    console.error("Error fetching users:", error);
    return c.json({ error: "Failed to fetch users" }, 500);
  }
});

// Delete user
userRoutes.delete("/users/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    console.log(`Deleting user ${userId}...`);

    const { error } = await supabase
      .from('users')
      .delete()
      .eq('user_id', userId);

    if (error) {
      console.error("Supabase error deleting user:", error);
      return c.json({ error: "Failed to delete user", details: error.message }, 500);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting user:", error);
    return c.json({ error: "Failed to delete user" }, 500);
  }
});

export default userRoutes;
