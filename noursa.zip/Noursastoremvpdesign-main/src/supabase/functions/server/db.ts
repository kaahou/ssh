import { createClient } from "jsr:@supabase/supabase-js@2";

// Create Supabase client
const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? 'https://example.supabase.co';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? 'example-key';

export const supabase = createClient(supabaseUrl, supabaseKey);
