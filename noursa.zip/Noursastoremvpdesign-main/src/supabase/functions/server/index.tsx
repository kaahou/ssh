import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
// ❌ REMOVED: logger middleware causes "connection closed" errors with Deno.serve
// import { logger } from "npm:hono/logger";

// Import all route modules
import productRoutes from "./product_routes.ts";
import orderRoutes from "./order_routes.ts";
import consultationRoutes from "./consultation_routes.ts";
import authRoutes from "./auth_routes.ts";
import userRoutes from "./user_routes.ts";
import articleRoutes from "./article_routes.ts";
import categoryRoutes from "./category_routes.ts";
import searchRoutes from "./search_routes.ts";
import paymentRoutes from "./payment_routes.ts";
import sitemapRoutes from "./sitemap_routes.ts";
import adminRoutes from "./admin_routes.ts";
import contactRoutes from "./contact_routes.ts";
import { initializeStorageBuckets } from "./storage_service.ts";
import { setupStoragePolicies } from "./setup_storage_policies.ts";

const app = new Hono();

// ❌ REMOVED: logger middleware - using built-in console.log in Deno.serve handler instead
// app.use('*', logger(console.log));

// Global error handler - CRITICAL: Always return a response
app.onError((err, c) => {
  console.error("🔥 Global Error:", err);
  console.error("🔥 Stack:", err.stack);
  
  // Always return JSON response to prevent connection close
  try {
    return c.json({ 
      error: "Internal Server Error", 
      message: err.message || "Unknown error",
      timestamp: new Date().toISOString()
    }, 500);
  } catch (jsonError) {
    console.error("❌ Failed to return JSON error:", jsonError);
    // Last resort: return text response with CORS
    return new Response("Internal Server Error", { 
      status: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS, PATCH",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, X-User-Phone"
      }
    });
  }
});

// ✅ Enable CORS for all routes - MUST be before mounting routes
app.use("*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization", "X-User-Phone"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
  exposeHeaders: ["Content-Length"],
  maxAge: 600,
  credentials: false,
}));

// Define API routes without prefix
const api = new Hono();

// Mount all route modules
api.route("/", productRoutes);
api.route("/", orderRoutes);
api.route("/", consultationRoutes);
api.route("/", authRoutes);
api.route("/", userRoutes);
api.route("/", articleRoutes);
api.route("/", categoryRoutes);
api.route("/", searchRoutes);
api.route("/", paymentRoutes);
api.route("/", sitemapRoutes);
api.route("/", adminRoutes);
api.route("/", contactRoutes);

// Initialize storage buckets
console.log("📦 Initializing storage buckets...");
initializeStorageBuckets().catch((error) => {
  console.error("❌ Failed to initialize storage buckets:", error);
});

// Setup storage policies
console.log("📦 Setting up storage policies...");
setupStoragePolicies().catch((error) => {
  console.error("❌ Failed to setup storage policies:", error);
});

// Initialize sample products data - removed as using Postgres
console.log("✅ Server initialized - using Postgres tables for products and categories");
console.log("✅ All route modules loaded successfully");

// Mount routes
app.route("/", api);
app.route("/make-server-fbc72c25", api);

// Add 404 catch-all handler - Must be AFTER mounting routes
app.all("*", (c) => {
  console.log(`⚠️ 404 Not Found: ${c.req.method} ${c.req.url}`);
  return c.json({ 
    error: "Not Found",
    path: c.req.url,
    method: c.req.method,
    timestamp: new Date().toISOString()
  }, 404);
});

// Start server with proper error handling
console.log("🚀 Starting Hono server...");
console.log("🔧 Server version: 2024-12-27-optimized-v5-no-cloning");

Deno.serve({
  handler: async (req) => {
    try {
      // Log incoming request
      const url = new URL(req.url);
      console.log(`📨 ${req.method} ${url.pathname}`);
      
      // Call Hono app and await the response
      const response = await app.fetch(req);
      
      // Ensure we always return a valid Response
      if (!response || !(response instanceof Response)) {
        console.error("❌ Handler did not return a Response object!");
        return new Response(
          JSON.stringify({ 
            error: "Internal Server Error",
            message: "Invalid response from handler",
            timestamp: new Date().toISOString()
          }), 
          { 
            status: 500,
            headers: { 
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*"
            }
          }
        );
      }
      
      // ✅ Return response directly without cloning (cloning can cause pipe issues)
      return response;
      
    } catch (error) {
      console.error("❌ Fatal server error in handler:", error);
      console.error("Stack:", error instanceof Error ? error.stack : "No stack trace");
      
      // Always return a proper Response with CORS
      return new Response(
        JSON.stringify({ 
          error: "Internal Server Error",
          message: error instanceof Error ? error.message : String(error),
          timestamp: new Date().toISOString()
        }), 
        { 
          status: 500,
          headers: { 
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
          }
        }
      );
    }
  },
  onError: (error) => {
    console.error("❌ Deno.serve onError:", error);
    // Return proper error response
    return new Response(
      JSON.stringify({ 
        error: "Server Error",
        message: String(error),
        timestamp: new Date().toISOString()
      }), 
      { 
        status: 500,
        headers: { 
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      }
    );
  }
});

console.log("✅ Server started successfully");