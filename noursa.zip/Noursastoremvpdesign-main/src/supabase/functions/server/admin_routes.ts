import { Hono } from "npm:hono";
import { supabase } from "./db.ts";

const adminRoutes = new Hono();

// Test endpoint to verify admin routes are working
adminRoutes.get("/admin/test", async (c) => {
  console.log("✅ Admin test endpoint called");
  return c.json({ 
    success: true, 
    message: "Admin routes are working",
    timestamp: new Date().toISOString()
  });
});

// Handle OPTIONS for CORS preflight
adminRoutes.options("/admin/orders/:orderId/payment-status", async (c) => {
  console.log("✅ OPTIONS request for payment-status endpoint");
  return c.json({ ok: true }, 200);
});

// Admin Dashboard Stats
adminRoutes.get("/admin/stats", async (c) => {
  try {
    console.log("📊 Fetching admin dashboard stats");
    
    // Helper function to check if order is paid
    const isOrderPaid = (order: any): boolean => {
      // Check payment_info JSON
      let paymentInfo = order.payment_info;
      if (typeof paymentInfo === 'string') {
        try {
          paymentInfo = JSON.parse(paymentInfo);
        } catch (e) {
          return false;
        }
      }
      
      // Check payment_status field inside JSON first (for new orders)
      if (paymentInfo?.payment_status) {
        return ['paid_zarinpal', 'paid_card', 'paid_manual'].includes(paymentInfo.payment_status);
      }
      
      // Fallback to status field (for compatibility)
      return paymentInfo?.status === 'paid';
    };
    
    // تاریخ امروز و 30 روز قبل
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 29);
    thirtyDaysAgo.setHours(0, 0, 0, 0);
    
    // ✅ بهینه‌سازی: یک‌بار همه داده‌های 30 روز گذشته را بگیر
    console.log(`📊 Fetching all data from ${thirtyDaysAgo.toISOString()} to ${today.toISOString()}`);
    
    const [ordersResult, usersResult, consultationsResult] = await Promise.all([
      supabase
        .from('orders')
        .select('id, total_amount, payment_info, created_at')
        .gte('created_at', thirtyDaysAgo.toISOString())
        .lte('created_at', today.toISOString()),
      supabase
        .from('users')
        .select('id, created_at')
        .gte('created_at', thirtyDaysAgo.toISOString())
        .lte('created_at', today.toISOString()),
      supabase
        .from('consultations')
        .select('id, created_at')
        .gte('created_at', thirtyDaysAgo.toISOString())
        .lte('created_at', today.toISOString())
    ]);
    
    console.log(`✅ Fetched ${ordersResult.data?.length || 0} orders, ${usersResult.data?.length || 0} users, ${consultationsResult.data?.length || 0} consultations`);
    
    // فیلتر سفارشات پرداخت شده
    const allOrders = ordersResult.data || [];
    const paidOrders = allOrders.filter(order => isOrderPaid(order));
    const allUsers = usersResult.data || [];
    const allConsultations = consultationsResult.data || [];
    
    // آمار امروز
    const todayPaidOrders = paidOrders.filter(order => {
      const orderDate = new Date(order.created_at);
      return orderDate >= todayStart && orderDate <= today;
    });
    const todaySales = todayPaidOrders.reduce((sum, order) => sum + (order.total_amount || 0), 0);
    
    const todayUsers = allUsers.filter(user => {
      const userDate = new Date(user.created_at);
      return userDate >= todayStart && userDate <= today;
    });
    
    const todayConsultations = allConsultations.filter(consultation => {
      const consultationDate = new Date(consultation.created_at);
      return consultationDate >= todayStart && consultationDate <= today;
    });
    
    console.log(`✅ Today stats - Orders: ${todayPaidOrders.length}, Sales: ${todaySales}, Users: ${todayUsers.length}, Consultations: ${todayConsultations.length}`);
    
    // ✅ گروه‌بندی داده‌ها بر اساس روز
    const chartData = [];
    
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const dateEnd = new Date(date);
      dateEnd.setHours(23, 59, 59, 999);
      
      const dateStr = date.toISOString().split('T')[0];
      
      // فیلتر سفارشات روز
      const dayOrders = paidOrders.filter(order => {
        const orderDate = new Date(order.created_at);
        return orderDate >= date && orderDate <= dateEnd;
      });
      const daySales = dayOrders.reduce((sum, order) => sum + (order.total_amount || 0), 0);
      
      // فیلتر کاربران روز
      const dayUsers = allUsers.filter(user => {
        const userDate = new Date(user.created_at);
        return userDate >= date && userDate <= dateEnd;
      });
      
      // فیلتر مشاوره‌های روز
      const dayConsultations = allConsultations.filter(consultation => {
        const consultationDate = new Date(consultation.created_at);
        return consultationDate >= date && consultationDate <= dateEnd;
      });
      
      chartData.push({
        date: dateStr,
        sales: daySales,
        orders: dayOrders.length,
        users: dayUsers.length,
        consultations: dayConsultations.length
      });
    }
    
    console.log(`✅ Chart data generated for 30 days`);
    
    return c.json({
      today: {
        sales: todaySales,
        orders: todayPaidOrders.length,
        users: todayUsers.length,
        consultations: todayConsultations.length
      },
      chart: chartData
    });
  } catch (error) {
    console.error("❌ Error fetching admin stats:", error);
    return c.json({ error: "Failed to fetch stats", message: error instanceof Error ? error.message : String(error) }, 500);
  }
});

// Update payment status (approve or reject card payment)
adminRoutes.post("/admin/orders/:orderId/payment-status", async (c) => {
  const orderId = c.req.param("orderId");
  
  try {
    console.log(`💳 [START] Payment status update request for order ${orderId}`);
    
    // Parse body directly with c.req.json()
    let action: string;
    try {
      const body = await c.req.json();
      action = body.action;
      console.log(`📥 Request body parsed successfully:`, body);
    } catch (e) {
      console.error("❌ Failed to parse request body:", e);
      return c.json({ error: "Invalid request body", details: String(e) }, 400);
    }
    
    if (!action || !['approve', 'reject'].includes(action)) {
      console.error(`❌ Invalid action: ${action}`);
      return c.json({ error: "Invalid action. Use 'approve' or 'reject'" }, 400);
    }
    
    console.log(`💳 Action: ${action}`);
    
    // Get current order
    console.log(`🔍 Fetching order ${orderId} from database...`);
    const { data: order, error: fetchError } = await supabase
      .from('orders')
      .select('payment_info')
      .eq('id', orderId)
      .single();
    
    if (fetchError || !order) {
      console.error("❌ Order fetch error:", fetchError);
      return c.json({ 
        error: "Order not found", 
        details: fetchError?.message || "No order data"
      }, 404);
    }
    
    console.log(`✅ Order found, payment_info type: ${typeof order.payment_info}`);
    
    // Parse payment_info safely
    let paymentInfo: any = {};
    if (order.payment_info) {
      if (typeof order.payment_info === 'string') {
        try {
          paymentInfo = JSON.parse(order.payment_info);
          console.log(`✅ Parsed payment_info`);
        } catch (e) {
          console.error("❌ Failed to parse payment_info string:", e);
          paymentInfo = {};
        }
      } else if (typeof order.payment_info === 'object') {
        paymentInfo = order.payment_info;
        console.log(`✅ Payment_info is already object`);
      }
    }
    
    // Update payment status based on action
    console.log(`🔄 Updating payment status to: ${action === 'approve' ? 'paid_card' : 'unpaid_card'}`);
    
    if (action === 'approve') {
      paymentInfo.payment_status = 'paid_card';
      paymentInfo.status = 'paid';
      paymentInfo.verified_at = new Date().toISOString();
    } else {
      paymentInfo.payment_status = 'unpaid_card';
      paymentInfo.status = 'failed';
      paymentInfo.rejected_at = new Date().toISOString();
    }
    
    // Convert to JSON string for storage
    const paymentInfoString = JSON.stringify(paymentInfo);
    console.log(`💾 Updating order in database...`);
    
    // ✅ Update ONLY payment_info (orders table doesn't have 'status' column)
    const { error: updateError } = await supabase
      .from('orders')
      .update({ 
        payment_info: paymentInfoString
      })
      .eq('id', orderId);
    
    if (updateError) {
      console.error("❌ Supabase update error:", updateError);
      return c.json({ 
        error: "Failed to update payment status", 
        details: updateError.message 
      }, 500);
    }
    
    console.log(`✅ [SUCCESS] Payment status updated for order ${orderId}: ${action}`);
    
    // CRITICAL: Return response immediately, don't await anything after
    return c.json({ 
      success: true, 
      message: action === 'approve' ? 'پرداخت تایید شد' : 'پرداخت رد شد',
      payment_status: paymentInfo.payment_status
    }, 200);
    
  } catch (error) {
    console.error("❌ [ERROR] Unexpected error in payment status update:", error);
    console.error("❌ Error details:", {
      name: error instanceof Error ? error.constructor.name : typeof error,
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : 'No stack'
    });
    
    // CRITICAL: Always return a response, even in catch
    return c.json({ 
      error: "Internal server error", 
      message: error instanceof Error ? error.message : String(error),
      orderId: orderId
    }, 500);
  }
});

export default adminRoutes;