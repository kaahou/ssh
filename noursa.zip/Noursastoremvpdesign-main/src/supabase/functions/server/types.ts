// Shared TypeScript Types and Interfaces

// ==================== Product Types ====================
export interface Product {
  id?: number;
  product_id?: number;
  slug: string;
  product_name: string;  // Changed from 'name' to 'product_name'
  variant_name?: string;  // Added variant_name
  short_description?: string;  // Changed from 'description' to 'short_description'
  price: number;
  old_price?: number;  // Changed from 'discount_price' to 'old_price'
  image?: string;
  image_urls?: string | null;  // Added image_urls
  category_id?: number;
  stock?: number;
  ingredients?: string;
  usage_instructions?: string;
  benefits?: string;
  warnings?: string;
  volume?: string;
  brand?: string;
  score?: number;  // امتیاز محصول برای مرتب‌سازی
  created_at?: string;
  updated_at?: string;
}

export interface Category {
  id?: number;
  slug: string;
  name: string;
  description?: string;
  parent_id?: number;
  image?: string;
  created_at?: string;
  updated_at?: string;
}

// ==================== Order Types ====================
export interface OrderItem {
  product_id: number;
  slug: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
}

export interface ShippingInfo {
  contact: {
    mobile: string;
    email: string;
  };
  address: {
    first_name: string;
    last_name: string;
    state: string;
    city: string;
    street: string;
    postal_code: string;
  };
}

export interface PaymentInfo {
  method: 'zarinpal' | 'card' | 'manual';
  status: 'pending' | 'paid' | 'failed' | 'cancelled';
  payment_status?: PaymentStatus; // ✅ Added to store payment_status inside JSON
  tracking_code?: string;
  authority?: string;
  ref_id?: string;
  card_pan?: string;
}

export type PaymentStatus = 
  | 'pending' 
  | 'paid_zarinpal' 
  | 'paid_card' 
  | 'paid_manual' 
  | 'failed' 
  | 'cancelled';

export interface Order {
  id?: number;
  user_id?: number;
  total_amount: number;
  subtotal?: number;
  post_price?: number;
  discount_amount?: number;
  shipping_info: ShippingInfo | string;
  payment_info: PaymentInfo | string;
  // ✅ Removed payment_status from top-level - now stored inside payment_info JSON
  status?: string;
  created_at?: string;
  updated_at?: string;
}

export interface CreateOrderRequest {
  customerName: string;
  phone: string;
  email: string;
  state: string;
  city: string;
  street: string;
  postalCode: string;
  paymentMethod: 'zarinpal' | 'card' | 'manual';
  trackingCode?: string;
  items: OrderItem[];
  totalAmount?: number;
}

// ==================== Consultation Types ====================
export interface ConsultationFormData {
  first_name: string;
  last_name: string;
  national_code: string;
  birth_year: string;
  gender: 'male' | 'female';
  weight: string;
  height: string;
  body_type: string;
  skin_color: string;
  city: string;
  has_disease: boolean;
  diseases?: string;
  medications?: string;
  pregnancy_status?: string;
  user_photos?: string[];
  skin_issues?: string;
  previous_treatments?: string;
  skin_type?: string;
  skin_sensitivity?: string;
  sun_exposure?: string;
  skincare_routine?: string;
  additional_notes?: string;
}

export interface Consultation {
  id?: number;
  user_id?: number;
  phone: string;
  first_name: string;
  last_name: string;
  national_code: string;
  birth_year: string;
  gender: 'male' | 'female';
  weight: string;
  height: string;
  body_type: string;
  skin_color: string;
  city: string;
  has_disease: boolean;
  diseases?: string;
  medications?: string;
  pregnancy_status?: string;
  user_photos?: string;
  skin_issues?: string;
  previous_treatments?: string;
  skin_type?: string;
  skin_sensitivity?: string;
  sun_exposure?: string;
  skincare_routine?: string;
  additional_notes?: string;
  status?: string;
  result?: string;
  created_at?: string;
  updated_at?: string;
}

// ==================== User Types ====================
export interface User {
  phone: string;
  first_name?: string;
  last_name?: string;
  created_at?: string;
}

// ==================== Article Types ====================
export interface Article {
  id?: number;
  slug: string;
  title: string;
  excerpt?: string;
  content: string;
  image?: string;
  author?: string;
  category?: string;
  tags?: string[];
  published_at?: string;
  created_at?: string;
  updated_at?: string;
}

// ==================== API Response Types ====================
export interface ApiResponse<T = any> {
  data?: T;
  error?: string;
  message?: string;
  success?: boolean;
}

export interface PaginatedResponse<T = any> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

// ==================== Payment Types ====================
export interface ZarinpalRequest {
  merchant_id: string;
  amount: number;
  description: string;
  callback_url: string;
  metadata?: {
    mobile?: string;
    email?: string;
    [key: string]: any;
  };
}

export interface ZarinpalVerify {
  merchant_id: string;
  amount: number;
  authority: string;
}

export interface ZarinpalResponse {
  success: boolean;
  authority?: string;
  payment_url?: string;
  ref_id?: string;
  card_pan?: string;
  errors?: any;
  code?: number;
}

// ==================== Admin Types ====================
export interface AdminStats {
  todaySales: number;
  todayOrdersCount: number;
  todayUsersCount: number;
  todayConsultationsCount: number;
  totalRevenue: number;
  totalOrders: number;
  totalUsers: number;
  totalConsultations: number;
  recentOrders: Order[];
  popularProducts: Product[];
}