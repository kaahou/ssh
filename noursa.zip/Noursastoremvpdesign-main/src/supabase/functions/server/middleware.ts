// Middleware Utilities

import type { Context, Next } from 'npm:hono';
import { supabase } from './db.ts';
import { ADMIN_PHONES, ERROR_MESSAGES } from './constants.ts';

// ==================== Admin Authentication Middleware ====================
export async function requireAdmin(c: Context, next: Next) {
  try {
    const phone = c.req.header('X-User-Phone');
    
    if (!phone) {
      console.log('❌ Admin auth: No phone header');
      return c.json({ error: ERROR_MESSAGES.UNAUTHORIZED }, 401);
    }
    
    if (!ADMIN_PHONES.includes(phone)) {
      console.log(`⚠️ Unauthorized admin access attempt from: ${phone}`);
      return c.json({ error: ERROR_MESSAGES.UNAUTHORIZED }, 403);
    }
    
    console.log(`✅ Admin access granted to: ${phone}`);
    
    // Store phone in context for use in handlers
    c.set('userPhone', phone);
    
    // Call next() and ensure it completes
    await next();
    
  } catch (error) {
    console.error('❌ Admin auth middleware error:', error);
    return c.json({ 
      error: ERROR_MESSAGES.SERVER_ERROR,
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
}

// ==================== User Authentication Middleware ====================
export async function requireAuth(c: Context, next: Next) {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      console.log('❌ User auth: No access token');
      return c.json({ error: ERROR_MESSAGES.UNAUTHORIZED }, 401);
    }
    
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user?.id) {
      console.error('❌ Auth error:', error);
      return c.json({ error: ERROR_MESSAGES.UNAUTHORIZED }, 401);
    }
    
    // Store user info in context
    c.set('userId', user.id);
    c.set('userEmail', user.email);
    
    // Call next() and ensure it completes
    await next();
    
  } catch (error) {
    console.error('❌ Auth middleware error:', error);
    return c.json({ 
      error: ERROR_MESSAGES.SERVER_ERROR,
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
}

// ==================== Optional Auth Middleware ====================
export async function optionalAuth(c: Context, next: Next) {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (accessToken) {
      const { data: { user } } = await supabase.auth.getUser(accessToken);
      
      if (user?.id) {
        c.set('userId', user.id);
        c.set('userEmail', user.email);
      }
    }
    
    // Always call next() for optional auth
    await next();
    
  } catch (error) {
    console.error('⚠️ Optional auth middleware error:', error);
    // Continue anyway for optional auth
    await next();
  }
}

// ==================== Request Body Validation Middleware ====================
export function validateBody(schema: any) {
  return async (c: Context, next: Next) => {
    try {
      const body = await c.req.json();
      
      // Basic validation - can be extended with a validation library
      if (!body || typeof body !== 'object') {
        return c.json({ error: ERROR_MESSAGES.INVALID_INPUT }, 400);
      }
      
      // Store validated body in context
      c.set('validatedBody', body);
      
      // Call next() and ensure it completes
      await next();
      
    } catch (error) {
      console.error('❌ Body validation error:', error);
      return c.json({ 
        error: ERROR_MESSAGES.INVALID_INPUT,
        details: error instanceof Error ? error.message : String(error)
      }, 400);
    }
  };
}

// ==================== Rate Limiting Middleware ====================
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(maxRequests: number, windowMs: number) {
  return async (c: Context, next: Next) => {
    try {
      const clientId = c.req.header('X-Forwarded-For') || 
                       c.req.header('X-Real-IP') || 
                       'unknown';
      
      const now = Date.now();
      const record = rateLimitStore.get(clientId);
      
      if (record && now < record.resetAt) {
        if (record.count >= maxRequests) {
          return c.json({ 
            error: 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً چند دقیقه دیگر تلاش کنید',
            retryAfter: Math.ceil((record.resetAt - now) / 1000)
          }, 429);
        }
        record.count++;
      } else {
        rateLimitStore.set(clientId, {
          count: 1,
          resetAt: now + windowMs,
        });
      }
      
      // Call next() and ensure it completes
      await next();
      
    } catch (error) {
      console.error('❌ Rate limit middleware error:', error);
      return c.json({ 
        error: ERROR_MESSAGES.SERVER_ERROR,
        details: error instanceof Error ? error.message : String(error)
      }, 500);
    }
  };
}