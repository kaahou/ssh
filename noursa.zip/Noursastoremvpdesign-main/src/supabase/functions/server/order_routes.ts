import { Hono } from "npm:hono";
import { supabase } from "./db.ts";
import { sendCardToCardOrderConfirmation } from "./order_sms.ts";

const orderRoutes = new Hono();

// Create order
orderRoutes.post("/orders", async (c) => {
  try {
    const body = await c.req.json();
    const { customerName, phone, email, state, city, street, postalCode, paymentMethod, trackingCode, items, totalAmount } = body;
    
    console.log("Creating customer order with items:", items?.length);
    
    if (!items || items.length === 0) {
      return c.json({ error: "سبد خرید خالی است" }, 400);
    }
    
    // Calculate totals
    const subtotal = items.reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0);
    const postPrice = 80000; // Fixed shipping cost
    const finalTotalAmount = totalAmount || (subtotal + postPrice);
    
    // Generate unique bigint ID for order
    const orderId = Date.now();
    
    // Prepare shipping info JSON object
    const shippingInfo = {
      contact: {
        mobile: phone || "",
        email: email || ""
      },
      address: {
        first_name: customerName?.split(' ')[0] || "",
        last_name: customerName?.split(' ').slice(1).join(' ') || "",
        state: state || "",
        city: city || "",
        street: street || "",
        postal_code: postalCode || ""
      }
    };
    
    // Prepare payment info JSON object
    const paymentInfo = {
      method: paymentMethod || "zarinpal",
      status: "pending",  // ✅ Always start as pending
      tracking_code: trackingCode || "",
      payment_status: 'pending' // ✅ Store payment_status inside JSON
    };
    
    // ✅ تعیین payment_status بر اساس method و status
    if (paymentMethod === 'card-to-card') {
      paymentInfo.payment_status = 'awaiting_verification'; // کارت به کارت در انتظار تایید
    } else if (paymentMethod === 'zarinpal') {
      paymentInfo.payment_status = 'pending'; // زرین‌پال رها شده
    }
    
    // Insert order into Postgres
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        id: orderId,
        user_id: null,
        created_at: new Date().toISOString(),
        shipping_info: JSON.stringify(shippingInfo),
        payment_info: JSON.stringify(paymentInfo),
        notes: JSON.stringify({
          created_by: 'customer',
          type: 'online_order'
        }),
        subtotal: subtotal,
        post_price: postPrice,
        discount_amount: 0,
        total_amount: finalTotalAmount
      })
      .select()
      .single();

    if (orderError) {
      console.error("Error creating order:", orderError);
      return c.json({ error: "Failed to create order", details: orderError.message }, 500);
    }

    // Get next ID for ordersitems
    const { data: maxIdResult } = await supabase
      .from('ordersitems')
      .select('id')
      .order('id', { ascending: false })
      .limit(1);
    
    let nextItemId = maxIdResult && maxIdResult.length > 0 ? maxIdResult[0].id + 1 : 1;

    // Insert order items
    const orderItems = items.map((item: any) => {
      const productId = parseInt(item.productId || item.product_id || 0);
      console.log(`📦 Mapping order item: productId="${item.productId}", product_id="${item.product_id}", parsed=${productId}`);
      return {
        id: nextItemId++,
        order_id: orderId,
        product_id: productId,
        unit_price: item.price,
        quantity: item.quantity
      };
    });
    
    console.log(`💾 Inserting ${orderItems.length} order items:`, orderItems.map(i => `ID=${i.product_id}`).join(', '));

    const { error: itemsError } = await supabase
      .from('ordersitems')
      .insert(orderItems);

    if (itemsError) {
      console.error("Error creating order items:", itemsError);
      // Rollback: delete the order
      await supabase.from('orders').delete().eq('id', orderId);
      return c.json({ error: "Failed to create order items", details: itemsError.message }, 500);
    }

    console.log(`Order ${orderId} created successfully with ${items.length} items`);
    
    // Send SMS confirmation for card-to-card orders
    if (paymentMethod === 'card-to-card' && phone) {
      sendCardToCardOrderConfirmation(phone, orderId);
    }
    
    return c.json({ success: true, orderId: String(orderId) });
  } catch (error) {
    console.error("Error creating order:", error);
    return c.json({ error: "Failed to create order" }, 500);
  }
});

// Get all orders
orderRoutes.get("/orders", async (c) => {
  try {
    console.log("Fetching orders from Postgres database...");
    
    // First fetch orders
    const { data: orders, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error("Supabase error fetching orders:", error);
      return c.json({ error: "Failed to fetch orders" }, 500);
    }
    
    // If we have orders, let's fetch their items to count them
    // We do this separately to avoid issues if foreign keys aren't perfect
    if (orders && orders.length > 0) {
      const orderIds = orders.map(o => o.id);
      
      // Try fetching items from 'order_items' (standard) or 'ordersitems' (user reported)
      let items = [];
      
      const { data: items1 } = await supabase
        .from('order_items')
        .select('order_id, product_id, quantity')
        .in('order_id', orderIds);
        
      if (items1 && items1.length > 0) {
        items = items1;
      } else {
        const { data: items2 } = await supabase
          .from('ordersitems')
          .select('order_id, product_id, quantity')
          .in('order_id', orderIds);
        if (items2) items = items2;
      }

      // Fetch product names for all items
      let productsMap = new Map();
      if (items && items.length > 0) {
        const productIds = [...new Set(items.map(i => i.product_id).filter(id => id !== 0 && id !== null))];
        
        console.log(`📦 Fetching product details for ${productIds.length} unique products:`, productIds);
        
        if (productIds.length > 0) {
          const { data: products, error: productsError } = await supabase
            .from('products')
            .select('id, product_name, variant_name')
            .in('id', productIds);
          
          if (productsError) {
            console.error('❌ Error fetching products:', productsError);
          }
          
          if (products) {
            console.log(`✅ Found ${products.length} products from database`);
            products.forEach(p => {
              const fullName = p.variant_name 
                ? `${p.variant_name} ${p.product_name}`.trim()
                : p.product_name;
              productsMap.set(String(p.id), fullName);
              console.log(`  - Product ${p.id}: variant="${p.variant_name || ''}", name="${p.product_name}", full="${fullName}"`);
            });
          } else {
            console.warn('⚠️ No products returned from database');
          }
        }
      }
        
      // Add items count and items array to each order and map fields from JSON columns
      orders.forEach(order => {
        // 1. Map items with product names
        const orderItems = items?.filter(i => String(i.order_id) === String(order.id)) || [];
        (order as any).items_count = orderItems.length;
        (order as any).items = orderItems.map(item => ({
          product_name: productsMap.get(String(item.product_id)) || `محصول ${item.product_id}`,
          quantity: item.quantity
        }));

        // 2. Map Shipping Info (Customer Name, Address, Phone)
        let shippingInfo = order.shipping_info;
        if (typeof shippingInfo === 'string') {
          try { shippingInfo = JSON.parse(shippingInfo); } catch (e) {}
        }
        
        if (shippingInfo) {
          // Map Customer Name
          const firstName = shippingInfo.address?.first_name || '';
          const lastName = shippingInfo.address?.last_name || '';
          if (firstName || lastName) {
            (order as any).customer_name = `${firstName} ${lastName}`.trim();
          }

          // Map Address
          const city = shippingInfo.address?.city || '';
          const state = shippingInfo.address?.state || '';
          // Check 'street' first (new format), then 'address' (old format)
          const addrText = shippingInfo.address?.street || shippingInfo.address?.address || '';
          const postalCode = shippingInfo.address?.postal_code || '';
          
          const addressParts = [state, city, addrText].filter(Boolean);
          if (addressParts.length > 0) {
            (order as any).address = addressParts.join(' - ');
            if (postalCode) (order as any).address += ` (کد پستی: ${postalCode})`;
          }

          // Map Phone
          if (shippingInfo.contact?.mobile) {
            (order as any).phone = shippingInfo.contact.mobile;
          }
        }

        // 3. Map Status from Payment Info if top-level status is missing or default
        let paymentInfo = order.payment_info;
        if (typeof paymentInfo === 'string') {
          try { paymentInfo = JSON.parse(paymentInfo); } catch (e) {}
        }

        // Extract payment_status for frontend - prioritize payment_status field
        (order as any).payment_status = paymentInfo?.payment_status || paymentInfo?.status || 'pending';

        // ✅ Determine order status based on payment_status (orders table doesn't have 'status' column)
        const paymentStatus = paymentInfo?.payment_status || paymentInfo?.status || 'pending';
        
        if (['paid_zarinpal', 'paid_card', 'paid_manual'].includes(paymentStatus)) {
          (order as any).status = 'processing'; // پرداخت شده → در حال پردازش
        } else if (paymentStatus === 'unpaid_manual') {
          (order as any).status = 'cancelled'; // رد شده → لغو شده
        } else if (paymentStatus === 'awaiting_verification') {
          (order as any).status = 'pending'; // در انتظار تایید → معلق
        } else {
          (order as any).status = 'pending'; // همه چیز دیگر → معلق
        }
      });
    }
    
    return c.json({ orders: orders || [] });
  } catch (error) {
    console.error("Error fetching orders:", error);
    return c.json({ error: "Failed to fetch orders" }, 500);
  }
});

// Get single order
orderRoutes.get("/orders/:id", async (c) => {
  try {
    const id = c.req.param("id");
    console.log(`Fetching order ${id}...`);
    
    const { data: order, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error("Error fetching order:", error);
      return c.json({ error: "Order not found" }, 404);
    }
    
    // Fetch items - try 'order_items' first, then 'ordersitems'
    let items = [];
    let itemsError = null;
    
    // Try standard name
    const result1 = await supabase
      .from('order_items')
      .select('*')
      .eq('order_id', id);
      
    if (result1.data && result1.data.length > 0) {
      items = result1.data;
    } else {
      // Try user suggested name
      const result2 = await supabase
        .from('ordersitems')
        .select('*')
        .eq('order_id', id);
        
      if (result2.data && result2.data.length > 0) {
        items = result2.data;
      } else {
        items = [];
        itemsError = result1.error || result2.error;
      }
    }
      
    if (itemsError) {
      console.warn("Error fetching order items:", itemsError);
    }
    
    // Enrich items with product names
    let enrichedItems = items || [];
    if (items && items.length > 0) {
      const productIds = items.map(i => i.product_id).filter(id => id !== 0 && id !== null);
      
      if (productIds.length > 0) {
        // Try to fetch products - if product_id is not found, it won't be in the result
        const { data: products, error: productsError } = await supabase
          .from('products')
          .select('id, product_name, variant_name')
          .in('id', productIds);
        
        if (productsError) {
          console.error('❌ Error fetching products for order items:', productsError);
        }
          
        if (products) {
          console.log('Enriching order items with product names:', { 
            itemsCount: items.length, 
            productsFound: products.length,
            sampleProduct: products[0]
          });
          
          enrichedItems = items.map(item => {
            // Ensure types match for comparison (convert both to String just in case)
            const product = products.find(p => String(p.id) === String(item.product_id));
            
            // Build full product name from variant_name and product_name
            let fullProductName = item.product_name || `محصول کد ${item.product_id}`;
            if (product) {
              const variantPart = product.variant_name || '';
              const productPart = product.product_name || '';
              fullProductName = variantPart 
                ? `${variantPart} ${productPart}`.trim() 
                : productPart || fullProductName;
              
              console.log(`Item ${item.product_id}: variant="${variantPart}", product="${productPart}", final="${fullProductName}"`);
            } else {
              console.log(`No product found for item ${item.product_id}`);
            }
            
            return {
              ...item,
              product_name: fullProductName
            };
          });
        }
      }
    }
    
    // Map JSON fields for the single order
    if (order) {
      // 1. Map Shipping Info
      let shippingInfo = order.shipping_info;
      if (typeof shippingInfo === 'string') {
        try { shippingInfo = JSON.parse(shippingInfo); } catch (e) {}
      }
      
      if (shippingInfo) {
        // Name
        const firstName = shippingInfo.address?.first_name || '';
        const lastName = shippingInfo.address?.last_name || '';
        if (firstName || lastName) {
          (order as any).customer_name = `${firstName} ${lastName}`.trim();
        }

        // Address
        const city = shippingInfo.address?.city || '';
        const state = shippingInfo.address?.state || '';
        // Check 'street' first, then 'address'
        const addrText = shippingInfo.address?.street || shippingInfo.address?.address || '';
        const postalCode = shippingInfo.address?.postal_code || '';
        
        const addressParts = [state, city, addrText].filter(Boolean);
        if (addressParts.length > 0) {
          (order as any).address = addressParts.join(' - ');
          if (postalCode) (order as any).address += ` (کد پستی: ${postalCode})`;
        }

        // Phone
        if (shippingInfo.contact?.mobile) {
          (order as any).phone = shippingInfo.contact.mobile;
        }
      }

      // 2. Map Status and Payment Status
      let paymentInfo = order.payment_info;
      if (typeof paymentInfo === 'string') {
        try { paymentInfo = JSON.parse(paymentInfo); } catch (e) {}
      }

      // Extract payment_status for frontend - prioritize payment_status field
      (order as any).payment_status = paymentInfo?.payment_status || paymentInfo?.status || 'pending';

      // ✅ Determine order status based on payment_status (orders table doesn't have 'status' column)
      const paymentStatus = paymentInfo?.payment_status || paymentInfo?.status || 'pending';
      
      if (['paid_zarinpal', 'paid_card', 'paid_manual'].includes(paymentStatus)) {
        (order as any).status = 'processing'; // پرداخت شده → در حال پردازش
      } else if (paymentStatus === 'unpaid_manual') {
        (order as any).status = 'cancelled'; // رد شده → لغو شده
      } else if (paymentStatus === 'awaiting_verification') {
        (order as any).status = 'pending'; // در انتظار تایید → معلق
      } else {
        (order as any).status = 'pending'; // همه چیز دیگر → معلق
      }
    }
    
    return c.json({ order, items: enrichedItems });
  } catch (error) {
    console.error("Error fetching order:", error);
    return c.json({ error: "Failed to fetch order" }, 500);
  }
});

// Get orders by phone number
orderRoutes.get("/orders/by-phone/:phone", async (c) => {
  try {
    const phone = c.req.param("phone");
    console.log(`Fetching orders for phone: ${phone}`);
    
    // Fetch all orders
    const { data: orders, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error("Error fetching orders:", error);
      return c.json({ error: "Failed to fetch orders" }, 500);
    }
    
    // Filter orders by phone number from shipping_info
    const phoneOrders = orders?.filter(order => {
      let shippingInfo = order.shipping_info;
      if (typeof shippingInfo === 'string') {
        try { shippingInfo = JSON.parse(shippingInfo); } catch (e) { return false; }
      }
      return shippingInfo?.contact?.mobile === phone;
    }) || [];
    
    // Fetch items for these orders
    if (phoneOrders.length > 0) {
      const orderIds = phoneOrders.map(o => o.id);
      
      let items = [];
      const { data: items1 } = await supabase
        .from('order_items')
        .select('order_id, product_id, quantity')
        .in('order_id', orderIds);
        
      if (items1 && items1.length > 0) {
        items = items1;
      } else {
        const { data: items2 } = await supabase
          .from('ordersitems')
          .select('order_id, product_id, quantity')
          .in('order_id', orderIds);
        if (items2) items = items2;
      }

      // Fetch product names
      let productsMap = new Map();
      if (items && items.length > 0) {
        const productIds = [...new Set(items.map(i => i.product_id).filter(id => id !== 0 && id !== null))];
        
        if (productIds.length > 0) {
          const { data: products } = await supabase
            .from('products')
            .select('id, product_name, variant_name')
            .in('id', productIds);
          
          if (products) {
            products.forEach(p => {
              const fullName = p.variant_name 
                ? `${p.variant_name} ${p.product_name}`.trim()
                : p.product_name;
              productsMap.set(String(p.id), fullName);
            });
          }
        }
      }
        
      // Enrich each order
      phoneOrders.forEach(order => {
        const orderItems = items?.filter(i => String(i.order_id) === String(order.id)) || [];
        (order as any).items_count = orderItems.length;
        (order as any).items = orderItems.map(item => ({
          product_name: productsMap.get(String(item.product_id)) || `محصول ${item.product_id}`,
          quantity: item.quantity
        }));

        // Map shipping info
        let shippingInfo = order.shipping_info;
        if (typeof shippingInfo === 'string') {
          try { shippingInfo = JSON.parse(shippingInfo); } catch (e) {}
        }
        
        if (shippingInfo) {
          const firstName = shippingInfo.address?.first_name || '';
          const lastName = shippingInfo.address?.last_name || '';
          if (firstName || lastName) {
            (order as any).customer_name = `${firstName} ${lastName}`.trim();
          }

          const city = shippingInfo.address?.city || '';
          const state = shippingInfo.address?.state || '';
          const addrText = shippingInfo.address?.street || shippingInfo.address?.address || '';
          const postalCode = shippingInfo.address?.postal_code || '';
          
          const addressParts = [state, city, addrText].filter(Boolean);
          if (addressParts.length > 0) {
            (order as any).address = addressParts.join(' - ');
            if (postalCode) (order as any).address += ` (کد پستی: ${postalCode})`;
          }

          if (shippingInfo.contact?.mobile) {
            (order as any).phone = shippingInfo.contact.mobile;
          }
        }

        // Map payment status
        let paymentInfo = order.payment_info;
        if (typeof paymentInfo === 'string') {
          try { paymentInfo = JSON.parse(paymentInfo); } catch (e) {}
        }

        (order as any).payment_status = paymentInfo?.payment_status || paymentInfo?.status || 'pending';

        const paymentStatus = paymentInfo?.payment_status || paymentInfo?.status || 'pending';
        
        if (['paid_zarinpal', 'paid_card', 'paid_manual'].includes(paymentStatus)) {
          (order as any).status = 'processing';
        } else if (paymentStatus === 'unpaid_manual') {
          (order as any).status = 'cancelled';
        } else if (paymentStatus === 'awaiting_verification') {
          (order as any).status = 'pending';
        } else {
          (order as any).status = 'pending';
        }
      });
    }
    
    return c.json({ orders: phoneOrders });
  } catch (error) {
    console.error("Error fetching orders by phone:", error);
    return c.json({ error: "Failed to fetch orders" }, 500);
  }
});

// Delete order
orderRoutes.delete("/orders/:id", async (c) => {
  try {
    const id = c.req.param("id");
    console.log(`Deleting order ${id}...`);

    // Delete items first (though cascade should handle it, let's be safe)
    await supabase.from('order_items').delete().eq('order_id', id);

    const { error } = await supabase
      .from('orders')
      .delete()
      .eq('id', id);

    if (error) {
      console.error("Supabase error deleting order:", error);
      return c.json({ error: "Failed to delete order" }, 500);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting order:", error);
    return c.json({ error: "Failed to delete order" }, 500);
  }
});

// Update order status
orderRoutes.put("/orders/:id/status", async (c) => {
  try {
    const id = c.req.param("id");
    const body = await c.req.json();
    const { status, payment_info } = body;
    
    console.log(`Updating order ${id} - status: ${status}, has payment_info: ${!!payment_info}`);

    // ✅ orders table doesn't have 'status' column - we only update payment_info
    const updateData: any = {};
    
    if (payment_info) {
        const parsedPaymentInfo = typeof payment_info === 'string' ? JSON.parse(payment_info) : payment_info;
        
        // Store payment_status inside the JSON instead of as a separate column
        if (parsedPaymentInfo.method === 'card-to-card') {
          if (parsedPaymentInfo.status === 'paid') {
            parsedPaymentInfo.payment_status = 'paid_card'; // کارت به کارت تایید شده
          } else if (parsedPaymentInfo.status === 'pending') {
            parsedPaymentInfo.payment_status = 'awaiting_verification'; // در انتظار تایید
          }
        } else if (parsedPaymentInfo.method === 'zarinpal' && parsedPaymentInfo.status === 'paid') {
          parsedPaymentInfo.payment_status = 'paid_zarinpal'; // زرین‌پال پرداخت شده
        }
        
        // If status was provided in the request, also update it inside payment_info
        if (status) {
          parsedPaymentInfo.order_status = status; // Store order status inside payment_info JSON
        }
        
        // Update with modified payment info
        updateData.payment_info = JSON.stringify(parsedPaymentInfo);
    }

    // Only update if we have something to update
    if (Object.keys(updateData).length === 0) {
      console.warn(`No data to update for order ${id}`);
      return c.json({ error: "No data to update" }, 400);
    }

    const { data, error } = await supabase
      .from('orders')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error("Supabase error updating order status:", error);
      return c.json({ error: "Failed to update order status", details: error.message }, 500);
    }

    console.log(`✅ Order ${id} updated successfully`);
    return c.json({ success: true, order: data });
  } catch (error) {
    console.error("Error updating order status:", error);
    return c.json({ error: "Failed to update order status" }, 500);
  }
});

// Create order manually (Admin)
orderRoutes.post("/admin/orders", async (c) => {
  try {
    const body = await c.req.json();
    const { shipping_info, items, total_amount, free_shipping, discount_amount, is_paid } = body;
    
    console.log("Creating manual order with items:", items.length);

    if (!shipping_info || !items || items.length === 0 || !total_amount) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Calculate shipping cost and totals
    const postPrice = free_shipping ? 0 : 80000;
    const subtotal = total_amount;
    const discountAmount = discount_amount || 0;
    const finalTotalAmount = subtotal + postPrice - discountAmount;

    // Determine payment status based on is_paid checkbox
    const paymentStatus = is_paid ? 'paid_manual' : 'unpaid_manual';

    // Generate unique bigint ID for order
    const orderId = Date.now();

    // Insert order with correct field names matching schema
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        id: orderId,
        user_id: null,
        created_at: new Date().toISOString(),
        shipping_info: typeof shipping_info === 'string' ? shipping_info : JSON.stringify(shipping_info),
        payment_info: JSON.stringify({
          method: 'manual',
          status: paymentStatus
        }),
        notes: JSON.stringify({
          created_by: 'admin',
          type: 'manual_order'
        }),
        metadata: JSON.stringify({
          free_shipping: free_shipping
        }),
        subtotal: subtotal,
        post_price: postPrice,
        discount_amount: discountAmount,
        total_amount: finalTotalAmount
      })
      .select()
      .single();

    if (orderError) {
      console.error("Error creating order:", orderError);
      return c.json({ error: "Failed to create order", details: orderError.message }, 500);
    }

    // Get next ID for ordersitems
    const { data: maxIdResult } = await supabase
      .from('ordersitems')
      .select('id')
      .order('id', { ascending: false })
      .limit(1);
    
    let nextItemId = maxIdResult && maxIdResult.length > 0 ? maxIdResult[0].id + 1 : 1;

    // Insert order items with correct field names matching schema
    const orderItems = items.map((item: any) => {
      const productId = parseInt(item.product_id);
      console.log(`📦 Admin order item: product_id="${item.product_id}", parsed=${productId}`);
      return {
        id: nextItemId++,
        order_id: orderId,
        product_id: productId,
        unit_price: item.price,
        quantity: item.quantity
      };
    });
    
    console.log(`💾 Inserting ${orderItems.length} admin order items:`, orderItems.map(i => `ID=${i.product_id}`).join(', '));

    const { error: itemsError } = await supabase
      .from('ordersitems')
      .insert(orderItems);

    if (itemsError) {
      console.error("Error creating order items:", itemsError);
      // Rollback: delete the order
      await supabase.from('orders').delete().eq('id', orderId);
      return c.json({ error: "Failed to create order items", details: itemsError.message }, 500);
    }

    console.log(`Manual order ${orderId} created successfully with ${items.length} items`);
    return c.json({ success: true, orderId: orderId, order: order });
  } catch (error) {
    console.error("Error creating manual order:", error);
    return c.json({ error: "Failed to create manual order" }, 500);
  }
});

// Update order (Admin)
orderRoutes.put("/admin/orders/:orderId", async (c) => {
  try {
    const orderId = c.req.param("orderId");
    const body = await c.req.json();
    const { shipping_info, items, total_amount, free_shipping, discount_amount, is_paid } = body;
    
    console.log(`Updating order ${orderId} with items:`, items.length);

    if (!shipping_info || !items || items.length === 0 || !total_amount) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Calculate shipping cost and totals
    const postPrice = free_shipping ? 0 : 80000;
    const subtotal = total_amount;
    const discountAmount = discount_amount || 0;
    const finalTotalAmount = subtotal + postPrice - discountAmount;

    // Determine payment status based on is_paid checkbox
    const paymentStatus = is_paid ? 'paid_manual' : 'unpaid_manual';

    // Update order with correct field names matching schema
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .update({
        shipping_info: typeof shipping_info === 'string' ? shipping_info : JSON.stringify(shipping_info),
        payment_info: JSON.stringify({
          method: 'manual',
          status: paymentStatus,
          payment_status: paymentStatus
        }),
        metadata: JSON.stringify({
          free_shipping: free_shipping,
          updated_by: 'admin',
          updated_at: new Date().toISOString()
        }),
        subtotal: subtotal,
        post_price: postPrice,
        discount_amount: discountAmount,
        total_amount: finalTotalAmount
      })
      .eq('id', orderId)
      .select()
      .single();

    if (orderError) {
      console.error("Error updating order:", orderError);
      return c.json({ error: "Failed to update order", details: orderError.message }, 500);
    }

    // Delete existing order items
    const { error: deleteError } = await supabase
      .from('ordersitems')
      .delete()
      .eq('order_id', orderId);

    if (deleteError) {
      console.error("Error deleting old order items:", deleteError);
      return c.json({ error: "Failed to delete old order items", details: deleteError.message }, 500);
    }

    // Get next ID for ordersitems
    const { data: maxIdResult } = await supabase
      .from('ordersitems')
      .select('id')
      .order('id', { ascending: false })
      .limit(1);
    
    let nextItemId = maxIdResult && maxIdResult.length > 0 ? maxIdResult[0].id + 1 : 1;

    // Insert new order items with correct field names matching schema
    const orderItems = items.map((item: any) => {
      const productId = parseInt(item.product_id);
      console.log(`📦 Updated order item: product_id="${item.product_id}", parsed=${productId}`);
      return {
        id: nextItemId++,
        order_id: parseInt(orderId),
        product_id: productId,
        unit_price: item.price,
        quantity: item.quantity
      };
    });
    
    console.log(`💾 Inserting ${orderItems.length} updated order items:`, orderItems.map(i => `ID=${i.product_id}`).join(', '));

    const { error: itemsError } = await supabase
      .from('ordersitems')
      .insert(orderItems);

    if (itemsError) {
      console.error("Error creating new order items:", itemsError);
      return c.json({ error: "Failed to create new order items", details: itemsError.message }, 500);
    }

    console.log(`Order ${orderId} updated successfully with ${items.length} items`);
    return c.json({ success: true, orderId: orderId, order: order });
  } catch (error) {
    console.error("Error updating order:", error);
    return c.json({ error: "Failed to update order" }, 500);
  }
});

export default orderRoutes;