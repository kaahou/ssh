import { Hono } from "npm:hono";
import { supabase } from "./db.ts";
import * as kv from "./kv_store.tsx";

const authRoutes = new Hono();

// Send SMS via Niazpardaz
authRoutes.post("/send-otp", async (c) => {
  try {
    const body = await c.req.json();
    const { phone } = body;
    
    if (!phone || phone.length < 11) {
      return c.json({ error: "شماره مبایل معتبر نیست" }, 400);
    }
    
    // Generate 6-digit OTP
    let otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Store OTP with 2 minutes expiration (matching frontend timer)
    const otpData = {
      code: otpCode,
      expiresAt: Date.now() + 2 * 60 * 1000, // 2 minutes
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`otp:${phone}`, otpData);
    console.log(`OTP ${otpCode} stored for phone ${phone} (expires in 10 minutes)`);
    
    // Send SMS via Niazpardaz
    const username = Deno.env.get('NIAZPARDAZ_USERNAME');
    const password = Deno.env.get('NIAZPARDAZ_PASSWORD');
    const fromNumber = Deno.env.get('NIAZPARDAZ_FROM_NUMBER');
    
    console.log(`Checking Niazpardaz credentials - Username: ${username ? 'SET' : 'NOT SET'}, Password: ${password ? 'SET' : 'NOT SET'}, From: ${fromNumber ? 'SET' : 'NOT SET'}`);
    
    let smsSuccess = false;
    let smsError = null;
    
    if (username && password && fromNumber) {
      const smsText = `کد تایید نورسا: ${otpCode}`;
      
      console.log(`Attempting to send OTP via Niazpardaz to ${phone}...`);
      
      try {
        // Niazpardaz API - Try multiple endpoint formats
        
        // Method 1: Standard format (current)
        let smsUrl = `https://panel.niazpardaz-sms.com/SMSInOutBox/SendSms`;
        smsUrl += `?userName=${encodeURIComponent(username)}`;
        smsUrl += `&password=${encodeURIComponent(password)}`;
        smsUrl += `&fromNumber=${encodeURIComponent(fromNumber)}`;
        smsUrl += `&toNumbers=${encodeURIComponent(phone)}`;
        smsUrl += `&messageContent=${encodeURIComponent(smsText)}`;
        smsUrl += `&isFlash=false`;
        
        let smsResponse = await fetch(smsUrl);
        let smsResult = await smsResponse.text();
        
        let apiResponseDetails = {
          method: 'Method 1 (userName/fromNumber/toNumbers)',
          url: smsUrl,
          status: smsResponse.status,
          statusText: smsResponse.statusText,
          headers: Object.fromEntries(smsResponse.headers.entries()),
          body: smsResult,
        };
        
        // Check if response indicates invalid parameters
        const bodyLower = smsResult.toLowerCase();
        const hasInvalidParams = bodyLower.includes('پارامتر') || 
                                bodyLower.includes('معتبر نیست') ||
                                bodyLower.includes('invalid');
        
        // Method 2: Alternative parameter names (username/from/to/text)
        if (!smsResponse.ok || hasInvalidParams) {
          console.log('Method 1 failed or invalid params, trying Method 2...');
          
          smsUrl = `https://panel.niazpardaz-sms.com/SMSInOutBox/SendSms`;
          smsUrl += `?username=${encodeURIComponent(username)}`;
          smsUrl += `&password=${encodeURIComponent(password)}`;
          smsUrl += `&from=${encodeURIComponent(fromNumber)}`;
          smsUrl += `&to=${encodeURIComponent(phone)}`;
          smsUrl += `&text=${encodeURIComponent(smsText)}`;
          
          smsResponse = await fetch(smsUrl);
          smsResult = await smsResponse.text();
          
          apiResponseDetails = {
            method: 'Method 2 (username/from/to/text)',
            url: smsUrl,
            status: smsResponse.status,
            statusText: smsResponse.statusText,
            headers: Object.fromEntries(smsResponse.headers.entries()),
            body: smsResult,
          };
        }
        
        // Check if the response body indicates success
        const finalBodyLower = smsResult.toLowerCase();
        const hasError = finalBodyLower.includes('error') || 
                        finalBodyLower.includes('exception') || 
                        finalBodyLower.includes('failed') ||
                        finalBodyLower.includes('null reference') ||
                        finalBodyLower.includes('پارامتر') ||
                        finalBodyLower.includes('معتبر نیست');
        
        if (smsResponse.ok && smsResponse.status === 200 && !hasError) {
          smsSuccess = true;
          console.log(`✅ SMS sent successfully to ${phone}`);
        } else {
          smsError = `HTTP ${smsResponse.status}: ${smsResult}`;
          console.error(`❌ SMS API Error: Status ${smsResponse.status}, Response: ${smsResult}`);
        }
        
        return c.json({ 
          success: true, 
          message: smsSuccess ? "کد تایید ارسال شد" : "کد تایید ذخیره شد (خطا در ارسال پیامک)",
          debug: { 
            otpCode, 
            smsSuccess,
            smsError: smsError || null,
            apiResponse: apiResponseDetails,
            note: "کد OTP در console نمایش داده می‌شود."
          }
        });
      } catch (fetchError) {
        smsError = String(fetchError);
        console.error("❌ Niazpardaz API Error:", fetchError instanceof Error ? fetchError.message : fetchError);
        
        return c.json({ 
          success: true, 
          message: "کد تایید ذخیره شد (خطا در ارسال پیامک)",
          debug: { 
            otpCode, 
            smsSuccess: false,
            smsError,
            note: "کد OTP در console نمایش داده می‌شود."
          }
        });
      }
    } else {
      smsError = "Missing credentials";
      console.error("Missing Niazpardaz credentials");
    }
    
    return c.json({ 
      success: true, 
      message: smsSuccess ? "کد تایید ارسال شد" : "کد تایید ذخیره شد (برای تست از console استفاده کنید)",
      debug: { 
        otpCode, 
        smsSuccess,
        smsError: smsError || null,
        note: "کد OTP در console نمایش داده می‌شود."
      }
    });
  } catch (error) {
    console.error("Error in send-otp endpoint:", error);
    return c.json({ error: "خطای سرور در ارسال کد تایید", details: String(error) }, 500);
  }
});

// Verify OTP for login/register
authRoutes.post("/verify-login-otp", async (c) => {
  try {
    const body = await c.req.json();
    const { phone, otpCode } = body;
    
    console.log("Verify login OTP request received for phone:", phone);
    
    if (!phone || !otpCode) {
      return c.json({ error: "شماره موبایل و کد تایید الزامی است" }, 400);
    }
    
    // Get stored OTP
    const storedOtpData = await kv.get(`otp:${phone}`);
    
    if (!storedOtpData) {
      return c.json({ error: "کد تایید منقضی شده است. لطفاً مجدداً درخواست دهید" }, 400);
    }
    
    // Check if OTP is expired
    if (Date.now() > storedOtpData.expiresAt) {
      await kv.del(`otp:${phone}`);
      return c.json({ error: "کد تایید منقضی شده است. لطفاً مجدداً درخواست دهید" }, 400);
    }
    
    // Verify OTP - Convert both to strings for comparison
    console.log(`🔍 OTP Verification Debug (Auth):`);
    console.log(`   Received OTP: "${otpCode}" (type: ${typeof otpCode})`);
    console.log(`   Stored OTP: "${storedOtpData.code}" (type: ${typeof storedOtpData.code})`);
    
    const receivedOtpStr = String(otpCode).trim();
    const storedOtpStr = String(storedOtpData.code).trim();
    
    if (storedOtpStr !== receivedOtpStr) {
      console.error(`❌ OTP mismatch: "${storedOtpStr}" !== "${receivedOtpStr}"`);
      return c.json({ error: "کد تایید اشتباه است" }, 400);
    }
    
    console.log(`✅ OTP verified successfully`);
    
    // OTP is valid, delete it
    await kv.del(`otp:${phone}`);
    
    // Check if user exists in KV store
    let user = await kv.get(`user:${phone}`);
    let isNewUser = false;
    
    if (!user) {
      isNewUser = true;
      user = {
        phone: phone,
        created_at: new Date().toISOString(),
      };
      await kv.set(`user:${phone}`, user);
    }
    
    // Try to save/update user in Supabase users table
    try {
      const { data: existingUser, error: checkError } = await supabase
        .from('users')
        .select('*')
        .eq('phone', phone)
        .single();
      
      let userId = null;
      
      if (!existingUser) {
        const generatedUserId = Date.now();
        const { data: newUser, error: insertError } = await supabase
          .from('users')
          .insert({
            user_id: generatedUserId,
            phone: phone,
            created_at: new Date().toISOString(),
            status: 'active'
          })
          .select()
          .single();
        
        if (!insertError) {
          userId = newUser.user_id;
          isNewUser = true;
          return c.json({ 
            success: true, 
            isNewUser: true,
            user: newUser,
            message: "حساب کاربری شما ایجاد شد" 
          });
        }
      } else {
        userId = existingUser.user_id;
        await supabase
          .from('users')
          .update({ last_seen_at: new Date().toISOString() })
          .eq('user_id', userId);
        
        return c.json({ 
          success: true, 
          isNewUser: false,
          user: existingUser,
          message: "خوش آمدید" 
        });
      }
      
      return c.json({ 
        success: true, 
        isNewUser,
        user: {
          user_id: userId,
          phone: phone,
        },
        message: isNewUser ? "حساب کاربری شما ایجاد شد" : "خوش آمدید" 
      });
    } catch (e) {
      console.warn("Error managing user in Supabase:", e);
      return c.json({ 
        success: true, 
        isNewUser,
        user: {
          id: null,
          phone_number: phone,
        },
        message: isNewUser ? "حساب کاربری شما ایجاد شد" : "خوش آمدید" 
      });
    }
  } catch (error) {
    console.error("Error verifying login OTP:", error);
    return c.json({ error: "تایید کد با خطا مواجه شد", details: String(error) }, 500);
  }
});

export default authRoutes;