# 🔧 Schema Error Fix - 'status' Column

## ❌ خطا
```
Supabase update error: {
  code: "PGRST204",
  details: null,
  hint: null,
  message: "Could not find the 'status' column of 'orders' in the schema cache"
}
```

## 🔍 علت

جدول `orders` در Postgres **فاقد ستون `status`** است. تمام اطلاعات وضعیت سفارش داخل فیلدهای JSON ذخیره می‌شوند:

### ساختار جدول Orders:
```sql
CREATE TABLE orders (
  id BIGINT PRIMARY KEY,
  user_id TEXT,
  created_at TIMESTAMP,
  shipping_info JSONB,      -- ✅ اطلاعات مشتری و آدرس
  payment_info JSONB,        -- ✅ اطلاعات پرداخت و وضعیت
  notes JSONB,               -- ✅ یادداشت‌ها
  metadata JSONB,            -- ✅ متادیتا
  subtotal NUMERIC,
  post_price NUMERIC,
  discount_amount NUMERIC,
  total_amount NUMERIC
);
-- ❌ بدون ستون 'status'
```

### ساختار payment_info JSON:
```json
{
  "method": "zarinpal" | "card-to-card" | "manual",
  "status": "pending" | "paid" | "failed",
  "payment_status": "pending" | "paid_zarinpal" | "paid_card" | "paid_manual" | "unpaid_manual" | "awaiting_verification",
  "tracking_code": "...",
  "verified_at": "...",
  "rejected_at": "..."
}
```

## ✅ راه‌حل

### 1️⃣ در `admin_routes.ts` - حذف آپدیت ستون status

**قبل:**
```typescript
const { error: updateError } = await supabase
  .from('orders')
  .update({ 
    payment_info: paymentInfoString,
    status: action === 'approve' ? 'processing' : 'cancelled'  // ❌ خطا
  })
  .eq('id', orderId);
```

**بعد:**
```typescript
const { error: updateError } = await supabase
  .from('orders')
  .update({ 
    payment_info: paymentInfoString  // ✅ فقط payment_info
  })
  .eq('id', orderId);
```

### 2️⃣ در `order_routes.ts` - محاسبه status از payment_status

**قبل:**
```typescript
if (paymentInfo?.status && paymentInfo.status.includes('paid') && (!order.status || order.status === 'pending')) {
  (order as any).status = 'processing';  // ❌ بررسی order.status که وجود ندارد
}
```

**بعد:**
```typescript
// ✅ Determine order status based on payment_status
const paymentStatus = paymentInfo?.payment_status || paymentInfo?.status || 'pending';

if (['paid_zarinpal', 'paid_card', 'paid_manual'].includes(paymentStatus)) {
  (order as any).status = 'processing'; // پرداخت شده → در حال پردازش
} else if (paymentStatus === 'unpaid_manual') {
  (order as any).status = 'cancelled'; // رد شده → لغو شده
} else if (paymentStatus === 'awaiting_verification') {
  (order as any).status = 'pending'; // در انتظار تایید → معلق
} else {
  (order as any).status = 'pending'; // همه چیز دیگر → معلق
}
```

### 3️⃣ در `PUT /orders/:id/status` - آپدیت فقط payment_info

**قبل:**
```typescript
const updateData: any = { status };  // ❌ خطا
if (payment_info) {
  updateData.payment_info = JSON.stringify(payment_info);
}
```

**بعد:**
```typescript
// ✅ orders table doesn't have 'status' column
const updateData: any = {};

if (payment_info) {
  const parsedPaymentInfo = typeof payment_info === 'string' ? JSON.parse(payment_info) : payment_info;
  
  // Store order status inside payment_info JSON
  if (status) {
    parsedPaymentInfo.order_status = status;
  }
  
  updateData.payment_info = JSON.stringify(parsedPaymentInfo);
}
```

## 📊 نقشه وضعیت‌ها (Status Mapping)

| Payment Status | Order Status (Computed) | نمایش در Frontend |
|---------------|------------------------|-------------------|
| `pending` | `pending` | "در انتظار" |
| `awaiting_verification` | `pending` | "در انتظار تایید" |
| `paid_zarinpal` | `processing` | "در حال پردازش" |
| `paid_card` | `processing` | "در حال پردازش" |
| `paid_manual` | `processing` | "در حال پردازش" |
| `unpaid_manual` | `cancelled` | "لغو شده" |

## 🔧 فایل‌های تغییر یافته

1. ✅ `/supabase/functions/server/admin_routes.ts`
   - حذف `status` از update در payment verification endpoint

2. ✅ `/supabase/functions/server/order_routes.ts`
   - محاسبه `order.status` از `payment_info.payment_status`
   - اصلاح در `GET /orders` (لیست سفارشات)
   - اصلاح در `GET /orders/:id` (جزئیات سفارش)
   - اصلاح در `PUT /orders/:id/status` (آپدیت وضعیت)

## 🧪 تست

### Test 1: تایید پرداخت کارت به کارت
```bash
curl -X POST \
  https://YOUR_PROJECT.supabase.co/functions/v1/make-server-fbc72c25/admin/orders/ORDER_ID/payment-status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{"action": "approve"}'
```

**نتیجه مورد انتظار:**
```json
{
  "success": true,
  "message": "پرداخت تایید شد",
  "payment_status": "paid_card"
}
```

### Test 2: دریافت لیست سفارشات
```bash
curl https://YOUR_PROJECT.supabase.co/functions/v1/make-server-fbc72c25/orders \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

**نتیجه مورد انتظار:**
```json
{
  "orders": [
    {
      "id": "...",
      "payment_status": "paid_card",
      "status": "processing",  // ✅ محاسبه شده از payment_status
      ...
    }
  ]
}
```

### Test 3: دریافت جزئیات سفارش
```bash
curl https://YOUR_PROJECT.supabase.co/functions/v1/make-server-fbc72c25/orders/ORDER_ID \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

**نتیجه مورد انتظار:**
```json
{
  "order": {
    "id": "...",
    "payment_status": "awaiting_verification",
    "status": "pending",  // ✅ محاسبه شده
    ...
  },
  "items": [...]
}
```

## 📝 نکات مهم

1. **هیچ‌وقت سعی نکنید ستون `status` را مستقیماً در جدول `orders` آپدیت کنید**
   - این ستون وجود ندارد
   - همه اطلاعات وضعیت در `payment_info` JSON هستند

2. **Frontend انتظار دارد که `status` و `payment_status` به صورت جداگانه بیایند**
   - در GET endpoints، این فیلدها را از `payment_info` استخراج کنید
   - `payment_status`: مستقیماً از JSON
   - `status`: محاسبه شده بر اساس `payment_status`

3. **برای ذخیره اطلاعات اضافی از `notes` یا `metadata` استفاده کنید**
   - این فیلدها JSONB هستند و می‌توانید هر چیزی در آنها ذخیره کنید

4. **payment_info.status vs payment_info.payment_status**
   - `status`: وضعیت کلی پرداخت (paid/pending/failed)
   - `payment_status`: وضعیت دقیق با جزئیات روش پرداخت

## 🎯 نتیجه

**قبل از Fix:**
```
❌ Error updating payment status: Failed to update payment status
❌ Supabase error: Could not find the 'status' column
```

**بعد از Fix:**
```
✅ Payment status updated successfully
✅ Orders fetched with computed status
✅ Frontend displays correct status badges
```

---

**وضعیت**: ✅ **FIXED**  
**تاریخ**: 2024-12-27  
**Version**: Schema Fix v1
