
export interface ZarinpalRequest {
  merchant_id: string;
  amount: number;
  description: string;
  callback_url: string;
  metadata?: {
    mobile?: string;
    email?: string;
    [key: string]: any;
  };
}

export interface ZarinpalVerify {
  merchant_id: string;
  amount: number;
  authority: string;
}

export async function requestPayment(data: ZarinpalRequest) {
  const url = "https://api.zarinpal.com/pg/v4/payment/request.json";
  
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();
    
    if (result.data && result.data.code === 100) {
      return {
        success: true,
        authority: result.data.authority,
        payment_url: `https://www.zarinpal.com/pg/StartPay/${result.data.authority}`,
      };
    } else {
      return {
        success: false,
        errors: result.errors,
        code: result.data?.code
      };
    }
  } catch (error) {
    console.error("Zarinpal Request Error:", error);
    throw error;
  }
}

export async function verifyPayment(data: ZarinpalVerify) {
  const url = "https://api.zarinpal.com/pg/v4/payment/verify.json";

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    // Code 100 means success
    // Code 101 means verified (already verified)
    if (result.data && (result.data.code === 100 || result.data.code === 101)) {
      return {
        success: true,
        ref_id: result.data.ref_id,
        card_pan: result.data.card_pan,
        code: result.data.code
      };
    } else {
      return {
        success: false,
        errors: result.errors,
        code: result.data?.code
      };
    }
  } catch (error) {
    console.error("Zarinpal Verify Error:", error);
    throw error;
  }
}
