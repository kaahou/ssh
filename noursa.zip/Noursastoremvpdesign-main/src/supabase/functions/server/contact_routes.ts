import { Hono } from "npm:hono";
import { createClient } from "npm:@supabase/supabase-js@2.39.7";

const contactRoutes = new Hono();

// Create Supabase client
const getSupabaseClient = () => {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );
};

// POST /make-server-fbc72c25/contact-messages - Create new contact message
contactRoutes.post("/contact-messages", async (c) => {
  try {
    const body = await c.req.json();
    const { full_name, email, phone_number, subject, message } = body;

    // Validate required fields
    if (!full_name || !phone_number || !subject || !message) {
      return c.json(
        { 
          error: "Missing required fields",
          required: ["full_name", "phone_number", "subject", "message"]
        },
        400
      );
    }

    const supabase = getSupabaseClient();

    // Insert contact message into database
    const { data, error } = await supabase
      .from("contact_messages")
      .insert({
        full_name,
        email: email || null,
        phone_number,
        subject,
        message,
        status: 'new'
      })
      .select()
      .single();

    if (error) {
      console.error("Error creating contact message:", error);
      return c.json(
        { error: "Failed to submit contact message", details: error.message },
        500
      );
    }

    console.log("✅ Contact message created successfully:", data.id);

    return c.json({
      success: true,
      message: "پیام شما با موفقیت ثبت شد",
      data
    }, 201);

  } catch (error) {
    console.error("Error in POST /contact-messages:", error);
    return c.json(
      { 
        error: "Internal server error while submitting contact message",
        details: error instanceof Error ? error.message : String(error)
      },
      500
    );
  }
});

// GET /make-server-fbc72c25/contact-messages/unread-count - Get count of unread messages
contactRoutes.get("/contact-messages/unread-count", async (c) => {
  try {
    const supabase = getSupabaseClient();

    // Count messages with status 'new'
    const { count, error } = await supabase
      .from("contact_messages")
      .select("*", { count: 'exact', head: true })
      .eq("status", "new");

    if (error) {
      console.error("Error getting unread count:", error);
      return c.json(
        { error: "Failed to get unread count", details: error.message },
        500
      );
    }

    return c.json({
      success: true,
      count: count || 0
    });

  } catch (error) {
    console.error("Error in GET /contact-messages/unread-count:", error);
    return c.json(
      { 
        error: "Internal server error while getting unread count",
        details: error instanceof Error ? error.message : String(error)
      },
      500
    );
  }
});

// GET /make-server-fbc72c25/contact-messages - Get all contact messages (admin only)
contactRoutes.get("/contact-messages", async (c) => {
  try {
    const supabase = getSupabaseClient();

    // Get all contact messages ordered by created_at descending
    const { data, error } = await supabase
      .from("contact_messages")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error getting contact messages:", error);
      return c.json(
        { error: "Failed to get contact messages", details: error.message },
        500
      );
    }

    return c.json({
      success: true,
      data
    });

  } catch (error) {
    console.error("Error in GET /contact-messages:", error);
    return c.json(
      { 
        error: "Internal server error while getting contact messages",
        details: error instanceof Error ? error.message : String(error)
      },
      500
    );
  }
});

// PATCH /make-server-fbc72c25/contact-messages/:id - Update message status
contactRoutes.patch("/contact-messages/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const body = await c.req.json();
    const { status, notes } = body;

    const supabase = getSupabaseClient();

    const updateData: any = {};
    if (status) updateData.status = status;
    if (notes !== undefined) updateData.notes = notes;

    const { data, error } = await supabase
      .from("contact_messages")
      .update(updateData)
      .eq("id", id)
      .select()
      .single();

    if (error) {
      console.error("Error updating contact message:", error);
      return c.json(
        { error: "Failed to update contact message", details: error.message },
        500
      );
    }

    return c.json({
      success: true,
      data
    });

  } catch (error) {
    console.error("Error in PATCH /contact-messages/:id:", error);
    return c.json(
      { 
        error: "Internal server error while updating contact message",
        details: error instanceof Error ? error.message : String(error)
      },
      500
    );
  }
});

export default contactRoutes;
