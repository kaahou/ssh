import { Hono } from "npm:hono";
import { supabase } from "./db.ts";

const articleRoutes = new Hono();

// Get all articles
articleRoutes.get("/articles", async (c) => {
  try {
    console.log("📰 Fetching articles from contents table...");
    
    const { data: articles, error } = await supabase
      .from('contents')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error("❌ Supabase error fetching articles:", error);
      return c.json({ articles: [] });
    }
    
    console.log(`✅ Found ${articles?.length || 0} articles from contents table`);
    return c.json({ articles: articles || [] });
  } catch (error) {
    console.error("❌ Error fetching articles:", error);
    return c.json({ articles: [] });
  }
});

// Create new article
articleRoutes.post("/articles", async (c) => {
  try {
    const body = await c.req.json();
    console.log("📝 Creating new article:", body.title);

    // Validate required fields
    if (!body.title || !body.slug || !body.content) {
      return c.json({ error: "Missing required fields: title, slug, content" }, 400);
    }

    // Generate unique ID
    const contentId = Date.now();
    
    const article = {
      content_id: contentId,
      slug: body.slug,
      page_titel: body.page_titel || body.title,
      title: body.title,
      content: body.content,
      featured_image: body.featured_image || null,
      created_at: new Date().toISOString(),
      status: body.status || 'published',
      meta_description: body.meta_description || null,
      keywords: body.keywords || null,
    };

    // Insert into contents table
    const { data: createdArticle, error } = await supabase
      .from('contents')
      .insert([article])
      .select()
      .single();

    if (error) {
      console.error("❌ Supabase error creating article:", error);
      return c.json({ error: "Failed to create article", details: error.message }, 500);
    }

    console.log("✅ Article created successfully:", contentId);
    return c.json({ article: createdArticle }, 201);
  } catch (error) {
    console.error("❌ Error creating article:", error);
    return c.json({ error: "Failed to create article", details: String(error) }, 500);
  }
});

// Get single article by slug
articleRoutes.get("/articles/:slug", async (c) => {
  try {
    const slug = c.req.param("slug");
    console.log(`🔍 Fetching article ${slug} from contents table...`);
    
    const { data: article, error } = await supabase
      .from('contents')
      .select('*')
      .eq('slug', slug)
      .single();
    
    if (error) {
      console.error("❌ Supabase error fetching article:", error);
      return c.json({ error: "Failed to fetch article from database" }, 500);
    }
    
    if (!article) {
      return c.json({ error: "Article not found" }, 404);
    }
    
    console.log("✅ Article found:", article.content_id);
    return c.json({ article });
  } catch (error) {
    console.error("❌ Error fetching article:", error);
    return c.json({ error: "Failed to fetch article", details: String(error) }, 500);
  }
});

// Get single article by ID
articleRoutes.get("/articles/by-id/:id", async (c) => {
  try {
    const id = c.req.param("id");
    console.log(`🔍 Fetching article by ID ${id} from contents table...`);
    
    const { data: article, error } = await supabase
      .from('contents')
      .select('*')
      .eq('content_id', id)
      .single();
    
    if (error) {
      console.error("❌ Supabase error fetching article:", error);
      return c.json({ error: "Failed to fetch article from database" }, 500);
    }
    
    if (!article) {
      return c.json({ error: "Article not found" }, 404);
    }
    
    console.log("✅ Article found:", article.content_id);
    return c.json({ article });
  } catch (error) {
    console.error("❌ Error fetching article:", error);
    return c.json({ error: "Failed to fetch article", details: String(error) }, 500);
  }
});

// Update article
articleRoutes.patch("/articles/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const body = await c.req.json();
    console.log(`📝 Updating article ${id}:`, body.title);

    // Validate required fields
    if (!body.title || !body.slug || !body.content) {
      return c.json({ error: "Missing required fields: title, slug, content" }, 400);
    }

    const updateData = {
      slug: body.slug,
      page_titel: body.page_titel || body.title,
      title: body.title,
      content: body.content,
      featured_image: body.featured_image || null,
      updated_at: new Date().toISOString(),
      status: body.status || 'published',
      meta_description: body.meta_description || null,
      keywords: body.keywords || null,
    };

    // Update in contents table
    const { data: updatedArticle, error } = await supabase
      .from('contents')
      .update(updateData)
      .eq('content_id', id)
      .select()
      .single();

    if (error) {
      console.error("❌ Supabase error updating article:", error);
      return c.json({ error: "Failed to update article", details: error.message }, 500);
    }

    console.log("✅ Article updated successfully:", id);
    return c.json({ article: updatedArticle });
  } catch (error) {
    console.error("❌ Error updating article:", error);
    return c.json({ error: "Failed to update article", details: String(error) }, 500);
  }
});

// Delete article
articleRoutes.delete("/articles/:id", async (c) => {
  try {
    const id = c.req.param("id");
    console.log(`🗑️ Deleting article ${id}...`);

    const { error } = await supabase
      .from('contents')
      .delete()
      .eq('content_id', id);

    if (error) {
      console.error("❌ Supabase error deleting article:", error);
      return c.json({ error: "Failed to delete article", details: error.message }, 500);
    }

    console.log("✅ Article deleted successfully");
    return c.json({ success: true });
  } catch (error) {
    console.error("❌ Error deleting article:", error);
    return c.json({ error: "Failed to delete article", details: String(error) }, 500);
  }
});

export default articleRoutes;