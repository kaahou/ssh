// Validation Utilities

import type { CreateOrderRequest, ConsultationFormData } from './types.ts';
import { ERROR_MESSAGES } from './constants.ts';

// ==================== Phone Validation ====================
export function isValidPhone(phone: string): boolean {
  // Iranian phone numbers: 09xx xxx xxxx
  const phoneRegex = /^09\d{9}$/;
  return phoneRegex.test(phone);
}

export function normalizePhone(phone: string): string {
  // Remove spaces, dashes, and other non-digit characters
  return phone.replace(/\D/g, '');
}

// ==================== National Code Validation ====================
export function isValidNationalCode(code: string): boolean {
  if (!code || code.length !== 10) return false;
  
  const check = parseInt(code[9]);
  let sum = 0;
  
  for (let i = 0; i < 9; i++) {
    sum += parseInt(code[i]) * (10 - i);
  }
  
  const remainder = sum % 11;
  
  return (remainder < 2 && check === remainder) || 
         (remainder >= 2 && check === 11 - remainder);
}

// ==================== Email Validation ====================
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// ==================== Order Validation ====================
export function validateOrderRequest(data: CreateOrderRequest): { valid: boolean; error?: string } {
  if (!data.customerName || data.customerName.trim().length < 2) {
    return { valid: false, error: 'نام و نام خانوادگی معتبر نیست' };
  }
  
  if (!isValidPhone(data.phone)) {
    return { valid: false, error: 'شماره موبایل معتبر نیست' };
  }
  
  if (data.email && !isValidEmail(data.email)) {
    return { valid: false, error: 'ایمیل معتبر نیست' };
  }
  
  if (!data.state || data.state.trim().length < 2) {
    return { valid: false, error: 'استان معتبر نیست' };
  }
  
  if (!data.city || data.city.trim().length < 2) {
    return { valid: false, error: 'شهر معتبر نیست' };
  }
  
  if (!data.street || data.street.trim().length < 10) {
    return { valid: false, error: 'آدرس معتبر نیست (حداقل 10 کاراکتر)' };
  }
  
  if (!data.postalCode || data.postalCode.length !== 10) {
    return { valid: false, error: 'کد پستی باید 10 رقم باشد' };
  }
  
  if (!data.items || data.items.length === 0) {
    return { valid: false, error: ERROR_MESSAGES.EMPTY_CART };
  }
  
  // Validate each item
  for (const item of data.items) {
    if (!item.product_id || !item.name || !item.price || !item.quantity) {
      return { valid: false, error: 'اطلاعات محصولات ناقص است' };
    }
    
    if (item.quantity <= 0) {
      return { valid: false, error: 'تعداد محصولات باید بیشتر از صفر باشد' };
    }
    
    if (item.price <= 0) {
      return { valid: false, error: 'قیمت محصولات نامعتبر است' };
    }
  }
  
  return { valid: true };
}

// ==================== Consultation Validation ====================
export function validateConsultationData(data: ConsultationFormData): { valid: boolean; error?: string } {
  if (!data.first_name || data.first_name.trim().length < 2) {
    return { valid: false, error: 'نام معتبر نیست' };
  }
  
  if (!data.last_name || data.last_name.trim().length < 2) {
    return { valid: false, error: 'نام خانوادگی معتبر نیست' };
  }
  
  if (!isValidNationalCode(data.national_code)) {
    return { valid: false, error: 'کد ملی معتبر نیست' };
  }
  
  if (!data.birth_year || parseInt(data.birth_year) < 1300 || parseInt(data.birth_year) > 1390) {
    return { valid: false, error: 'سال تولد معتبر نیست' };
  }
  
  if (!data.gender || !['male', 'female'].includes(data.gender)) {
    return { valid: false, error: 'جنسیت معتبر نیست' };
  }
  
  if (!data.weight || parseFloat(data.weight) < 20 || parseFloat(data.weight) > 300) {
    return { valid: false, error: 'وزن معتبر نیست' };
  }
  
  if (!data.height || parseFloat(data.height) < 100 || parseFloat(data.height) > 250) {
    return { valid: false, error: 'قد معتبر نیست' };
  }
  
  return { valid: true };
}

// ==================== Product Validation ====================
export function validateProductData(data: any): { valid: boolean; error?: string } {
  // Support both 'name' (for backward compatibility) and 'product_name'
  const productName = data.product_name || data.name;
  
  if (!productName || productName.trim().length < 3) {
    return { valid: false, error: 'نام محصول باید حداقل 3 کاراکتر باشد' };
  }
  
  if (!data.slug || data.slug.trim().length < 3) {
    return { valid: false, error: 'شناسه URL معتبر نیست' };
  }
  
  if (!data.price || data.price <= 0) {
    return { valid: false, error: 'قیمت معتبر نیست' };
  }
  
  // Support both 'discount_price' and 'old_price'
  const discountPrice = data.old_price || data.discount_price;
  if (discountPrice && discountPrice >= data.price) {
    return { valid: false, error: 'قیمت تخفیف باید کمتر از قیمت اصلی باشد' };
  }
  
  return { valid: true };
}

// ==================== Slug Validation ====================
export function isValidSlug(slug: string): boolean {
  // Only lowercase letters, numbers, and hyphens
  const slugRegex = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
  return slugRegex.test(slug);
}

export function sanitizeSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// ==================== Postal Code Validation ====================
export function isValidPostalCode(code: string): boolean {
  // Iranian postal codes are 10 digits
  const postalRegex = /^\d{10}$/;
  return postalRegex.test(code);
}

// ==================== Amount Validation ====================
export function isValidAmount(amount: number): boolean {
  return amount > 0 && amount < 1000000000 && Number.isInteger(amount);
}