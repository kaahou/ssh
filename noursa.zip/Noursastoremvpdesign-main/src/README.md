# 🛒 فروشگاه آنلاین نورسا

## 📋 درباره پروژه

فروشگاه آنلاین نورسا یک MVP (حداقل محصول قابل عرضه) است که در ۱۰ روز طراحی و توسعه داده شده است. این پروژه یک فروشگاه آنلاین کامل با امکانات زیر را ارائه می‌دهد:

### ✨ ویژگی‌های اصلی

#### 🎯 صفحات اصلی
- **صفحه خانه (Home)**: شامل Hero Section، دسته‌بندی محصولات، محصولات ویژه و بخش مشاوره
- **لیست محصولات (Products)**: نمایش تمام محصولات با فیلتر و جستجو
- **جزئیات محصول (Product Detail)**: نمایش اطلاعات کامل محصول، محصولات مرتبط
- **سبد خرید (Cart)**: مدیریت سبد خرید و تسویه حساب

#### 🧩 کامپوننت‌های پایه
- **Header**: هدر sticky با منوی ناوبری و آیکون سبد خرید
- **Footer**: فوتر کامل با لینک‌ها، اطلاعات تماس و فرم مشاوره
- **ProductCard**: کارت محصول با تصویر، قیمت، تخفیف و دکمه افزودن به سبد
- **FloatingContactButton**: دکمه شناور ارتباط با شبکه‌های اجتماعی (واتساپ، تلگرام، ایتا، اینستاگرام، تماس)
- **ConsultationForm**: فرم درخواست مشاوره رایگان

#### 🎨 طراحی
- **رنگ‌بندی**: سبز جنگلی (#1A2011) و کرم (#F9E1B4)
- **ظاهر**: Minimal و Functional
- **فونت**: Vazirmatn (فارسی)
- **Responsive**: کاملاً واکنش‌گرا برای موبایل، تبلت و دسکتاپ
- **RTL**: پشتیبانی کامل از راست‌چین برای زبان فارسی

#### 🔧 فناوری‌ها
- **Frontend**: React + TypeScript
- **Styling**: Tailwind CSS v4
- **Backend**: Supabase (Edge Functions + KV Store)
- **Icons**: Lucide React
- **State Management**: React Context API

---

## 🗂 ساختار پروژه

```
/
├── App.tsx                           # کامپوننت اصلی اپلیکیشن
├── components/
│   ├── Header.tsx                    # هدر سایت
│   ├── Footer.tsx                    # فوتر سایت با فرم مشاوره
│   ├── ProductCard.tsx               # کارت محصول
│   ├── FloatingContactButton.tsx     # دکمه شناور تماس
│   ├── ConsultationForm.tsx          # فرم مشاوره
│   ├── CartContext.tsx               # مدیریت state سبد خرید
│   ├── pages/
│   │   ├── HomePage.tsx              # صفحه خانه
│   │   ├── ProductListPage.tsx       # لیست محصولات
│   │   ├── ProductDetailPage.tsx     # جزئیات محصول
│   │   └── CartPage.tsx              # سبد خرید و تسویه
│   └── ui/                           # کامپوننت‌های UI
├── styles/
│   └── globals.css                   # استایل‌های سراسری و متغیرهای CSS
├── supabase/functions/server/
│   ├── index.tsx                     # سرور Hono - API endpoints
│   └── kv_store.tsx                  # مدیریت KV Store (محافظت شده)
└── utils/supabase/
    └── info.tsx                      # اطلاعات Supabase (محافظت شده)
```

---

## 🚀 راه‌اندازی

### پیش‌نیازها
این پروژه در محیط Figma Make اجرا می‌شود و نیازی به نصب دستی ندارد.

### تنظیمات Backend
Backend از Supabase استفاده می‌کند و به صورت خودکار تنظیم شده است:
- **جداول**: از KV Store برای ذخیره‌سازی استفاده می‌شود
- **محصولات نمونه**: به صورت خودکار در اولین اجرا ایجاد می‌شوند

### API Endpoints

#### محصولات
```
GET  /make-server-fbc72c25/products          # دریافت تمام محصولات
GET  /make-server-fbc72c25/products/featured # دریافت محصولات ویژه
GET  /make-server-fbc72c25/products/:id      # دریافت یک محصول
```

#### سفارشات
```
POST /make-server-fbc72c25/orders            # ایجاد سفارش جدید
```

#### مشاوره
```
POST /make-server-fbc72c25/consultations     # ایجاد درخواست مشاوره
```

---

## 📊 دیتابیس

### ساختار KV Store

#### محصولات (Products)
```typescript
{
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: string;
  description: string;
  image: string;
  stock: number;
  featured?: boolean;
}
```

#### سفارشات (Orders)
```typescript
{
  id: string;
  customerName: string;
  phone: string;
  address: string;
  items: Array<{
    productId: string;
    name: string;
    price: number;
    quantity: number;
  }>;
  totalAmount: number;
  status: string;
  createdAt: string;
}
```

#### مشاوره (Consultations)
```typescript
{
  id: string;
  name: string;
  phone: string;
  subject: string;
  message: string;
  status: string;
  createdAt: string;
}
```

---

## 🎨 سیستم طراحی

### رنگ‌ها
```css
/* اصلی */
--color-primary-dark: #1A2011      /* سبز جنگلی تیره */
--color-primary-medium: #484D2C    /* سبز جنگلی میانه */
--color-cream: #F9E1B4             /* کرم */

/* معنایی */
--color-success: #16A34A           /* موفقیت */
--color-error: #DC2626             /* خطا */

/* خنثی */
--color-gray-50: #FAFAFA           /* پس‌زمینه */
--color-gray-200: #E8E8E8          /* بوردر */
--color-gray-500: #888888          /* متن کم‌رنگ */
```

### فونت
- **خانواده**: Vazirmatn
- **منبع**: CDN jsdelivr
- **وزن‌ها**: 400 (Regular), 500 (Medium), 700 (Bold)

### Border Radius
```css
--radius-sm: 8px
--radius-md: 12px
--radius-lg: 16px
--radius-xl: 20px
```

برای اطلاعات بیشتر، فایل `/DESIGN_SYSTEM.md` را مشاهده کنید.

---

## 🔐 امنیت

- **SUPABASE_SERVICE_ROLE_KEY**: فقط در سمت سرور استفاده می‌شود
- **CORS**: تنظیم شده برای امنیت بیشتر
- **Validation**: اعتبارسنجی داده‌ها در سمت سرور

---

## 📱 تماس با ما

این پروژه شامل چندین راه ارتباطی است:

### دکمه شناور
- واتساپ: `https://wa.me/989219675992`
- تلگرام: `https://t.me/Nurssa_ir`
- ایتا: `https://eitaa.com/nurssa_ir`
- اینستاگرام: `https://instagram.com/nursaa.ir`
- تماس مستقیم: `tel:09219675992`

### فرم مشاوره
- موجود در صفحه خانه (بخش CTA)
- موجود در فوتر
- ذخیره در KV Store تحت کلید `consultation:*`

---

## 📝 یادداشت‌های مهم

### فایل‌های محافظت شده
این فایل‌ها **نباید** ویرایش شوند:
- `/supabase/functions/server/kv_store.tsx`
- `/utils/supabase/info.tsx`
- `/components/figma/ImageWithFallback.tsx`

### توسعه آینده
برای توسعه پروژه می‌توانید:
1. دسته‌بندی محصولات را فعال کنید
2. سیستم جستجو پیشرفته اضافه کنید
3. سیستم احراز هویت (Auth) پیاده‌سازی کنید
4. پنل ادمین برای مدیریت محصولات بسازید
5. سیستم پرداخت آنلاین متصل کنید

---

## 📄 مجوز

© ۱۴۰۳ فروشگاه نورسا. تمامی حقوق محفوظ است.

---

## 🙏 تشکر

از ابزارهای زیر استفاده شده است:
- React
- Tailwind CSS
- Supabase
- Lucide Icons
- Vazirmatn Font

برای سوالات یا مشکلات، لطفاً از بخش مشاوره استفاده کنید.