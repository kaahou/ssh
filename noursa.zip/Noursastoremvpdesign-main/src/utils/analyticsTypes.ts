/**
 * Type Definitions برای GA4 Events
 * تمام interface ها و type های مورد نیاز برای type-safety
 */

// ============================================
// PRODUCT TYPES
// ============================================

export interface Product {
  product_id?: string | number;
  id?: string | number;
  name: string;
  price: number;
  image_url?: string;
  slug?: string;
  product_family?: string;
  category?: string;
  brand?: string;
  description?: string;
  in_stock?: boolean;
  rating?: number;
  review_count?: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface GA4Product {
  item_id: string;
  item_name: string;
  item_brand?: string;
  item_category?: string;
  item_category2?: string;
  item_category3?: string;
  item_variant?: string;
  price: number;
  quantity: number;
  index?: number;
  discount?: number;
}

// ============================================
// E-COMMERCE EVENT PARAMETERS
// ============================================

export interface ViewItemListParams {
  item_list_id: string;
  item_list_name: string;
  items: GA4Product[];
}

export interface ViewItemParams {
  currency: string;
  value: number;
  items: GA4Product[];
}

export interface SelectItemParams {
  item_list_id: string;
  item_list_name: string;
  items: GA4Product[];
}

export interface AddToCartParams {
  currency: string;
  value: number;
  items: GA4Product[];
}

export interface RemoveFromCartParams {
  currency: string;
  value: number;
  items: GA4Product[];
}

export interface ViewCartParams {
  currency: string;
  value: number;
  items: GA4Product[];
}

export interface BeginCheckoutParams {
  currency: string;
  value: number;
  items: GA4Product[];
  coupon?: string;
}

export interface AddShippingInfoParams {
  currency: string;
  value: number;
  shipping_tier: string;
  items: GA4Product[];
}

export interface AddPaymentInfoParams {
  currency: string;
  value: number;
  payment_type: string;
  items: GA4Product[];
}

export interface PurchaseParams {
  transaction_id: string;
  currency: string;
  value: number;
  tax?: number;
  shipping?: number;
  coupon?: string;
  items: GA4Product[];
}

export interface RefundParams {
  transaction_id: string;
  currency: string;
  value: number;
  items?: GA4Product[];
}

// ============================================
// SEARCH EVENT PARAMETERS
// ============================================

export interface SearchParams {
  search_term: string;
  results_count?: number;
}

export interface ViewSearchResultsParams {
  search_term: string;
  results_count: number;
}

// ============================================
// USER EVENT PARAMETERS
// ============================================

export interface LoginParams {
  method: string; // 'email', 'google', 'facebook', 'phone'
}

export interface SignUpParams {
  method: string;
}

export interface ShareParams {
  content_type: string; // 'product', 'article', 'page'
  content_id: string;
  method?: string; // 'whatsapp', 'telegram', 'copy_link'
}

// ============================================
// CONSULTATION EVENT PARAMETERS
// ============================================

export interface ConsultationStepParams {
  event_category: string;
  event_label: string;
  step_number: number;
}

export interface CompleteConsultationParams {
  event_category: string;
  consultation_id: string;
}

// ============================================
// BLOG & CONTENT EVENT PARAMETERS
// ============================================

export interface ViewBlogListParams {
  event_category: string;
  articles_count: number;
}

export interface ViewArticleParams {
  event_category: string;
  article_id: string;
  article_title: string;
  article_category?: string;
}

export interface ArticleReadTimeParams {
  event_category: string;
  article_id: string;
  read_time_seconds: number;
}

// ============================================
// NAVIGATION EVENT PARAMETERS
// ============================================

export interface ClickNavigationParams {
  event_category: string;
  menu_item: string;
}

export interface ClickBreadcrumbParams {
  event_category: string;
  breadcrumb_path: string;
}

// ============================================
// CONTACT EVENT PARAMETERS
// ============================================

export interface ClickFloatingContactParams {
  event_category: string;
  contact_method: 'phone' | 'whatsapp' | 'telegram';
}

// ============================================
// FILTER & SORT EVENT PARAMETERS
// ============================================

export interface ApplyFilterParams {
  event_category: string;
  filter_type: string;
  filter_value: string;
}

export interface SortProductsParams {
  event_category: string;
  sort_method: string;
}

export interface ChangePageParams {
  event_category: string;
  page_number: number;
  total_pages: number;
}

// ============================================
// PROFILE EVENT PARAMETERS
// ============================================

export interface ViewProfileParams {
  event_category: string;
  profile_section: string;
}

export interface UpdateProfileParams {
  event_category: string;
  update_type: string;
}

export interface ViewOrderHistoryParams {
  event_category: string;
  orders_count: number;
}

export interface TrackOrderParams {
  event_category: string;
  tracking_code: string;
}

// ============================================
// AFFILIATE EVENT PARAMETERS
// ============================================

export interface GenerateAffiliateLinkParams {
  event_category: string;
  product_id?: string;
}

// ============================================
// FOOTER EVENT PARAMETERS
// ============================================

export interface ClickFooterLinkParams {
  event_category: string;
  link_text: string;
  link_url: string;
}

export interface SubscribeNewsletterParams {
  event_category: string;
  email_domain: string;
}

// ============================================
// ERROR EVENT PARAMETERS
// ============================================

export interface ExceptionParams {
  description: string;
  error_location: string;
  fatal: boolean;
}

// ============================================
// SCROLL EVENT PARAMETERS
// ============================================

export interface ScrollDepthParams {
  event_category: string;
  scroll_percentage: number;
}

// ============================================
// VIDEO EVENT PARAMETERS
// ============================================

export interface VideoStartParams {
  event_category: string;
  video_title: string;
  video_url: string;
}

// ============================================
// PRODUCT INTERACTION EVENT PARAMETERS
// ============================================

export interface HoverProductCardParams {
  event_category: string;
  product_id: string;
  product_name: string;
}

export interface ViewProductImageParams {
  event_category: string;
  product_id: string;
  image_index: number;
}

// ============================================
// WALLET EVENT PARAMETERS
// ============================================

export interface ViewWalletParams {
  event_category: string;
  wallet_balance: number;
}

export interface AddMoneyToWalletParams {
  event_category: string;
  currency: string;
  value: number;
}

// ============================================
// FAQ EVENT PARAMETERS
// ============================================

export interface ExpandFAQItemParams {
  event_category: string;
  question: string;
}

// ============================================
// ADMIN EVENT PARAMETERS
// ============================================

export interface AdminActionParams {
  event_category: string;
  action_type: string; // 'create', 'update', 'delete', 'view'
  entity_type: string; // 'product', 'order', 'user', 'article'
  entity_id?: string;
}

// ============================================
// PAGE VIEW EVENT PARAMETERS
// ============================================

export interface PageViewParams {
  page_path: string;
  page_title?: string;
  page_location?: string;
}

// ============================================
// GTAG WINDOW INTERFACE
// ============================================

declare global {
  interface Window {
    gtag?: (
      command: 'config' | 'event' | 'js' | 'consent',
      targetId: string | Date,
      config?: Record<string, any>
    ) => void;
    dataLayer?: any[];
  }
}

// ============================================
// EVENT NAME TYPES
// ============================================

export type GAEventName =
  // Standard E-commerce Events
  | 'page_view'
  | 'view_item_list'
  | 'view_item'
  | 'select_item'
  | 'add_to_cart'
  | 'remove_from_cart'
  | 'view_cart'
  | 'begin_checkout'
  | 'add_shipping_info'
  | 'add_payment_info'
  | 'purchase'
  | 'refund'
  // Search Events
  | 'search'
  | 'view_search_results'
  // User Events
  | 'login'
  | 'sign_up'
  | 'share'
  // Custom Events
  | 'start_consultation'
  | 'consultation_step_complete'
  | 'complete_consultation'
  | 'view_blog_list'
  | 'view_article'
  | 'article_read_time'
  | 'click_navigation'
  | 'click_breadcrumb'
  | 'open_mobile_menu'
  | 'click_floating_contact'
  | 'submit_contact_form'
  | 'apply_filter'
  | 'sort_products'
  | 'change_page'
  | 'view_profile'
  | 'update_profile'
  | 'view_order_history'
  | 'track_order'
  | 'view_affiliate_program'
  | 'generate_affiliate_link'
  | 'click_footer_link'
  | 'subscribe_newsletter'
  | 'exception'
  | 'scroll_depth'
  | 'video_start'
  | 'hover_product_card'
  | 'view_product_image'
  | 'view_wallet'
  | 'add_money_to_wallet'
  | 'view_faq'
  | 'expand_faq_item'
  | 'admin_action';

// ============================================
// EVENT CATEGORY TYPES
// ============================================

export type EventCategory =
  | 'ecommerce'
  | 'consultation'
  | 'content'
  | 'navigation'
  | 'contact'
  | 'product_discovery'
  | 'user_account'
  | 'affiliate'
  | 'footer'
  | 'engagement'
  | 'video'
  | 'product_interaction'
  | 'wallet'
  | 'help'
  | 'admin';

// ============================================
// CURRENCY TYPE
// ============================================

export type Currency = 'IRR' | 'USD' | 'EUR';

// ============================================
// UTILITY TYPES
// ============================================

export type EventParams =
  | ViewItemListParams
  | ViewItemParams
  | SelectItemParams
  | AddToCartParams
  | RemoveFromCartParams
  | ViewCartParams
  | BeginCheckoutParams
  | AddShippingInfoParams
  | AddPaymentInfoParams
  | PurchaseParams
  | RefundParams
  | SearchParams
  | ViewSearchResultsParams
  | LoginParams
  | SignUpParams
  | ShareParams
  | ConsultationStepParams
  | CompleteConsultationParams
  | ViewBlogListParams
  | ViewArticleParams
  | ArticleReadTimeParams
  | ClickNavigationParams
  | ClickBreadcrumbParams
  | ClickFloatingContactParams
  | ApplyFilterParams
  | SortProductsParams
  | ChangePageParams
  | ViewProfileParams
  | UpdateProfileParams
  | ViewOrderHistoryParams
  | TrackOrderParams
  | GenerateAffiliateLinkParams
  | ClickFooterLinkParams
  | SubscribeNewsletterParams
  | ExceptionParams
  | ScrollDepthParams
  | VideoStartParams
  | HoverProductCardParams
  | ViewProductImageParams
  | ViewWalletParams
  | AddMoneyToWalletParams
  | ExpandFAQItemParams
  | AdminActionParams
  | PageViewParams;

// ============================================
// ANALYTICS CONFIG
// ============================================

export interface AnalyticsConfig {
  measurementId: string;
  debug?: boolean;
  sendPageView?: boolean;
  cookieFlags?: string;
}

// ============================================
// CONSENT MODE
// ============================================

export type ConsentMode = 'granted' | 'denied';

export interface ConsentParams {
  analytics_storage?: ConsentMode;
  ad_storage?: ConsentMode;
  functionality_storage?: ConsentMode;
  personalization_storage?: ConsentMode;
  security_storage?: ConsentMode;
}

// ============================================
// CUSTOM DIMENSIONS (برای آینده)
// ============================================

export interface CustomDimensions {
  user_type?: 'guest' | 'registered' | 'vip';
  user_lifetime_value?: number;
  user_segment?: string;
  device_type?: 'mobile' | 'tablet' | 'desktop';
  is_admin?: boolean;
  ab_test_variant?: string;
}

// ============================================
// ORDER INTERFACE
// ============================================

export interface Order {
  order_id: string;
  user_id: string;
  items: CartItem[];
  total_amount: number;
  shipping_cost: number;
  tax: number;
  discount?: number;
  coupon_code?: string;
  payment_method: string;
  shipping_method: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
  created_at: string;
  updated_at: string;
}

// ============================================
// CONSULTATION INTERFACE
// ============================================

export interface Consultation {
  consultation_id: string;
  user_id: string;
  personal_info: {
    name: string;
    email: string;
    phone: string;
    age?: number;
    gender?: string;
  };
  skin_type?: string;
  skin_concerns?: string[];
  lifestyle?: {
    diet?: string;
    sleep_hours?: number;
    stress_level?: string;
  };
  product_preferences?: {
    budget?: string;
    preferred_brands?: string[];
    avoid_ingredients?: string[];
  };
  status: 'pending' | 'in_progress' | 'completed';
  recommendations?: Product[];
  created_at: string;
}

// ============================================
// ARTICLE INTERFACE
// ============================================

export interface Article {
  article_id: string;
  title: string;
  slug: string;
  content: string;
  excerpt?: string;
  category: string;
  tags?: string[];
  author?: string;
  featured_image?: string;
  published_at: string;
  updated_at?: string;
  view_count?: number;
  read_time_minutes?: number;
}

// ============================================
// USER INTERFACE
// ============================================

export interface User {
  user_id: string;
  email: string;
  phone?: string;
  name: string;
  avatar?: string;
  created_at: string;
  last_login?: string;
  is_admin?: boolean;
  wallet_balance?: number;
  total_orders?: number;
  total_spent?: number;
  affiliate_code?: string;
}

// ============================================
// ANALYTICS CONTEXT TYPE
// ============================================

export interface AnalyticsContextType {
  trackEvent: (eventName: GAEventName, params?: EventParams) => void;
  trackPageView: (path: string, title?: string) => void;
  setUserId: (userId: string) => void;
  setUserProperties: (properties: Record<string, any>) => void;
  isInitialized: boolean;
}

// ============================================
// HOOK RETURN TYPES
// ============================================

export interface UseAnalyticsReturn {
  // Page Events
  trackPageView: (page_path: string, page_title?: string) => void;

  // E-commerce Events
  trackViewItemList: (products: Product[], list_name: string) => void;
  trackViewItem: (product: Product) => void;
  trackSelectItem: (product: Product, list_name: string, index?: number) => void;
  trackAddToCart: (product: Product, quantity: number) => void;
  trackRemoveFromCart: (product: Product, quantity: number) => void;
  trackViewCart: (cartItems: CartItem[], totalValue: number) => void;
  trackBeginCheckout: (cartItems: CartItem[], totalValue: number) => void;
  trackAddShippingInfo: (cartItems: CartItem[], totalValue: number, shippingTier?: string) => void;
  trackAddPaymentInfo: (cartItems: CartItem[], totalValue: number, paymentType: string) => void;
  trackPurchase: (orderId: string, cartItems: CartItem[], totalValue: number, shippingCost?: number, tax?: number) => void;
  trackRefund: (orderId: string, value: number, items?: CartItem[]) => void;

  // Search Events
  trackSearch: (searchTerm: string, resultsCount?: number) => void;
  trackViewSearchResults: (searchTerm: string, results: any[]) => void;

  // User Events
  trackLogin: (method: string) => void;
  trackSignUp: (method: string) => void;
  trackShare: (contentType: string, contentId: string, method?: string) => void;

  // Consultation Events
  trackStartConsultation: () => void;
  trackConsultationStep: (stepNumber: number, stepName: string) => void;
  trackCompleteConsultation: (consultationId: string) => void;

  // Blog Events
  trackViewBlogList: (articlesCount: number) => void;
  trackViewArticle: (articleId: string, articleTitle: string, category?: string) => void;
  trackArticleReadTime: (articleId: string, readTimeSeconds: number) => void;

  // Navigation Events
  trackClickNavigation: (menuItem: string) => void;
  trackClickBreadcrumb: (breadcrumbPath: string) => void;
  trackOpenMobileMenu: () => void;

  // Contact Events
  trackClickFloatingContact: (method: 'phone' | 'whatsapp' | 'telegram') => void;
  trackSubmitContactForm: () => void;

  // Filter Events
  trackApplyFilter: (filterType: string, filterValue: string) => void;
  trackSortProducts: (sortMethod: string) => void;
  trackChangePage: (pageNumber: number, totalPages: number) => void;

  // Profile Events
  trackViewProfile: (section: string) => void;
  trackUpdateProfile: (updateType: string) => void;
  trackViewOrderHistory: (ordersCount: number) => void;
  trackOrderTracking: (trackingCode: string) => void;

  // Affiliate Events
  trackViewAffiliateProgram: () => void;
  trackGenerateAffiliateLink: (productId?: string) => void;

  // Footer Events
  trackClickFooterLink: (linkText: string, linkUrl: string) => void;
  trackSubscribeNewsletter: (email: string) => void;

  // Error Events
  trackError: (errorMessage: string, errorLocation: string, isFatal: boolean) => void;

  // Engagement Events
  trackScrollDepth: (percentage: number) => void;

  // Video Events
  trackPlayVideo: (videoTitle: string, videoUrl: string) => void;

  // Product Interaction Events
  trackHoverProductCard: (productId: string, productName: string) => void;
  trackViewProductImage: (productId: string, imageIndex: number) => void;

  // Wallet Events
  trackViewWallet: (balance: number) => void;
  trackAddMoneyToWallet: (amount: number) => void;

  // Help Events
  trackViewFAQ: () => void;
  trackExpandFAQItem: (questionText: string) => void;

  // Admin Events
  trackAdminAction: (actionType: string, entityType: string, entityId?: string) => void;
}

// ============================================
// EXPORT ALL
// ============================================

export type {
  Product,
  CartItem,
  GA4Product,
  Order,
  Consultation,
  Article,
  User,
};
