/**
 * Performance Monitoring Utilities for nursaa
 * Monitors Core Web Vitals and sends data to analytics
 */

// Core Web Vitals thresholds
const THRESHOLDS = {
  LCP: 2500, // Largest Contentful Paint - Good: < 2.5s
  FID: 100,  // First Input Delay - Good: < 100ms
  CLS: 0.1,  // Cumulative Layout Shift - Good: < 0.1
  FCP: 1800, // First Contentful Paint - Good: < 1.8s
  TTFB: 800, // Time to First Byte - Good: < 800ms
};

interface PerformanceMetric {
  name: string;
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  delta?: number;
  id?: string;
}

// Track performance metrics
export function trackPerformance() {
  // Check if Performance API is available
  if (!('performance' in window)) {
    console.warn('Performance API not available');
    return;
  }

  // Navigation Timing
  if ('getEntriesByType' in performance) {
    const navigationTiming = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
    
    if (navigationTiming) {
      // Time to First Byte (TTFB)
      const ttfb = navigationTiming.responseStart - navigationTiming.requestStart;
      logMetric('TTFB', ttfb, THRESHOLDS.TTFB);

      // DOM Content Loaded
      const domContentLoaded = navigationTiming.domContentLoadedEventEnd - navigationTiming.domContentLoadedEventStart;
      logMetric('DOMContentLoaded', domContentLoaded, 1000);

      // Page Load Time
      const loadTime = navigationTiming.loadEventEnd - navigationTiming.fetchStart;
      logMetric('PageLoadTime', loadTime, 3000);
    }
  }

  // Use Web Vitals library if available (from CDN or npm)
  if (typeof window !== 'undefined') {
    // Largest Contentful Paint (LCP)
    measureLCP();
    
    // First Input Delay (FID)
    measureFID();
    
    // Cumulative Layout Shift (CLS)
    measureCLS();
    
    // First Contentful Paint (FCP)
    measureFCP();
  }
}

// Measure Largest Contentful Paint
function measureLCP() {
  if ('PerformanceObserver' in window) {
    try {
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1] as any;
        
        if (lastEntry) {
          const lcp = lastEntry.renderTime || lastEntry.loadTime;
          logMetric('LCP', lcp, THRESHOLDS.LCP);
          
          // Send to Analytics
          sendToAnalytics({
            name: 'LCP',
            value: lcp,
            rating: getRating(lcp, THRESHOLDS.LCP),
          });
        }
      });
      
      observer.observe({ type: 'largest-contentful-paint', buffered: true });
    } catch (e) {
      console.warn('LCP measurement failed:', e);
    }
  }
}

// Measure First Input Delay
function measureFID() {
  if ('PerformanceObserver' in window) {
    try {
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        
        entries.forEach((entry: any) => {
          const fid = entry.processingStart - entry.startTime;
          logMetric('FID', fid, THRESHOLDS.FID);
          
          sendToAnalytics({
            name: 'FID',
            value: fid,
            rating: getRating(fid, THRESHOLDS.FID),
          });
        });
      });
      
      observer.observe({ type: 'first-input', buffered: true });
    } catch (e) {
      console.warn('FID measurement failed:', e);
    }
  }
}

// Measure Cumulative Layout Shift
function measureCLS() {
  if ('PerformanceObserver' in window) {
    try {
      let clsValue = 0;
      
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        
        entries.forEach((entry: any) => {
          if (!entry.hadRecentInput) {
            clsValue += entry.value;
          }
        });
        
        logMetric('CLS', clsValue, THRESHOLDS.CLS);
        
        sendToAnalytics({
          name: 'CLS',
          value: clsValue,
          rating: getRating(clsValue, THRESHOLDS.CLS),
        });
      });
      
      observer.observe({ type: 'layout-shift', buffered: true });
    } catch (e) {
      console.warn('CLS measurement failed:', e);
    }
  }
}

// Measure First Contentful Paint
function measureFCP() {
  if ('PerformanceObserver' in window) {
    try {
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        
        entries.forEach((entry: any) => {
          if (entry.name === 'first-contentful-paint') {
            const fcp = entry.startTime;
            logMetric('FCP', fcp, THRESHOLDS.FCP);
            
            sendToAnalytics({
              name: 'FCP',
              value: fcp,
              rating: getRating(fcp, THRESHOLDS.FCP),
            });
          }
        });
      });
      
      observer.observe({ type: 'paint', buffered: true });
    } catch (e) {
      console.warn('FCP measurement failed:', e);
    }
  }
}

// Get rating based on threshold
function getRating(value: number, threshold: number): 'good' | 'needs-improvement' | 'poor' {
  if (value <= threshold) return 'good';
  if (value <= threshold * 1.5) return 'needs-improvement';
  return 'poor';
}

// Log metric to console (dev only)
function logMetric(name: string, value: number, threshold: number) {
  const rating = getRating(value, threshold);
  const emoji = rating === 'good' ? '✅' : rating === 'needs-improvement' ? '⚠️' : '❌';
  
  if (process.env.NODE_ENV === 'development') {
    console.log(`${emoji} ${name}: ${value.toFixed(2)}ms (${rating})`);
  }
}

// Send to Analytics (GA4)
function sendToAnalytics(metric: PerformanceMetric) {
  // Check if gtag is available
  if (typeof window !== 'undefined' && (window as any).gtag) {
    (window as any).gtag('event', 'web_vitals', {
      event_category: 'Web Vitals',
      event_label: metric.name,
      value: Math.round(metric.value),
      metric_rating: metric.rating,
      non_interaction: true,
    });
  }
  
  // Also send to dataLayer for GTM
  if (typeof window !== 'undefined' && (window as any).dataLayer) {
    (window as any).dataLayer.push({
      event: 'web_vitals',
      metric_name: metric.name,
      metric_value: Math.round(metric.value),
      metric_rating: metric.rating,
    });
  }
}

// Monitor resource loading
export function trackResourcePerformance() {
  if (!('performance' in window)) return;

  const resources = performance.getEntriesByType('resource') as PerformanceResourceTiming[];
  
  // Group resources by type
  const resourcesByType: Record<string, number[]> = {};
  
  resources.forEach((resource) => {
    const type = resource.initiatorType;
    const duration = resource.duration;
    
    if (!resourcesByType[type]) {
      resourcesByType[type] = [];
    }
    resourcesByType[type].push(duration);
  });
  
  // Log resource stats in development only - warnings disabled in production
  // This prevents console noise from intentional lazy loading behaviors
  Object.entries(resourcesByType).forEach(([type, durations]) => {
    const avg = durations.reduce((a, b) => a + b, 0) / durations.length;
    const max = Math.max(...durations);
    
    if (process.env.NODE_ENV === 'development') {
      console.log(`📦 ${type}: avg=${avg.toFixed(2)}ms, max=${max.toFixed(2)}ms, count=${durations.length}`);
    }
    
    // DISABLED: Resource warnings are disabled because:
    // 1. GTM intentionally lazy loads with 3s delay
    // 2. Images intentionally lazy load on scroll
    // 3. Third-party services (GA4, Zarinpal) can be slow on slow networks
    // 4. These are all optimized behaviors, not problems
    
    // Only track genuinely problematic resources (>60 seconds)
    if (max > 60000) {
      // Send to analytics for monitoring (silently, no console warnings)
      if (typeof window !== 'undefined' && (window as any).dataLayer) {
        (window as any).dataLayer.push({
          event: 'slow_resource',
          resource_type: type,
          resource_duration: Math.round(max),
        });
      }
    }
  });
}

// Initialize performance monitoring
export function initPerformanceMonitoring() {
  // Only track Core Web Vitals, disable resource performance warnings
  // Resource warnings are disabled because optimized lazy loading causes false positives
  
  // Wait for page load
  if (document.readyState === 'complete') {
    trackPerformance();
    // trackResourcePerformance() is intentionally disabled to prevent false warnings
  } else {
    window.addEventListener('load', () => {
      // Small delay to ensure all metrics are captured
      setTimeout(() => {
        trackPerformance();
        // trackResourcePerformance() is intentionally disabled to prevent false warnings
      }, 0);
    }, { once: true });
  }
}

// Export for manual tracking
export { sendToAnalytics };