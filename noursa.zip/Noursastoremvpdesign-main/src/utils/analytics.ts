/**
 * Google Analytics 4 (GA4) Integration for nursaa
 * تمام eventهای GA4 برای tracking رفتار کاربران
 */

// تایپ‌های GA4
declare global {
  interface Window {
    gtag?: (
      command: string,
      eventName: string,
      params?: Record<string, any>
    ) => void;
    dataLayer?: any[];
  }
}

// ============================================
// 1. PAGE VIEW EVENTS (رویدادهای مشاهده صفحه)
// ============================================

/**
 * Track page view
 * زمان: هر بار که صفحه‌ای نمایش داده می‌شود
 */
export const trackPageView = (page_path: string, page_title?: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'page_view', {
      page_path,
      page_title: page_title || document.title,
      page_location: window.location.href,
    });
  }
};

// ============================================
// 2. E-COMMERCE EVENTS (رویدادهای فروشگاهی)
// ============================================

/**
 * View Item List - مشاهده لیست محصولات
 * زمان: کاربر صفحه لیست محصولات را مشاهده می‌کند
 */
export const trackViewItemList = (products: any[], list_name: string = 'محصولات') => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_item_list', {
      item_list_id: list_name,
      item_list_name: list_name,
      items: products.map((product, index) => ({
        item_id: String(product.product_id || product.id),
        item_name: product.name,
        item_brand: 'nursaa',
        item_category: product.product_family || 'uncategorized',
        price: product.price,
        quantity: 1,
        index: index,
      })),
    });
  }
};

/**
 * View Item - مشاهده جزئیات محصول
 * زمان: کاربر وارد صفحه جزئیات محصول می‌شود
 */
export const trackViewItem = (product: any) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_item', {
      currency: 'IRR',
      value: product.price,
      items: [{
        item_id: String(product.product_id || product.id),
        item_name: product.name,
        item_brand: 'nursaa',
        item_category: product.product_family || 'uncategorized',
        price: product.price,
        quantity: 1,
      }],
    });
  }
};

/**
 * Select Item - انتخاب محصول از لیست
 * زمان: کاربر روی کارت محصول کلیک می‌کند
 */
export const trackSelectItem = (product: any, list_name: string = 'محصولات', index?: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'select_item', {
      item_list_id: list_name,
      item_list_name: list_name,
      items: [{
        item_id: String(product.product_id || product.id),
        item_name: product.name,
        item_brand: 'nursaa',
        item_category: product.product_family || 'uncategorized',
        price: product.price,
        index: index,
      }],
    });
  }
};

/**
 * Add to Cart - افزودن به سبد خرید
 * زمان: کاربر محصول را به سبد اضافه می‌کند
 */
export const trackAddToCart = (product: any, quantity: number = 1) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'add_to_cart', {
      currency: 'IRR',
      value: product.price * quantity,
      items: [{
        item_id: String(product.product_id || product.id),
        item_name: product.name,
        item_brand: 'nursaa',
        item_category: product.product_family || 'uncategorized',
        price: product.price,
        quantity: quantity,
      }],
    });
  }
};

/**
 * Remove from Cart - حذف از سبد خرید
 * زمان: کاربر محصول را از سبد حذف می‌کند
 */
export const trackRemoveFromCart = (product: any, quantity: number = 1) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'remove_from_cart', {
      currency: 'IRR',
      value: product.price * quantity,
      items: [{
        item_id: String(product.product_id || product.id),
        item_name: product.name,
        item_brand: 'nursaa',
        item_category: product.product_family || 'uncategorized',
        price: product.price,
        quantity: quantity,
      }],
    });
  }
};

/**
 * View Cart - مشاهده سبد خرید
 * زمان: کاربر سبد خرید را باز می‌کند (در Header یا Checkout)
 */
export const trackViewCart = (cartItems: any[], totalValue: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_cart', {
      currency: 'IRR',
      value: totalValue,
      items: cartItems.map((item) => ({
        item_id: String(item.product_id || item.id),
        item_name: item.name,
        item_brand: 'nursaa',
        item_category: item.product_family || 'uncategorized',
        price: item.price,
        quantity: item.quantity,
      })),
    });
  }
};

/**
 * Begin Checkout - شروع فرآیند خرید
 * زمان: کاربر وارد صفحه Checkout می‌شود
 */
export const trackBeginCheckout = (cartItems: any[], totalValue: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'begin_checkout', {
      currency: 'IRR',
      value: totalValue,
      items: cartItems.map((item) => ({
        item_id: String(item.product_id || item.id),
        item_name: item.name,
        item_brand: 'nursaa',
        item_category: item.product_family || 'uncategorized',
        price: item.price,
        quantity: item.quantity,
      })),
    });
  }
};

/**
 * Add Shipping Info - وارد کردن اطلاعات ارسال
 * زمان: کاربر اطلاعات آدرس ارسال را وارد می‌کند
 */
export const trackAddShippingInfo = (cartItems: any[], totalValue: number, shippingTier?: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'add_shipping_info', {
      currency: 'IRR',
      value: totalValue,
      shipping_tier: shippingTier || 'standard',
      items: cartItems.map((item) => ({
        item_id: String(item.product_id || item.id),
        item_name: item.name,
        item_brand: 'nursaa',
        price: item.price,
        quantity: item.quantity,
      })),
    });
  }
};

/**
 * Add Payment Info - انتخاب روش پرداخت
 * زمان: کاربر روش پرداخت را انتخاب می‌کند
 */
export const trackAddPaymentInfo = (cartItems: any[], totalValue: number, paymentType: string = 'zarinpal') => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'add_payment_info', {
      currency: 'IRR',
      value: totalValue,
      payment_type: paymentType,
      items: cartItems.map((item) => ({
        item_id: String(item.product_id || item.id),
        item_name: item.name,
        item_brand: 'nursaa',
        price: item.price,
        quantity: item.quantity,
      })),
    });
  }
};

/**
 * Purchase - تکمیل خرید
 * زمان: خرید با موفقیت انجام می‌شود
 */
export const trackPurchase = (
  orderId: string,
  cartItems: any[],
  totalValue: number,
  shippingCost: number = 0,
  tax: number = 0
) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'purchase', {
      transaction_id: orderId,
      currency: 'IRR',
      value: totalValue,
      shipping: shippingCost,
      tax: tax,
      items: cartItems.map((item) => ({
        item_id: String(item.product_id || item.id),
        item_name: item.name,
        item_brand: 'nursaa',
        item_category: item.product_family || 'uncategorized',
        price: item.price,
        quantity: item.quantity,
      })),
    });
  }
};

/**
 * Refund - بازگشت وجه
 * زمان: سفارش مرجوع می‌شود
 */
export const trackRefund = (orderId: string, value: number, items?: any[]) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'refund', {
      transaction_id: orderId,
      currency: 'IRR',
      value: value,
      items: items?.map((item) => ({
        item_id: String(item.product_id || item.id),
        item_name: item.name,
        quantity: item.quantity,
      })),
    });
  }
};

// ============================================
// 3. SEARCH EVENTS (رویدادهای جستجو)
// ============================================

/**
 * Search - جستجو
 * زمان: کاربر جستجو می‌کند
 */
export const trackSearch = (searchTerm: string, resultsCount?: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'search', {
      search_term: searchTerm,
      results_count: resultsCount,
    });
  }
};

/**
 * View Search Results - مشاهده نتایج جستجو
 * زمان: صفحه نتایج جستجو نمایش داده می‌شود
 */
export const trackViewSearchResults = (searchTerm: string, results: any[]) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_search_results', {
      search_term: searchTerm,
      results_count: results.length,
    });
  }
};

// ============================================
// 4. USER ENGAGEMENT EVENTS (رویدادهای تعامل کاربر)
// ============================================

/**
 * Login - ورود کاربر
 * زمان: کاربر وارد حساب کاربری می‌شود
 */
export const trackLogin = (method: string = 'email') => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'login', {
      method: method,
    });
  }
};

/**
 * Sign Up - ثبت‌نام کاربر
 * زمان: کاربر جدید ثبت‌نام می‌کند
 */
export const trackSignUp = (method: string = 'email') => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'sign_up', {
      method: method,
    });
  }
};

/**
 * Share - اشتراک‌گذاری
 * زمان: کاربر محتوا را به اشتراک می‌گذارد
 */
export const trackShare = (contentType: string, contentId: string, method?: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'share', {
      content_type: contentType,
      content_id: contentId,
      method: method || 'unknown',
    });
  }
};

// ============================================
// 5. CONSULTATION EVENTS (رویدادهای مشاوره)
// ============================================

/**
 * Start Consultation - شروع فرم مشاوره
 * زمان: کاربر وارد ویزارد مشاوره می‌شود
 */
export const trackStartConsultation = () => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'start_consultation', {
      event_category: 'consultation',
      event_label: 'consultation_wizard_started',
    });
  }
};

/**
 * Consultation Step Complete - تکمیل مرحله مشاوره
 * زمان: کاربر یک مرحله از ویزارد را تکمیل می‌کند
 */
export const trackConsultationStep = (stepNumber: number, stepName: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'consultation_step_complete', {
      event_category: 'consultation',
      event_label: stepName,
      step_number: stepNumber,
    });
  }
};

/**
 * Complete Consultation - تکمیل فرم مشاوره
 * زمان: کاربر فرم مشاوره را ارسال می‌کند
 */
export const trackCompleteConsultation = (consultationId: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'complete_consultation', {
      event_category: 'consultation',
      consultation_id: consultationId,
    });
  }
};

// ============================================
// 6. BLOG & CONTENT EVENTS (رویدادهای محتوا)
// ============================================

/**
 * View Blog List - مشاهده لیست مقالات
 * زمان: کاربر صفحه لیست مقالات را مشاهده می‌کند
 */
export const trackViewBlogList = (articlesCount: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_blog_list', {
      event_category: 'content',
      articles_count: articlesCount,
    });
  }
};

/**
 * View Article - مشاهده مقاله
 * زمان: کاربر مقاله را می‌خواند
 */
export const trackViewArticle = (articleId: string, articleTitle: string, category?: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_article', {
      event_category: 'content',
      article_id: articleId,
      article_title: articleTitle,
      article_category: category,
    });
  }
};

/**
 * Article Read Time - زمان خواندن مقاله
 * زمان: کاربر مدت زمانی روی مقاله می‌ماند
 */
export const trackArticleReadTime = (articleId: string, readTimeSeconds: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'article_read_time', {
      event_category: 'content',
      article_id: articleId,
      read_time_seconds: readTimeSeconds,
    });
  }
};

// ============================================
// 7. NAVIGATION EVENTS (رویدادهای ناوبری)
// ============================================

/**
 * Click Navigation - کلیک روی منوی هدر
 * زمان: کاربر روی آیتم منو کلیک می‌کند
 */
export const trackClickNavigation = (menuItem: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'click_navigation', {
      event_category: 'navigation',
      menu_item: menuItem,
    });
  }
};

/**
 * Click Breadcrumb - کلیک روی Breadcrumb
 * زمان: کاربر روی breadcrumb کلیک می‌کند
 */
export const trackClickBreadcrumb = (breadcrumbPath: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'click_breadcrumb', {
      event_category: 'navigation',
      breadcrumb_path: breadcrumbPath,
    });
  }
};

/**
 * Open Mobile Menu - باز کردن منوی موبایل
 * زمان: کاربر منوی موبایل را باز می‌کند
 */
export const trackOpenMobileMenu = () => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'open_mobile_menu', {
      event_category: 'navigation',
    });
  }
};

// ============================================
// 8. CONTACT EVENTS (رویدادهای تماس)
// ============================================

/**
 * Click Contact Button - کلیک روی دکمه تماس شناور
 * زمان: کاربر روی FloatingContactButton کلیک می‌کند
 */
export const trackClickFloatingContact = (method: 'phone' | 'whatsapp' | 'telegram') => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'click_floating_contact', {
      event_category: 'contact',
      contact_method: method,
    });
  }
};

/**
 * Submit Contact Form - ارسال فرم تماس
 * زمان: کاربر فرم تماس را ارسال می‌کند
 */
export const trackSubmitContactForm = () => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'submit_contact_form', {
      event_category: 'contact',
    });
  }
};

// ============================================
// 9. FILTER & SORT EVENTS (رویدادهای فیلتر)
// ============================================

/**
 * Apply Filter - اعمال فیلتر
 * زمان: کاربر فیلتر محصولات را تغییر می‌دهد
 */
export const trackApplyFilter = (filterType: string, filterValue: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'apply_filter', {
      event_category: 'product_discovery',
      filter_type: filterType,
      filter_value: filterValue,
    });
  }
};

/**
 * Sort Products - مرتب‌سازی محصولات
 * زمان: کاربر ترتیب محصولات را تغییر می‌دهد
 */
export const trackSortProducts = (sortMethod: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'sort_products', {
      event_category: 'product_discovery',
      sort_method: sortMethod,
    });
  }
};

// ============================================
// 10. PAGINATION EVENTS (رویدادهای صفحه‌بندی)
// ============================================

/**
 * Change Page - تغییر صفحه
 * زمان: کاربر در pagination صفحه را تغییر می‌دهد
 */
export const trackChangePage = (pageNumber: number, totalPages: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'change_page', {
      event_category: 'navigation',
      page_number: pageNumber,
      total_pages: totalPages,
    });
  }
};

// ============================================
// 11. PROFILE & ACCOUNT EVENTS (رویدادهای پروفایل)
// ============================================

/**
 * View Profile - مشاهده پروفایل
 * زمان: کاربر وارد پنل کاربری می‌شود
 */
export const trackViewProfile = (section: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_profile', {
      event_category: 'user_account',
      profile_section: section,
    });
  }
};

/**
 * Update Profile - ویرایش پروفایل
 * زمان: کاربر اطلاعات پروفایل را تغییر می‌دهد
 */
export const trackUpdateProfile = (updateType: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'update_profile', {
      event_category: 'user_account',
      update_type: updateType,
    });
  }
};

/**
 * View Order History - مشاهده تاریخچه سفارشات
 * زمان: کاربر سفارشات خود را مشاهده می‌کند
 */
export const trackViewOrderHistory = (ordersCount: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_order_history', {
      event_category: 'user_account',
      orders_count: ordersCount,
    });
  }
};

/**
 * Track Order - پیگیری سفارش
 * زمان: کاربر کد پیگیری سفارش را چک می‌کند
 */
export const trackOrderTracking = (trackingCode: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'track_order', {
      event_category: 'user_account',
      tracking_code: trackingCode,
    });
  }
};

// ============================================
// 12. AFFILIATE EVENTS (رویدادهای همکاری)
// ============================================

/**
 * View Affiliate Program - مشاهده برنامه همکاری
 * زمان: کاربر وارد صفحه همکاری در فروش می‌شود
 */
export const trackViewAffiliateProgram = () => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_affiliate_program', {
      event_category: 'affiliate',
    });
  }
};

/**
 * Generate Affiliate Link - ایجاد لینک همکاری
 * زمان: کاربر لینک همکاری ایجاد می‌کند
 */
export const trackGenerateAffiliateLink = (productId?: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'generate_affiliate_link', {
      event_category: 'affiliate',
      product_id: productId,
    });
  }
};

// ============================================
// 13. FOOTER EVENTS (رویدادهای فوتر)
// ============================================

/**
 * Click Footer Link - کلیک روی لینک فوتر
 * زمان: کاربر روی لینک در فوتر کلیک می‌کند
 */
export const trackClickFooterLink = (linkText: string, linkUrl: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'click_footer_link', {
      event_category: 'footer',
      link_text: linkText,
      link_url: linkUrl,
    });
  }
};

/**
 * Subscribe Newsletter - اشتراک در خبرنامه
 * زمان: کاربر در فوتر ایمیل برای خبرنامه وارد می‌کند
 */
export const trackSubscribeNewsletter = (email: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'subscribe_newsletter', {
      event_category: 'engagement',
      // برای حفظ حریم خصوصی، فقط دامنه ایمیل را ذخیره کنید
      email_domain: email.split('@')[1] || 'unknown',
    });
  }
};

// ============================================
// 14. ERROR & EXCEPTION EVENTS (رویدادهای خطا)
// ============================================

/**
 * Track Error - ردیابی خطا
 * زمان: خطایی در اپلیکیشن رخ می‌دهد
 */
export const trackError = (errorMessage: string, errorLocation: string, isFatal: boolean = false) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'exception', {
      description: errorMessage,
      error_location: errorLocation,
      fatal: isFatal,
    });
  }
};

// ============================================
// 15. SCROLL & ENGAGEMENT EVENTS (رویدادهای اسکرول)
// ============================================

/**
 * Scroll Depth - عمق اسکرول
 * زمان: کاربر تا درصد مشخصی از صفحه اسکرول می‌کند
 */
export const trackScrollDepth = (percentage: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'scroll_depth', {
      event_category: 'engagement',
      scroll_percentage: percentage,
    });
  }
};

// ============================================
// 16. VIDEO EVENTS (رویدادهای ویدیو - در صورت وجود)
// ============================================

/**
 * Play Video - پخش ویدیو
 * زمان: کاربر ویدیو را پخش می‌کند
 */
export const trackPlayVideo = (videoTitle: string, videoUrl: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'video_start', {
      event_category: 'video',
      video_title: videoTitle,
      video_url: videoUrl,
    });
  }
};

// ============================================
// 17. PRODUCT CARD INTERACTIONS (تعاملات کارت محصول)
// ============================================

/**
 * Hover Product Card - hover روی کارت محصول
 * زمان: کاربر mouse را روی کارت محصول می‌برد
 */
export const trackHoverProductCard = (productId: string, productName: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'hover_product_card', {
      event_category: 'product_interaction',
      product_id: productId,
      product_name: productName,
    });
  }
};

/**
 * View Product Image - مشاهده تصویر محصول
 * زمان: کاربر تصویر محصول را zoom می‌کند یا تغییر می‌دهد
 */
export const trackViewProductImage = (productId: string, imageIndex: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_product_image', {
      event_category: 'product_interaction',
      product_id: productId,
      image_index: imageIndex,
    });
  }
};

// ============================================
// 18. WALLET EVENTS (رویدادهای کیف پول)
// ============================================

/**
 * View Wallet - مشاهده کیف پول
 * زمان: کاربر وارد صفحه کیف پول می‌شود
 */
export const trackViewWallet = (balance: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_wallet', {
      event_category: 'wallet',
      wallet_balance: balance,
    });
  }
};

/**
 * Add Money to Wallet - شارژ کیف پول
 * زمان: کاربر کیف پول را شارژ می‌کند
 */
export const trackAddMoneyToWallet = (amount: number) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'add_money_to_wallet', {
      event_category: 'wallet',
      currency: 'IRR',
      value: amount,
    });
  }
};

// ============================================
// 19. FAQ & HELP EVENTS (رویدادهای راهنما)
// ============================================

/**
 * View FAQ - مشاهده سوالات متداول
 * زمان: کاربر وارد صفحه FAQ می‌شود
 */
export const trackViewFAQ = () => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'view_faq', {
      event_category: 'help',
    });
  }
};

/**
 * Expand FAQ Item - باز کردن سوال
 * زمان: کاربر یک سوال را باز می‌کند
 */
export const trackExpandFAQItem = (questionText: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'expand_faq_item', {
      event_category: 'help',
      question: questionText,
    });
  }
};

// ============================================
// 20. ADMIN EVENTS (رویدادهای ادمین)
// ============================================

/**
 * Admin Action - عملیات ادمین
 * زمان: ادمین عملیاتی انجام می‌دهد
 */
export const trackAdminAction = (actionType: string, entityType: string, entityId?: string) => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'admin_action', {
      event_category: 'admin',
      action_type: actionType,
      entity_type: entityType,
      entity_id: entityId,
    });
  }
};

// ============================================
// INITIALIZATION
// ============================================

/**
 * Generic Event Tracking - رویداد عمومی
 * برای eventهایی که دسته‌بندی خاصی ندارند
 */
export const trackEvent = (eventName: string, params?: Record<string, any>) => {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    try {
      window.gtag('event', eventName, params || {});
    } catch (error) {
      // Silently fail to avoid blocking UI
      console.warn('Analytics tracking failed:', error);
    }
  }
};

/**
 * Initialize GA4
 * این تابع را در App.tsx صدا بزنید
 */
export const initializeGA4 = (measurementId: string) => {
  if (typeof window !== 'undefined') {
    // ایجاد script tag برای GA4
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
    document.head.appendChild(script);

    // Initialize dataLayer
    window.dataLayer = window.dataLayer || [];
    window.gtag = function gtag() {
      window.dataLayer!.push(arguments);
    };
    window.gtag('js', new Date());
    window.gtag('config', measurementId, {
      send_page_view: false, // صفحات را manual track می‌کنیم
    });
  }
};