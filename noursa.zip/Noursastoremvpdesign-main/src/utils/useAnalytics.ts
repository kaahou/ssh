/**
 * Custom React Hook for Google Analytics 4
 * استفاده آسان از GA4 در کامپوننت‌های React
 */

import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import * as analytics from './analytics';

/**
 * Hook برای tracking خودکار page views
 * این hook را در App.tsx یا Layout اصلی استفاده کنید
 */
export const usePageTracking = () => {
  const location = useLocation();
  const prevLocation = useRef<string>('');

  useEffect(() => {
    // جلوگیری از track کردن مجدد همان صفحه
    if (location.pathname + location.search !== prevLocation.current) {
      prevLocation.current = location.pathname + location.search;
      
      // Track page view
      analytics.trackPageView(location.pathname + location.search);
    }
  }, [location]);
};

/**
 * Hook برای tracking زمان صرف شده روی صفحه
 * برای صفحات مقالات مفید است
 */
export const useReadTimeTracking = (articleId: string, enabled: boolean = true) => {
  const startTimeRef = useRef<number>(Date.now());

  useEffect(() => {
    if (!enabled) return;

    startTimeRef.current = Date.now();

    return () => {
      const readTime = Math.floor((Date.now() - startTimeRef.current) / 1000);
      if (readTime > 5) { // فقط اگر بیشتر از 5 ثانیه روی صفحه بود
        analytics.trackArticleReadTime(articleId, readTime);
      }
    };
  }, [articleId, enabled]);
};

/**
 * Hook برای tracking scroll depth
 * برای صفحات محتوایی طولانی
 */
export const useScrollTracking = (enabled: boolean = true) => {
  const trackedDepths = useRef<Set<number>>(new Set());

  useEffect(() => {
    if (!enabled) return;

    const handleScroll = () => {
      const scrollPercentage = Math.round(
        (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
      );

      // Track at 25%, 50%, 75%, 100%
      const milestones = [25, 50, 75, 100];
      milestones.forEach((milestone) => {
        if (scrollPercentage >= milestone && !trackedDepths.current.has(milestone)) {
          trackedDepths.current.add(milestone);
          analytics.trackScrollDepth(milestone);
        }
      });
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [enabled]);
};

/**
 * Hook برای دسترسی به تمام توابع analytics
 * استفاده در کامپوننت‌ها:
 * 
 * const analytics = useAnalytics();
 * analytics.trackAddToCart(product);
 */
export const useAnalytics = () => {
  return {
    // Page Events
    trackPageView: analytics.trackPageView,

    // E-commerce Events
    trackViewItemList: analytics.trackViewItemList,
    trackViewItem: analytics.trackViewItem,
    trackSelectItem: analytics.trackSelectItem,
    trackAddToCart: analytics.trackAddToCart,
    trackRemoveFromCart: analytics.trackRemoveFromCart,
    trackViewCart: analytics.trackViewCart,
    trackBeginCheckout: analytics.trackBeginCheckout,
    trackAddShippingInfo: analytics.trackAddShippingInfo,
    trackAddPaymentInfo: analytics.trackAddPaymentInfo,
    trackPurchase: analytics.trackPurchase,
    trackRefund: analytics.trackRefund,

    // Search Events
    trackSearch: analytics.trackSearch,
    trackViewSearchResults: analytics.trackViewSearchResults,

    // User Events
    trackLogin: analytics.trackLogin,
    trackSignUp: analytics.trackSignUp,
    trackShare: analytics.trackShare,

    // Consultation Events
    trackStartConsultation: analytics.trackStartConsultation,
    trackConsultationStep: analytics.trackConsultationStep,
    trackCompleteConsultation: analytics.trackCompleteConsultation,

    // Blog Events
    trackViewBlogList: analytics.trackViewBlogList,
    trackViewArticle: analytics.trackViewArticle,
    trackArticleReadTime: analytics.trackArticleReadTime,

    // Navigation Events
    trackClickNavigation: analytics.trackClickNavigation,
    trackClickBreadcrumb: analytics.trackClickBreadcrumb,
    trackOpenMobileMenu: analytics.trackOpenMobileMenu,

    // Contact Events
    trackClickFloatingContact: analytics.trackClickFloatingContact,
    trackSubmitContactForm: analytics.trackSubmitContactForm,

    // Filter Events
    trackApplyFilter: analytics.trackApplyFilter,
    trackSortProducts: analytics.trackSortProducts,
    trackChangePage: analytics.trackChangePage,

    // Profile Events
    trackViewProfile: analytics.trackViewProfile,
    trackUpdateProfile: analytics.trackUpdateProfile,
    trackViewOrderHistory: analytics.trackViewOrderHistory,
    trackOrderTracking: analytics.trackOrderTracking,

    // Affiliate Events
    trackViewAffiliateProgram: analytics.trackViewAffiliateProgram,
    trackGenerateAffiliateLink: analytics.trackGenerateAffiliateLink,

    // Footer Events
    trackClickFooterLink: analytics.trackClickFooterLink,
    trackSubscribeNewsletter: analytics.trackSubscribeNewsletter,

    // Error Events
    trackError: analytics.trackError,

    // Engagement Events
    trackScrollDepth: analytics.trackScrollDepth,

    // Video Events
    trackPlayVideo: analytics.trackPlayVideo,

    // Product Interaction Events
    trackHoverProductCard: analytics.trackHoverProductCard,
    trackViewProductImage: analytics.trackViewProductImage,

    // Wallet Events
    trackViewWallet: analytics.trackViewWallet,
    trackAddMoneyToWallet: analytics.trackAddMoneyToWallet,

    // Help Events
    trackViewFAQ: analytics.trackViewFAQ,
    trackExpandFAQItem: analytics.trackExpandFAQItem,

    // Admin Events
    trackAdminAction: analytics.trackAdminAction,
  };
};

/**
 * Hook برای tracking hover events با debounce
 * جلوگیری از ارسال event های زیاد
 */
export const useHoverTracking = (
  callback: () => void,
  delay: number = 1000
) => {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hasTrackedRef = useRef(false);

  const handleMouseEnter = () => {
    if (hasTrackedRef.current) return;

    timeoutRef.current = setTimeout(() => {
      callback();
      hasTrackedRef.current = true;
    }, delay);
  };

  const handleMouseLeave = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  };

  return { handleMouseEnter, handleMouseLeave };
};

export default useAnalytics;
