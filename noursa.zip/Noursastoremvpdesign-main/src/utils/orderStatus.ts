// Payment status types and utilities
export type PaymentStatus = 
  | 'pending'                  // سبد رها شده
  | 'paid_zarinpal'           // پرداخت شده زرین‌پال
  | 'awaiting_verification'   // در انتظار تایید پرداخت (کارت به کارت قبل از تایید)
  | 'paid_card'               // پرداخت شده کارت (کارت به کارت بعد از تایید)
  | 'paid_manual'             // پرداخت شده دستی
  | 'unpaid_card'             // پرداخت نشده کارتی (رد شده)
  | 'unpaid_manual';          // پرداخت نشده دستی

export type OrderStatus = 
  | 'pending'       // در انتظار
  | 'processing'    // در حال پردازش
  | 'completed'     // تکمیل شده
  | 'cancelled';    // لغو شده

// Get payment status label in Persian
export function getPaymentStatusLabel(status: string): string {
  switch (status) {
    case 'pending':
      return 'رها شده';
    case 'paid_zarinpal':
      return 'پرداخت شده (زرین‌پال)';
    case 'awaiting_verification':
      return 'در انتظار تایید پرداخت کارت';
    case 'paid_card':
      return 'پرداخت شده (کارت)';
    case 'paid_manual':
      return 'پرداخت شده (دستی)';
    case 'unpaid_card':
      return 'پرداخت نشده (کارتی)';
    case 'unpaid_manual':
      return 'پرداخت نشده (دستی)';
    case 'paid':
      return 'پرداخت شده';
    default:
      return status;
  }
}

// Get payment status color classes
export function getPaymentStatusColor(status: string): string {
  switch (status) {
    case 'pending':
      return 'bg-[#FEF3C7] text-[#92400E]'; // زرد
    case 'paid_zarinpal':
      return 'bg-[#D1FAE5] text-[#065F46]'; // سبز
    case 'awaiting_verification':
      return 'bg-[#FED7AA] text-[#9A3412]'; // نارنجی
    case 'paid_card':
      return 'bg-[#DBEAFE] text-[#1E40AF]'; // آبی
    case 'paid_manual':
      return 'bg-[#E0E7FF] text-[#3730A3]'; // بنفش
    case 'unpaid_card':
      return 'bg-[#FEE2E2] text-[#991B1B]'; // قرمز
    case 'unpaid_manual':
      return 'bg-[#FEE2E2] text-[#991B1B]'; // قرمز
    case 'paid':
      return 'bg-[#D1FAE5] text-[#065F46]'; // سبز
    default:
      return 'bg-[#F3F4F6] text-[#6B7280]'; // خاکستری
  }
}

// Get order status label in Persian
export function getOrderStatusLabel(status: string): string {
  switch (status) {
    case 'completed':
      return 'تکمیل شده';
    case 'processing':
      return 'در حال پردازش';
    case 'pending':
      return 'در انتظار';
    case 'cancelled':
      return 'لغو شده';
    default:
      return status;
  }
}

// Get order status color classes
export function getOrderStatusColor(status: string): string {
  switch (status) {
    case 'completed':
      return 'bg-[#D1FAE5] text-[#065F46]';
    case 'processing':
      return 'bg-[#DBEAFE] text-[#1E40AF]';
    case 'pending':
      return 'bg-[#FEF3C7] text-[#92400E]';
    case 'cancelled':
      return 'bg-[#FEE2E2] text-[#991B1B]';
    default:
      return 'bg-[#F3F4F6] text-[#6B7280]';
  }
}