import { Product } from '../components/ProductCard';

/**
 * Get the display name of a product by combining variant_name and product_name
 */
export function getProductName(product: Product): string {
  if (product.variant_name) {
    return `${product.variant_name} ${product.product_name}`;
  }
  return product.product_name || product.name || 'محصول';
}

/**
 * Get the product ID (supports both product_id and legacy id field)
 */
export function getProductId(product: Product): string {
  return String(product.product_id || product.id);
}
