/**
 * Constants برای GA4 Events
 * استفاده از این constants جلوی typo و inconsistency را می‌گیرد
 */

// ============================================
// LIST NAMES - نام‌های لیست‌های محصولات
// ============================================

export const LIST_NAMES = {
  ALL_PRODUCTS: 'تمام محصولات',
  FEATURED_PRODUCTS: 'محصولات ویژه',
  SEARCH_RESULTS: 'نتایج جستجو',
  RELATED_PRODUCTS: 'محصولات مرتبط',
  CATEGORY_FACE: 'مراقبت پوست صورت',
  CATEGORY_BODY: 'مراقبت پوست بدن',
  CATEGORY_HAIR: 'مراقبت مو',
  HOMEPAGE_FEATURED: 'محصولات ویژه صفحه اصلی',
  HOMEPAGE_BESTSELLERS: 'پرفروش‌ترین‌ها',
  HOMEPAGE_NEW_ARRIVALS: 'تازه‌های فروشگاه',
} as const;

// ============================================
// CONSULTATION STEPS - مراحل مشاوره
// ============================================

export const CONSULTATION_STEPS = {
  PERSONAL_INFO: 'اطلاعات شخصی',
  SKIN_TYPE: 'نوع پوست',
  SKIN_CONCERNS: 'مشکلات پوستی',
  LIFESTYLE: 'سبک زندگی',
  PRODUCT_PREFERENCES: 'ترجیحات محصولات',
  BUDGET: 'بودجه',
  FINAL_REVIEW: 'بررسی نهایی',
} as const;

// ============================================
// LOGIN METHODS - روش‌های ورود
// ============================================

export const LOGIN_METHODS = {
  EMAIL: 'email',
  PHONE: 'phone',
  GOOGLE: 'google',
  FACEBOOK: 'facebook',
  APPLE: 'apple',
} as const;

// ============================================
// PAYMENT METHODS - روش‌های پرداخت
// ============================================

export const PAYMENT_METHODS = {
  ZARINPAL: 'zarinpal',
  WALLET: 'wallet',
  BANK_TRANSFER: 'bank_transfer',
  CASH_ON_DELIVERY: 'cash_on_delivery',
} as const;

// ============================================
// SHIPPING METHODS - روش‌های ارسال
// ============================================

export const SHIPPING_METHODS = {
  STANDARD: 'standard',
  EXPRESS: 'express',
  SUPER_EXPRESS: 'super_express',
  IN_STORE_PICKUP: 'in_store_pickup',
} as const;

// ============================================
// SHARE METHODS - روش‌های اشتراک‌گذاری
// ============================================

export const SHARE_METHODS = {
  WHATSAPP: 'whatsapp',
  TELEGRAM: 'telegram',
  INSTAGRAM: 'instagram',
  FACEBOOK: 'facebook',
  TWITTER: 'twitter',
  COPY_LINK: 'copy_link',
  EMAIL: 'email',
  SMS: 'sms',
} as const;

// ============================================
// CONTACT METHODS - روش‌های تماس
// ============================================

export const CONTACT_METHODS = {
  PHONE: 'phone',
  WHATSAPP: 'whatsapp',
  TELEGRAM: 'telegram',
  EMAIL: 'email',
  CONTACT_FORM: 'contact_form',
  LIVE_CHAT: 'live_chat',
} as const;

// ============================================
// PROFILE SECTIONS - بخش‌های پروفایل
// ============================================

export const PROFILE_SECTIONS = {
  HOME: 'home',
  ORDERS: 'orders',
  CONSULTATIONS: 'consultations',
  WALLET: 'wallet',
  SETTINGS: 'settings',
  ADDRESSES: 'addresses',
  FAVORITE_PRODUCTS: 'favorite_products',
  AFFILIATE: 'affiliate',
  NOTIFICATIONS: 'notifications',
} as const;

// ============================================
// NAVIGATION ITEMS - آیتم‌های منو
// ============================================

export const NAVIGATION_ITEMS = {
  HOME: 'خانه',
  PRODUCTS: 'محصولات',
  BLOG: 'بلاگ',
  CONSULTATION: 'مشاوره',
  ABOUT: 'درباره ما',
  CONTACT: 'تماس با ما',
  FAQ: 'سوالات متداول',
  PROFILE: 'پروفایل',
  CART: 'سبد خرید',
  SEARCH: 'جستجو',
} as const;

// ============================================
// FILTER TYPES - انواع فیلتر
// ============================================

export const FILTER_TYPES = {
  CATEGORY: 'category',
  PRICE_RANGE: 'price_range',
  BRAND: 'brand',
  SKIN_TYPE: 'skin_type',
  CONCERN: 'concern',
  INGREDIENT: 'ingredient',
  AVAILABILITY: 'availability',
  RATING: 'rating',
} as const;

// ============================================
// SORT METHODS - روش‌های مرتب‌سازی
// ============================================

export const SORT_METHODS = {
  DEFAULT: 'default',
  NEWEST: 'newest',
  OLDEST: 'oldest',
  PRICE_ASC: 'price_asc',
  PRICE_DESC: 'price_desc',
  NAME_ASC: 'name_asc',
  NAME_DESC: 'name_desc',
  RATING: 'rating',
  POPULARITY: 'popularity',
  BESTSELLING: 'bestselling',
} as const;

// ============================================
// ADMIN ACTIONS - عملیات ادمین
// ============================================

export const ADMIN_ACTIONS = {
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  VIEW: 'view',
  EXPORT: 'export',
  IMPORT: 'import',
  APPROVE: 'approve',
  REJECT: 'reject',
  PUBLISH: 'publish',
  UNPUBLISH: 'unpublish',
} as const;

// ============================================
// ADMIN ENTITY TYPES - انواع موجودیت‌های ادمین
// ============================================

export const ADMIN_ENTITY_TYPES = {
  PRODUCT: 'product',
  ORDER: 'order',
  USER: 'user',
  ARTICLE: 'article',
  CONSULTATION: 'consultation',
  CATEGORY: 'category',
  COUPON: 'coupon',
  REVIEW: 'review',
  BANNER: 'banner',
  SETTING: 'setting',
} as const;

// ============================================
// CONTENT TYPES - انواع محتوا
// ============================================

export const CONTENT_TYPES = {
  PRODUCT: 'product',
  ARTICLE: 'article',
  CATEGORY: 'category',
  PAGE: 'page',
  VIDEO: 'video',
  IMAGE: 'image',
} as const;

// ============================================
// PROFILE UPDATE TYPES - انواع ویرایش پروفایل
// ============================================

export const PROFILE_UPDATE_TYPES = {
  PERSONAL_INFO: 'personal_info',
  AVATAR: 'avatar',
  PASSWORD: 'password',
  EMAIL: 'email',
  PHONE: 'phone',
  ADDRESS: 'address',
  PREFERENCES: 'preferences',
  NOTIFICATIONS: 'notifications',
} as const;

// ============================================
// ARTICLE CATEGORIES - دسته‌بندی مقالات
// ============================================

export const ARTICLE_CATEGORIES = {
  SKINCARE_TIPS: 'نکات مراقبت پوست',
  PRODUCT_REVIEWS: 'بررسی محصولات',
  INGREDIENT_GUIDE: 'راهنمای مواد تشکیل‌دهنده',
  ROUTINE_GUIDE: 'راهنمای روتین پوستی',
  COMMON_PROBLEMS: 'مشکلات رایج پوستی',
  SEASONAL_CARE: 'مراقبت فصلی',
  NEWS: 'اخبار و رویدادها',
  TUTORIALS: 'آموزش‌ها',
} as const;

// ============================================
// SCROLL DEPTH MILESTONES - نقاط عمق اسکرول
// ============================================

export const SCROLL_MILESTONES = [25, 50, 75, 90, 100] as const;

// ============================================
// PAGE NAMES - نام صفحات
// ============================================

export const PAGE_NAMES = {
  HOME: 'صفحه اصلی',
  PRODUCTS: 'لیست محصولات',
  PRODUCT_DETAIL: 'جزئیات محصول',
  CART: 'سبد خرید',
  CHECKOUT: 'تسویه حساب',
  PAYMENT_CALLBACK: 'نتیجه پرداخت',
  BLOG: 'وبلاگ',
  ARTICLE: 'مقاله',
  CONSULTATION: 'مشاوره',
  CONSULTATION_SUCCESS: 'تایید مشاوره',
  CONTACT: 'تماس با ما',
  ABOUT: 'درباره ما',
  FAQ: 'سوالات متداول',
  PROFILE: 'پروفایل کاربری',
  LOGIN: 'ورود / ثبت‌نام',
  SEARCH: 'جستجو',
  ORDER_TRACKING: 'پیگیری سفارش',
  TERMS: 'قوانین و مقررات',
  PRIVACY: 'حریم خصوصی',
  RETURN_POLICY: 'قوانین مرجوعی',
  SHIPPING_GUIDE: 'راهنمای ارسال',
  MONEY_BACK_GUARANTEE: 'ضمانت بازگشت وجه',
  AFFILIATE: 'همکاری در فروش',
} as const;

// ============================================
// ERROR LOCATIONS - محل‌های بروز خطا
// ============================================

export const ERROR_LOCATIONS = {
  // Pages
  HOME_PAGE: 'HomePage',
  PRODUCT_LIST_PAGE: 'ProductListPage',
  PRODUCT_DETAIL_PAGE: 'ProductDetailPage',
  CHECKOUT_PAGE: 'CheckoutPage',
  PAYMENT_CALLBACK_PAGE: 'PaymentCallbackPage',
  CONSULTATION_WIZARD: 'ConsultationWizard',
  
  // Components
  HEADER: 'Header',
  FOOTER: 'Footer',
  PRODUCT_CARD: 'ProductCard',
  CART_CONTEXT: 'CartContext',
  USER_CONTEXT: 'UserContext',
  
  // Functions
  FETCH_PRODUCTS: 'fetchProducts',
  FETCH_ARTICLES: 'fetchArticles',
  CREATE_ORDER: 'createOrder',
  VERIFY_PAYMENT: 'verifyPayment',
  SUBMIT_CONSULTATION: 'submitConsultation',
  
  // API Calls
  API_PRODUCTS: 'API.products',
  API_ORDERS: 'API.orders',
  API_PAYMENT: 'API.payment',
  API_USERS: 'API.users',
} as const;

// ============================================
// HOVER DELAY - تاخیر برای track کردن hover
// ============================================

export const HOVER_DELAY_MS = 1000; // 1 second

// ============================================
// SEARCH DEBOUNCE - تاخیر برای جستجو
// ============================================

export const SEARCH_DEBOUNCE_MS = 500; // 500ms

// ============================================
// READ TIME THRESHOLD - حداقل زمان برای track کردن read time
// ============================================

export const MIN_READ_TIME_SECONDS = 5; // 5 seconds

// ============================================
// Helper Types
// ============================================

export type ListName = typeof LIST_NAMES[keyof typeof LIST_NAMES];
export type ConsultationStep = typeof CONSULTATION_STEPS[keyof typeof CONSULTATION_STEPS];
export type LoginMethod = typeof LOGIN_METHODS[keyof typeof LOGIN_METHODS];
export type PaymentMethod = typeof PAYMENT_METHODS[keyof typeof PAYMENT_METHODS];
export type ShippingMethod = typeof SHIPPING_METHODS[keyof typeof SHIPPING_METHODS];
export type ShareMethod = typeof SHARE_METHODS[keyof typeof SHARE_METHODS];
export type ContactMethod = typeof CONTACT_METHODS[keyof typeof CONTACT_METHODS];
export type ProfileSection = typeof PROFILE_SECTIONS[keyof typeof PROFILE_SECTIONS];
export type NavigationItem = typeof NAVIGATION_ITEMS[keyof typeof NAVIGATION_ITEMS];
export type FilterType = typeof FILTER_TYPES[keyof typeof FILTER_TYPES];
export type SortMethod = typeof SORT_METHODS[keyof typeof SORT_METHODS];
export type AdminAction = typeof ADMIN_ACTIONS[keyof typeof ADMIN_ACTIONS];
export type AdminEntityType = typeof ADMIN_ENTITY_TYPES[keyof typeof ADMIN_ENTITY_TYPES];
export type ContentType = typeof CONTENT_TYPES[keyof typeof CONTENT_TYPES];
export type ProfileUpdateType = typeof PROFILE_UPDATE_TYPES[keyof typeof PROFILE_UPDATE_TYPES];
export type ArticleCategory = typeof ARTICLE_CATEGORIES[keyof typeof ARTICLE_CATEGORIES];
export type PageName = typeof PAGE_NAMES[keyof typeof PAGE_NAMES];
export type ErrorLocation = typeof ERROR_LOCATIONS[keyof typeof ERROR_LOCATIONS];

// ============================================
// USAGE EXAMPLES
// ============================================

/**
 * مثال استفاده:
 * 
 * import { LIST_NAMES, PAYMENT_METHODS, CONSULTATION_STEPS } from './utils/analyticsConstants';
 * 
 * // در ProductListPage
 * analytics.trackViewItemList(products, LIST_NAMES.ALL_PRODUCTS);
 * 
 * // در CheckoutPage
 * analytics.trackAddPaymentInfo(cartItems, total, PAYMENT_METHODS.ZARINPAL);
 * 
 * // در ConsultationWizard
 * analytics.trackConsultationStep(1, CONSULTATION_STEPS.SKIN_TYPE);
 * 
 * // مزایا:
 * // 1. جلوی typo را می‌گیرد
 * // 2. Autocomplete در IDE
 * // 3. Type-safe
 * // 4. Refactoring آسان
 * // 5. Consistency در همه جای پروژه
 */
