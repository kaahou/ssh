# 🎨 سیستم طراحی نورسا - مستندات پیاده‌سازی

## نمای کلی

این پروژه از **سیستم طراحی کامل نورسا** با تم رنگی **سبز جنگلی و کرم** استفاده می‌کند.

---

## 🎨 رنگ‌های اعمال شده

### رنگ‌های اصلی (Primary):
```css
--color-primary-dark: #1A2011     /* سبز جنگلی تیره - دکمه‌ها، عناوین */
--color-primary-medium: #484D2C    /* سبز جنگلی میانه - Hover states */
--color-primary-light: #6B7345     /* سبز جنگلی روشن - بوردرها */
--color-primary-green: #144236     /* سبز آکسنت */
```

### رنگ‌های ثانویه (Secondary):
```css
--color-cream: #F9E1B4            /* کرم اصلی - آکسنت‌ها، دکمه‌های ثانویه */
--color-cream-light: #FEF5E7      /* کرم روشن - پس‌زمینه‌ها */
```

### رنگ‌های خنثی (Neutral):
```css
--color-gray-50: #FAFAFA          /* پس‌زمینه صفحه */
--color-gray-200: #E8E8E8         /* بوردرها */
--color-gray-500: #888888         /* متن کم‌رنگ */
--color-gray-900: #1A2011         /* متن اصلی */
```

### رنگ‌های معنایی (Semantic):
```css
--color-success: #16A34A          /* موفقیت */
--color-error: #DC2626            /* خطا */
--color-warning: #F59E0B          /* هشدار */
```

---

## 🔤 تایپوگرافی

### فونت:
- **خانواده فونت**: Vazirmatn (فونت فارسی)
- **منبع**: CDN jsdelivr
- **استفاده**: برای همه متون (عناوین، متن اصلی، کپشن)

### سایزها:
```css
h1: 2rem (32px)         - font-weight: 700
h2: 1.75rem (28px)      - font-weight: 700
h3: 1.5rem (24px)       - font-weight: 500
h4: 1.25rem (20px)      - font-weight: 500
p:  1rem (16px)         - font-weight: 400
```

### Line Height:
- H1, H2: 1.4 (140%)
- H3, H4: 1.45-1.5 (145-150%)
- Body: 1.75 (175%)

---

## 📏 فاصله‌گذاری

```css
--spacing-xs: 4px       /* فاصله بسیار کم */
--spacing-sm: 8px       /* فاصله کم */
--spacing-md: 12px      /* فاصله متوسط */
--spacing-lg: 16px      /* فاصله استاندارد */
--spacing-xl: 20px      /* فاصه بزرگ */
--spacing-2xl: 24px     /* فاصله بخش‌ها */
--spacing-3xl: 32px     /* فاصله بزرگ‌تر */
--spacing-4xl: 48px     /* فاصله بین سکشن‌ها */
```

### قوانین فاصله‌گذاری:
- ✅ بین سکشن‌های اصلی: **48px**
- ✅ داخل سکشن: **24px**
- ✅ بین عناصر: **16px**
- ✅ Padding کارت‌ها: **24px**

---

## 🔲 Border Radius

```css
--radius-sm: 8px        /* تگ‌ها، badge‌ها */
--radius-md: 12px       /* دکمه‌ها، input‌ها */
--radius-lg: 16px       /* کارت‌ها */
--radius-xl: 20px       /* کارت‌های ویژه */
--radius-full: 9999px   /* دایره‌ها، pill buttons */
```

### استفاده:
- **دکمه‌ها**: 12px
- **کارت‌ها**: 16px
- **Input‌ها**: 12px
- **Badge/Tag**: 9999px (pill shape)

---

## 🎭 سایه‌ها (Shadows)

```css
--shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05)          /* کارت‌ها */
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1)        /* Hover states */
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1)      /* Modals */
--shadow-button: 0 10px 15px -3px rgba(26, 32, 17, 0.2) /* دکمه‌ها */
```

---

## 🖲️ کامپوننت‌ها

### Button (دکمه‌ها):
```tsx
// Sizes
Small: h-[40px], px-[16px]
Medium: h-[48px], px-[24px]
Large: h-[56px], px-[32px]

// Variants
Primary: bg-[#1A2011], hover:bg-[#484D2C]
Secondary: bg-[#F9E1B4], text-[#1A2011]
Outline: border-[#E8E8E8], hover:border-[#1A2011]

// Border Radius
rounded-[12px]
```

### Card (کارت‌ها):
```tsx
// Styling
bg-white
border: border-[#E8E8E8]
rounded-[16px]
p-[24px]
shadow: hover:shadow-md

// Hover Effect
hover:shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1)]
transition-shadow duration-200
```

### Input (ورودی‌ها):
```tsx
// Styling
h-[48px]
rounded-[12px]
border-[#E8E8E8]
bg-[#F3F3F5]

// Focus State
focus:border-[#1A2011]
```

### Badge (نشان‌ها):
```tsx
// Styling
rounded-full (pill shape)

// Variants
Success: bg-[#D1FAE5], text-[#065F46]
Error: bg-destructive
Warning: bg-[#FEF3C7]
```

---

## 📱 Breakpoints

```css
Mobile: < 768px         (4 ستون)
Tablet: 768px - 1024px  (8 ستون)
Desktop: > 1024px       (12 ستون)

Container: max-width 1200px (desktop)
```

---

## 🎯 صفحات پیاده‌سازی شده

### 1. HomePage (صفحه خانه)
- ✅ Hero Section با gradient سبز جنگلی و کرم
- ✅ دسته‌بندی‌ها با آیکون‌ها
- ✅ محصولات ویژه
- ✅ بخش CTA با پس‌زمینه سبز جنگلی

### 2. ProductListPage (لیست محصولات)
- ✅ فیلتر جستجو
- ✅ دسته‌بندی و مرتب‌سازی
- ✅ Grid محصولات

### 3. ProductDetailPage (جزئیات محصول)
- ✅ تصویر بزرگ محصول
- ✅ اطلاعات کامل
- ✅ کنترل تعداد
- ✅ محصولات مرتبط

### 4. CartPage (سبد خرید)
- ✅ لیست آیتم‌های سبد
- ✅ خلاصه سفارش
- ✅ فرم تسویه حساب

---

## 🎨 نمونه کد

### استفاده از رنگ‌ها:
```tsx
// Primary Color
<Button className="bg-[#1A2011] hover:bg-[#484D2C]">

// Cream Color
<div className="bg-[#F9E1B4]">

// Border
<div className="border-[#E8E8E8]">

// Text Colors
<p className="text-[#1A2011]">     {/* متن اصلی */}
<p className="text-[#888888]">     {/* متن کم‌رنگ */}
```

### استفاده از Border Radius:
```tsx
<Button className="rounded-[12px]">
<div className="rounded-[16px]">      {/* Card */}
<Badge className="rounded-full">     {/* Pill */}
```

### استفاده از Spacing:
```tsx
<section className="space-y-[48px]">  {/* بین سکشن‌ها */}
<div className="p-[24px]">            {/* Padding کارت */}
<div className="mb-[16px]">           {/* فاصله بین عناصر */}
```

---

## ✅ چک‌لیست کیفیت

### رنگ‌ها:
- ✅ همه دکمه‌های اصلی: `#1A2011`
- ✅ Hover state: `#484D2C`
- ✅ کرم آکسنت: `#F9E1B4`
- ✅ بوردرها: `#E8E8E8`
- ✅ متن اصلی: `#1A2011`
- ✅ متن کم‌رنگ: `#888888`

### Typography:
- ✅ فونت Vazirmatn برای همه متون
- ✅ H1-H4 با font-weight درست
- ✅ Line-height استاندارد

### Spacing:
- ✅ فاصله بین سکشن‌ها: 48px
- ✅ Padding کارت‌ها: 24px
- ✅ فاصله بین عناصر: 16px

### Components:
- ✅ دکمه‌ها: height استاندارد
- ✅ کارت‌ها: radius 16px
- ✅ Input‌ها: height 48px
- ✅ Badge‌ها: pill shape

### Responsive:
- ✅ موبایل: 1-2 ستون
- ✅ تبلت: 2-3 ستون
- ✅ دسکتاپ: 3-4 ستون

---

## 📚 منابع

- **سیستم طراحی کامل**: `/DESIGN_SYSTEM.md`
- **فونت Vazirmatn**: https://github.com/rastikerdar/vazirmatn
- **Tailwind CSS**: https://tailwindcss.com
- **Lucide Icons**: https://lucide.dev

---

**✨ با این سیستم طراحی، تجربه کاربری یکپارچه و حرفه‌ای در تمام صفحات نورسا ایجاد شده است!**
