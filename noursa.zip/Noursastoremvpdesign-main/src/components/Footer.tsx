import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin } from 'lucide-react';
import { OptimizedImage } from './OptimizedImage';
import { EnamadTrustSeal } from './EnamadTrustSeal';

export function Footer() {
  return (
    <footer className="bg-[#F4F4F5] border-t border-[#E8E8E8] mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <OptimizedImage 
                src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo_top.png" 
                alt="نورسا" 
                className="h-16 w-auto"
              />
            </div>
            <p className="text-[#888888]">
              فروشگاه آنلاین نورسا با ارائه محصولات با کیفیت و خدمات عالی، بهترین انتخاب برای خرید آنلاین شماست. با ما تماس بگیرید و از مشاوره رایگان استفاده کنید.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-[#1A2011]">لینک‌های سریع</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/about"
                  className="text-[#888888] hover:text-[#1A2011] transition-colors"
                >
                  درباره ما
                </Link>
              </li>
              <li>
                <Link 
                  to="/shipping-guide"
                  className="text-[#888888] hover:text-[#1A2011] transition-colors"
                >
                  راهنمای خرید و ارسال
                </Link>
              </li>
              <li>
                <Link 
                  to="/return-policy"
                  className="text-[#888888] hover:text-[#1A2011] transition-colors"
                >
                  بازگشت کالا
                </Link>
              </li>
              <li>
                <Link 
                  to="/money-back-guarantee"
                  className="text-[#888888] hover:text-[#1A2011] transition-colors"
                >
                  ضمانت بازگشت وجه
                </Link>
              </li>
              <li>
                <Link 
                  to="/faq"
                  className="text-[#888888] hover:text-[#1A2011] transition-colors"
                >
                  پرسش‌های متداول
                </Link>
              </li>
              <li>
                <Link 
                  to="/contact"
                  className="text-[#888888] hover:text-[#1A2011] transition-colors"
                >
                  تماس با ما
                </Link>
              </li>
              <li>
                <Link 
                  to="/order-tracking"
                  className="text-[#888888] hover:text-[#1A2011] transition-colors"
                >
                  پیگیری سفارش
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-[#1A2011]">تماس با ما</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-[#888888]">
                <Phone className="w-4 h-4" />
                <span dir="ltr">۰۵۱-۳۸۳۷۳۵۳۰</span>
              </li>
              <li className="flex items-center gap-2 text-[#888888]">
                <Mail className="w-4 h-4" />
                <span>be@nursaa.ir</span>
              </li>
              <li className="flex items-center gap-2 text-[#888888]">
                <MapPin className="w-4 h-4" />
                <span>خراسان رضوی، گلمکان، اسجیل، صاحب‌الزمان ۴</span>
              </li>
            </ul>
          </div>

          {/* E-Namad Logo - Separate Column */}
          <div className="flex items-center justify-center md:justify-start">
            <EnamadTrustSeal />
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-[#E8E8E8] text-center text-[#888888]">
          <p>© ۱۴۰۴ فروشگاه نورسا. تمامی حقوق محفوظ است.</p>
          <div className="flex flex-wrap justify-center gap-4 mt-4 text-sm">
            <Link 
              to="/terms"
              className="hover:text-[#1A2011] transition-colors"
            >
              قوانین و مقررات
            </Link>
            <span>|</span>
            <Link 
              to="/privacy"
              className="hover:text-[#1A2011] transition-colors"
            >
              سیاست حریم خصوصی
            </Link>
            <span>|</span>
            <Link 
              to="/money-back-guarantee"
              className="hover:text-[#1A2011] transition-colors"
            >
              ضمانت بازگشت ۱۰۰٪ وجه
            </Link>
            <span>|</span>
            <Link 
              to="/site-map"
              className="hover:text-[#1A2011] transition-colors"
            >
              نقشه سایت
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}