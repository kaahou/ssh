import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product } from '../utils/product';
import { logger } from '../src/utils/logger';

export interface CartItem extends Product {
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getTotalItems: () => number;
  getTotalPrice: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    // Load cart from localStorage on init with validation
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('noursa-cart');
        
        if (!saved) {
          return [];
        }
        
        const parsed = JSON.parse(saved);
        
        // ✅ Validation: باید array باشد
        if (!Array.isArray(parsed)) {
          logger.warn('Invalid cart data in localStorage (not an array), resetting');
          localStorage.removeItem('noursa-cart');
          return [];
        }
        
        // ✅ Validation: بررسی ساختار هر item
        const validItems = parsed.filter((item: any) => {
          const hasId = item.id || item.product_id;
          const hasPrice = typeof item.price === 'number' && item.price >= 0;
          const hasQuantity = typeof item.quantity === 'number' && item.quantity > 0;
          
          if (!hasId || !hasPrice || !hasQuantity) {
            logger.warn('Invalid cart item detected, skipping:', item);
            return false;
          }
          
          return true;
        });
        
        // اگر تعداد آیتم‌های معتبر کمتر از کل باشد، localStorage را بروز کنید
        if (validItems.length !== parsed.length) {
          logger.log(`Cleaned cart: ${parsed.length} items -> ${validItems.length} valid items`);
          localStorage.setItem('noursa-cart', JSON.stringify(validItems));
        }
        
        return validItems;
        
      } catch (error) {
        logger.error('Error loading cart from localStorage:', error);
        // پاک کردن localStorage خراب شده
        localStorage.removeItem('noursa-cart');
        return [];
      }
    }
    return [];
  });

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('noursa-cart', JSON.stringify(items));
      } catch (error) {
        logger.error('Error saving cart to localStorage:', error);
      }
    }
  }, [items]);

  const addItem = (product: Product) => {
    try {
      setItems((currentItems) => {        
        // Use 'id' first (WooCommerce), then 'product_id' (Postgres) as fallback
        const productId = String(product.id || product.product_id);
        
        if (!productId || productId === 'undefined') {
          logger.error('Invalid product ID:', product);
          return currentItems;
        }
        
        const existingItem = currentItems.find((item) => {
          const itemId = String(item.id || item.product_id);
          return itemId === productId;
        });
        
        if (existingItem) {
          // Increase quantity if item already in cart
          return currentItems.map((item) => {
            const itemId = String(item.id || item.product_id);
            return itemId === productId
              ? { ...item, quantity: item.quantity + 1 }
              : item;
          });
        } else {
          // Add new item with quantity 1
          // Create a clean copy with only serializable fields
          const cleanProduct: CartItem = {
            // WooCommerce fields (primary)
            id: product.id,
            name: product.name,
            slug: product.slug,
            price: product.price,
            image: product.image,
            stock: product.stock,
            category: product.category,
            originalPrice: product.originalPrice,
            short_description: product.short_description,
            description: product.description,
            // Postgres fields (optional)
            product_id: product.product_id,
            product_name: product.product_name,
            variant_name: product.variant_name,
            full_description: product.full_description,
            original_price: product.original_price,
            category_id: product.category_id,
            product_family: product.product_family,
            image_url: product.image_urls || product.image_url,
            featured: product.featured,
            created_at: product.created_at,
            updated_at: product.updated_at,
            // Add quantity
            quantity: 1
          };
          
          return [...currentItems, cleanProduct];
        }
      });
    } catch (error) {
      logger.error('Error in addItem:', error);
      throw error; // Re-throw to be caught by caller
    }
  };

  const removeItem = (productId: string) => {
    setItems((currentItems) =>
      currentItems.filter((item) => {
        const itemId = String(item.id || item.product_id);
        return itemId !== productId;
      })
    );
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }

    setItems((currentItems) =>
      currentItems.map((item) => {
        const itemId = String(item.id || item.product_id);
        return itemId === productId ? { ...item, quantity } : item;
      })
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  const getTotalItems = () => {
    return items.reduce((total, item) => total + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return items.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        getTotalItems,
        getTotalPrice,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}