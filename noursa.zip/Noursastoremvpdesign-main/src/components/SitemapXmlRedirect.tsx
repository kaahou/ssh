import { useEffect } from 'react';
import { projectId } from '../utils/supabase/info';

/**
 * Component to redirect /sitemap.xml requests to the server-generated XML sitemap
 * This ensures Google Search Console receives proper XML instead of React HTML
 */
export function SitemapXmlRedirect() {
  useEffect(() => {
    // Redirect to server endpoint for XML sitemap
    window.location.href = `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/sitemap.xml`;
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="text-center">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1A2011] border-r-transparent mb-4"></div>
        <p className="text-[#888888]">در حال بارگذاری نقشه سایت...</p>
      </div>
    </div>
  );
}
