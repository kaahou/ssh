import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface User {
  user_id: number;
  phone?: string;
  first_name?: string;
  last_name?: string;
  email?: string;
  gender?: string;
  created_at: string;
  last_seen_at?: string;
  status?: string;
  profile?: any;
}

interface UserContextType {
  user: User | null;
  loading: boolean;
  updateUser: (updates: Partial<User>) => Promise<boolean>;
  isProfileComplete: () => boolean;
  getCompletionPercentage: () => number;
  logout: () => void;
  reloadUser: () => Promise<void>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      // Check both sessionStorage (for session) and localStorage (for persistent login)
      let userId = sessionStorage.getItem('userId');
      if (!userId) {
        userId = localStorage.getItem('userId');
        // If found in localStorage, also save to sessionStorage for current session
        if (userId) {
          sessionStorage.setItem('userId', userId);
        }
      }
      
      if (!userId) {
        setLoading(false);
        return;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/user/${userId}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const userData = data.user;
        
        // Clean up "nan" strings and parse profile
        if (userData) {
          // Helper to clean "nan"
          const cleanValue = (val: any) => (val === "nan" || val === "null" ? null : val);
          
          userData.first_name = cleanValue(userData.first_name);
          userData.last_name = cleanValue(userData.last_name);
          userData.email = cleanValue(userData.email);
          userData.phone = cleanValue(userData.phone);
          
          // Parse profile if it's a string
          if (typeof userData.profile === 'string') {
            try {
              userData.profile = JSON.parse(userData.profile);
            } catch (e) {
              console.error('Error parsing user profile JSON:', e);
              userData.profile = {};
            }
          }
          
          // If profile is null/undefined, make it empty object
          if (!userData.profile) {
            userData.profile = {};
          }
        }
        
        setUser(userData);
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateUser = async (updates: Partial<User>): Promise<boolean> => {
    try {
      if (!user) return false;

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/user/${user.user_id}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(updates),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error updating user:', error);
      return false;
    }
  };

  const isProfileComplete = (): boolean => {
    if (!user) return false;
    return !!(user.first_name && user.last_name && user.email);
  };

  const getCompletionPercentage = (): number => {
    if (!user) return 0;
    
    let total = 0;
    let completed = 0;
    
    // Required fields
    if (user.phone) completed++;
    total++;
    
    if (user.first_name) completed++;
    total++;
    
    if (user.last_name) completed++;
    total++;
    
    // Optional fields
    if (user.email) completed++;
    total++;
    
    if (user.gender) completed++;
    total++;
    
    return Math.round((completed / total) * 100);
  };

  const logout = () => {
    localStorage.removeItem('userId');
    localStorage.removeItem('userPhone');
    sessionStorage.removeItem('userId');
    setUser(null);
  };

  const reloadUser = async () => {
    await loadUser();
  };

  return (
    <UserContext.Provider value={{ 
      user, 
      loading, 
      updateUser, 
      isProfileComplete, 
      getCompletionPercentage,
      logout,
      reloadUser
    }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}