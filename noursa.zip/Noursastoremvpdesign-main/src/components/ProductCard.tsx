import { ShoppingCart } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { OptimizedImage } from "./OptimizedImage";

export interface Product {
  // Main WooCommerce fields (for backward compatibility)
  id: number | string;
  name: string;
  slug: string;
  price: number;
  image: string | null;
  stock: number;
  category?: string;
  originalPrice?: number | null;
  short_description?: string | null;
  description?: string | null;
  
  // Postgres schema fields (actual table structure)
  product_id?: number;
  product_name?: string;
  variant_name?: string | null;
  product_family?: number | null;
  full_description?: string | null;
  old_price?: number | null; // Changed from original_price
  category_id?: number | null;
  image_urls?: string | null; // Changed from image_url (plural!)
  meta_description?: string | null;
  keywords?: string | null;
  score?: number | null; // امتیاز محصول برای مرتب‌سازی
  created_at?: string;
  updated_at?: string;
  
  // For backward compatibility - will be mapped from new fields
  original_price?: number | null;
  image_url?: string | null;
  featured?: boolean;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, event?: React.MouseEvent) => void;
  priority?: boolean; // For optimizing image loading
}

export function ProductCard({ product, onAddToCart, priority = false }: ProductCardProps) {
  // Support both old and new field names
  const productImage = product.image_urls || product.image_url || product.image || '';
  const productOriginalPrice = product.old_price || product.original_price || product.originalPrice;
  
  // Combine variant_name and product_name
  const productName = product.variant_name 
    ? `${product.variant_name} ${product.product_name}` 
    : (product.product_name || product.name || 'بدون نام');
  
  const shortDescription = product.short_description || '';
  
  const hasDiscount = productOriginalPrice && productOriginalPrice > product.price;
  const discountPercent = hasDiscount 
    ? Math.round(((productOriginalPrice! - product.price) / productOriginalPrice!) * 100)
    : 0;

  return (
    <div className="group relative bg-white rounded-[16px] border border-border overflow-hidden hover:shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1)] transition-shadow duration-200">
      {/* Product Image */}
      <div className="relative aspect-[4/5] overflow-hidden bg-[#F3F4F6]">
        {productImage ? (
          <OptimizedImage
            src={productImage}
            alt={productName}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            priority={priority}
            width={400}
            height={500}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-[#E8E8E8] text-[#888888]">
            بدون تصویر
          </div>
        )}
        
        {/* Badges */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          {hasDiscount && (
            <Badge variant="destructive" className="shadow-sm rounded-full">
              {discountPercent}% تخفیف
            </Badge>
          )}
        </div>
      </div>

      {/* Product Info */}
      <div className="p-[24px] space-y-3">
        <div>
          <h3 className="line-clamp-2 min-h-[3rem] mb-2">
            {productName}
          </h3>
          {shortDescription && (
            <p className="text-[#888888] line-clamp-2 text-sm">
              {shortDescription}
            </p>
          )}
        </div>

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="text-primary">
            {product.price ? product.price.toLocaleString('fa-IR') : '0'} تومان
          </span>
          {hasDiscount && (
            <span className="text-muted-foreground line-through">
              {productOriginalPrice!.toLocaleString('fa-IR')}
            </span>
          )}
        </div>

        {/* Add to Cart Button */}
        <Button
          onClick={(e) => {
            e.preventDefault(); // Prevent navigation
            e.stopPropagation(); // Stop event bubbling to Link
            onAddToCart(product, e);
          }}
          className="w-full h-[48px] rounded-[12px]"
          size="sm"
        >
          <ShoppingCart className="w-4 h-4 ml-2" />
          افزودن به سبد
        </Button>
      </div>
    </div>
  );
}