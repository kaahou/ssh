import { useState, useEffect } from "react";
import { ArrowRight, Save } from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "sonner@2.0.3";
import { logger } from "../../../src/utils/logger";

interface ConsultationDetail {
  id: string;
  phone: string;
  first_name?: string;
  last_name?: string;
  created_at: string;
  consultation_result?: string | null;
  status: string;
  personal_info?: any;
  skin_type?: string;
  skin_concerns?: string;
  lifestyle?: string;
  allergies?: string;
  budget_range?: string;
  user_id?: string;
  user_photos?: string | string[]; // ⭐ اضافه شد
}

export function AdminConsultationDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [consultation, setConsultation] = useState<ConsultationDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [adminNote, setAdminNote] = useState("");
  const [photoUrls, setPhotoUrls] = useState<string[]>([]); // ⭐ اضافه شد

  // دیکشنری ترجمه فیلدها
  const fieldTranslations: Record<string, string> = {
    // Personal Info
    'age': 'سن',
    'gender': 'جنسیت',
    
    // Hair Analysis
    'hair_stem': 'ضخامت ساقه مو',
    'hair_shaft': 'جنس ساقه مو',
    'hair_state': 'حالت مو (صاف/مجعد)',
    'hair_condition': 'حالت مو',
    'scalp_type': 'جنس پوست سر',
    'scalp_nature': 'طبیعت پوست سر',
    'hair_length': 'طول مو',
    'hair_growth': 'رشد مو',
    'hair_porosity': 'تخلخل مو',
    'problem_to_treat': 'مشکل اصلی برای درمان',
    
    // Lifestyle
    'stress_level': 'میزان استرس روزانه',
    'digestive_issues': 'مشکلات گوارشی',
    'washing_frequency': 'تعداد دفعات شستشو در هفته',
    'wash_frequency': 'تعداد دفعات شستشو در هفته',
    'medical_conditions': 'سابقه دارو یا بیماری',
    'environment': 'شرایط محیطی زندگی',
    
    // Current Routine
    'products_used': 'محصولات مراقبتی فعلی',
    'hair_care_goals': 'اهداف مراقبت از مو',
    'heat_tool_usage': 'استفاده از سشوار یا اتوی مو',
    'treatment_history': 'سابقه اعمال آرایشگاهی',
    
    // Consultation Details
    'additional_comments': 'توضیحات اضافی',
    'consultation_method': 'روش مشاوره',
    
    // Old structure
    'main_goals': 'اهداف اصلی',
    'main_problems': 'مشکلات اصلی مو',
    'wash-frequency': 'تعداد دفعات شستشو در هفته',
    'medical_history': 'سابقه دارو یا بیماری',
    'current_products': 'محصولات مراقبتی فعلی',
    'scalp_temperament': 'طبع سر (سرد/گرم/معتدل)',
    'has_digestive_issues': 'مشکلات گوارشی',
    'environmental_conditions': 'شرایط محیطی زندگی',
    'uses_heat': 'استفاده از سشوار یا اتوی مو',
    'has_salon_history': 'سابقه اعمال آرایشگاهی',
    'salon_history_details': 'جزئیات سوابق آرایشگاهی',
    'additional_notes': 'توضیحات اضافی',
  };

  useEffect(() => {
    if (id) {
      fetchConsultationDetail();
    }
  }, [id]);

  const fetchConsultationDetail = async () => {
    try {
      setLoading(true);
      logger.debug('Admin fetching consultation ID:', id);
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/admin/consultations/${id}`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      logger.debug('Admin response status:', response.status, response.ok);

      if (response.ok) {
        const data = await response.json();
        logger.debug('Admin response data:', data);
        
        // Verify response has consultation data
        if (!data || !data.consultation) {
          logger.error('Invalid consultation data received:', data);
          toast.error("داده‌های مشاوره معتبر نیست");
          navigate('/admin/consultations');
          return;
        }
        
        logger.debug('Admin consultation data valid, ID:', data.consultation.id);
        setConsultation(data.consultation);
        setAdminNote(data.consultation.consultation_result || "");
        
        // ⭐ پردازش تصاویر
        let photos: string[] = [];
        
        // Extract from user_photos (old field)
        if (data.consultation.user_photos) {
          if (typeof data.consultation.user_photos === 'string') {
            try {
              photos = JSON.parse(data.consultation.user_photos);
            } catch {
              photos = [data.consultation.user_photos];
            }
          } else if (Array.isArray(data.consultation.user_photos)) {
            photos = data.consultation.user_photos;
          }
          logger.debug('User photos loaded:', photos.length);
        }
        
        // Extract from personal_info.photo_urls (new field)
        if (data.consultation.personal_info?.photo_urls) {
          const newPhotos = data.consultation.personal_info.photo_urls;
          if (Array.isArray(newPhotos)) {
            newPhotos.forEach((url: string) => {
              if (url && !photos.includes(url)) {
                photos.push(url);
              }
            });
            logger.debug('Photos from personal_info.photo_urls added:', newPhotos.length);
          }
        }
        
        // Extract from personal_info.media.photo_url (old structure)
        if (data.consultation.personal_info?.media?.photo_url) {
          const photoUrl = data.consultation.personal_info.media.photo_url;
          if (photoUrl && !photos.includes(photoUrl)) {
            photos.push(photoUrl);
            logger.debug('Photo from personal_info.media added');
          }
        }
        
        setPhotoUrls(photos);
        logger.debug('Total photos loaded:', photos.length);
      } else {
        const errorData = await response.json().catch(() => ({}));
        logger.error('Admin response not OK:', response.status, errorData);
        toast.error("خطا در بارگذاری اطلاعات مشاوره");
        navigate('/admin/consultations');
      }
    } catch (error) {
      logger.error("Error fetching consultation detail:", error);
      toast.error("خطا در بارگذاری اطلاعات");
      navigate('/admin/consultations');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!adminNote.trim()) {
      toast.error("لطفاً نظر خود را وارد کنید");
      return;
    }

    try {
      setSaving(true);
      logger.debug(`Saving admin note for consultation ${id}...`);
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/admin/consultations/${id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            consultation_result: adminNote,
          }),
        }
      );

      const responseData = await response.json();
      logger.debug('Save response:', response.status, responseData);

      if (response.ok) {
        toast.success("نظر مدیر با موفقیت ثبت و پیامک ارسال شد");
        fetchConsultationDetail(); // بارگذاری مجدد برای به‌روزرسانی وضعیت
      } else {
        logger.error("Error response:", responseData);
        const errorMessage = responseData.details 
          ? `${responseData.error}: ${responseData.details}`
          : responseData.error || "خطا در ثبت نظر";
        toast.error(errorMessage);
      }
    } catch (error) {
      logger.error("Exception saving admin note:", error);
      toast.error("خطا در ثبت نظر");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="text-center py-12">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1A2011] border-r-transparent"></div>
          <p className="mt-4 text-[#888888]">در حال بارگذاری...</p>
        </div>
      </AdminLayout>
    );
  }

  if (!consultation) {
    return (
      <AdminLayout>
        <div className="text-center py-12">
          <p className="text-[#888888]">مشاوره یافت نشد</p>
        </div>
      </AdminLayout>
    );
  }

  // ⭐ تابع کمکی برای فرمت کردن مقادیر
  const formatValue = (value: any): string => {
    if (value === null || value === undefined || value === '') {
      return 'وارد نشده';
    }
    if (typeof value === 'boolean') {
      return value ? 'دارد' : 'ندارد';
    }
    if (Array.isArray(value)) {
      return value.length > 0 ? value.join('، ') : 'وارد نشده';
    }
    if (typeof value === 'object') {
      return JSON.stringify(value, null, 2);
    }
    return String(value);
  };

  // ⭐ استخراج داده‌ها از personal_info با ساختار جدید
  const extractValue = (obj: any, path: string): any => {
    const keys = path.split('.');
    let current = obj;
    for (const key of keys) {
      if (current && key in current) {
        current = current[key];
      } else {
        return null;
      }
    }
    return current;
  };

  // فیلدهای قابل نمایش (به جز consultation_result و status)
  const displayFields: Array<{ label: string; value: string }> = [
    { label: "کد مشاوره", value: consultation.id },
    { label: "شماره تماس", value: consultation.phone },
    { label: "تاریخ ثبت", value: new Date(consultation.created_at).toLocaleString('fa-IR') },
  ];

  // ⭐ استخراج نام و نام خانوادگی از personal_info یا consultation
  const firstName = consultation.personal_info?.first_name || consultation.first_name || 'وارد نشده';
  const lastName = consultation.personal_info?.last_name || consultation.last_name || 'وارد نشده';
  
  displayFields.push({ label: "نام", value: firstName });
  displayFields.push({ label: "نام خانوادگی", value: lastName });

  // ⭐ استخراج داده‌ها از personal_info با ساختار جدید
  if (consultation.personal_info && typeof consultation.personal_info === 'object') {
    const personalInfo = consultation.personal_info;
    
    // ⭐ سن و جنسیت - ابتدا از سطح بالا، سپس از personal_info.personal_info
    const age = personalInfo.age || extractValue(personalInfo, 'personal_info.age');
    const gender = personalInfo.gender || extractValue(personalInfo, 'personal_info.gender');
    
    if (age) displayFields.push({ label: 'سن', value: formatValue(age) });
    if (gender) {
      const genderDisplay = gender === 'male' || gender === 'مرد' ? 'مرد' 
                          : gender === 'female' || gender === 'زن' ? 'زن' 
                          : formatValue(gender);
      displayFields.push({ label: 'جنسیت', value: genderDisplay });
    }
    
    // Hair Analysis
    if (personalInfo.hair_analysis) {
      const hairAnalysis = personalInfo.hair_analysis;
      Object.entries(hairAnalysis).forEach(([key, value]) => {
        displayFields.push({
          label: fieldTranslations[key] || key,
          value: formatValue(value)
        });
      });
    }
    
    // Lifestyle
    if (personalInfo.lifestyle) {
      const lifestyle = personalInfo.lifestyle;
      Object.entries(lifestyle).forEach(([key, value]) => {
        displayFields.push({
          label: fieldTranslations[key] || key,
          value: formatValue(value)
        });
      });
    }
    
    // Current Routine
    if (personalInfo.current_routine) {
      const routine = personalInfo.current_routine;
      Object.entries(routine).forEach(([key, value]) => {
        displayFields.push({
          label: fieldTranslations[key] || key,
          value: formatValue(value)
        });
      });
    }
    
    // Consultation Details
    if (personalInfo.consultation_details) {
      const details = personalInfo.consultation_details;
      Object.entries(details).forEach(([key, value]) => {
        displayFields.push({
          label: fieldTranslations[key] || key,
          value: formatValue(value)
        });
      });
    }
    
    // فیلدهای سطح بالا (برای ساختار قدیمی)
    Object.entries(personalInfo).forEach(([key, value]) => {
      if (
        key !== 'personal_info' && 
        key !== 'hair_analysis' && 
        key !== 'lifestyle' && 
        key !== 'current_routine' && 
        key !== 'consultation_details' &&
        key !== 'media' &&
        key !== 'photo_urls' &&
        key !== 'first_name' &&
        key !== 'last_name' &&
        key !== 'age' &&
        key !== 'gender' &&
        value !== null && 
        value !== undefined && 
        value !== ''
      ) {
        const exists = displayFields.some(f => f.label === (fieldTranslations[key] || key));
        if (!exists) {
          displayFields.push({
            label: fieldTranslations[key] || key,
            value: formatValue(value)
          });
        }
      }
    });
  }

  // ⭐ اضافه کردن فیلدهای مسطح (برای سازگاری با ساختار قدیمی)
  const flatFields = [
    { key: 'skin_type', label: 'نوع پوست' },
    { key: 'skin_concerns', label: 'مشکلات پوستی' },
    { key: 'lifestyle', label: 'سبک زندگی' },
    { key: 'allergies', label: 'حساسیت‌ها' },
    { key: 'budget_range', label: 'محدوده بودجه' },
  ];

  flatFields.forEach(({ key, label }) => {
    const value = (consultation as any)[key];
    if (value && !displayFields.some(f => f.label === label)) {
      displayFields.push({ label, value: formatValue(value) });
    }
  });

  return (
    <AdminLayout>
      {/* Header Actions */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate('/admin/consultations')}
          className="flex items-center gap-2 text-[#444444] hover:text-[#1A2011] transition-colors"
        >
          <ArrowRight size={20} />
          بازگشت به لیست
        </button>
      </div>

      {/* ⭐ نمایش تصاویر */}
      {photoUrls.length > 0 && (
        <div className="bg-white rounded-[12px] border border-gray-200 overflow-hidden mb-6">
          <div className="bg-[#F4F4F5] px-6 py-4 border-b border-gray-200">
            <h2 className="font-semibold text-[#1A2011]">تصاویر ارسالی مشتری</h2>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {photoUrls.map((url, index) => (
                <div key={index} className="relative aspect-square rounded-lg overflow-hidden border border-gray-200">
                  <img
                    src={url}
                    alt={`تصویر ${index + 1}`}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      logger.error('Failed to load image:', url);
                      e.currentTarget.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100"%3E%3Crect fill="%23f0f0f0" width="100" height="100"/%3E%3Ctext fill="%23999" x="50%25" y="50%25" text-anchor="middle" dy=".3em"%3Eخطا در بارگذاری%3C/text%3E%3C/svg%3E';
                    }}
                  />
                  <a
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 hover:opacity-100"
                  >
                    <span className="text-white text-sm bg-black/50 px-3 py-1 rounded">مشاهده</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Consultation Details Table */}
      <div className="bg-white rounded-[12px] border border-gray-200 overflow-hidden mb-6">
        <div className="bg-[#F4F4F5] px-6 py-4 border-b border-gray-200">
          <h2 className="font-semibold text-[#1A2011]">اطلاعات مشاوره</h2>
        </div>
        <div className="p-6">
          <table className="w-full">
            <tbody className="divide-y divide-gray-200">
              {displayFields.map((field, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-[#1A2011] w-1/3">
                    {field.label}
                  </td>
                  <td className="py-3 px-4 text-[#444444] whitespace-pre-wrap">
                    {field.value}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admin Note Section */}
      <div className="bg-white rounded-[12px] border border-gray-200 overflow-hidden">
        <div className="bg-[#F4F4F5] px-6 py-4 border-b border-gray-200">
          <h2 className="font-semibold text-[#1A2011]">نظر مدیر</h2>
        </div>
        <div className="p-6">
          <textarea
            value={adminNote}
            onChange={(e) => setAdminNote(e.target.value)}
            rows={8}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011] resize-none"
            placeholder="نظر خود را در مورد این مشاوره وارد کنید..."
          />
          
          <div className="flex justify-end mt-4">
            <button
              onClick={handleSave}
              disabled={saving || !adminNote.trim()}
              className="flex items-center gap-2 px-6 py-3 bg-[#1A2011] text-white rounded-lg hover:bg-[#222222] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save size={20} />
              {saving ? "در حال ذخیره..." : "ثبت نظر و ارسال پیامک"}
            </button>
          </div>

          {consultation.consultation_result && consultation.consultation_result.trim() !== '' && (
            <div className="mt-4 p-4 bg-[#D1FAE5] border border-[#16A34A]/30 rounded-lg">
              <p className="text-sm text-[#065F46]">
                ✅ این مشاوره قبلاً بررسی شده است
              </p>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}