import { useState, useEffect } from "react";
import { 
  Plus, 
  Search, 
  Eye, 
  Edit, 
  Trash2,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Calendar,
  User
} from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { toast } from "sonner@2.0.3";
import { useNavigate } from "react-router-dom";
import { logger } from "../../../src/utils/logger";

interface Article {
  content_id: number;
  title: string;
  slug: string;
  content: string;
  keywords?: string;
  featured_image?: string;
  created_at: string;
  updated_at?: string;
  status?: string;
  meta_description?: string;
}

export function AdminArticles() {
  const navigate = useNavigate();
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const articlesPerPage = 10;

  useEffect(() => {
    fetchArticles();
  }, []);

  async function fetchArticles() {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/articles`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch articles");
      }

      const data = await response.json();
      setArticles(data.articles || []);
    } catch (error) {
      logger.error("Error fetching articles:", error);
      toast.error("خطا در بارگذاری مقالات");
    } finally {
      setLoading(false);
    }
  }

  const handleDelete = async (id: number) => {
    if (!window.confirm("آیا از حذف این مقاله اطمینان دارید؟")) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/articles/${id}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete article");
      }

      toast.success("مقاله با موفقیت حذف شد");
      fetchArticles(); // Refresh list
    } catch (error) {
      logger.error("Error deleting article:", error);
      toast.error("خطا در حذف مقاله");
    }
  };

  const filteredArticles = articles.filter(article => {
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = (
      (article.title && article.title.toLowerCase().includes(searchLower)) ||
      (article.keywords && article.keywords.toLowerCase().includes(searchLower)) ||
      (article.content && article.content.toLowerCase().includes(searchLower))
    );

    return matchesSearch;
  });

  // Pagination calculations
  const totalPages = Math.ceil(filteredArticles.length / articlesPerPage);
  const indexOfLastArticle = currentPage * articlesPerPage;
  const indexOfFirstArticle = indexOfLastArticle - articlesPerPage;
  const currentArticles = filteredArticles.slice(indexOfFirstArticle, indexOfLastArticle);

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  // Reset to page 1 when search query changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  return (
    <AdminLayout>
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6">
        {/* Left: Add Button */}
        <button 
          onClick={() => navigate("/admin/article/add")}
          className="h-[48px] px-6 bg-[#1A2011] text-white rounded-[12px] font-semibold hover:bg-[#222222] flex items-center gap-2 justify-center"
        >
          <Plus size={20} />
          افزودن مقاله جدید
        </button>

        {/* Right: Search */}
        <div className="flex flex-col md:flex-row items-center gap-3">
          {/* Search */}
          <div className="w-full md:w-[280px] h-[48px] px-4 bg-white border border-[#E8E8E8] rounded-[12px] flex items-center gap-2">
            <Search size={18} className="text-[#888888]" />
            <input
              type="text"
              placeholder="جستجو در مقالات..."
              className="flex-1 bg-transparent text-[14px] outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">کل مقالات</p>
          <p className="text-[24px] font-bold text-[#1A2011]">{articles.length}</p>
        </div>
        
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">منتشر شده</p>
          <p className="text-[24px] font-bold text-[#16A34A]">
            {articles.filter(a => a.status === 'published').length}
          </p>
        </div>
        
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">پیش‌نویس</p>
          <p className="text-[24px] font-bold text-[#F59E0B]">
            {articles.filter(a => a.status === 'draft').length}
          </p>
        </div>
      </div>

      {/* Articles Table */}
      <div className="bg-white rounded-[20px] border border-[#E8E8E8] overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center p-12">
            <Loader2 className="w-8 h-8 animate-spin text-[#1A2011]" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#FAFAFA] border-b border-[#E8E8E8]">
                <tr>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">تصویر</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">عنوان</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">نویسنده</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">تاریخ ایجاد</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">وضعیت</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {currentArticles.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-[#888888]">
                      {searchQuery ? "نتیجه‌ای یافت نشد" : "مقاله‌ای موجود نیست"}
                    </td>
                  </tr>
                ) : (
                  currentArticles.map((article) => (
                    <tr key={article.content_id} className="border-b border-[#E8E8E8] hover:bg-[#FAFAFA] transition-colors">
                      {/* Image */}
                      <td className="px-6 py-4">
                        <div className="w-12 h-12 bg-[#F5F5F5] rounded-[8px] overflow-hidden">
                          {article.featured_image ? (
                            <img src={article.featured_image} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-gray-400">
                              تصویر ندارد
                            </div>
                          )}
                        </div>
                      </td>
                      
                      {/* Title */}
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="text-[14px] font-medium text-[#1A2011] max-w-[300px] truncate">
                            {article.title || 'بدون عنوان'}
                          </span>
                          <span className="text-[11px] text-[#888888]">{article.slug}</span>
                        </div>
                      </td>
                      
                      {/* Category/Keywords */}
                      <td className="px-6 py-4">
                        <span className="text-[14px] text-[#444444]">
                          {article.keywords || '-'}
                        </span>
                      </td>
                      
                      {/* Created Date */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Calendar size={14} className="text-[#888888]" />
                          <span className="text-[14px] text-[#444444]">
                            {new Date(article.created_at).toLocaleDateString('fa-IR')}
                          </span>
                        </div>
                      </td>
                      
                      {/* Status */}
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center h-[28px] px-3 rounded-full text-[12px] font-medium ${
                          article.status === 'published'
                            ? 'bg-[#D1FAE5] text-[#065F46]' 
                            : 'bg-[#FEF3C7] text-[#92400E]'
                        }`}>
                          {article.status === 'published' ? 'منتشر شده' : 'پیش‌نویس'}
                        </span>
                      </td>
                      
                      {/* Actions */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => window.open(`/read/${article.slug}`, '_blank')}
                            className="w-8 h-8 flex items-center justify-center hover:bg-[#DBEAFE] hover:text-[#1E40AF] rounded-[8px]"
                            title="مشاهده"
                          >
                            <Eye size={16} />
                          </button>
                          <button 
                            onClick={() => navigate(`/admin/blog/edit/${article.content_id}`)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-[#FEF3C7] hover:text-[#92400E] rounded-[8px]"
                            title="ویرایش"
                          >
                            <Edit size={16} />
                          </button>
                          <button 
                            onClick={() => handleDelete(article.content_id)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-[#FEE2E2] hover:text-[#DC2626] rounded-[8px]"
                            title="حذف"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {!loading && filteredArticles.length > 0 && (
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4 bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <div className="text-[14px] text-[#888888]">
            نمایش {indexOfFirstArticle + 1} تا {Math.min(indexOfLastArticle, filteredArticles.length)} از {filteredArticles.length} مقاله
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                currentPage === 1 
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                  : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
              }`}
            >
              <ChevronRight size={20} />
            </button>
            
            {/* Page Numbers */}
            <div className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                // Show only relevant pages
                if (
                  page === 1 ||
                  page === totalPages ||
                  (page >= currentPage - 1 && page <= currentPage + 1)
                ) {
                  return (
                    <button
                      key={page}
                      onClick={() => handlePageChange(page)}
                      className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                        currentPage === page
                          ? 'bg-[#1A2011] text-white'
                          : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  );
                } else if (page === currentPage - 2 || page === currentPage + 2) {
                  return (
                    <span key={page} className="text-[#888888] px-2">
                      ...
                    </span>
                  );
                }
                return null;
              })}
            </div>

            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                currentPage === totalPages
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
              }`}
            >
              <ChevronLeft size={20} />
            </button>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}