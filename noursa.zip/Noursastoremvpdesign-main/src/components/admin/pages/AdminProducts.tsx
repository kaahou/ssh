import { useState, useEffect } from "react";
import { 
  Plus, 
  Search, 
  Eye, 
  Edit, 
  Trash2,
  Loader2,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { Product } from "../../ProductCard";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { toast } from "sonner@2.0.3";
import { EditProductModal } from "../products/EditProductModal";
import { useNavigate } from "react-router-dom";
import { logger } from "../../../src/utils/logger";

interface AdminProductsProps {
  onNavigate?: (page: string) => void;
}

export function AdminProducts({ onNavigate: legacyNavigate }: AdminProductsProps) {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<{id: number, name: string}[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const productsPerPage = 10;

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, []);

  async function fetchCategories() {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/categories`,
        {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        }
      );
      if (response.ok) {
        const data = await response.json();
        setCategories(data.categories || []);
      }
    } catch (error) {
      logger.error("Error fetching categories:", error);
    }
  }

  async function fetchProducts() {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }

      const data = await response.json();
      setProducts(data.products || []);
    } catch (error) {
      logger.error("Error fetching products:", error);
      toast.error("خطا در بارگذاری محصولات");
    } finally {
      setLoading(false);
    }
  }

  const handleDelete = async (id: number) => {
    if (!window.confirm("آیا از حذف این محصول اطمینان دارید؟")) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/${id}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete product");
      }

      toast.success("محصول با موفقیت حذف شد");
      fetchProducts(); // Refresh list
    } catch (error) {
      logger.error("Error deleting product:", error);
      toast.error("خطا در حذف محصول");
    }
  };

  const filteredProducts = products.filter(product => {
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = (
      (product.product_name && product.product_name.toLowerCase().includes(searchLower)) ||
      (product.variant_name && product.variant_name.toLowerCase().includes(searchLower)) ||
      (product.short_description && product.short_description.toLowerCase().includes(searchLower))
    );

    return matchesSearch;
  });

  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);

  const totalPages = Math.ceil(filteredProducts.length / productsPerPage);

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  // Reset to page 1 when search query or filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, filter]);

  return (
    <AdminLayout title="مدیریت محصولات" activePage="admin-products" onNavigate={legacyNavigate}>
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6">
        {/* Left: Add Button */}
        <button 
          onClick={() => navigate("/admin/product/add")}
          className="h-[48px] px-6 bg-[#1A2011] text-white rounded-[12px] font-semibold hover:bg-[#222222] flex items-center gap-2 justify-center"
        >
          <Plus size={20} />
          افزودن محصول جدید
        </button>

        {/* Right: Search + Filter */}
        <div className="flex flex-col md:flex-row items-center gap-3">
          {/* Search */}
          <div className="w-full md:w-[280px] h-[48px] px-4 bg-white border border-[#E8E8E8] rounded-[12px] flex items-center gap-2">
            <Search size={18} className="text-[#888888]" />
            <input
              type="text"
              placeholder="جستجو در محصولات..."
              className="flex-1 bg-transparent text-[14px] outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">کل محصولات</p>
          <p className="text-[24px] font-bold text-[#1A2011]">{products.length}</p>
        </div>
        
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">ویژه</p>
          <p className="text-[24px] font-bold text-[#F59E0B]">{products.filter(p => p.featured).length}</p>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-[20px] border border-[#E8E8E8] overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center p-12">
            <Loader2 className="w-8 h-8 animate-spin text-[#1A2011]" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#FAFAFA] border-b border-[#E8E8E8]">
                <tr>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">تصویر</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">نام محصول</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">دسته‌بندی</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">قیمت</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {currentProducts.map((product) => {
                  const productImage = product.image_urls || product.image_url || product.image || '';
                  const productName = product.variant_name 
                    ? `${product.variant_name} ${product.product_name}` 
                    : (product.product_name || '');

                  return (
                    <tr key={product.product_id || product.id} className="border-b border-[#E8E8E8] hover:bg-[#FAFAFA] transition-colors">
                      {/* Image */}
                      <td className="px-6 py-4">
                        <div className="w-12 h-12 bg-[#F5F5F5] rounded-[8px] overflow-hidden">
                          {productImage ? (
                            <img src={productImage} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-gray-400">تصویر ندارد</div>
                          )}
                        </div>
                      </td>
                      
                      {/* Title */}
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="text-[14px] font-medium text-[#1A2011]">{productName}</span>
                          <span className="text-[11px] text-[#888888]">{product.slug}</span>
                        </div>
                      </td>
                      
                      {/* Category */}
                      <td className="px-6 py-4">
                        <span className="text-[14px] text-[#444444]">
                          {product.category_id 
                            ? categories.find(c => c.id === product.category_id)?.name || `ID: ${product.category_id}`
                            : (product.category || '-')}
                        </span>
                      </td>
                      
                      {/* Price */}
                      <td className="px-6 py-4">
                        <span className="text-[14px] font-semibold text-[#1A2011]">
                          {product.price ? product.price.toLocaleString('fa-IR') : 0} تومان
                        </span>
                      </td>
                      
                      {/* Actions */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => window.open(`/product/${product.slug}`, '_blank')}
                            className="w-8 h-8 flex items-center justify-center hover:bg-[#DBEAFE] hover:text-[#1E40AF] rounded-[8px]"
                          >
                            <Eye size={16} />
                          </button>
                          <button 
                            onClick={() => {
                              setEditingProductId(product.product_id || parseInt(product.id as string));
                              setIsEditModalOpen(true);
                            }}
                            className="w-8 h-8 flex items-center justify-center hover:bg-[#FEF3C7] hover:text-[#92400E] rounded-[8px]"
                          >
                            <Edit size={16} />
                          </button>
                          <button 
                            onClick={() => handleDelete(product.product_id || parseInt(product.id as string))}
                            className="w-8 h-8 flex items-center justify-center hover:bg-[#FEE2E2] hover:text-[#DC2626] rounded-[8px]"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {!loading && filteredProducts.length > 0 && (
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4 bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <div className="text-[14px] text-[#888888]">
            نمایش {indexOfFirstProduct + 1} تا {Math.min(indexOfLastProduct, filteredProducts.length)} از {filteredProducts.length} محصول
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                currentPage === 1 
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                  : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
              }`}
            >
              <ChevronRight size={20} />
            </button>
            
            {/* Page Numbers */}
            <div className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                // Show only relevant pages
                if (
                  page === 1 ||
                  page === totalPages ||
                  (page >= currentPage - 1 && page <= currentPage + 1)
                ) {
                  return (
                    <button
                      key={page}
                      onClick={() => handlePageChange(page)}
                      className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                        currentPage === page
                          ? 'bg-[#1A2011] text-white'
                          : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  );
                } else if (page === currentPage - 2 || page === currentPage + 2) {
                  return (
                    <span key={page} className="text-[#888888] px-2">
                      ...
                    </span>
                  );
                }
                return null;
              })}
            </div>

            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                currentPage === totalPages
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
              }`}
            >
              <ChevronLeft size={20} />
            </button>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {isEditModalOpen && editingProductId !== null && (
        <EditProductModal
          isOpen={isEditModalOpen}
          productId={editingProductId}
          onClose={() => setIsEditModalOpen(false)}
          onProductUpdated={fetchProducts}
        />
      )}
    </AdminLayout>
  );
}