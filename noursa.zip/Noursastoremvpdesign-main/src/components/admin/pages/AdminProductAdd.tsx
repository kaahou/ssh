import { useState, useEffect } from "react";
import { ArrowRight, Save, Loader2, Upload } from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import { Label } from "../../ui/label";
import { Textarea } from "../../ui/textarea";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { logger } from "../../../src/utils/logger";
import { useNavigate } from "react-router-dom";

interface Category {
  id: number;
  name: string;
}

export function AdminProductAdd() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  
  const [formData, setFormData] = useState({
    product_name: "",
    variant_name: "",
    slug: "",
    price: "",
    original_price: "",
    category_id: "",
    short_description: "",
    full_description: "",
    image_urls: "",
  });

  // Fetch categories on mount
  useEffect(() => {
    async function fetchCategories() {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/categories`,
          {
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
          }
        );
        
        if (response.ok) {
          const data = await response.json();
          setCategories(data.categories || []);
        }
      } catch (error) {
        logger.error("Error fetching categories:", error);
      }
    }
    
    fetchCategories();
  }, []);

  // Auto-generate slug from name
  useEffect(() => {
    if (formData.product_name) {
      const slug = formData.product_name
        .toLowerCase()
        .replace(/[^\w\s-]/g, '') // Remove special chars
        .replace(/\s+/g, '-') // Replace spaces with -
        .replace(/--+/g, '-'); // Replace multiple - with single -
      
      // Only update if slug is empty or was auto-generated (simple check)
      if (!formData.slug || formData.slug.includes(slug)) {
        // We don't overwrite if user manually edited it, but for now simple logic
        // actually better to only set if slug is empty to avoid annoyance
      }
    }
  }, [formData.product_name]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validate
      if (!formData.product_name || !formData.price) {
        toast.error("لطفا نام محصول و قیمت را وارد کنید");
        setIsLoading(false);
        return;
      }

      // Prepare payload
      const payload = {
        ...formData,
        price: Number(formData.price),
        original_price: formData.original_price ? Number(formData.original_price) : null,
        category_id: formData.category_id ? Number(formData.category_id) : null,
        // Ensure slug is set
        slug: formData.slug || formData.product_name.replace(/\s+/g, '-').toLowerCase(),
      };

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(payload),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        logger.error("Failed to create product - Server response:", result);
        throw new Error(result.details || result.error || "خطا در ایجاد محصول");
      }

      toast.success("محصول با موفقیت ایجاد شد");
      navigate("/admin/products");
    } catch (error: any) {
      logger.error("Error creating product:", error);
      toast.error(error.message || "خطا در ایجاد محصول");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AdminLayout title="افزودن محصول جدید" activePage="admin-products" onNavigate={navigate}>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/admin/products")}
            className="rounded-full w-10 h-10 p-0"
          >
            <ArrowRight className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold text-[#1A2011]">افزودن محصول جدید</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Info */}
          <div className="bg-white p-6 rounded-[20px] border border-[#E8E8E8] shadow-sm">
            <h2 className="text-lg font-semibold mb-4">اطلاعات پایه</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="product_name">نام محصول *</Label>
                <Input
                  id="product_name"
                  name="product_name"
                  value={formData.product_name}
                  onChange={handleChange}
                  placeholder="مثال: کرم ضد آفتاب"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="variant_name">نام مدل/تنوع (اختیاری)</Label>
                <Input
                  id="variant_name"
                  name="variant_name"
                  value={formData.variant_name}
                  onChange={handleChange}
                  placeholder="مثال: SPF 50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug">اسلاگ (شناسه یکتا در URL)</Label>
                <Input
                  id="slug"
                  name="slug"
                  value={formData.slug}
                  onChange={handleChange}
                  placeholder="مثال: sun-cream-spf50"
                  dir="ltr"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category_id">دسته‌بندی</Label>
                <select
                  id="category_id"
                  name="category_id"
                  value={formData.category_id}
                  onChange={handleChange}
                  className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="">انتخاب کنید...</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Pricing */}
          <div className="bg-white p-6 rounded-[20px] border border-[#E8E8E8] shadow-sm">
            <h2 className="text-lg font-semibold mb-4">قیمت‌گذاری</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="price">قیمت (تومان) *</Label>
                <Input
                  id="price"
                  name="price"
                  type="number"
                  value={formData.price}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="original_price">قیمت اصلی (قبل از تخفیف)</Label>
                <Input
                  id="original_price"
                  name="original_price"
                  type="number"
                  value={formData.original_price}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-white p-6 rounded-[20px] border border-[#E8E8E8] shadow-sm">
            <h2 className="text-lg font-semibold mb-4">توضیحات</h2>
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="short_description">توضیحات کوتاه</Label>
                <Textarea
                  id="short_description"
                  name="short_description"
                  value={formData.short_description}
                  onChange={handleChange}
                  rows={3}
                  placeholder="توضیحات مختصر محصول که در لیست محصولات نمایش داده می‌شود"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="full_description">توضیحات کامل محصول</Label>
                <Textarea
                  id="full_description"
                  name="full_description"
                  value={formData.full_description}
                  onChange={handleChange}
                  rows={8}
                  placeholder="توضیحات کامل محصول که در صفحه جزئیات نمایش داده می‌شود"
                />
              </div>
            </div>
          </div>

          {/* Media */}
          <div className="bg-white p-6 rounded-[20px] border border-[#E8E8E8] shadow-sm">
            <h2 className="text-lg font-semibold mb-4">تصاویر</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="image_urls">لینک تصاویر اصلی</Label>
                <div className="flex gap-2">
                  <Input
                    id="image_urls"
                    name="image_urls"
                    value={formData.image_urls}
                    onChange={handleChange}
                    placeholder="https://..."
                    dir="ltr"
                  />
                </div>
                <p className="text-xs text-gray-500">
                  در حال حاضر فقط امکان وارد کردن لینک مستقیم تصویر وجود دارد.
                </p>
              </div>
              
              {formData.image_urls && (
                <div className="mt-4 w-32 h-32 rounded-lg border border-gray-200 overflow-hidden bg-gray-50">
                  <img 
                    src={formData.image_urls} 
                    alt="Preview" 
                    className="w-full h-full object-cover"
                    onError={(e) => (e.currentTarget.style.display = 'none')} 
                  />
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/admin/products")}
              className="h-12 px-8"
            >
              انصراف
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="h-12 px-8 bg-[#1A2011] hover:bg-[#2d3820]"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  در حال ذخیره...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 ml-2" />
                  ذخیره محصول
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </AdminLayout>
  );
}