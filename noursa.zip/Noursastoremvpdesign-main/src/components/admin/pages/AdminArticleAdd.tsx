import { useState } from "react";
import { ArrowRight, Save, X, Image as ImageIcon } from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { toast } from "sonner@2.0.3";
import { useNavigate } from "react-router-dom";
import { logger } from "../../../src/utils/logger";

export function AdminArticleAdd() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    page_titel: "",
    content: "",
    featured_image: "",
    status: "published",
    meta_description: "",
    keywords: "",
  });

  // Auto-generate slug from title
  const handleTitleChange = (title: string) => {
    setFormData(prev => ({
      ...prev,
      title,
      slug: generateSlug(title)
    }));
  };

  const generateSlug = (text: string): string => {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^\u0600-\u06FFa-z0-9\s-]/g, '') // Keep Persian, English, numbers, spaces, hyphens
      .replace(/\s+/g, '-') // Replace spaces with hyphens
      .replace(/-+/g, '-'); // Replace multiple hyphens with single hyphen
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.title.trim()) {
      toast.error("عنوان مقاله الزامی است");
      return;
    }
    
    if (!formData.slug.trim()) {
      toast.error("اسلاگ مقاله الزامی است");
      return;
    }
    
    if (!formData.content.trim()) {
      toast.error("محتوای مقاله الزامی است");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/articles`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(formData),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to create article");
      }

      toast.success("مقاله با موفقیت ایجاد شد");
      navigate("/admin/blog");
    } catch (error) {
      logger.error("Error creating article:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ایجاد مقاله");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout>
      {/* Header Actions */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => navigate("/admin/blog")}
          className="flex items-center gap-2 text-[#444444] hover:text-[#1A2011] transition-colors"
        >
          <ArrowRight size={20} />
          <span className="text-[14px] font-medium">بازگشت به لیست مقالات</span>
        </button>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Main Content Card */}
        <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
          <h2 className="text-[18px] font-semibold text-[#1A2011] mb-6 pb-4 border-b border-[#E8E8E8]">
            اطلاعات اصلی مقاله
          </h2>

          <div className="space-y-6">
            {/* Title */}
            <div>
              <label className="block text-[14px] font-medium text-[#444444] mb-2">
                عنوان مقاله <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors"
                placeholder="مثال: ۱۰ نکته مهم برای مراقبت از پوست"
                required
              />
            </div>

            {/* Slug */}
            <div>
              <label className="block text-[14px] font-medium text-[#444444] mb-2">
                اسلاگ (URL) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.slug}
                onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors dir-ltr text-right"
                placeholder="10-skin-care-tips"
                required
              />
              <p className="text-[12px] text-[#888888] mt-1">
                این فیلد به صورت خودکار از عنوان ساخته می‌شود. می‌توانید آن را ویرایش کنید.
              </p>
            </div>

            {/* Page Title (SEO) */}
            <div>
              <label className="block text-[14px] font-medium text-[#444444] mb-2">
                عنوان صفحه (SEO)
              </label>
              <input
                type="text"
                value={formData.page_titel}
                onChange={(e) => setFormData(prev => ({ ...prev, page_titel: e.target.value }))}
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors"
                placeholder="عنوان صفحه برای موتورهای جستجو"
              />
            </div>

            {/* Meta Description */}
            <div>
              <label className="block text-[14px] font-medium text-[#444444] mb-2">
                توضیحات متا (SEO)
              </label>
              <textarea
                value={formData.meta_description}
                onChange={(e) => setFormData(prev => ({ ...prev, meta_description: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors resize-none"
                placeholder="توضیح کوتاهی که در نتایج جستجو نمایش داده می‌شود..."
              />
            </div>

            {/* Content */}
            <div>
              <label className="block text-[14px] font-medium text-[#444444] mb-2">
                محتوای مقاله <span className="text-red-500">*</span>
              </label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                rows={12}
                className="w-full px-4 py-3 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors resize-none leading-relaxed"
                placeholder="محتوای کامل مقاله را اینجا بنویسید...&#10;&#10;می‌توانید از HTML یا Markdown استفاده کنید."
                required
              />
            </div>

            {/* Row: Featured Image + Keywords */}
            <div className="grid md:grid-cols-2 gap-4">
              {/* Featured Image */}
              <div>
                <label className="block text-[14px] font-medium text-[#444444] mb-2">
                  <div className="flex items-center gap-2">
                    <ImageIcon size={16} />
                    آدرس تصویر شاخص
                  </div>
                </label>
                <input
                  type="url"
                  value={formData.featured_image}
                  onChange={(e) => setFormData(prev => ({ ...prev, featured_image: e.target.value }))}
                  className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors dir-ltr text-right"
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              {/* Keywords */}
              <div>
                <label className="block text-[14px] font-medium text-[#444444] mb-2">
                  کلمات کلیدی (SEO)
                </label>
                <input
                  type="text"
                  value={formData.keywords}
                  onChange={(e) => setFormData(prev => ({ ...prev, keywords: e.target.value }))}
                  className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors"
                  placeholder="مثال: پوست، مراقبت، زیبایی"
                />
              </div>
            </div>

            {/* Image Preview */}
            {formData.featured_image && (
              <div>
                <p className="text-[12px] font-medium text-[#444444] mb-2">پیش‌نمایش تصویر:</p>
                <div className="w-full max-w-md h-48 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] overflow-hidden">
                  <img 
                    src={formData.featured_image} 
                    alt="Preview" 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.parentElement!.innerHTML = '<div class="flex items-center justify-center h-full text-red-500 text-sm">تصویر یافت نشد</div>';
                    }}
                  />
                </div>
              </div>
            )}

            {/* Status */}
            <div className="pt-4 border-t border-[#E8E8E8]">
              <label className="block text-[14px] font-medium text-[#444444] mb-2">
                وضعیت انتشار
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[14px] outline-none focus:border-[#1A2011] transition-colors"
              >
                <option value="published">منتشر شده</option>
                <option value="draft">پیش‌نویس</option>
                <option value="archived">آرشیو شده</option>
              </select>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 bg-white rounded-[20px] border border-[#E8E8E8] p-6">
          <button
            type="button"
            onClick={() => navigate("/admin/blog")}
            disabled={loading}
            className="h-[48px] px-6 bg-white border border-[#E8E8E8] text-[#444444] rounded-[12px] font-medium hover:bg-[#FAFAFA] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <X size={18} />
            انصراف
          </button>
          
          <button
            type="submit"
            disabled={loading}
            className="h-[48px] px-6 bg-[#1A2011] text-white rounded-[12px] font-medium hover:bg-[#222222] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                در حال ذخیره...
              </>
            ) : (
              <>
                <Save size={18} />
                ذخیره مقاله
              </>
            )}
          </button>
        </div>
      </form>
    </AdminLayout>
  );
}
