import { 
  DollarSign, 
  TrendingUp, 
  ShoppingBag, 
  Users, 
  MessageSquare,
  Loader2
} from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { useEffect, useState } from "react";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { logger } from "../../../src/utils/logger";

interface AdminDashboardProps {
  onNavigate: (page: string) => void;
}

interface TodayStats {
  sales: number;
  orders: number;
  users: number;
  consultations: number;
}

interface ChartData {
  date: string;
  sales: number;
  orders: number;
  users: number;
  consultations: number;
}

interface StatsResponse {
  today: TodayStats;
  chart: ChartData[];
}

export function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const [stats, setStats] = useState<TodayStats | null>(null);
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/admin/stats`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (response.ok) {
        const data: StatsResponse = await response.json();
        logger.debug("Stats Response:", data);
        logger.debug("Today Stats:", data.today);
        logger.debug("Chart Data Length:", data.chart.length);
        logger.debug("First 3 days:", data.chart.slice(0, 3));
        logger.debug("Last 3 days:", data.chart.slice(-3));
        setStats(data.today);
        setChartData(data.chart);
      } else {
        const errorText = await response.text();
        logger.error("Failed to fetch stats:", response.status, errorText);
      }
    } catch (error) {
      logger.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatNumber = (num: number): string => {
    return num.toLocaleString('fa-IR');
  };

  const formatCurrency = (amount: number): string => {
    return `${(amount / 1000000).toFixed(1)} میلیون`;
  };

  const statCards = [
    { 
      id: 1, 
      label: 'فروش امروز', 
      value: stats ? formatCurrency(stats.sales) : '-',
      rawValue: stats?.sales || 0,
      icon: DollarSign, 
      color: 'bg-[#D1FAE5] text-[#065F46]' 
    },
    { 
      id: 2, 
      label: 'سفارشات امروز', 
      value: stats ? formatNumber(stats.orders) : '-',
      rawValue: stats?.orders || 0,
      icon: ShoppingBag, 
      color: 'bg-[#DBEAFE] text-[#1E40AF]' 
    },
    { 
      id: 3, 
      label: 'کاربران جدید امروز', 
      value: stats ? formatNumber(stats.users) : '-',
      rawValue: stats?.users || 0,
      icon: Users, 
      color: 'bg-[#FCE7F3] text-[#9F1239]' 
    },
    { 
      id: 4, 
      label: 'مشاوره امروز', 
      value: stats ? formatNumber(stats.consultations) : '-',
      rawValue: stats?.consultations || 0,
      icon: MessageSquare, 
      color: 'bg-[#FEF3C7] text-[#92400E]' 
    }
  ];

  // تبدیل تاریخ میلادی به شمسی برای نمایش
  const formatPersianDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    return `${month}/${day}`;
  };

  // Custom tooltip برای نمودار
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 rounded-lg shadow-lg border border-[#E8E8E8]">
          <p className="text-sm text-[#888888] mb-2">{formatPersianDate(payload[0].payload.date)}</p>
          <p className="text-sm text-[#065F46]">فروش: {formatCurrency(payload[0].payload.sales)} تومان</p>
          <p className="text-sm text-[#1E40AF]">سفارشات: {formatNumber(payload[0].payload.orders)}</p>
          <p className="text-sm text-[#9F1239]">کاربران: {formatNumber(payload[0].payload.users)}</p>
          <p className="text-sm text-[#92400E]">مشاوره: {formatNumber(payload[0].payload.consultations)}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <AdminLayout title="داشبورد" activePage="admin-dashboard" onNavigate={onNavigate}>
      {loading ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="w-8 h-8 animate-spin text-[#484D2C]" />
        </div>
      ) : (
        <>
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
            {statCards.map((stat) => {
              const Icon = stat.icon;
              return (
                <div key={stat.id} className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
                  <div className="flex items-center justify-between mb-4">
                    {/* Icon */}
                    <div className={`w-12 h-12 rounded-[12px] flex items-center justify-center ${stat.color}`}>
                      <Icon size={24} />
                    </div>
                  </div>
                  <h3 className="text-[24px] lg:text-[28px] font-bold text-[#1A2011] mb-1">{stat.value}</h3>
                  <p className="text-[14px] text-[#888888]">{stat.label}</p>
                </div>
              );
            })}
          </div>

          {/* Chart Section */}
          <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6 mb-8">
            <h3 className="font-bold text-[18px] text-[#1A2011] mb-6">آمار ۳۰ روز گذشته</h3>
            
            {chartData && chartData.length > 0 ? (
              <div className="w-full" style={{ height: '400px', minHeight: '400px' }}>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E8E8E8" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={formatPersianDate}
                      stroke="#888888"
                      style={{ fontSize: '12px' }}
                    />
                    <YAxis 
                      stroke="#888888"
                      style={{ fontSize: '12px' }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      wrapperStyle={{ fontSize: '14px', paddingTop: '20px' }}
                      formatter={(value) => {
                        const labels: { [key: string]: string } = {
                          sales: 'فروش',
                          orders: 'سفارشات',
                          users: 'کاربران',
                          consultations: 'مشاوره'
                        };
                        return labels[value] || value;
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="sales" 
                      stroke="#065F46" 
                      strokeWidth={2}
                      dot={{ fill: '#065F46', r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="orders" 
                      stroke="#1E40AF" 
                      strokeWidth={2}
                      dot={{ fill: '#1E40AF', r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="users" 
                      stroke="#9F1239" 
                      strokeWidth={2}
                      dot={{ fill: '#9F1239', r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="consultations" 
                      stroke="#92400E" 
                      strokeWidth={2}
                      dot={{ fill: '#92400E', r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="w-full flex items-center justify-center" style={{ minHeight: '400px' }}>
                <p className="text-[#888888] text-sm">داده‌ای برای نمایش وجود ندارد</p>
              </div>
            )}
          </div>
        </>
      )}
    </AdminLayout>
  );
}