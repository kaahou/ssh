import { useState, useEffect } from "react";
import { 
  Download, 
  SlidersHorizontal, 
  User, 
  Check, 
  X, 
  Eye, 
  Edit, 
  Trash2 
} from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { Button } from "../../ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../ui/select";
import { Label } from "../../ui/label";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";

interface AdminUsersProps {
  onNavigate: (page: string) => void;
}

interface User {
  user_id: number;
  phone: string;
  first_name?: string | null;
  last_name?: string | null;
  email?: string | null;
  created_at: string;
  last_seen_at?: string | null;
  status?: string;
}

export function AdminUsers({ onNavigate }: AdminUsersProps) {
  const [showFilters, setShowFilters] = useState(false);
  const [filterVerified, setFilterVerified] = useState("all");
  const [sortBy, setSortBy] = useState("");
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; userId: number | null }>(
    {
      open: false,
      userId: null
    }
  );
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch users from API
  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/users`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }

      const data = await response.json();
      setUsers(data.users || []);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('خطا در بارگذاری کاربران');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async () => {
    if (deleteDialog.userId) {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/users/${deleteDialog.userId}`,
          {
            method: 'DELETE',
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
          }
        );

        if (!response.ok) {
          throw new Error('Failed to delete user');
        }

        setUsers(users.filter(u => u.user_id !== deleteDialog.userId));
        toast.success('کاربر با موفقیت حذف شد');
        setDeleteDialog({ open: false, userId: null });
      } catch (error) {
        console.error('Error deleting user:', error);
        toast.error('خطا در حذف کاربر');
      }
    }
  };

  const getUserDisplayName = (user: User) => {
    if (user.first_name && user.last_name) {
      return `${user.first_name} ${user.last_name}`;
    } else if (user.first_name) {
      return user.first_name;
    } else if (user.last_name) {
      return user.last_name;
    }
    return 'بدون نام';
  };

  return (
    <AdminLayout title="مدیریت کاربران" activePage="admin-users" onNavigate={onNavigate}>
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="text-[14px] text-[#888888]">
            تعداد کاربران: {users.length}
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowFilters(true)}
            className="h-[48px] px-6 bg-white border border-[#E8E8E8] rounded-[12px] font-semibold hover:bg-[#FAFAFA] flex items-center gap-2"
          >
            <SlidersHorizontal size={20} />
            فیلترها
          </button>

          <button className="h-[48px] px-6 bg-white border border-[#E8E8E8] rounded-[12px] font-semibold hover:bg-[#FAFAFA] flex items-center gap-2">
            <Download size={20} />
            خروجی Excel
          </button>
        </div>
      </div>

      {/* Filter Dialog */}
      <Dialog open={showFilters} onOpenChange={setShowFilters}>
        <DialogContent className="sm:max-w-[425px]" dir="rtl">
          <DialogHeader className="text-right">
            <DialogTitle>فیلتر کاربران</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Verified Status */}
            <div className="space-y-2">
              <Label>وضعیت تایید</Label>
              <Select value={filterVerified} onValueChange={setFilterVerified}>
                <SelectTrigger>
                  <SelectValue placeholder="همه" />
                </SelectTrigger>
                <SelectContent dir="rtl">
                  <SelectItem value="all">همه</SelectItem>
                  <SelectItem value="verified">تایید شده</SelectItem>
                  <SelectItem value="unverified">تایید نشده</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Sort By */}
            <div className="space-y-2">
              <Label>مرتب‌سازی بر اساس</Label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب کنید" />
                </SelectTrigger>
                <SelectContent dir="rtl">
                  <SelectItem value="created_at">تاریخ ثبت‌نام</SelectItem>
                  <SelectItem value="last_seen_at">آخرین ورود</SelectItem>
                  <SelectItem value="name">نام</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter className="flex-row gap-2 justify-end">
            <Button onClick={() => setShowFilters(false)}>اعمال فیلتر</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Users Table */}
      <div className="bg-white rounded-[20px] border border-[#E8E8E8] overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-[14px] text-[#888888]">در حال بارگذاری...</div>
          </div>
        ) : users.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-[14px] text-[#888888]">کاربری یافت نشد</div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#FAFAFA] border-b border-[#E8E8E8]">
                <tr>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">کاربر</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">شماره تماس</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">ایمیل</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">تاریخ ثبت‌نام</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">آخرین ورود</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">وضعیت</th>
                  <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.user_id} className="border-b border-[#E8E8E8] hover:bg-[#FAFAFA]">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#E8E8E8] rounded-full flex items-center justify-center">
                          <User size={18} className="text-[#888888]" />
                        </div>
                        <div>
                          <p className="text-[14px] font-medium text-[#1A2011]">{getUserDisplayName(user)}</p>
                          <p className="text-[12px] text-[#888888]">ID: {user.user_id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[14px] text-[#444444] font-mono">{user.phone}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[14px] text-[#888888]">{user.email || '-'}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[14px] text-[#888888]">
                        {new Intl.DateTimeFormat('fa-IR').format(new Date(user.created_at))}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[14px] text-[#888888]">
                        {user.last_seen_at 
                          ? new Intl.DateTimeFormat('fa-IR').format(new Date(user.last_seen_at))
                          : '-'
                        }
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {user.status === 'active' ? (
                        <span className="inline-flex items-center gap-1 h-[28px] px-3 rounded-full text-[12px] font-medium bg-[#D1FAE5] text-[#065F46]">
                          <Check size={12} />
                          فعال
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 h-[28px] px-3 rounded-full text-[12px] font-medium bg-[#FEF3C7] text-[#92400E]">
                          <X size={12} />
                          غیرفعال
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button 
                          className="w-8 h-8 flex items-center justify-center hover:bg-[#DBEAFE] hover:text-[#1E40AF] rounded-[8px]"
                        >
                          <Eye size={16} />
                        </button>
                        <button 
                          className="w-8 h-8 flex items-center justify-center hover:bg-[#FEF3C7] hover:text-[#92400E] rounded-[8px]"
                        >
                          <Edit size={16} />
                        </button>
                        <button 
                          onClick={() => setDeleteDialog({ open: true, userId: user.user_id })}
                          className="w-8 h-8 flex items-center justify-center hover:bg-[#FEE2E2] hover:text-[#DC2626] rounded-[8px]"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog(prev => ({ ...prev, open }))}>
        <DialogContent dir="rtl">
          <DialogHeader className="text-right">
            <DialogTitle>حذف کاربر</DialogTitle>
            <DialogDescription className="text-right">
              آیا مطمئن هستید که می‌خواهید این کاربر را حذف کنید؟ این عمل قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setDeleteDialog({ open: false, userId: null })}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={handleDeleteUser}>
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}