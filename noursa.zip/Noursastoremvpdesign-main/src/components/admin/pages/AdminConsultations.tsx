import { useState, useEffect } from "react";
import { Eye, Search, CheckCircle, Clock } from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { useNavigate } from "react-router-dom";
import { logger } from "../../../src/utils/logger";

interface Consultation {
  id: string;
  phone: string;
  first_name?: string;
  last_name?: string;
  created_at: string;
  consultation_result?: string | null;
  status: string;
  personal_info?: any;
}

interface AdminConsultationsProps {
  onNavigate: (page: string) => void;
}

export function AdminConsultations({ onNavigate }: AdminConsultationsProps) {
  const navigate = useNavigate();
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetchConsultations();
  }, []);

  const fetchConsultations = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/admin/consultations`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        setConsultations(data.consultations || []);
      }
    } catch (error) {
      logger.error("Error fetching consultations:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusInfo = (consultation: Consultation) => {
    // اگر consultation_result پر باشد، وضعیت "بررسی شده" است
    if (consultation.consultation_result && consultation.consultation_result.trim() !== '') {
      return {
        label: 'بررسی شده',
        color: 'bg-[#D1FAE5] text-[#065F46]',
        icon: CheckCircle
      };
    }
    return {
      label: 'بررسی نشده',
      color: 'bg-[#FEF3C7] text-[#92400E]',
      icon: Clock
    };
  };

  const handleViewConsultation = (id: string | number) => {
    navigate(`/admin-consultation-detail/${String(id)}`);
  };

  const filteredConsultations = consultations.filter(consultation => {
    const query = searchQuery.toLowerCase();
    const phone = consultation.phone || '';
    const firstName = consultation.first_name || '';
    const lastName = consultation.last_name || '';
    const fullName = `${firstName} ${lastName}`.toLowerCase();
    const consultationId = String(consultation.id).toLowerCase();
    
    return phone.includes(query) || fullName.includes(query) || consultationId.includes(query);
  });

  // نمایش فقط 5 مشاوره اخیر
  const recentConsultations = filteredConsultations.slice(0, 5);

  return (
    <AdminLayout title="مدیریت مشاوره‌ها" activePage="admin-consultations" onNavigate={onNavigate}>
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="جستجو بر اساس نام، شماره تماس یا کد مشاوره..."
            className="w-full h-[48px] pr-10 pl-4 bg-white border border-gray-300 rounded-[12px] focus:outline-none focus:border-[#1A2011]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="text-sm text-[#888888]">
          نمایش {recentConsultations.length} مشاوره از {consultations.length} مشاوره
        </div>
      </div>

      {/* Consultations Table */}
      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1A2011] border-r-transparent"></div>
          <p className="mt-4 text-[#888888]">در حال بارگذاری...</p>
        </div>
      ) : recentConsultations.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-[12px] border border-gray-200">
          <p className="text-[#888888]">هیچ مشاوره‌ای یافت نشد</p>
        </div>
      ) : (
        <div className="bg-white rounded-[12px] border border-gray-200 overflow-hidden">
          {/* Desktop Table View */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#F4F4F5] border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-[#1A2011]">کد مشاوره</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-[#1A2011]">نام و نام خانوادگی</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-[#1A2011]">شماره تماس</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-[#1A2011]">تاریخ</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-[#1A2011]">وضعیت</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-[#1A2011]">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {recentConsultations.map((consultation) => {
                  const statusInfo = getStatusInfo(consultation);
                  const StatusIcon = statusInfo.icon;
                  
                  return (
                    <tr key={consultation.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <span className="text-sm text-[#444444] font-mono">{String(consultation.id).slice(0, 8)}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-[#444444]">
                          {consultation.first_name && consultation.last_name
                            ? `${consultation.first_name} ${consultation.last_name}`
                            : 'نامشخص'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-[#444444] font-mono" dir="ltr">{consultation.phone}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-[#888888]">
                          {new Date(consultation.created_at).toLocaleDateString('fa-IR')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs ${statusInfo.color}`}>
                          <StatusIcon size={14} />
                          {statusInfo.label}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleViewConsultation(consultation.id)}
                            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                            title="مشاهده جزئیات"
                          >
                            <Eye size={18} className="text-[#1A2011]" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile Card View */}
          <div className="md:hidden divide-y divide-gray-200">
            {recentConsultations.map((consultation) => {
              const statusInfo = getStatusInfo(consultation);
              const StatusIcon = statusInfo.icon;
              
              return (
                <div key={consultation.id} className="p-4 hover:bg-gray-50">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] text-[#888888]">کد:</span>
                      <span className="text-[13px] font-semibold text-[#1A2011] font-mono">{String(consultation.id).slice(0, 8)}</span>
                    </div>
                    <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-[11px] ${statusInfo.color}`}>
                      <StatusIcon size={12} />
                      {statusInfo.label}
                    </span>
                  </div>

                  {/* Info */}
                  <div className="space-y-2 mb-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[#888888]">نام:</span>
                      <span className="text-[13px] text-[#444444]">
                        {consultation.first_name && consultation.last_name
                          ? `${consultation.first_name} ${consultation.last_name}`
                          : 'نامشخص'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[#888888]">شماره:</span>
                      <span className="text-[13px] text-[#444444] font-mono" dir="ltr">{consultation.phone}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[#888888]">تاریخ:</span>
                      <span className="text-[13px] text-[#444444]">
                        {new Date(consultation.created_at).toLocaleDateString('fa-IR')}
                      </span>
                    </div>
                  </div>

                  {/* Action */}
                  <button
                    onClick={() => handleViewConsultation(consultation.id)}
                    className="w-full h-[40px] flex items-center justify-center gap-2 bg-[#1A2011] text-white rounded-[8px] hover:bg-[#222222] transition-colors"
                  >
                    <Eye size={16} />
                    <span className="text-[13px] font-medium">مشاهده جزئیات</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </AdminLayout>
  );
}