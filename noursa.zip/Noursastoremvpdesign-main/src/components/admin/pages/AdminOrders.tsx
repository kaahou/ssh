import { useState, useEffect } from "react";
import { Download, Eye, Printer, MapPin, Search, Filter, ChevronLeft, ChevronRight, Plus, Edit } from "lucide-react";
import { AdminLayout } from "../AdminLayout";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { OrderDetailsModal } from "../orders/OrderDetailsModal";
import { CreateOrderModal } from "../orders/CreateOrderModal";
import { EditOrderModal } from "../orders/EditOrderModal";
import { useNavigate } from "react-router-dom";
import { getPaymentStatusLabel, getPaymentStatusColor, getOrderStatusLabel, getOrderStatusColor } from "../../../utils/orderStatus";
import { logger } from "../../../src/utils/logger";

interface Order {
  id: string;
  customer_name: string;
  created_at: string;
  items_count?: number;
  items?: Array<{ product_name: string; quantity: number }>;
  total_amount: number;
  status: string;
  payment_status?: string;
}

export function AdminOrders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const ordersPerPage = 10;
  const [selectedOrders, setSelectedOrders] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );
      
      if (response.ok) {
        const data = await response.json();
        setOrders(data.orders || []);
      }
    } catch (error) {
      logger.error("Error fetching orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewOrder = (id: string) => {
    setSelectedOrderId(id);
    setIsModalOpen(true);
  };

  const handleEditOrder = (id: string) => {
    setSelectedOrderId(id);
    setIsEditModalOpen(true);
  };

  const handlePrintInvoice = (id: string) => {
    // Pass the order ID as the "productId" parameter to reuse the routing logic
    navigate(`/admin/print-invoice/${id}`);
  };

  const handlePrintAddress = (id: string) => {
    navigate(`/admin/print-address/${id}`);
  };

  const handleToggleOrder = (orderId: string) => {
    setSelectedOrders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(orderId)) {
        newSet.delete(orderId);
      } else {
        newSet.add(orderId);
      }
      return newSet;
    });
  };

  const handleToggleAll = () => {
    if (selectedOrders.size === currentOrders.length) {
      setSelectedOrders(new Set());
    } else {
      setSelectedOrders(new Set(currentOrders.map(order => order.id)));
    }
  };

  const handleBulkPrintInvoices = () => {
    if (selectedOrders.size === 0) {
      alert('لطفاً حداقل یک سفارش را انتخاب کنید');
      return;
    }
    const orderIds = Array.from(selectedOrders).join(',');
    navigate(`/admin/print-invoices/${orderIds}`);
  };

  const handleBulkPrintLabels = () => {
    if (selectedOrders.size === 0) {
      alert('لطفاً حداقل یک سفارش را انتخاب کنید');
      return;
    }
    const orderIds = Array.from(selectedOrders).join(',');
    navigate(`/admin/print-labels/${orderIds}`);
  };

  const filteredOrders = orders.filter(order => {
    // Safely handle potentially missing or non-string IDs
    const orderId = String(order.id || '');
    const customerName = String(order.customer_name || '');
    const query = searchQuery.toLowerCase();
    
    return orderId.toLowerCase().includes(query) ||
           customerName.toLowerCase().includes(query);
  });

  // Stats calculation
  const totalOrders = orders.length;
  const processingOrders = orders.filter(o => o.status === 'processing').length;
  const completedOrders = orders.filter(o => o.status === 'completed').length;
  const cancelledOrders = orders.filter(o => o.status === 'cancelled').length;

  // Pagination
  const indexOfLastOrder = currentPage * ordersPerPage;
  const indexOfFirstOrder = indexOfLastOrder - ordersPerPage;
  const currentOrders = filteredOrders.slice(indexOfFirstOrder, indexOfLastOrder);

  const totalPages = Math.ceil(filteredOrders.length / ordersPerPage);

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  // Reset to page 1 when search query changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  return (
    <AdminLayout>
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="جستجو در سفارشات..."
            className="w-full h-[48px] pr-10 pl-4 bg-white border border-[#E8E8E8] rounded-[12px] focus:outline-none focus:border-[#1A2011]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          <button className="h-[48px] px-4 md:px-6 bg-white border border-[#E8E8E8] text-[#444444] rounded-[12px] font-semibold hover:bg-gray-50 flex items-center gap-2 justify-center flex-1 sm:flex-none min-w-[100px]">
            <Filter size={20} />
            <span className="hidden sm:inline">فیلتر</span>
          </button>
          <button className="h-[48px] px-4 md:px-6 bg-[#1A2011] text-white rounded-[12px] font-semibold hover:bg-[#222222] flex items-center gap-2 justify-center flex-1 sm:flex-none min-w-[100px]">
            <Download size={20} />
            <span className="hidden sm:inline">خروجی Excel</span>
          </button>
          <button className="h-[48px] px-4 md:px-6 bg-[#1A2011] text-white rounded-[12px] font-semibold hover:bg-[#222222] flex items-center gap-2 justify-center flex-1 sm:flex-none min-w-[100px]" onClick={() => setIsCreateModalOpen(true)}>
            <Plus size={20} />
            <span className="hidden sm:inline">سفارش جدید</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">کل سفارشات</p>
          <p className="text-[24px] font-bold text-[#1A2011]">{totalOrders}</p>
        </div>
        
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">در حال پردازش</p>
          <p className="text-[24px] font-bold text-[#1E40AF]">{processingOrders}</p>
        </div>
        
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">تکمیل شده</p>
          <p className="text-[24px] font-bold text-[#16A34A]">{completedOrders}</p>
        </div>
        
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <p className="text-[13px] text-[#888888] mb-1">لغو شده</p>
          <p className="text-[24px] font-bold text-[#DC2626]">{cancelledOrders}</p>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-[20px] border border-[#E8E8E8] overflow-hidden min-h-[400px]">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-[#1A2011] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-gray-500">
            <p>سفارشی یافت نشد</p>
          </div>
        ) : (
          <>
            {/* Desktop Table View */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#FAFAFA] border-b border-[#E8E8E8]">
                  <tr>
                    <th className="text-center px-4 py-4 text-[13px] font-semibold text-[#444444] w-12">
                      <input
                        type="checkbox"
                        checked={selectedOrders.size === currentOrders.length && currentOrders.length > 0}
                        onChange={handleToggleAll}
                        className="w-4 h-4 cursor-pointer accent-[#1A2011]"
                      />
                    </th>
                    <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">شماره سفارش</th>
                    <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">مشتری</th>
                    <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">تاریخ</th>
                    <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">محصولات</th>
                    <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">مبلغ کل</th>
                    <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">وضعیت پرداخت</th>
                    <th className="text-right px-6 py-4 text-[13px] font-semibold text-[#444444]">عملیات</th>
                  </tr>
                </thead>
                <tbody>
                  {currentOrders.map((order) => (
                    <tr key={order.id} className="border-b border-[#E8E8E8] hover:bg-[#FAFAFA]">
                      <td className="px-4 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={selectedOrders.has(order.id)}
                          onChange={() => handleToggleOrder(order.id)}
                          className="w-4 h-4 cursor-pointer accent-[#1A2011]"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[14px] font-semibold text-[#1A2011] font-mono" dir="ltr">{String(order.id)}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[14px] text-[#444444]">{order.customer_name || 'کاربر مهمان'}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[14px] text-[#888888]">
                          {new Date(order.created_at).toLocaleDateString('fa-IR')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-[13px] text-[#444444] space-y-1">
                          {order.items && order.items.length > 0 ? (
                            order.items.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-1">
                                <span className="text-[#888888]">{item.quantity}×</span>
                                <span 
                                  className={`truncate max-w-[200px] ${item.product_name?.includes('محصول کد') || item.product_name?.startsWith('محصول ') ? 'text-red-500' : ''}`}
                                  title={item.product_name}
                                >
                                  {item.product_name || 'بدون نام'}
                                </span>
                              </div>
                            ))
                          ) : (
                            <span className="text-[#888888]">بدون محصول</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[14px] font-semibold text-[#1A2011]">{order.total_amount?.toLocaleString('fa-IR')} تومان</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center h-[28px] px-3 rounded-full text-[12px] font-medium ${getPaymentStatusColor(order.payment_status || 'pending')}`}>
                          {getPaymentStatusLabel(order.payment_status || 'pending')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => handleViewOrder(order.id)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 text-gray-600 rounded-[8px] transition-colors"
                            title="مشاهده جزئیات"
                          >
                            <Eye size={16} />
                          </button>
                          <button 
                            onClick={() => handlePrintInvoice(order.id)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-blue-50 text-blue-600 rounded-[8px] transition-colors"
                            title="چاپ فاکتور"
                          >
                            <Printer size={16} />
                          </button>
                          <button 
                            onClick={() => handlePrintAddress(order.id)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-green-50 text-green-600 rounded-[8px] transition-colors"
                            title="چاپ آدرس"
                          >
                            <MapPin size={16} />
                          </button>
                          <button 
                            onClick={() => handleEditOrder(order.id)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 text-gray-600 rounded-[8px] transition-colors"
                            title="ویرایش سفارش"
                          >
                            <Edit size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card View */}
            <div className="md:hidden divide-y divide-[#E8E8E8]">
              {currentOrders.map((order) => (
                <div key={order.id} className="p-4 hover:bg-[#FAFAFA]">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] text-[#888888]">سفارش</span>
                      <span className="text-[14px] font-semibold text-[#1A2011] font-mono" dir="ltr">{String(order.id)}</span>
                    </div>
                    <span className={`inline-flex items-center h-[24px] px-2 rounded-full text-[11px] font-medium ${getPaymentStatusColor(order.payment_status || 'pending')}`}>
                      {getPaymentStatusLabel(order.payment_status || 'pending')}
                    </span>
                  </div>

                  {/* Info */}
                  <div className="space-y-2 mb-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[#888888]">مشتری:</span>
                      <span className="text-[13px] text-[#444444]">{order.customer_name || 'کاربر مهمان'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[#888888]">تاریخ:</span>
                      <span className="text-[13px] text-[#444444]">
                        {new Date(order.created_at).toLocaleDateString('fa-IR')}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[#888888]">مبلغ:</span>
                      <span className="text-[13px] font-semibold text-[#1A2011]">{order.total_amount?.toLocaleString('fa-IR')} تومان</span>
                    </div>
                  </div>

                  {/* Products */}
                  <div className="mb-3 p-2 bg-[#FAFAFA] rounded-[8px]">
                    <div className="text-[11px] text-[#888888] mb-1">محصولات:</div>
                    <div className="text-[12px] text-[#444444] space-y-1">
                      {order.items && order.items.length > 0 ? (
                        order.items.map((item, idx) => (
                          <div key={idx} className="flex items-center gap-1">
                            <span className="text-[#888888]">{item.quantity}×</span>
                            <span 
                              className={`truncate ${item.product_name?.includes('محصول کد') || item.product_name?.startsWith('محصول ') ? 'text-red-500' : ''}`}
                              title={item.product_name}
                            >
                              {item.product_name || 'بدون نام'}
                            </span>
                          </div>
                        ))
                      ) : (
                        <span className="text-[#888888]">بدون محصول</span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => handleViewOrder(order.id)}
                      className="h-[36px] flex items-center justify-center gap-2 bg-white border border-[#E8E8E8] text-gray-600 rounded-[8px] hover:bg-gray-50 transition-colors"
                    >
                      <Eye size={14} />
                      <span className="text-[12px]">جزئیات</span>
                    </button>
                    <button 
                      onClick={() => handleEditOrder(order.id)}
                      className="h-[36px] flex items-center justify-center gap-2 bg-purple-50 border border-purple-100 text-purple-600 rounded-[8px] hover:bg-purple-100 transition-colors"
                    >
                      <Edit size={14} />
                      <span className="text-[12px]">ویرایش</span>
                    </button>
                    <button 
                      onClick={() => handlePrintInvoice(order.id)}
                      className="h-[36px] flex items-center justify-center gap-2 bg-blue-50 border border-blue-100 text-blue-600 rounded-[8px] hover:bg-blue-100 transition-colors"
                    >
                      <Printer size={14} />
                      <span className="text-[12px]">فاکتور</span>
                    </button>
                    <button 
                      onClick={() => handlePrintAddress(order.id)}
                      className="h-[36px] flex items-center justify-center gap-2 bg-green-50 border border-green-100 text-green-600 rounded-[8px] hover:bg-green-100 transition-colors"
                    >
                      <MapPin size={14} />
                      <span className="text-[12px]">آدرس</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Pagination */}
      {filteredOrders.length > 0 && (
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4 bg-white rounded-[16px] border border-[#E8E8E8] p-4">
          <div className="text-[14px] text-[#888888]">
            نمایش {indexOfFirstOrder + 1} تا {Math.min(indexOfLastOrder, filteredOrders.length)} از {filteredOrders.length} سفارش
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                currentPage === 1 
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                  : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
              }`}
            >
              <ChevronRight size={20} />
            </button>
            
            {/* Page Numbers */}
            <div className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                // Show only relevant pages
                if (
                  page === 1 ||
                  page === totalPages ||
                  (page >= currentPage - 1 && page <= currentPage + 1)
                ) {
                  return (
                    <button
                      key={page}
                      onClick={() => handlePageChange(page)}
                      className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                        currentPage === page
                          ? 'bg-[#1A2011] text-white'
                          : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  );
                } else if (page === currentPage - 2 || page === currentPage + 2) {
                  return (
                    <span key={page} className="text-[#888888] px-2">
                      ...
                    </span>
                  );
                }
                return null;
              })}
            </div>

            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`h-[40px] w-[40px] rounded-[12px] flex items-center justify-center transition-colors ${
                currentPage === totalPages
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-white border border-[#E8E8E8] text-[#444444] hover:bg-gray-50'
              }`}
            >
              <ChevronLeft size={20} />
            </button>
          </div>
        </div>
      )}

      {/* Bulk Print Actions */}
      {selectedOrders.size > 0 && (
        <div className="mt-4 flex flex-col sm:flex-row items-center gap-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-[16px] border border-blue-200 p-4">
          <div className="flex items-center gap-2 flex-1">
            <span className="text-[14px] font-semibold text-[#1A2011]">
              {selectedOrders.size} سفارش انتخاب شده
            </span>
          </div>
          
          <div className="flex flex-wrap gap-2 w-full sm:w-auto">
            <button
              onClick={handleBulkPrintInvoices}
              className="h-[48px] px-6 bg-blue-600 text-white rounded-[12px] font-semibold hover:bg-blue-700 flex items-center gap-2 justify-center flex-1 sm:flex-none transition-colors"
            >
              <Printer size={20} />
              <span>چاپ فاکتورها</span>
            </button>
            
            <button
              onClick={handleBulkPrintLabels}
              className="h-[48px] px-6 bg-green-600 text-white rounded-[12px] font-semibold hover:bg-green-700 flex items-center gap-2 justify-center flex-1 sm:flex-none transition-colors"
            >
              <MapPin size={20} />
              <span>چاپ برچسب‌ها</span>
            </button>
          </div>
        </div>
      )}

      <OrderDetailsModal 
        isOpen={isModalOpen}
        orderId={selectedOrderId}
        onClose={() => setIsModalOpen(false)}
        onPrintInvoice={handlePrintInvoice}
        onPrintAddress={handlePrintAddress}
      />
      <CreateOrderModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onOrderCreated={fetchOrders}
      />
      <EditOrderModal 
        isOpen={isEditModalOpen}
        orderId={selectedOrderId}
        onClose={() => setIsEditModalOpen(false)}
        onOrderUpdated={fetchOrders}
      />
    </AdminLayout>
  );
}