import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingBag, 
  MessageSquare, 
  FileText, 
  BarChart3, 
  Users, 
  Upload, 
  MessageCircle, 
  Ticket, 
  Percent, 
  DollarSign, 
  Wallet, 
  UserCheck, 
  FolderOpen, 
  LogOut, 
  X,
  Menu,
  Search,
  Bell,
  Settings
} from "lucide-react";
import { useUser } from "../UserContext";
import { logger } from "../../src/utils/logger";
import { projectId, publicAnonKey } from "../../utils/supabase/info";

interface AdminLayoutProps {
  children: React.ReactNode;
}

// Admin phone numbers
const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
];

export function AdminLayout({ children }: AdminLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);
  const { user, loading } = useUser();
  const navigate = useNavigate();
  const location = useLocation();

  // Check if user is authorized (only admin phone numbers)
  useEffect(() => {
    if (!loading && !ADMIN_PHONES.includes(user?.phone)) {
      // Redirect unauthorized users to home page
      navigate('/');
    }
  }, [user, loading, navigate]);

  // Fetch unread contact messages count
  useEffect(() => {
    // بررسی دسترسی قبل از هر چیز
    if (!user?.phone || !ADMIN_PHONES.includes(user.phone)) {
      return;
    }

    const fetchUnreadCount = async () => {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/contact-messages/unread-count`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`
            }
          }
        );

        if (response.ok) {
          const data = await response.json();
          setUnreadCount(data.count || 0);
        }
      } catch (error) {
        logger.error('Error fetching unread count:', error);
      }
    };

    // Fetch اولیه
    fetchUnreadCount();
    
    // تنظیم interval
    const interval = setInterval(fetchUnreadCount, 30000);
    
    // Cleanup function
    return () => clearInterval(interval);
  }, [user?.phone]); // فقط phone را track می‌کنیم

  // Show nothing while loading or if user is not authorized
  if (loading || !ADMIN_PHONES.includes(user?.phone)) {
    return null;
  }

  const menuItems = [
    { id: 'admin-dashboard', label: 'داشبورد', icon: LayoutDashboard, path: '/admin' },
    { id: 'admin-products', label: 'محصولات', icon: Package, path: '/admin/products' },
    { id: 'admin-orders', label: 'سفارشات', icon: ShoppingBag, path: '/admin/orders' },
    { id: 'admin-blog', label: 'مقالات', icon: FileText, path: '/admin/blog' },
    { id: 'admin-consultations', label: 'مشاوره‌ها', icon: MessageSquare, path: '/admin/consultations' },
    { id: 'admin-contact-messages', label: 'پیام‌ها', icon: MessageCircle, path: '/admin/contact-messages' },
  ];

  // Get page title based on current route
  const getPageTitle = () => {
    const currentItem = menuItems.find(item => item.path === location.pathname);
    return currentItem?.label || 'داشبورد';
  };

  const title = getPageTitle();

  return (
    <div className="min-h-screen bg-[#FAFAFA]" dir="rtl">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block fixed right-0 top-0 h-full bg-white border-l border-[#E8E8E8] z-40 w-[280px] overflow-y-auto">
        {/* Header Logo */}
        <div className="h-[72px] flex items-center justify-between px-6 border-b border-[#E8E8E8]">
          <button onClick={() => navigate('/admin')} className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#1A2011] to-[#484D2C] rounded-[12px] flex items-center justify-center">
              <span className="text-white font-bold text-[18px]">ن</span>
            </div>
            <div className="text-right">
              <h1 className="font-bold text-[18px] text-[#1A2011]">نورسا</h1>
              <p className="text-[11px] text-[#888888]">پنل مدیریت</p>
            </div>
          </button>
        </div>

        {/* Menu Items */}
        <div className="p-4 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            const disabled = item.path === '#';
            
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (!disabled) {
                    navigate(item.path);
                  }
                }}
                disabled={disabled}
                className={`
                  w-full flex items-center gap-3 h-[48px] px-4 rounded-[12px] mb-1 transition-all
                  ${active 
                    ? 'bg-[#1A2011] text-white shadow-lg' 
                    : disabled
                    ? 'text-[#AAAAAA] cursor-not-allowed opacity-50'
                    : 'text-[#444444] hover:bg-[#FAFAFA]'
                  }
                `}
              >
                <Icon size={20} />
                <span className="text-[14px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Footer Logout */}
        <div className="p-3 border-t border-[#E8E8E8] mt-auto">
          <button 
            onClick={() => navigate('/')}
            className="w-full flex items-center gap-3 h-[48px] px-4 rounded-[12px] text-[#DC2626] hover:bg-[#FEE2E2]"
          >
            <LogOut size={20} />
            <span className="text-[14px] font-medium">خروج از پنل</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen md:mr-[280px]">
        {/* Page Content */}
        <main className="p-4 md:p-6 flex-1 bg-[#FAFAFA] pb-20 md:pb-6 md:-mr-[150px]">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-[#E8E8E8] z-40 shadow-lg">
        <div className="flex items-center justify-around px-2 py-2 max-w-lg mx-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className="flex flex-col items-center gap-1 min-w-[60px] py-1"
              >
                <div className={`
                  p-2 rounded-[12px] transition-all
                  ${active 
                    ? 'bg-[#1A2011] text-white shadow-md' 
                    : 'text-[#888888]'
                  }
                `}>
                  <Icon size={20} />
                </div>
                <span className={`
                  text-[10px] font-medium
                  ${active ? 'text-[#1A2011]' : 'text-[#888888]'}
                `}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}