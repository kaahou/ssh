import { AlertCircle, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../ui/button';

export function UnauthorizedPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAFAFA] px-4">
      <div className="max-w-md w-full text-center">
        <div className="mb-8">
          <div className="w-24 h-24 bg-[#FEE2E2] rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-12 h-12 text-[#DC2626]" />
          </div>
          <h1 className="text-3xl font-bold text-[#1A2011] mb-3">
            دسترسی غیرمجاز
          </h1>
          <p className="text-[#888888] text-lg mb-2">
            شما مجوز دسترسی به این بخش را ندارید.
          </p>
          <p className="text-[#AAAAAA] text-sm">
            در صورت نیاز به دسترسی، لطفاً با مدیر سایت تماس بگیرید.
          </p>
        </div>

        <div className="space-y-3">
          <Button
            onClick={() => navigate('/')}
            className="w-full h-12 bg-[#1A2011] hover:bg-[#484D2C] text-white rounded-[12px] flex items-center justify-center gap-2"
          >
            <Home className="w-5 h-5" />
            بازگشت به صفحه اصلی
          </Button>

          <Button
            onClick={() => navigate(-1)}
            variant="outline"
            className="w-full h-12 border-[#E8E8E8] hover:bg-[#F4F4F5] text-[#1A2011] rounded-[12px]"
          >
            بازگشت به صفحه قبل
          </Button>
        </div>

        <div className="mt-8 pt-6 border-t border-[#E8E8E8]">
          <p className="text-xs text-[#AAAAAA]">
            کد خطا: 403 - Forbidden
          </p>
        </div>
      </div>
    </div>
  );
}
