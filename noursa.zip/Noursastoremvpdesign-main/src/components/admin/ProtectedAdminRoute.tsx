import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../UserContext";
import { logger } from "../../src/utils/logger";

// Admin phone numbers - must match backend ADMIN_PHONES
const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
];

export function ProtectedAdminRoute({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, loading } = useUser();
  const navigate = useNavigate();

  useEffect(() => {
    // If still loading user data, wait
    if (loading) return;

    // If no user logged in, redirect to login
    if (!user) {
      navigate('/login', { replace: true, state: { from: '/admin' } });
      return;
    }

    // If user is logged in but not authorized (not in ADMIN_PHONES list)
    if (!ADMIN_PHONES.includes(user.phone)) {
      logger.warn(`Unauthorized admin access attempt from: ${user.phone}`);
      navigate('/', { replace: true });
      return;
    }
  }, [user, loading, navigate]);

  // Show loading state while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAFAFA]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#1A2011] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-[#888888]">در حال بررسی دسترسی...</p>
        </div>
      </div>
    );
  }

  // If user is not logged in, show nothing (will redirect)
  if (!user) {
    return null;
  }

  // If user doesn't have permission, show nothing (will redirect)
  if (!ADMIN_PHONES.includes(user.phone)) {
    return null;
  }

  // User is authorized, render the protected content
  return <>{children}</>;
}