import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { logger } from "../../../src/utils/logger";

interface Order {
  id: string;
  customer_name: string;
  phone: string;
  address: string;
}

export function BulkPrintLabels() {
  const { orderIds } = useParams<{ orderIds: string }>();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchOrders() {
      if (!orderIds) return;
      
      try {
        const ids = orderIds.split(',');
        const orderPromises = ids.map(async (id) => {
          const response = await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders/${id.trim()}`,
            {
              headers: {
                Authorization: `Bearer ${publicAnonKey}`,
              },
            }
          );
          if (response.ok) {
            const data = await response.json();
            return data.order;
          }
          return null;
        });
        
        const fetchedOrders = await Promise.all(orderPromises);
        setOrders(fetchedOrders.filter((order): order is Order => order !== null));
      } catch (error) {
        logger.error("Error fetching orders:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchOrders();
  }, [orderIds]);

  useEffect(() => {
    if (!loading && orders.length > 0) {
      setTimeout(() => {
        window.print();
      }, 500);
    }
  }, [loading, orders]);

  if (loading) return <div className="p-8 text-center">در حال آماده‌سازی برچسب‌ها...</div>;
  if (orders.length === 0) return <div className="p-8 text-center text-red-500">هیچ سفارشی یافت نشد</div>;

  // Group orders into groups of 3 for printing 3 per A5 page
  const groupedOrders: Order[][] = [];
  for (let i = 0; i < orders.length; i += 3) {
    groupedOrders.push(orders.slice(i, i + 3));
  }

  return (
    <div className="bg-white" dir="rtl">
      {groupedOrders.map((orderGroup, pageIndex) => (
        <div 
          key={pageIndex}
          className="flex flex-col items-center justify-center gap-3 p-3 break-after-page"
          style={{
            width: '148mm',
            minHeight: '210mm',
            maxHeight: '210mm',
            pageBreakAfter: 'always'
          }}
        >
          {orderGroup.map((order) => (
            <div 
              key={order.id}
              className="border-2 border-gray-800 p-3 rounded-xl bg-white w-full"
            >
              {/* Sender */}
              <div className="mb-3 border-b-2 border-dashed border-gray-300 pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-gray-500 text-[10px] w-12">فرستنده:</span>
                      <span className="font-bold text-sm">فروشگاه آنلاین نورسا</span>
                    </div>
                    <div className="flex items-start gap-2 mb-1">
                      <span className="font-bold text-gray-500 text-[10px] w-12">آدرس:</span>
                      <span className="text-[10px]">خراسان رضوی، گلمکان، اسجیل، صاحب‌الزمان ۴</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-500 text-[10px] w-12">تلفن:</span>
                      <span className="text-[10px]">۰۵۱-۳۸۳۷۳۵۳۰</span>
                    </div>
                  </div>
                  <img 
                    src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo_top.png" 
                    alt="Norsa Logo" 
                    className="h-10 object-contain"
                  />
                </div>
              </div>

              {/* Receiver */}
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-gray-500 text-[10px] w-12">گیرنده:</span>
                  <span className="font-bold text-base">{order.customer_name || 'کاربر مهمان'}</span>
                </div>
                <div className="flex items-start gap-2 mb-1">
                  <span className="font-bold text-gray-500 text-[10px] w-12 mt-0.5">آدرس:</span>
                  <p className="text-sm leading-relaxed flex-1">{order.address || 'آدرس ثبت نشده'}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-gray-500 text-[10px] w-12">تلفن:</span>
                  <span className="text-base dir-ltr font-mono">{order.phone || '---'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ))}

      <style>{`
        @media print {
          @page {
            size: A5;
            margin: 0;
          }
          body {
            margin: 0;
            padding: 0;
          }
          .break-after-page {
            page-break-after: always;
          }
        }
      `}</style>
    </div>
  );
}