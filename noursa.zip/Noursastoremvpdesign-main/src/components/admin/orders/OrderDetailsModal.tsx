import { useEffect, useState } from "react";
import { X, Printer, MapPin, Phone, User, Calendar, DollarSign, Package, CheckCircle, Clock, AlertCircle, CreditCard, Check, XCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../../ui/dialog";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { getPaymentStatusLabel, getPaymentStatusColor, getOrderStatusLabel, getOrderStatusColor } from "../../../utils/orderStatus";
import { toast } from "sonner@2.0.3";
import { logger } from "../../../src/utils/logger";

interface OrderItem {
  id: string;
  product_name: string;
  quantity: number;
  price?: number;
  unit_price?: number;
}

interface Order {
  id: string;
  customer_name: string;
  phone: string;
  address: string;
  total_amount: number;
  subtotal?: number;
  post_price?: number;
  discount_amount?: number;
  status: string;
  payment_status?: string;
  created_at: string;
  items?: OrderItem[];
}

interface OrderDetailsModalProps {
  orderId: string | null;
  isOpen: boolean;
  onClose: () => void;
  onPrintInvoice: (id: string) => void;
  onPrintAddress: (id: string) => void;
}

export function OrderDetailsModal({ orderId, isOpen, onClose, onPrintInvoice, onPrintAddress }: OrderDetailsModalProps) {
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [updatingPayment, setUpdatingPayment] = useState(false);

  const fetchOrderDetails = () => {
    if (!orderId) return;
    
    setLoading(true);
    fetch(`https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders/${orderId}`, {
      headers: {
        Authorization: `Bearer ${publicAnonKey}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.order) {
          setOrder({ ...data.order, items: data.items });
        }
      })
      .catch((err) => logger.error("Error fetching order details:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (isOpen && orderId) {
      fetchOrderDetails();
    } else {
      setOrder(null);
    }
  }, [isOpen, orderId]);

  const handlePaymentAction = async (action: 'approve' | 'reject') => {
    if (!orderId) return;
    
    setUpdatingPayment(true);
    
    try {
      logger.debug(`Starting payment ${action} for order ${orderId}`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
      
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/admin/orders/${orderId}/payment-status`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({ action }),
            signal: controller.signal,
          }
        );
        
        clearTimeout(timeoutId); // ✅ Clear timeout بعد از response
        
        logger.debug(`Response status: ${response.status}`);
        
        if (!response.ok) {
          let errorMessage = 'خطا در به‌روزرسانی وضعیت پرداخت';
          try {
            const result = await response.json();
            errorMessage = result.error || result.message || errorMessage;
          } catch (e) {
            logger.error('Failed to parse error response:', e);
          }
          throw new Error(errorMessage);
        }
        
        const result = await response.json();
        logger.debug(`Payment status updated successfully:`, result);
        
        toast.success(result.message || (action === 'approve' ? 'پرداخت تایید شد' : 'پرداخت رد شد'));
        
        // Refresh order details after a short delay
        setTimeout(() => {
          fetchOrderDetails();
        }, 500);
        
      } catch (fetchError) {
        clearTimeout(timeoutId); // ✅ Clear timeout در catch هم
        throw fetchError;
      }
      
    } catch (error: any) {
      logger.error('Error updating payment status:', error);
      
      if (error.name === 'AbortError') {
        toast.error('زمان درخواست تمام شد. لطفاً دوباره تلاش کنید.');
      } else {
        toast.error(error.message || 'خطا در به‌روزرسانی وضعیت پرداخت');
      }
    } finally {
      setUpdatingPayment(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-50 border-green-200';
      case 'processing': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'pending': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'cancelled': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle size={16} />;
      case 'processing': return <Clock size={16} />;
      case 'pending': return <AlertCircle size={16} />;
      case 'cancelled': return <X size={16} />;
      default: return <Clock size={16} />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'تکمیل شده';
      case 'processing': return 'در حال پردازش';
      case 'pending': return 'در انتظار';
      case 'cancelled': return 'لغو شده';
      default: return status;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex items-center gap-2">
            <Package className="text-gray-500" />
            جزئیات سفارش
            {order && <span className="text-gray-500 font-normal text-sm mr-2">#{String(order.id).slice(0, 8)}</span>}
          </DialogTitle>
          <DialogDescription className="text-sm text-gray-500">
            {order ? `جزئیات سفارش برای ${order.customer_name} ثبت شده در تاریخ ${new Date(order.created_at).toLocaleDateString('fa-IR')}` : "در حال بارگذاری جزئیات سفارش..."}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-12 flex justify-center">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : order ? (
          <div className="space-y-6">
            {/* Status Bar */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="flex flex-col gap-2 bg-gray-50 p-4 rounded-lg border border-gray-100">
                <span className="text-sm text-gray-500 flex items-center gap-1.5">
                  <Package size={14} />
                  وضعیت سفارش:
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium border flex items-center gap-1.5 w-fit ${getStatusColor(order.status)}`}>
                  {getStatusIcon(order.status)}
                  {getStatusLabel(order.status)}
                </span>
              </div>
              
              <div className="flex flex-col gap-2 bg-gray-50 p-4 rounded-lg border border-gray-100">
                <span className="text-sm text-gray-500 flex items-center gap-1.5">
                  <CreditCard size={14} />
                  وضعیت پرداخت:
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1.5 w-fit ${getPaymentStatusColor(order.payment_status || 'pending')}`}>
                  {getPaymentStatusLabel(order.payment_status || 'pending')}
                </span>
              </div>
            </div>
            
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 text-sm text-gray-600 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Calendar size={14} />
                تاریخ ثبت:
              </span>
              <span className="font-medium text-gray-900">
                {new Date(order.created_at).toLocaleDateString('fa-IR', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>

            {/* Customer Info */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="border rounded-xl p-4 space-y-3">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2 border-b pb-2 mb-2">
                  <User size={18} className="text-gray-500" />
                  اطلاعات مشتری
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">نام مشتری:</span>
                    <span className="font-medium">{order.customer_name || 'کاربر مهمان'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">شماره تماس:</span>
                    <span className="font-medium dir-ltr">{order.phone || '---'}</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-xl p-4 space-y-3">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2 border-b pb-2 mb-2">
                  <MapPin size={18} className="text-gray-500" />
                  اطلاعات ارسال
                </h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {order.address || 'آدرس ثبت نشده'}
                </p>
              </div>
            </div>

            {/* Order Items */}
            <div className="border rounded-xl overflow-hidden">
              <div className="bg-gray-50 px-4 py-3 border-b flex justify-between items-center">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Package size={18} className="text-gray-500" />
                  اقلام سفارش
                </h3>
                <span className="text-sm text-gray-500">{order.items?.length || 0} قلم کالا</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-3 text-right font-medium text-gray-500">نام محصول</th>
                      <th className="px-4 py-3 text-center font-medium text-gray-500 w-24">تعداد</th>
                      <th className="px-4 py-3 text-left font-medium text-gray-500 w-32">قیمت واحد</th>
                      <th className="px-4 py-3 text-left font-medium text-gray-500 w-36">مبلغ کل</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {order.items?.map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50">
                        <td className={`px-4 py-3 ${item.product_name?.includes('محصول کد') || item.product_name?.startsWith('محصول ') ? 'text-red-500' : 'text-gray-900'}`}>
                          {item.product_name || 'بدون نام'}
                        </td>
                        <td className="px-4 py-3 text-center text-gray-900">{item.quantity}</td>
                        <td className="px-4 py-3 text-left text-gray-600">
                          {(item.price || item.unit_price || 0).toLocaleString('fa-IR')}
                        </td>
                        <td className="px-4 py-3 text-left font-medium text-gray-900">
                          {((item.price || item.unit_price || 0) * item.quantity).toLocaleString('fa-IR')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-gray-50 font-medium text-sm">
                    {(() => {
                      const itemsSubtotal = (order.items || []).reduce(
                        (sum, item) => sum + ((item.price || item.unit_price || 0) * item.quantity),
                        0
                      );
                      const subtotal = order.subtotal || itemsSubtotal;
                      const postPrice = order.post_price || 0;
                      const discountAmount = order.discount_amount || 0;
                      
                      return (
                        <>
                          <tr className="border-t">
                            <td colSpan={3} className="px-4 py-2 text-left text-gray-700">جمع محصولات</td>
                            <td className="px-4 py-2 text-left text-gray-900">
                              {subtotal.toLocaleString('fa-IR')} <span className="text-xs text-gray-500">تومان</span>
                            </td>
                          </tr>
                          {postPrice > 0 && (
                            <tr>
                              <td colSpan={3} className="px-4 py-2 text-left text-gray-700">هزینه ارسال</td>
                              <td className="px-4 py-2 text-left text-gray-900">
                                {postPrice.toLocaleString('fa-IR')} <span className="text-xs text-gray-500">تومان</span>
                              </td>
                            </tr>
                          )}
                          {discountAmount > 0 && (
                            <tr>
                              <td colSpan={3} className="px-4 py-2 text-left text-red-600">تخفیف</td>
                              <td className="px-4 py-2 text-left text-red-600">
                                -{discountAmount.toLocaleString('fa-IR')} <span className="text-xs text-gray-500">تومان</span>
                              </td>
                            </tr>
                          )}
                          <tr className="border-t-2">
                            <td colSpan={3} className="px-4 py-3 text-left text-gray-900 font-bold">مبلغ قابل پرداخت</td>
                            <td className="px-4 py-3 text-left text-emerald-600 text-lg font-bold">
                              {order.total_amount.toLocaleString('fa-IR')} <span className="text-xs text-gray-500">تومان</span>
                            </td>
                          </tr>
                        </>
                      );
                    })()}
                  </tfoot>
                </table>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 justify-end pt-4 border-t">
              {/* Payment Action Buttons - Only show for awaiting_verification */}
              {order.payment_status === 'awaiting_verification' && (
                <>
                  <button
                    onClick={() => handlePaymentAction('approve')}
                    disabled={updatingPayment}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Check size={18} />
                    {updatingPayment ? 'در حال تایید...' : 'تایید پرداخت'}
                  </button>
                  <button
                    onClick={() => handlePaymentAction('reject')}
                    disabled={updatingPayment}
                    className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <XCircle size={18} />
                    {updatingPayment ? 'در حال رد...' : 'رد پرداخت'}
                  </button>
                  <div className="flex-1" />
                </>
              )}
              
              <button
                onClick={() => onPrintInvoice(order.id)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700 transition-colors"
              >
                <Printer size={18} />
                چاپ فاکتور
              </button>
              <button
                onClick={() => onPrintAddress(order.id)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700 transition-colors"
              >
                <MapPin size={18} />
                چاپ آدرس
              </button>
              <button
                onClick={onClose}
                className="px-6 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
              >
                بستن
              </button>
            </div>
          </div>
        ) : (
          <div className="py-12 text-center text-red-500">اطلاعات سفارش دریافت نشد</div>
        )}
      </DialogContent>
    </Dialog>
  );
}