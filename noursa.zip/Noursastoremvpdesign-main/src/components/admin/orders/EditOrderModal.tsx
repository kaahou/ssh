import { useState, useEffect } from "react";
import { X, Plus, Trash2, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../../ui/dialog";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { logger } from "../../../src/utils/logger";

interface Product {
  product_id: string;
  product_name: string;
  variant_name: string;
  price: number;
  stock: number;
}

interface OrderItem {
  product_id: string;
  product_name: string;
  variant_name: string;
  quantity: number;
  price: number;
  unique_key: string;
}

interface EditOrderModalProps {
  isOpen: boolean;
  orderId: string | null;
  onClose: () => void;
  onOrderUpdated: () => void;
}

export function EditOrderModal({ isOpen, orderId, onClose, onOrderUpdated }: EditOrderModalProps) {
  const [loading, setLoading] = useState(false);
  const [fetchingOrder, setFetchingOrder] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showProductList, setShowProductList] = useState(false);
  const [selectedItems, setSelectedItems] = useState<OrderItem[]>([]);
  const [freeShipping, setFreeShipping] = useState(false);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [isPaid, setIsPaid] = useState(false);
  
  // Form fields
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [mobile, setMobile] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [street, setStreet] = useState("");
  const [postalCode, setPostalCode] = useState("");

  useEffect(() => {
    if (isOpen && orderId) {
      fetchOrderDetails();
      fetchProducts();
    }
  }, [isOpen, orderId]);

  const fetchOrderDetails = async () => {
    if (!orderId) return;
    
    setFetchingOrder(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders/${orderId}`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );
      
      if (response.ok) {
        const data = await response.json();
        const order = data.order;
        
        // پر کردن فیلدهای فرم با داده‌های موجود
        let shippingInfo = order.shipping_info || {};
        
        // Parse shipping_info if it's a string
        if (typeof shippingInfo === 'string') {
          try {
            shippingInfo = JSON.parse(shippingInfo);
          } catch (e) {
            logger.error("Error parsing shipping_info:", e);
            shippingInfo = {};
          }
        }
        
        const address = shippingInfo.address || {};
        const contact = shippingInfo.contact || {};
        
        setFirstName(address.first_name || "");
        setLastName(address.last_name || "");
        setMobile(contact.mobile || "");
        setState(address.state || "");
        setCity(address.city || "");
        setStreet(address.street || "");
        setPostalCode(address.postal_code || "");
        
        // Parse metadata for free_shipping
        let metadata = order.metadata || {};
        if (typeof metadata === 'string') {
          try {
            metadata = JSON.parse(metadata);
          } catch (e) {
            logger.error("Error parsing metadata:", e);
            metadata = {};
          }
        }
        
        // Parse payment_info for payment status
        let paymentInfo = order.payment_info || {};
        if (typeof paymentInfo === 'string') {
          try {
            paymentInfo = JSON.parse(paymentInfo);
          } catch (e) {
            logger.error("Error parsing payment_info:", e);
            paymentInfo = {};
          }
        }
        
        // تنظیم محصولات - items باید از endpoint برگردانده شده باشند
        const items = data.items || [];
        const formattedItems = items.map((item: any, index: number) => ({
          product_id: String(item.product_id || ""),
          product_name: item.product_name || "",
          variant_name: item.variant_name || "",
          quantity: item.quantity || 1,
          price: item.unit_price || item.price || 0,
          unique_key: `${item.product_id || index}-${item.variant_name || 'no-variant'}-${item.product_name || index}`,
        }));
        setSelectedItems(formattedItems);
        
        // تنظیم سایر تنظیمات
        setFreeShipping(metadata.free_shipping || false);
        setDiscountAmount(order.discount_amount || 0);
        
        // Check if payment is paid (various statuses)
        const paymentStatus = paymentInfo.payment_status || paymentInfo.status || 'pending';
        setIsPaid(['paid_zarinpal', 'paid_card', 'paid_manual'].includes(paymentStatus));
        
      } else {
        logger.error("Failed to fetch order details");
        alert("خطا در دریافت اطلاعات سفارش");
      }
    } catch (error) {
      logger.error("Error fetching order details:", error);
      alert("خطا در دریافت اطلاعات سفارش");
    } finally {
      setFetchingOrder(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );
      const data = await response.json();
      setProducts(data.products || []);
    } catch (error) {
      logger.error("Error fetching products:", error);
    }
  };

  const filteredProducts = products.filter((product) => {
    const query = searchQuery.toLowerCase();
    const productName = (product.product_name || "").toLowerCase();
    const variantName = (product.variant_name || "").toLowerCase();
    return productName.includes(query) || variantName.includes(query);
  });

  const handleAddProduct = (product: Product) => {
    const fullName = product.variant_name
      ? `${product.variant_name} ${product.product_name}`.trim()
      : product.product_name;

    const uniqueKey = `${product.product_id || 'no-id'}-${product.variant_name || 'no-variant'}-${product.product_name}`;

    const existingItem = selectedItems.find(
      (item) => item.unique_key === uniqueKey
    );

    if (existingItem) {
      setSelectedItems(
        selectedItems.map((item) =>
          item.unique_key === uniqueKey
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setSelectedItems([
        ...selectedItems,
        {
          product_id: product.product_id,
          product_name: fullName,
          variant_name: product.variant_name,
          quantity: 1,
          price: product.price,
          unique_key: uniqueKey,
        },
      ]);
    }

    setSearchQuery("");
    setShowProductList(false);
  };

  const handleRemoveProduct = (uniqueKey: string) => {
    setSelectedItems(selectedItems.filter((item) => item.unique_key !== uniqueKey));
  };

  const handleQuantityChange = (uniqueKey: string, quantity: number) => {
    if (quantity < 1) return;
    setSelectedItems(
      selectedItems.map((item) =>
        item.unique_key === uniqueKey ? { ...item, quantity } : item
      )
    );
  };

  const calculateTotal = () => {
    return selectedItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (selectedItems.length === 0) {
      alert("لطفاً حداقل یک محصول اضافه کنید");
      return;
    }

    if (!firstName || !lastName || !mobile || !state || !city || !street) {
      alert("لطفاً تمام فیلدهای الزامی را پر کنید");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/admin/orders/${orderId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            shipping_info: {
              address: {
                first_name: firstName,
                last_name: lastName,
                state: state,
                city: city,
                street: street,
                postal_code: postalCode,
              },
              contact: {
                mobile: mobile,
              },
            },
            items: selectedItems,
            total_amount: calculateTotal(),
            free_shipping: freeShipping,
            discount_amount: discountAmount,
            is_paid: isPaid,
          }),
        }
      );

      const data = await response.json();

      if (response.ok && data.success) {
        alert("سفارش با موفقیت ویرایش شد");
        onOrderUpdated();
        handleClose();
      } else {
        alert(data.error || "خطا در ویرایش سفارش");
      }
    } catch (error) {
      logger.error("Error updating order:", error);
      alert("خطا در ویرایش سفارش");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSelectedItems([]);
    setFreeShipping(false);
    setDiscountAmount(0);
    setIsPaid(false);
    setFirstName("");
    setLastName("");
    setMobile("");
    setState("");
    setCity("");
    setStreet("");
    setPostalCode("");
    setSearchQuery("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">ویرایش سفارش #{orderId}</DialogTitle>
        </DialogHeader>

        {fetchingOrder ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-4 border-[#1A2011] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* محصولات */}
            <div className="border rounded-xl p-4">
              <h3 className="font-semibold mb-4">محصولات سفارش</h3>

              {/* جستجوی محصول */}
              <div className="relative mb-4">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="text"
                    placeholder="جستجوی محصول..."
                    className="w-full h-[48px] pr-10 pl-4 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setShowProductList(e.target.value.length > 0);
                    }}
                    onFocus={() => searchQuery.length > 0 && setShowProductList(true)}
                  />
                </div>

                {/* لیست محصولات */}
                {showProductList && filteredProducts.length > 0 && (
                  <div className="absolute z-10 w-full mt-2 bg-white border border-gray-300 rounded-lg shadow-lg max-h-64 overflow-y-auto">
                    {filteredProducts.map((product, index) => {
                      const fullName = product.variant_name
                        ? `${product.variant_name} ${product.product_name}`.trim()
                        : product.product_name;

                      return (
                        <button
                          key={`${product.product_id}-${index}`}
                          type="button"
                          onClick={() => handleAddProduct(product)}
                          className="w-full px-4 py-3 text-right hover:bg-gray-50 border-b last:border-b-0 flex justify-between items-center"
                        >
                          <div>
                            <div className="font-medium text-gray-900">{fullName}</div>
                            <div className="text-sm text-gray-500">
                              موجودی: {product.stock} | قیمت: {product.price.toLocaleString('fa-IR')} تومان
                            </div>
                          </div>
                          <Plus size={20} className="text-gray-400" />
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* محصولات انتخاب شده */}
              {selectedItems.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">محصولات انتخاب شده:</h4>
                  {selectedItems.map((item) => (
                    <div
                      key={item.unique_key}
                      className="flex items-center justify-between bg-gray-50 p-3 rounded-lg"
                    >
                      <div className="flex-1">
                        <div className="font-medium text-gray-900">{item.product_name}</div>
                        <div className="text-sm text-gray-600">
                          {item.price.toLocaleString('fa-IR')} تومان
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleQuantityChange(item.unique_key, item.quantity - 1)}
                            className="w-8 h-8 flex items-center justify-center bg-white border border-gray-300 rounded hover:bg-gray-50"
                          >
                            -
                          </button>
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) =>
                              handleQuantityChange(item.unique_key, parseInt(e.target.value) || 1)
                            }
                            className="w-16 h-8 text-center border border-gray-300 rounded"
                          />
                          <button
                            type="button"
                            onClick={() => handleQuantityChange(item.unique_key, item.quantity + 1)}
                            className="w-8 h-8 flex items-center justify-center bg-white border border-gray-300 rounded hover:bg-gray-50"
                          >
                            +
                          </button>
                        </div>

                        <div className="font-medium text-gray-900 min-w-[100px] text-left">
                          {(item.price * item.quantity).toLocaleString('fa-IR')} تومان
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveProduct(item.unique_key)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>
                  ))}

                  <div className="flex justify-between items-center pt-3 border-t">
                    <span className="font-semibold text-gray-900">جمع محصولات:</span>
                    <span className="font-semibold text-gray-900">
                      {calculateTotal().toLocaleString('fa-IR')} تومان
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-700">هزینه ارسال:</span>
                    <span className="text-sm text-gray-900">
                      {freeShipping ? (
                        <span className="text-green-600 font-medium">رایگان</span>
                      ) : (
                        '80,000 تومان'
                      )}
                    </span>
                  </div>

                  {discountAmount > 0 && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-700">تخفیف:</span>
                      <span className="text-sm text-red-600 font-medium">
                        - {discountAmount.toLocaleString('fa-IR')} تومان
                      </span>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-2 border-t">
                    <span className="font-bold text-gray-900">جمع کل سفارش:</span>
                    <span className="text-lg font-bold text-[#1A2011]">
                      {(calculateTotal() + (freeShipping ? 0 : 80000) - discountAmount).toLocaleString('fa-IR')} تومان
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* اطلاعات مشتری */}
            <div className="border rounded-xl p-4">
              <h3 className="font-semibold mb-4">اطلاعات مشتری</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    نام <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full h-[44px] px-4 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    نام خانوادگی <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full h-[44px] px-4 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    شماره موبایل <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    placeholder="09123456789"
                    className="w-full h-[44px] px-4 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>
              </div>
            </div>

            {/* آدرس */}
            <div className="border rounded-xl p-4">
              <h3 className="font-semibold mb-4">آدرس ارسال</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    استان <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full h-[44px] px-4 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    شهر <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full h-[44px] px-4 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    آدرس کامل <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    required
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    کد پستی
                  </label>
                  <input
                    type="text"
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    placeholder="1234567890"
                    className="w-full h-[44px] px-4 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>

                <div className="col-span-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={freeShipping}
                      onChange={(e) => setFreeShipping(e.target.checked)}
                      className="w-5 h-5 rounded border-gray-300 text-[#1A2011] focus:ring-[#1A2011]"
                    />
                    <span className="text-sm font-medium text-gray-700">
                      ارسال رایگان (دستی)
                    </span>
                  </label>
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    مبلغ تخفیف
                  </label>
                  <input
                    type="number"
                    value={discountAmount}
                    onChange={(e) => setDiscountAmount(parseInt(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full h-[44px] px-4 border border-gray-300 rounded-lg focus:outline-none focus:border-[#1A2011]"
                  />
                </div>

                <div className="col-span-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isPaid}
                      onChange={(e) => setIsPaid(e.target.checked)}
                      className="w-5 h-5 rounded border-gray-300 text-[#1A2011] focus:ring-[#1A2011]"
                    />
                    <span className="text-sm font-medium text-gray-700">
                      پرداخت شده
                    </span>
                  </label>
                </div>
              </div>
            </div>

            {/* دکمه‌ها */}
            <div className="flex gap-3 justify-end pt-4 border-t">
              <button
                type="button"
                onClick={handleClose}
                className="px-6 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                disabled={loading}
              >
                انصراف
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-[#1A2011] text-white rounded-lg hover:bg-[#222222] transition-colors disabled:opacity-50"
                disabled={loading || selectedItems.length === 0}
              >
                {loading ? "در حال ذخیره..." : "ذخیره تغییرات"}
              </button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}