import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { logger } from "../../../src/utils/logger";

interface OrderItem {
  id: string;
  product_name: string;
  quantity: number;
  price?: number;
  unit_price?: number;
}

interface Order {
  id: string;
  customer_name: string;
  phone: string;
  address: string;
  total_amount: number;
  subtotal?: number;
  post_price?: number;
  discount_amount?: number;
  created_at: string;
  items?: OrderItem[];
}

export function BulkPrintInvoices() {
  const { orderIds } = useParams<{ orderIds: string }>();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchOrders() {
      if (!orderIds) return;
      
      try {
        const ids = orderIds.split(',');
        const orderPromises = ids.map(async (id) => {
          const response = await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders/${id.trim()}`,
            {
              headers: {
                Authorization: `Bearer ${publicAnonKey}`,
              },
            }
          );
          if (response.ok) {
            const data = await response.json();
            return { ...data.order, items: data.items };
          }
          return null;
        });
        
        const fetchedOrders = await Promise.all(orderPromises);
        setOrders(fetchedOrders.filter((order): order is Order => order !== null));
      } catch (error) {
        logger.error("Error fetching orders:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchOrders();
  }, [orderIds]);

  useEffect(() => {
    if (!loading && orders.length > 0) {
      setTimeout(() => {
        window.print();
      }, 500);
    }
  }, [loading, orders]);

  if (loading) return <div className="p-8 text-center">در حال آماده‌سازی فاکتورها...</div>;
  if (orders.length === 0) return <div className="p-8 text-center text-red-500">هیچ سفارشی یافت نشد</div>;

  return (
    <div className="bg-white" dir="rtl">
      {orders.map((order, index) => (
        <div 
          key={order.id} 
          className="p-8 mx-auto text-right break-after-page"
          style={{
            width: '148mm',
            minHeight: '210mm',
            maxHeight: '210mm',
            pageBreakAfter: 'always'
          }}
        >
          {/* Header */}
          <div className="flex justify-between items-start border-b-2 border-gray-800 pb-6 mb-8">
            <div>
              <h1 className="text-2xl font-bold mb-2">فاکتور فروش</h1>
              <p className="text-gray-600">فروشگاه آنلاین نورسا</p>
            </div>
            <div className="text-left">
              <img 
                src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo_top.png" 
                alt="Nursaa Logo" 
                className="h-12 mb-2 object-contain"
              />
              <p className="text-sm text-gray-500">تاریخ: {new Date(order.created_at).toLocaleDateString('fa-IR')}</p>
              <p className="text-sm text-gray-500">شماره سفارش: {String(order.id).slice(0, 8)}</p>
            </div>
          </div>

          {/* Customer Info */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-gray-800 mb-2 border-b pb-1">اطلاعات فروشنده</h3>
              <p className="text-sm mb-1">نام: فروشگاه نورسا</p>
              <p className="text-sm mb-1">وب‌سایت: www.nursaa.ir</p>
              <div className="flex items-center gap-2 text-sm mb-1">
                <span>تلفن:</span>
                <span dir="ltr">۰۵۱-۳۸۳۷۳۵۳۰</span>
              </div>
            </div>
            <div>
              <h3 className="font-bold text-gray-800 mb-2 border-b pb-1">اطلاعات خریدار</h3>
              <p className="text-sm mb-1">نام: {order.customer_name || 'کاربر مهمان'}</p>
              <p className="text-sm mb-1">تلفن: {order.phone || '---'}</p>
              <p className="text-sm mb-1">آدرس: {order.address || 'آدرس ثبت نشده'}</p>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full mb-8 border-collapse">
            <thead>
              <tr className="bg-gray-100 border-b border-gray-300">
                <th className="py-2 px-4 text-right border border-gray-300 w-12">#</th>
                <th className="py-2 px-4 text-right border border-gray-300">شرح کالا / خدمات</th>
                <th className="py-2 px-4 text-center border border-gray-300 w-24">تعداد</th>
                <th className="py-2 px-4 text-left border border-gray-300 w-32">قیمت واحد</th>
                <th className="py-2 px-4 text-left border border-gray-300 w-36">مبلغ کل (تومان)</th>
              </tr>
            </thead>
            <tbody>
              {(order.items && order.items.length > 0) ? (
                order.items.map((item, idx) => (
                  <tr key={item.id || idx}>
                    <td className="py-2 px-4 text-center border border-gray-300">{idx + 1}</td>
                    <td className={`py-2 px-4 border border-gray-300 ${item.product_name?.includes('محصول کد') || item.product_name?.startsWith('محصول ') ? 'text-red-500' : ''}`}>
                      {item.product_name || 'محصول بدون نام'}
                    </td>
                    <td className="py-2 px-4 text-center border border-gray-300">{item.quantity || 0}</td>
                    <td className="py-2 px-4 text-left border border-gray-300">
                      {(item.price || item.unit_price || 0).toLocaleString('fa-IR')}
                    </td>
                    <td className="py-2 px-4 text-left border border-gray-300">
                      {((item.price || item.unit_price || 0) * (item.quantity || 0)).toLocaleString('fa-IR')}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-4 px-4 text-center border border-gray-300 text-gray-500">
                    هیچ محصولی در این سفارش ثبت نشده است
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              {(() => {
                const itemsSubtotal = (order.items || []).reduce(
                  (sum, item) => sum + ((item.price || item.unit_price || 0) * (item.quantity || 0)), 
                  0
                );
                const subtotal = order.subtotal || itemsSubtotal;
                const postPrice = order.post_price || 0;
                const discountAmount = order.discount_amount || 0;
                
                return (
                  <>
                    <tr>
                      <td colSpan={4} className="py-2 px-4 text-left border border-gray-300 bg-gray-50">جمع محصولات</td>
                      <td className="py-2 px-4 text-left border border-gray-300 bg-gray-50">
                        {subtotal.toLocaleString('fa-IR')}
                      </td>
                    </tr>
                    {postPrice > 0 && (
                      <tr>
                        <td colSpan={4} className="py-2 px-4 text-left border border-gray-300 bg-gray-50">هزینه ارسال</td>
                        <td className="py-2 px-4 text-left border border-gray-300 bg-gray-50">
                          {postPrice.toLocaleString('fa-IR')}
                        </td>
                      </tr>
                    )}
                    {discountAmount > 0 && (
                      <tr>
                        <td colSpan={4} className="py-2 px-4 text-left border border-gray-300 bg-gray-50 text-red-600">تخفیف</td>
                        <td className="py-2 px-4 text-left border border-gray-300 bg-gray-50 text-red-600">
                          -{discountAmount.toLocaleString('fa-IR')}
                        </td>
                      </tr>
                    )}
                    <tr>
                      <td colSpan={4} className="py-3 px-4 text-left font-bold border border-gray-300 bg-gray-100">مبلغ قابل پرداخت (تومان)</td>
                      <td className="py-3 px-4 text-left font-bold border border-gray-300 bg-gray-100 text-lg">
                        {order.total_amount.toLocaleString('fa-IR')}
                      </td>
                    </tr>
                  </>
                );
              })()}
            </tfoot>
          </table>

          {/* Footer */}
          <div className="mt-12 text-center text-sm text-gray-500 border-t pt-4">
            <p>با تشکر از خرید شما از فروشگاه نورسا</p>
          </div>
        </div>
      ))}

      <style>{`
        @media print {
          @page {
            size: A5;
            margin: 0;
          }
          body {
            margin: 0;
            padding: 0;
          }
          .break-after-page {
            page-break-after: always;
          }
        }
      `}</style>
    </div>
  );
}
