import { useEffect, useState } from "react";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { logger } from "../../../src/utils/logger";

interface Order {
  id: string;
  customer_name: string;
  phone: string;
  address: string;
}

interface PrintAddressProps {
  orderId: string;
}

export function PrintAddress({ orderId }: PrintAddressProps) {
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchOrder() {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders/${orderId}`,
          {
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
          }
        );
        if (response.ok) {
          const data = await response.json();
          setOrder(data.order);
        }
      } catch (error) {
        logger.error("Error fetching order:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchOrder();
  }, [orderId]);

  useEffect(() => {
    if (!loading && order) {
      setTimeout(() => {
        window.print();
      }, 500);
    }
  }, [loading, order]);

  if (loading) return <div className="p-8 text-center">در حال آماده‌سازی برچسب آدرس...</div>;
  if (!order) return <div className="p-8 text-center text-red-500">سفارش یافت نشد</div>;

  return (
    <div className="bg-white p-8 min-h-screen flex items-center justify-center" dir="rtl">
      <div className="border-2 border-gray-800 p-4 rounded-xl max-w-[140mm] w-full bg-white">
        {/* Sender */}
        <div className="mb-4 border-b-2 border-dashed border-gray-300 pb-4">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-bold text-gray-500 text-xs w-14">فرستنده:</span>
                <span className="font-bold text-base">فروشگاه آنلاین نورسا</span>
              </div>
              <div className="flex items-start gap-2 mb-1">
                <span className="font-bold text-gray-500 text-xs w-14">آدرس:</span>
                <span className="text-xs">خراسان رضوی، گلمکان، اسجیل، صاحب‌الزمان ۴</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-gray-500 text-xs w-14">تلفن:</span>
                <span className="text-xs">۰۵۱-۳۸۳۷۳۵۳۰</span>
              </div>
            </div>
            <img 
              src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo_top.png" 
              alt="Norsa Logo" 
              className="h-12 object-contain"
            />
          </div>
        </div>

        {/* Receiver */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="font-bold text-gray-500 text-xs w-14">گیرنده:</span>
            <span className="font-bold text-lg">{order.customer_name || 'کاربر مهمان'}</span>
          </div>
          <div className="flex items-start gap-2 mb-2">
            <span className="font-bold text-gray-500 text-xs w-14 mt-1">آدرس:</span>
            <p className="text-base leading-relaxed flex-1">{order.address || 'آدرس ثبت نشده'}</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-gray-500 text-xs w-14">تلفن:</span>
            <span className="text-lg dir-ltr font-mono">{order.phone || '---'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}