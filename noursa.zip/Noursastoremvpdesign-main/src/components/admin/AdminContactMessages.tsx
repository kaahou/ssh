import { useState, useEffect } from 'react';
import { AdminLayout } from './AdminLayout';
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { logger } from "../../src/utils/logger";
import { MessageSquare, Mail, Phone, Calendar, FileText, X, Clock, CheckCircle, XCircle } from 'lucide-react';

interface ContactMessage {
  id: number;
  full_name: string;
  email: string | null;
  phone_number: string;
  subject: string;
  message: string;
  created_at: string;
  status: 'new' | 'in_progress' | 'resolved' | 'closed';
  notes: string | null;
}

const subjectLabels: Record<string, string> = {
  product: 'سوال درباره محصول',
  order: 'پیگیری سفارش',
  return: 'بازگشت کالا',
  complaint: 'شکایت',
  suggestion: 'پیشنهاد',
  other: 'سایر'
};

const statusLabels: Record<string, string> = {
  new: 'جدید',
  in_progress: 'در حال بررسی',
  resolved: 'حل شده',
  closed: 'بسته شده'
};

const statusColors: Record<string, string> = {
  new: 'bg-red-100 text-red-800 border-red-200',
  in_progress: 'bg-blue-100 text-blue-800 border-blue-200',
  resolved: 'bg-green-100 text-green-800 border-green-200',
  closed: 'bg-gray-100 text-gray-800 border-gray-200'
};

export function AdminContactMessages() {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/contact-messages`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setMessages(data.data || []);
      }
    } catch (error) {
      logger.error('Error fetching messages:', error);
      toast.error('خطا در بارگذاری پیام‌ها', {
        style: { direction: 'rtl', fontFamily: 'inherit' }
      });
    } finally {
      setLoading(false);
    }
  };

  const updateMessageStatus = async (id: number, status: string, notes?: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/contact-messages/${id}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({ status, notes })
        }
      );

      if (response.ok) {
        toast.success('وضعیت پیام به‌روزرسانی شد', {
          style: { direction: 'rtl', fontFamily: 'inherit' }
        });
        fetchMessages();
        if (selectedMessage?.id === id) {
          const data = await response.json();
          setSelectedMessage(data.data);
        }
      }
    } catch (error) {
      logger.error('Error updating message:', error);
      toast.error('خطا در به‌روزرسانی وضعیت', {
        style: { direction: 'rtl', fontFamily: 'inherit' }
      });
    }
  };

  const filteredMessages = filterStatus === 'all' 
    ? messages 
    : messages.filter(m => m.status === filterStatus);

  const stats = {
    total: messages.length,
    new: messages.filter(m => m.status === 'new').length,
    in_progress: messages.filter(m => m.status === 'in_progress').length,
    resolved: messages.filter(m => m.status === 'resolved').length,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#484D2C] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-[#888888]">در حال بارگذاری پیام‌ها...</p>
        </div>
      </div>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-[16px] p-6 border border-[#E8E8E8]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[#888888] text-[13px] mb-1">کل پیام‌ها</p>
                <p className="text-[28px] font-bold text-[#1A2011]">{stats.total.toLocaleString('fa-IR')}</p>
              </div>
              <div className="w-12 h-12 bg-[#F9E1B4]/20 rounded-full flex items-center justify-center">
                <MessageSquare size={24} className="text-[#484D2C]" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[16px] p-6 border border-[#E8E8E8]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[#888888] text-[13px] mb-1">پیام‌های جدید</p>
                <p className="text-[28px] font-bold text-[#DC2626]">{stats.new.toLocaleString('fa-IR')}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Clock size={24} className="text-[#DC2626]" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[16px] p-6 border border-[#E8E8E8]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[#888888] text-[13px] mb-1">در حال بررسی</p>
                <p className="text-[28px] font-bold text-[#2563EB]">{stats.in_progress.toLocaleString('fa-IR')}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <MessageSquare size={24} className="text-[#2563EB]" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[16px] p-6 border border-[#E8E8E8]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[#888888] text-[13px] mb-1">حل شده</p>
                <p className="text-[28px] font-bold text-[#16A34A]">{stats.resolved.toLocaleString('fa-IR')}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle size={24} className="text-[#16A34A]" />
              </div>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] p-2">
          <div className="flex gap-2 overflow-x-auto">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors whitespace-nowrap ${
                filterStatus === 'all' ? 'bg-[#1A2011] text-white' : 'text-[#444444] hover:bg-[#FAFAFA]'
              }`}
            >
              همه ({messages.length})
            </button>
            <button
              onClick={() => setFilterStatus('new')}
              className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors whitespace-nowrap ${
                filterStatus === 'new' ? 'bg-[#DC2626] text-white' : 'text-[#444444] hover:bg-[#FAFAFA]'
              }`}
            >
              جدید ({stats.new})
            </button>
            <button
              onClick={() => setFilterStatus('in_progress')}
              className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors whitespace-nowrap ${
                filterStatus === 'in_progress' ? 'bg-[#2563EB] text-white' : 'text-[#444444] hover:bg-[#FAFAFA]'
              }`}
            >
              در حال بررسی ({stats.in_progress})
            </button>
            <button
              onClick={() => setFilterStatus('resolved')}
              className={`px-4 py-2 rounded-[8px] text-[14px] font-medium transition-colors whitespace-nowrap ${
                filterStatus === 'resolved' ? 'bg-[#16A34A] text-white' : 'text-[#444444] hover:bg-[#FAFAFA]'
              }`}
            >
              حل شده ({stats.resolved})
            </button>
          </div>
        </div>

        {/* Messages List */}
        <div className="bg-white rounded-[16px] border border-[#E8E8E8] overflow-hidden">
          {filteredMessages.length === 0 ? (
            <div className="p-12 text-center">
              <MessageSquare size={48} className="mx-auto mb-4 text-[#CCCCCC]" />
              <p className="text-[#888888]">پیامی برای نمایش وجود ندارد</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#FAFAFA] border-b border-[#E8E8E8]">
                  <tr>
                    <th className="px-6 py-4 text-right text-[13px] font-medium text-[#888888]">نام</th>
                    <th className="px-6 py-4 text-right text-[13px] font-medium text-[#888888]">موضوع</th>
                    <th className="px-6 py-4 text-right text-[13px] font-medium text-[#888888]">تماس</th>
                    <th className="px-6 py-4 text-right text-[13px] font-medium text-[#888888]">تاریخ</th>
                    <th className="px-6 py-4 text-right text-[13px] font-medium text-[#888888]">وضعیت</th>
                    <th className="px-6 py-4 text-right text-[13px] font-medium text-[#888888]">عملیات</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredMessages.map((message) => (
                    <tr key={message.id} className="border-b border-[#E8E8E8] hover:bg-[#FAFAFA] transition-colors">
                      <td className="px-6 py-4">
                        <p className="text-[14px] text-[#1A2011] font-medium">{message.full_name}</p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-[14px] text-[#444444]">{subjectLabels[message.subject] || message.subject}</p>
                      </td>
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <p className="text-[13px] text-[#444444] flex items-center gap-2">
                            <Phone size={14} />
                            {message.phone_number}
                          </p>
                          {message.email && (
                            <p className="text-[13px] text-[#444444] flex items-center gap-2">
                              <Mail size={14} />
                              {message.email}
                            </p>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-[13px] text-[#888888]">
                          {new Date(message.created_at).toLocaleDateString('fa-IR', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex px-3 py-1 rounded-full text-[12px] font-medium border ${statusColors[message.status]}`}>
                          {statusLabels[message.status]}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => setSelectedMessage(message)}
                          className="text-[14px] text-[#1A2011] hover:underline font-medium"
                        >
                          مشاهده جزئیات
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Message Detail Modal */}
        {selectedMessage && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setSelectedMessage(null)}>
            <div className="bg-white rounded-[20px] max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="p-6 border-b border-[#E8E8E8]">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-[20px] font-bold text-[#1A2011]">جزئیات پیام</h2>
                  <button onClick={() => setSelectedMessage(null)} className="text-[#888888] hover:text-[#1A2011]">
                    <XCircle size={24} />
                  </button>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-[13px] text-[#888888] mb-1">نام فرستنده</p>
                    <p className="text-[15px] text-[#1A2011] font-medium">{selectedMessage.full_name}</p>
                  </div>
                  <div>
                    <p className="text-[13px] text-[#888888] mb-1">موضوع</p>
                    <p className="text-[15px] text-[#1A2011] font-medium">{subjectLabels[selectedMessage.subject]}</p>
                  </div>
                  <div>
                    <p className="text-[13px] text-[#888888] mb-1">شماره تماس</p>
                    <p className="text-[15px] text-[#1A2011] font-medium">{selectedMessage.phone_number}</p>
                  </div>
                  <div>
                    <p className="text-[13px] text-[#888888] mb-1">ایمیل</p>
                    <p className="text-[15px] text-[#1A2011] font-medium">{selectedMessage.email || '-'}</p>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-[13px] text-[#888888] mb-1">تاریخ ارسال</p>
                  <p className="text-[15px] text-[#1A2011]">
                    {new Date(selectedMessage.created_at).toLocaleDateString('fa-IR', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>

                <div className="mb-4">
                  <p className="text-[13px] text-[#888888] mb-2">متن پیام</p>
                  <div className="bg-[#FAFAFA] rounded-[12px] p-4 border border-[#E8E8E8]">
                    <p className="text-[15px] text-[#1A2011] whitespace-pre-wrap">{selectedMessage.message}</p>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-[13px] text-[#888888] mb-2">وضعیت</p>
                  <div className="flex gap-2">
                    {(['new', 'in_progress', 'resolved', 'closed'] as const).map((status) => (
                      <button
                        key={status}
                        onClick={() => updateMessageStatus(selectedMessage.id, status)}
                        className={`px-4 py-2 rounded-[8px] text-[13px] font-medium border transition-colors ${
                          selectedMessage.status === status
                            ? statusColors[status]
                            : 'bg-white text-[#888888] border-[#E8E8E8] hover:bg-[#FAFAFA]'
                        }`}
                      >
                        {statusLabels[status]}
                      </button>
                    ))}
                  </div>
                </div>

                {selectedMessage.notes && (
                  <div>
                    <p className="text-[13px] text-[#888888] mb-2">یادداشت‌ها</p>
                    <div className="bg-[#FFF9E6] rounded-[12px] p-4 border border-[#F9E1B4]">
                      <p className="text-[14px] text-[#1A2011]">{selectedMessage.notes}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}