import { Link } from "react-router-dom";
import { Home } from "lucide-react";
import { useUser } from "../UserContext";

// Admin phone numbers - must match backend ADMIN_PHONES
const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
];

export function AdminTopBar() {
  const { user } = useUser();
  
  // Only show AdminTopBar for admin phone numbers
  if (!user || !ADMIN_PHONES.includes(user.phone)) {
    return null;
  }

  return (
    <div className="bg-[#1A2011] text-white h-10 px-4 md:px-8 flex items-center justify-between text-sm relative z-50">
      <div className="flex items-center gap-2">
        <span className="font-bold">پنل مدیریت فروشگاه نورسا</span>
      </div>
      <Link 
        to="/admin"
        className="flex items-center gap-2 hover:bg-white/10 px-3 py-1 rounded-md transition-colors font-medium"
      >
        <Home size={16} />
        <span>ورود به پنل ادمین</span>
      </Link>
    </div>
  );
}