import { useState, useEffect } from "react";
import { X, Save, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../../ui/dialog";
import { Input } from "../../ui/input";
import { Label } from "../../ui/label";
import { Textarea } from "../../ui/textarea";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import { Product } from "../../ProductCard";

interface Category {
  id: number;
  name: string;
}

interface EditProductModalProps {
  isOpen: boolean;
  productId: number | null;
  onClose: () => void;
  onProductUpdated: () => void;
}

export function EditProductModal({ isOpen, productId, onClose, onProductUpdated }: EditProductModalProps) {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  
  const [formData, setFormData] = useState({
    product_name: "",
    variant_name: "",
    slug: "",
    price: "",
    old_price: "",
    category_id: "",
    short_description: "",
    full_description: "",
    meta_description: "",
    keywords: "",
    image_urls: "",
  });

  // Fetch categories
  useEffect(() => {
    async function fetchCategories() {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/categories`,
          {
            headers: { Authorization: `Bearer ${publicAnonKey}` },
          }
        );
        if (response.ok) {
          const data = await response.json();
          setCategories(data.categories || []);
        }
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    }
    
    fetchCategories();
  }, []);

  // Fetch product details when modal opens
  useEffect(() => {
    if (isOpen && productId) {
      fetchProduct();
    }
  }, [isOpen, productId]);

  const fetchProduct = async () => {
    if (!productId) return;
    
    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/${productId}`,
        {
          headers: { Authorization: `Bearer ${publicAnonKey}` },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const product = data.product;
        
        setFormData({
          product_name: product.product_name || "",
          variant_name: product.variant_name || "",
          slug: product.slug || "",
          price: String(product.price || ""),
          old_price: String(product.old_price || ""),
          category_id: String(product.category_id || ""),
          short_description: product.short_description || "",
          full_description: product.full_description || "",
          meta_description: product.meta_description || "",
          keywords: product.keywords || "",
          image_urls: product.image_urls || "",
        });
      } else {
        toast.error("خطا در بارگذاری اطلاعات محصول");
      }
    } catch (error) {
      console.error("Error fetching product:", error);
      toast.error("خطا در بارگذاری اطلاعات محصول");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId) return;
    
    setSaving(true);

    try {
      // Validate
      if (!formData.product_name || !formData.price) {
        toast.error("لطفا نام محصول و قیمت را وارد کنید");
        setSaving(false);
        return;
      }

      // Prepare payload
      const payload = {
        ...formData,
        price: Number(formData.price),
        old_price: formData.old_price ? Number(formData.old_price) : null,
        category_id: formData.category_id ? Number(formData.category_id) : null,
        slug: formData.slug || formData.product_name.replace(/\s+/g, '-').toLowerCase(),
      };

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/${productId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(payload),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        const errorMessage = result.details 
          ? `${result.error}: ${result.details}` 
          : result.error || "خطا در به‌روزرسانی محصول";
        throw new Error(errorMessage);
      }

      toast.success("محصول با موفقیت به‌روزرسانی شد");
      onProductUpdated();
      onClose();
    } catch (error: any) {
      console.error("Error updating product:", error);
      toast.error(error.message || "خطا در به‌روزرسانی محصول", {
        style: { direction: 'rtl', fontFamily: 'inherit' }
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">ویرایش محصول</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="py-12 flex justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-[#1A2011]" />
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Info */}
            <div className="bg-[#FAFAFA] p-6 rounded-[16px] space-y-4">
              <h3 className="font-semibold text-[#1A2011] mb-4">اطلاعات پایه</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product_name">نام محصول *</Label>
                  <Input
                    id="product_name"
                    name="product_name"
                    value={formData.product_name}
                    onChange={handleChange}
                    required
                    className="h-[48px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="variant_name">نام واریانت</Label>
                  <Input
                    id="variant_name"
                    name="variant_name"
                    value={formData.variant_name}
                    onChange={handleChange}
                    className="h-[48px]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug">شناسه URL (Slug)</Label>
                <Input
                  id="slug"
                  name="slug"
                  value={formData.slug}
                  onChange={handleChange}
                  dir="ltr"
                  className="h-[48px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="short_description">توضیحات کوتاه</Label>
                <Textarea
                  id="short_description"
                  name="short_description"
                  value={formData.short_description}
                  onChange={handleChange}
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="full_description">توضیحات کامل</Label>
                <Textarea
                  id="full_description"
                  name="full_description"
                  value={formData.full_description}
                  onChange={handleChange}
                  rows={4}
                />
              </div>
            </div>

            {/* Pricing & Stock */}
            <div className="bg-[#FAFAFA] p-6 rounded-[16px] space-y-4">
              <h3 className="font-semibold text-[#1A2011] mb-4">قیمت</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">قیمت (تومان) *</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    value={formData.price}
                    onChange={handleChange}
                    required
                    className="h-[48px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="old_price">قیمت اصلی (تومان)</Label>
                  <Input
                    id="old_price"
                    name="old_price"
                    type="number"
                    value={formData.old_price}
                    onChange={handleChange}
                    className="h-[48px]"
                  />
                </div>
              </div>
            </div>

            {/* Category & Image */}
            <div className="bg-[#FAFAFA] p-6 rounded-[16px] space-y-4">
              <h3 className="font-semibold text-[#1A2011] mb-4">دسته‌بندی</h3>
              
              <div className="space-y-2">
                <Label htmlFor="category_id">دسته‌بندی</Label>
                <select
                  id="category_id"
                  name="category_id"
                  value={formData.category_id}
                  onChange={handleChange}
                  className="w-full h-[48px] px-4 bg-white border border-[#E8E8E8] rounded-[12px] outline-none"
                >
                  <option value="">بدون دسته‌بندی</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Product Images */}
            <div className="bg-[#FAFAFA] p-6 rounded-[16px] space-y-4">
              <h3 className="font-semibold text-[#1A2011] mb-4">تصاویر محصول</h3>
              
              <div className="space-y-2">
                <Label htmlFor="image_urls">لینک‌های تصاویر</Label>
                <Textarea
                  id="image_urls"
                  name="image_urls"
                  value={formData.image_urls}
                  onChange={handleChange}
                  rows={3}
                  placeholder="https://example.com/image1.jpg,https://example.com/image2.jpg"
                  dir="ltr"
                />
                <p className="text-xs text-[#888888]">
                  می‌توانید چند لینک تصویر را با کاما (,) از هم جدا کنید
                </p>
              </div>
            </div>

            {/* SEO */}
            <div className="bg-[#FAFAFA] p-6 rounded-[16px] space-y-4">
              <h3 className="font-semibold text-[#1A2011] mb-4">تنظیمات SEO</h3>
              
              <div className="space-y-2">
                <Label htmlFor="meta_description">توضیحات متا (Meta Description)</Label>
                <Textarea
                  id="meta_description"
                  name="meta_description"
                  value={formData.meta_description}
                  onChange={handleChange}
                  rows={2}
                  placeholder="توضیحات کوتاهی برای موتورهای جستجو"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="keywords">کلمات کلیدی (Keywords)</Label>
                <Input
                  id="keywords"
                  name="keywords"
                  value={formData.keywords}
                  onChange={handleChange}
                  className="h-[48px]"
                  placeholder="کلمه1، کلمه2، کلمه3"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 justify-end pt-4 border-t">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 bg-white border border-[#E8E8E8] text-[#444444] rounded-[12px] hover:bg-gray-50 transition-colors"
                disabled={saving}
              >
                انصراف
              </button>
              <button
                type="submit"
                className="px-6 py-3 bg-[#1A2011] text-white rounded-[12px] hover:bg-[#222222] transition-colors flex items-center gap-2"
                disabled={saving}
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    در حال ذخیره...
                  </>
                ) : (
                  <>
                    <Save size={18} />
                    ذخیره تغییرات
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}