import { useState, useEffect } from "react";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { logger } from "../../src/utils/logger";

export function DebugSchema() {
  const [schema, setSchema] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchSchema() {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/schema/debug`,
          {
            headers: { Authorization: `Bearer ${publicAnonKey}` },
          }
        );
        const data = await response.json();
        setSchema(data);
      } catch (error) {
        logger.error("Error fetching schema:", error);
      } finally {
        setLoading(false);
      }
    }
    
    fetchSchema();
  }, []);

  if (loading) return <div className="p-4 text-center">Loading schema...</div>;

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg max-w-4xl mx-auto my-8" dir="ltr">
      <h2 className="text-2xl font-bold mb-4">Products Table Schema Debug</h2>
      <div className="bg-gray-100 p-4 rounded overflow-auto">
        <pre className="text-sm">{JSON.stringify(schema, null, 2)}</pre>
      </div>
      
      {schema?.schema && (
        <div className="mt-4">
          <h3 className="text-lg font-semibold mb-2">Available Columns:</h3>
          <ul className="list-disc pl-6">
            {schema.schema.map((col: string) => (
              <li key={col} className="font-mono text-sm py-1">{col}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}