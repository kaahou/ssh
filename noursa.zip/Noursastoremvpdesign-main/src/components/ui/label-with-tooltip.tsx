import { Info } from "lucide-react";
import { Label } from "./label";
import { useState } from "react";

interface LabelWithTooltipProps {
  htmlFor?: string;
  children: React.ReactNode;
  tooltip?: string;
  required?: boolean;
  className?: string;
}

export function LabelWithTooltip({
  htmlFor,
  children,
  tooltip,
  required,
  className = "",
}: LabelWithTooltipProps) {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="relative mb-2">
      <Label htmlFor={htmlFor} className={`text-[#444444] block ${className}`}>
        {children}
        {required && <span className="text-destructive mr-1">*</span>}
        {tooltip && (
          <button
            type="button"
            className="inline-flex items-center mr-1 relative"
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            onClick={(e) => {
              e.preventDefault();
              setShowTooltip(!showTooltip);
            }}
          >
            <Info className="w-4 h-4 text-[#888888] hover:text-[#1A2011] transition-colors" />
          </button>
        )}
      </Label>

      {tooltip && showTooltip && (
        <div className="absolute z-50 top-full right-0 mt-2 w-[280px] bg-white border-2 border-[#E8E8E8] rounded-[12px] p-3 shadow-lg text-sm text-[#444444] leading-relaxed">
          <div className="absolute -top-2 right-4 w-4 h-4 bg-white border-t-2 border-r-2 border-[#E8E8E8] transform rotate-45"></div>
          {tooltip}
        </div>
      )}
    </div>
  );
}
