/**
 * Custom CVA (Class Variance Authority) implementation
 * A minimal type-safe variant system for Tailwind CSS
 */

type ClassValue = string | number | boolean | undefined | null;
type ClassArray = ClassValue[];
type ClassDictionary = Record<string, any>;
type ClassProp = ClassValue | ClassArray | ClassDictionary;

// Simple cn (classnames) utility
export function cn(...inputs: ClassProp[]): string {
  const classes: string[] = [];

  inputs.forEach((input) => {
    if (!input) return;

    if (typeof input === "string" || typeof input === "number") {
      classes.push(String(input));
    } else if (Array.isArray(input)) {
      const inner = cn(...input);
      if (inner) classes.push(inner);
    } else if (typeof input === "object") {
      Object.entries(input).forEach(([key, value]) => {
        if (value) classes.push(key);
      });
    }
  });

  return classes.join(" ");
}

// CVA types
type ConfigVariants = Record<string, Record<string, ClassValue>>;
type ConfigVariantsMulti<V extends ConfigVariants> = {
  [K in keyof V]?: keyof V[K] | (keyof V[K])[];
};

interface Config<V extends ConfigVariants> {
  variants?: V;
  defaultVariants?: ConfigVariantsMulti<V>;
  compoundVariants?: Array<
    ConfigVariantsMulti<V> & { className?: ClassValue }
  >;
}

export type VariantProps<T extends (...args: any) => any> = Omit<
  Parameters<T>[0],
  "className"
>;

/**
 * Create variant-based className builder
 */
export function cva<V extends ConfigVariants>(
  base?: ClassValue,
  config?: Config<V>
) {
  return (props?: ConfigVariantsMulti<V> & { className?: ClassValue }) => {
    if (!config?.variants) {
      return cn(base, props?.className);
    }

    const classes: ClassValue[] = [base];

    // Apply variant classes
    if (props) {
      Object.entries(config.variants).forEach(([variantName, variantValues]) => {
        const variantValue = props[variantName as keyof typeof props];
        if (variantValue && variantValue in variantValues) {
          classes.push(variantValues[variantValue as string]);
        } else if (config.defaultVariants?.[variantName as keyof V]) {
          const defaultValue = config.defaultVariants[variantName as keyof V];
          if (defaultValue && defaultValue in variantValues) {
            classes.push(variantValues[defaultValue as string]);
          }
        }
      });

      // Apply compound variants
      if (config.compoundVariants) {
        config.compoundVariants.forEach((compound) => {
          const { className: compoundClassName, ...compoundVariants } = compound;
          const matches = Object.entries(compoundVariants).every(
            ([key, value]) => {
              const propValue = props[key as keyof typeof props];
              if (Array.isArray(value)) {
                return value.includes(propValue as any);
              }
              return propValue === value;
            }
          );
          if (matches && compoundClassName) {
            classes.push(compoundClassName);
          }
        });
      }

      classes.push(props.className);
    } else if (config.defaultVariants) {
      // Apply default variants when no props provided
      Object.entries(config.defaultVariants).forEach(([variantName, defaultValue]) => {
        if (defaultValue && config.variants?.[variantName]?.[defaultValue as string]) {
          classes.push(config.variants[variantName][defaultValue as string]);
        }
      });
    }

    return cn(...classes);
  };
}