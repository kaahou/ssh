import * as React from "react";
import { Check } from "lucide-react";

interface MultiSelectProps {
  value: string[];
  onChange: (value: string[]) => void;
  options: string[];
  className?: string;
}

export function MultiSelect({
  value,
  onChange,
  options,
  className = "",
}: MultiSelectProps) {
  const toggleOption = (option: string) => {
    if (value.includes(option)) {
      onChange(value.filter((v) => v !== option));
    } else {
      onChange([...value, option]);
    }
  };

  return (
    <div className={`grid grid-cols-2 gap-2 ${className}`}>
      {options.map((option) => {
        const isSelected = value.includes(option);
        return (
          <button
            key={option}
            type="button"
            onClick={() => toggleOption(option)}
            className={`flex items-center gap-3 p-3 rounded-[12px] border-2 text-right transition-all ${
              isSelected
                ? "bg-[#1A2011]/5 border-[#1A2011]"
                : "bg-[#FAFAFA] border-[#E8E8E8] hover:border-[#1A2011]/30"
            }`}
          >
            <div
              className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                isSelected
                  ? "bg-[#1A2011] border-[#1A2011]"
                  : "bg-white border-[#E8E8E8]"
              }`}
            >
              {isSelected && <Check className="w-3 h-3 text-white" />}
            </div>
            <span className="text-sm text-[#444444]">{option}</span>
          </button>
        );
      })}
    </div>
  );
}