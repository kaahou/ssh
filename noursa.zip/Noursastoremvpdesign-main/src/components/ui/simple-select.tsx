import * as React from "react";

interface SimpleSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: string[];
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}

export function SimpleSelect({
  value,
  onChange,
  options,
  placeholder = "انتخاب کنید...",
  className = "",
  disabled = false,
}: SimpleSelectProps) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className={`w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] text-[#1A2011] focus:outline-none focus:border-[#1A2011] focus:bg-white transition-all disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    >
      <option value="" disabled>
        {placeholder}
      </option>
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  );
}
