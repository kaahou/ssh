import * as React from "react";
import { Check } from "lucide-react";

interface CheckboxProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  className?: string;
}

export function Checkbox({
  label,
  checked,
  onChange,
  className = "",
}: CheckboxProps) {
  return (
    <label
      className={`flex items-center gap-3 cursor-pointer group ${className}`}
    >
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="sr-only"
      />
      <div
        className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
          checked
            ? "bg-[#1A2011] border-[#1A2011]"
            : "bg-white border-[#E8E8E8] group-hover:border-[#1A2011]"
        }`}
      >
        {checked && <Check className="w-3 h-3 text-white" />}
      </div>
      <span className="text-[#444444] text-sm">{label}</span>
    </label>
  );
}