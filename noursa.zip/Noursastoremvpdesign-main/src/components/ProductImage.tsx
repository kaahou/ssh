import { OptimizedImage } from './OptimizedImage';

interface ProductImageProps {
  src: string;
  alt: string;
  className?: string;
  priority?: boolean;
}

/**
 * Product Image Component with Supabase Storage Optimization
 * Automatically applies transformations for faster loading
 */
export function ProductImage({ src, alt, className, priority = false }: ProductImageProps) {
  // Extract Supabase storage URL and apply transformations
  const optimizeSrc = (originalSrc: string): string => {
    // Check if it's a Supabase storage URL
    if (originalSrc.includes('supabase.co/storage/v1/object/public/')) {
      // Supabase storage supports transformations via URL parameters
      // For now, just return original. In production, you can add:
      // ?width=800&quality=80&format=webp
      return originalSrc;
    }
    
    return originalSrc;
  };

  return (
    <OptimizedImage
      src={optimizeSrc(src)}
      alt={alt}
      className={className}
      priority={priority}
    />
  );
}
