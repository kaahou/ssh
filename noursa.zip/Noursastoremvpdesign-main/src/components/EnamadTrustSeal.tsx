import { useEffect, useRef } from 'react';

export function EnamadTrustSeal() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      // Clear any existing content
      containerRef.current.innerHTML = '';
      
      // Create the exact HTML structure from Enamad
      const link = document.createElement('a');
      link.setAttribute('referrerpolicy', 'origin');
      link.setAttribute('target', '_blank');
      link.setAttribute('href', 'https://trustseal.enamad.ir/?id=578418&Code=Sl2rVpsMpscFr9tUxzJXZPBY4TEmBOvG');
      
      const img = document.createElement('img');
      img.setAttribute('referrerpolicy', 'origin');
      img.setAttribute('src', 'https://trustseal.enamad.ir/logo.aspx?id=578418&Code=Sl2rVpsMpscFr9tUxzJXZPBY4TEmBOvG');
      img.setAttribute('alt', 'نماد اعتماد الکترونیکی');
      img.setAttribute('style', 'cursor:pointer');
      img.setAttribute('code', 'Sl2rVpsMpscFr9tUxzJXZPBY4TEmBOvG');
      
      link.appendChild(img);
      containerRef.current.appendChild(link);
    }
  }, []);

  return <div ref={containerRef} className="inline-block" />;
}
