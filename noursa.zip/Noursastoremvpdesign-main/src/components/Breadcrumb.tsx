import { ChevronLeft } from "lucide-react";

interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

export function Breadcrumb({ items }: BreadcrumbProps) {
  return (
    <nav className="flex items-center gap-2 text-sm text-[#888888]">
      {items.map((item, index) => (
        <div key={index} className="flex items-center gap-2">
          {item.onClick ? (
            <button
              onClick={item.onClick}
              className="hover:text-[#1A2011] transition-colors"
            >
              {item.label}
            </button>
          ) : (
            <span className="text-[#1A2011]">{item.label}</span>
          )}
          {index < items.length - 1 && (
            <ChevronLeft size={14} className="rotate-180" />
          )}
        </div>
      ))}
    </nav>
  );
}
