/**
 * Resource Hints Component
 * Adds DNS prefetch and preconnect hints for faster loading
 * Optimized to avoid blocking resources
 */

export function ResourceHints() {
  return (
    <>
      {/* DNS Prefetch for third-party domains - non-blocking */}
      <link rel="dns-prefetch" href="https://www.googletagmanager.com" />
      <link rel="dns-prefetch" href="https://www.google-analytics.com" />
      <link rel="dns-prefetch" href="https://jqxhriqljtpsateawvmb.supabase.co" />
      
      {/* Preconnect to critical domains only */}
      <link rel="preconnect" href="https://jqxhriqljtpsateawvmb.supabase.co" crossOrigin="anonymous" />
      
      {/* Remove preload hints for large images to avoid blocking initial render */}
      {/* Images will be loaded on-demand with lazy loading */}
    </>
  );
}