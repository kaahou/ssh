import { 
  ShoppingCart, 
  Menu, 
  X, 
  User, 
  Settings,
  Home,
  Package,
  BookOpen,
  Activity,
  Phone
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { useUser } from "./UserContext";
import { useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HeaderProps {
  cartItemCount?: number;
  currentPage?: string;
  onNavigate?: () => void;
}

// Admin phone numbers
const ADMIN_PHONES = [
  '09219675992',
  '09154409625',
  '09022002453',
  '09380088686',
];

export function Header({ cartItemCount = 0, currentPage = "" }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user } = useUser();

  const navItems = [
    { id: "home", label: "خانه", icon: Home, to: "/" },
    { id: "products", label: "محصولات", icon: Package, to: "/products" },
    { id: "blog", label: "مقالات", icon: BookOpen, to: "/blog" },
    { id: "consultation", label: "مشاوره", icon: Activity, to: "/consultation" },
    { id: "contact", label: "تماس", icon: Phone, to: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-[#E8E8E8] shadow-[0_1px_2px_0_rgba(0,0,0,0.05)]">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link 
            to="/"
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-30 h-30 rounded-[12px] flex items-center justify-center overflow-hidden">
              <ImageWithFallback 
                src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo_top.png"
                alt="لوگو نورسا"
                className="w-full h-full object-contain"
              />
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.id}
                  to={item.to}
                  className={`flex items-center gap-2 px-3 py-2 rounded-[12px] transition-colors duration-200 ${
                    currentPage === item.id
                      ? "bg-[#1A2011] text-white"
                      : "hover:bg-[#F4F4F5] text-[#1A2011]"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {/* Right Side Buttons */}
          <div className="flex items-center gap-4">
            {/* Admin Panel Button - Only for admin phones */}
            {user?.phone && ADMIN_PHONES.includes(user.phone) && (
              <Link to="/admin">
                <Button
                  variant="outline"
                  size="icon"
                  className="rounded-[12px] border-[#E8E8E8] hover:bg-[#16A34A]/10 hover:border-[#16A34A]"
                  title="پنل مدیریت"
                >
                  <Settings className="w-6 h-6 text-[#16A34A]" />
                </Button>
              </Link>
            )}

            {/* Login/Profile Button */}
            <Link to={user ? '/profile' : '/login'}>
              <Button
                variant="outline"
                size="icon"
                className="rounded-[12px] border-[#E8E8E8] hover:bg-[#F9E1B4]/20 hover:border-[#1A2011]"
                title={user ? 'پروفایل کاربری' : 'ورود / ثبت نام'}
              >
                <User className="w-6 h-6" />
              </Button>
            </Link>

            {/* Cart Button */}
            <Link to="/checkout">
              <Button
                variant="outline"
                size="icon"
                className="relative rounded-[12px] border-[#E8E8E8]"
              >
                <ShoppingCart className="w-6 h-6" />
                {cartItemCount > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                  >
                    {cartItemCount}
                  </Badge>
                )}
              </Button>
            </Link>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-[#E8E8E8]">
            {/* Admin Link for Mobile - Only for admin phones */}
            {user?.phone && ADMIN_PHONES.includes(user.phone) && (
              <Link
                to="/admin"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-3 w-full px-4 py-3 rounded-[12px] transition-colors duration-200 bg-gradient-to-l from-[#16A34A] to-[#065F46] text-white mb-2"
              >
                <Settings className="w-5 h-5" />
                پنل مدیریت
              </Link>
            )}

            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.id}
                  to={item.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-3 w-full px-4 py-3 rounded-[12px] transition-colors duration-200 ${
                    currentPage === item.id
                      ? "bg-[#1A2011] text-white"
                      : "hover:bg-[#F4F4F5] text-[#1A2011]"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        )}
      </div>
    </header>
  );
}