import { useEffect } from 'react';

interface GoogleTagManagerProps {
  gtmId: string;
}

export function GoogleTagManager({ gtmId }: GoogleTagManagerProps) {
  useEffect(() => {
    // Lazy load GTM after initial page load to improve performance
    const loadGTM = () => {
      // Check if already loaded
      if (document.querySelector(`script[src*="googletagmanager.com/gtm.js"]`)) {
        console.log('📊 GTM already loaded');
        return;
      }

      try {
        // Initialize dataLayer first
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          'gtm.start': new Date().getTime(),
          event: 'gtm.js'
        });

        // Load GTM script asynchronously
        const script = document.createElement('script');
        script.async = true;
        script.defer = true;
        script.src = `https://www.googletagmanager.com/gtm.js?id=${gtmId}`;
        
        // Add error handler for script loading
        script.onerror = () => {
          // GTM loading fails in dev/preview mode - this is expected behavior
          // Only log in production if needed for debugging
          if (window.location.hostname !== 'localhost' && !window.location.hostname.includes('preview')) {
            console.warn('⚠️ GTM failed to load');
          }
        };
        
        script.onload = () => {
          if (window.location.hostname !== 'localhost' && !window.location.hostname.includes('preview')) {
            console.log('✅ GTM loaded successfully');
          }
        };
        
        const firstScript = document.getElementsByTagName('script')[0];
        firstScript.parentNode?.insertBefore(script, firstScript);
        
        console.log('📊 GTM script injected');
      } catch (error) {
        console.warn('⚠️ Failed to initialize GTM:', error);
      }
    };

    // Use requestIdleCallback for better performance with longer timeout
    const scheduleGTMLoad = () => {
      if ('requestIdleCallback' in window) {
        // Wait until browser is idle, or max 5 seconds
        (window as any).requestIdleCallback(loadGTM, { timeout: 5000 });
      } else {
        // Fallback: wait 4 seconds to ensure page is fully loaded
        setTimeout(loadGTM, 4000);
      }
    };

    // Delay GTM loading until after critical resources
    if (document.readyState === 'complete') {
      // Page already loaded, schedule GTM
      scheduleGTMLoad();
    } else {
      // Wait for page load, then schedule GTM
      const handleLoad = () => {
        scheduleGTMLoad();
      };
      window.addEventListener('load', handleLoad, { once: true });
      
      // Cleanup
      return () => {
        window.removeEventListener('load', handleLoad);
      };
    }
  }, [gtmId]);

  // Noscript fallback
  return (
    <noscript>
      <iframe
        src={`https://www.googletagmanager.com/ns.html?id=${gtmId}`}
        height="0"
        width="0"
        style={{ display: 'none', visibility: 'hidden' }}
      />
    </noscript>
  );
}