import { useState } from "react";
import { MessageCircle, Phone, Instagram, Send, X } from "lucide-react";
import { Button } from "./ui/button";

interface SocialLink {
  name: string;
  icon: React.ElementType;
  url: string;
  color: string;
}

export function FloatingContactButton() {
  const [isOpen, setIsOpen] = useState(false);

  const socialLinks: SocialLink[] = [
    {
      name: "واتساپ",
      icon: MessageCircle,
      url: "https://wa.me/989219675992",
      color: "bg-[#25D366] hover:bg-[#20BA5A]",
    },
    {
      name: "تلگرام",
      icon: Send,
      url: "https://t.me/Nurssa_ir",
      color: "bg-[#0088cc] hover:bg-[#0077b5]",
    },
    {
      name: "ایتا",
      icon: Send,
      url: "https://eitaa.com/nurssa_ir",
      color: "bg-[#D32F2F] hover:bg-[#C62828]",
    },
    {
      name: "اینستاگرام",
      icon: Instagram,
      url: "https://instagram.com/nursaa.ir",
      color: "bg-gradient-to-br from-[#833AB4] via-[#E1306C] to-[#F77737] hover:opacity-90",
    },
    {
      name: "تماس",
      icon: Phone,
      url: "tel:09219675992",
      color: "bg-[#16A34A] hover:bg-[#15803D]",
    },
  ];

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleLinkClick = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer");
    setIsOpen(false);
  };

  return (
    <>
      <style>{`
        @keyframes shake {
          0%, 100% { transform: rotate(0deg); }
          10%, 30%, 50%, 70%, 90% { transform: rotate(-10deg); }
          20%, 40%, 60%, 80% { transform: rotate(10deg); }
        }
        .shake-animation {
          animation: shake 3s ease-in-out infinite;
        }
        .shake-animation:hover {
          animation: none;
        }
      `}</style>
      
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-[1040] transition-opacity duration-200"
          onClick={() => setIsOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Floating Button Container */}
      <div className="fixed bottom-[49px] left-6 z-[1050] flex flex-col items-center gap-3" role="complementary" aria-label="دکمه‌های تماس">
        {/* Social Links Menu */}
        {isOpen && (
          <div className="flex flex-col gap-2 animate-in slide-in-from-bottom-5 fade-in duration-200">
            {socialLinks.map((link, index) => {
              const Icon = link.icon;
              return (
                <button
                  key={index}
                  onClick={() => handleLinkClick(link.url)}
                  className={`group flex items-center gap-3 ${link.color} text-white rounded-full shadow-lg transition-all duration-200 hover:scale-105 active:scale-95 pr-4 pl-5 py-3`}
                  style={{ 
                    animationDelay: `${index * 50}ms`,
                    animationFillMode: 'both'
                  }}
                  aria-label={`ارتباط از طریق ${link.name}`}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <span className="text-sm whitespace-nowrap">{link.name}</span>
                </button>
              );
            })}</div>
        )}

        {/* Main Floating Button with Badge */}
        <div className="relative">
          {/* Red Badge */}
          {!isOpen && (
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-[#DC2626] rounded-full flex items-center justify-center shadow-lg animate-pulse z-10">
              <span className="text-white text-[10px] font-bold">1</span>
            </div>
          )}
          
          <Button
            onClick={toggleMenu}
            className={`w-14 h-14 rounded-full shadow-[0_4px_12px_rgba(26,32,17,0.3)] transition-all duration-200 hover:scale-110 active:scale-95 ${
              isOpen
                ? "bg-[#DC2626] hover:bg-[#B91C1C]"
                : "bg-[#1A2011] hover:bg-[#484D2C] shake-animation"
            }`}
            size="icon"
            aria-label={isOpen ? "بستن منوی تماس" : "باز کردن منوی تماس"}
            aria-expanded={isOpen}
          >
            {isOpen ? (
              <X className="w-6 h-6 text-white" aria-hidden="true" />
            ) : (
              <img 
                src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/favicon_white64.png"
                alt="نورسا"
                className="w-8 h-8"
                aria-hidden="true"
              />
            )}
          </Button>
        </div>
      </div>
    </>
  );
}