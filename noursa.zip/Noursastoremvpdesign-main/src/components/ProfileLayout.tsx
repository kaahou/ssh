import { ReactNode } from 'react';
import { MessageSquare, ShoppingBag, TrendingUp, Wallet as WalletIcon, Settings, Home, Wrench } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { useUser } from './UserContext';

interface ProfileLayoutProps {
  children: ReactNode;
  activePage?: 'home' | 'consultations' | 'orders' | 'affiliate' | 'wallet' | 'settings';
  onNavigate?: (page: string) => void;
}

export function ProfileLayout({
  children,
  activePage,
}: ProfileLayoutProps) {
  const { user } = useUser();

  const navItems = [
    { id: 'home', label: 'داشبورد', icon: Home, to: '/profile' },
    { id: 'consultations', label: 'مشاوره‌ها', icon: MessageSquare, to: '/profile/consultations' },
    { id: 'orders', label: 'سفارشات', icon: ShoppingBag, to: '/profile/orders' },
    { id: 'wallet', label: 'کیف پول', icon: WalletIcon, to: '/profile/wallet', disabled: true },
    { id: 'affiliate', label: 'همکاری', icon: TrendingUp, to: '/profile/affiliate', disabled: true },
    { id: 'settings', label: 'تنظیمات', icon: Settings, to: '/profile/settings' },
  ];

  return (
    <div className="min-h-screen bg-[#FAFAFA]" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-[280px_1fr] gap-6">
          {/* Desktop Sidebar */}
          <aside className="hidden md:block">
            <div className="sticky top-8 space-y-4">
              {/* User Profile Card */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-[20px] p-6 border border-[#E8E8E8] shadow-sm"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-[#484D2C] to-[#6B7345] rounded-full flex items-center justify-center">
                    <span className="text-white text-[20px] font-bold">
                      {user?.first_name?.charAt(0) || user?.phone?.charAt(0) || 'ک'}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-[16px] text-[#1A2011] truncate">
                      {user?.first_name && user?.last_name 
                        ? `${user.first_name} ${user.last_name}`
                        : user?.first_name || user?.phone || 'کاربر گرامی'
                      }
                    </h3>
                    <p className="text-[13px] text-[#888888]">
                      {user?.phone || 'بدون شماره تماس'}
                    </p>
                  </div>
                </div>
                
                {/* Navigation Links */}
                <nav className="space-y-1">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activePage === item.id;
                    const isDisabled = item.disabled;
                    
                    const linkContent = (
                      <div
                        className={`
                          flex items-center gap-3 px-4 py-3 rounded-[12px] transition-all
                          ${isActive 
                            ? 'bg-gradient-to-r from-[#484D2C] to-[#6B7345] text-white shadow-md' 
                            : isDisabled
                            ? 'text-[#CCCCCC] cursor-not-allowed'
                            : 'text-[#888888] hover:bg-[#F9E1B4]/20 hover:text-[#484D2C]'
                          }
                        `}
                      >
                        <Icon size={20} />
                        <span className="font-medium">{item.label}</span>
                        {isDisabled && (
                          <Wrench size={14} className="mr-auto" />
                        )}
                      </div>
                    );
                    
                    if (isDisabled) {
                      return (
                        <div key={item.id} title="در حال توسعه...">
                          {linkContent}
                        </div>
                      );
                    }
                    
                    return (
                      <Link key={item.id} to={item.to}>
                        {linkContent}
                      </Link>
                    );
                  })}
                </nav>
              </motion.div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="pb-20 md:pb-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {children}
            </motion.div>
          </main>
        </div>

        {/* Mobile Bottom Navigation */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-[#E8E8E8] px-4 py-3 z-40 shadow-lg">
          <div className="flex items-center justify-around max-w-lg mx-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              const isDisabled = item.disabled;
              
              const linkContent = (
                <div className="flex flex-col items-center gap-1 min-w-[60px]">
                  <div className={`
                    relative p-2 rounded-[12px] transition-all
                    ${isActive 
                      ? 'bg-gradient-to-r from-[#484D2C] to-[#6B7345] text-white shadow-md' 
                      : isDisabled
                      ? 'text-[#CCCCCC]'
                      : 'text-[#888888]'
                    }
                  `}>
                    <Icon size={20} />
                    {isDisabled && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#F59E0B] rounded-full flex items-center justify-center">
                        <Wrench size={10} className="text-white" />
                      </div>
                    )}
                  </div>
                  <span className={`
                    text-[10px] font-medium
                    ${isActive ? 'text-[#484D2C]' : isDisabled ? 'text-[#CCCCCC]' : 'text-[#888888]'}
                  `}>
                    {item.label}
                  </span>
                </div>
              );
              
              if (isDisabled) {
                return (
                  <div key={item.id} className="cursor-not-allowed">
                    {linkContent}
                  </div>
                );
              }
              
              return (
                <Link key={item.id} to={item.to}>
                  {linkContent}
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}