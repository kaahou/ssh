import { useState, useEffect, useRef } from 'react';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  priority?: boolean;
  onLoad?: () => void;
  wrapperClassName?: string;
  preload?: boolean;
}

/**
 * Optimized Image Component
 * Features:
 * - Lazy loading with Intersection Observer
 * - Blur placeholder while loading
 * - Automatic error handling with fallback
 * - Priority loading for above-the-fold images
 * - Preload support for critical images
 */
export function OptimizedImage({
  src,
  alt,
  className = '',
  width,
  height,
  priority = false,
  onLoad,
  loading,
  fetchPriority,
  wrapperClassName = '',
  style,
  preload = false,
  ...props
}: OptimizedImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isInView, setIsInView] = useState(priority); // If priority, load immediately
  const [error, setError] = useState(false);
  const imgRef = useRef<HTMLDivElement>(null);

  // Preload critical images
  useEffect(() => {
    if (preload && !error) {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'image';
      link.href = src;
      link.fetchPriority = 'high';
      document.head.appendChild(link);
      
      return () => {
        if (document.head.contains(link)) {
          document.head.removeChild(link);
        }
      };
    }
  }, [src, preload, error]);

  // Intersection Observer for lazy loading
  useEffect(() => {
    if (priority) return; // Skip observer if priority image

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsInView(true);
            observer.disconnect();
          }
        });
      },
      {
        rootMargin: '200px', // Start loading 200px before image enters viewport (increased from 100px)
        threshold: 0.01
      }
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, [priority]);

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setError(true);
    // Only log if src is not empty (empty src is expected for missing images)
    if (src && src.trim() !== '') {
      console.warn(`Failed to load image: ${src}`);
    }
  };

  // Fallback image
  const fallbackSrc = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"%3E%3Crect fill="%23f0f0f0" width="400" height="300"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" fill="%23999" font-family="sans-serif" font-size="18"%3EImage%3C/text%3E%3C/svg%3E';

  return (
    <div 
      ref={imgRef}
      className={`relative ${wrapperClassName}`}
      style={style}
    >
      {/* Blur placeholder - only show if not loaded and image is in view */}
      {!isLoaded && !error && isInView && (
        <div 
          className="absolute inset-0 bg-gray-100"
          style={{
            background: 'linear-gradient(90deg, #f5f5f5 25%, #e8e8e8 50%, #f5f5f5 75%)',
            backgroundSize: '200% 100%',
            animation: 'shimmer 1.5s infinite',
          }}
        />
      )}

      {/* Actual image */}
      {isInView && (
        <img
          src={error ? fallbackSrc : src}
          alt={alt}
          className={`${className} transition-opacity duration-300 ${
            isLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          onLoad={handleLoad}
          onError={handleError}
          loading={loading || (priority ? 'eager' : 'lazy')}
          decoding="async"
          // @ts-ignore - fetchpriority is a valid HTML attribute
          fetchpriority={fetchPriority || (priority ? 'high' : 'auto')}
          width={width}
          height={height}
          {...props}
        />
      )}

      <style>{`
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
      `}</style>
    </div>
  );
}