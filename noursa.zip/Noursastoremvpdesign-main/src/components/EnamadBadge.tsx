interface EnamadBadgeProps {
  className?: string;
}

/**
 * Enamad Badge Component
 * Displays the official Enamad trust badge using the exact code provided by Enamad
 * IMPORTANT: Code must be used exactly as provided - do not add rel="noopener noreferrer"
 */
export function EnamadBadge({ className = "h-48 w-auto" }: EnamadBadgeProps) {
  return (
    <div className={className}>
      <a referrerPolicy='origin' target='_blank' href='https://trustseal.enamad.ir/?id=578418&Code=Sl2rVpsMpscFr9tUxzJXZPBY4TEmBOvG'><img referrerPolicy='origin' src='https://trustseal.enamad.ir/logo.aspx?id=578418&Code=Sl2rVpsMpscFr9tUxzJXZPBY4TEmBOvG' alt='' style={{ cursor: 'pointer' }} code='Sl2rVpsMpscFr9tUxzJXZPBY4TEmBOvG' /></a>
    </div>
  );
}