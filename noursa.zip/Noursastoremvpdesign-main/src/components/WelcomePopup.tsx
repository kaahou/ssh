import { X, MessageCircle, Sparkles, UserPlus, TrendingUp } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { trackEvent } from '../utils/analytics';

export function WelcomePopup() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // ✅ بررسی اینکه آیا قبلاً پاپ‌آپ نمایش داده شده است
    const hasSeenPopup = localStorage.getItem('welcome_popup_shown');
    if (hasSeenPopup) {
      return; // اگر قبلاً دیده شده، دیگر نمایش نده
    }

    // ✅ بررسی اینکه آیا در صفحات مجاز هستیم
    const currentPath = location.pathname;
    const isAllowedPage = 
      currentPath === '/products' ||
      currentPath.startsWith('/product/') || 
      currentPath.startsWith('/category/');
    
    if (!isAllowedPage) {
      return; // فقط در صفحات محصولات نمایش بده
    }

    // Show popup after page is fully loaded
    const showPopup = () => {
      setIsOpen(true);
      // ذخیره وضعیت نمایش در localStorage
      localStorage.setItem('welcome_popup_shown', 'true');
      
      // Track event asynchronously to avoid blocking
      requestAnimationFrame(() => {
        trackEvent('welcome_popup_shown', {
          timestamp: new Date().toISOString(),
          page: currentPath
        });
      });
    };

    const schedulePopup = () => {
      // Use requestIdleCallback with shorter timeout than GTM
      // This ensures popup shows before heavy GTM loads
      if ('requestIdleCallback' in window) {
        (window as any).requestIdleCallback(showPopup, { timeout: 2000 });
      } else {
        setTimeout(showPopup, 2000);
      }
    };

    // Show popup on initial load
    if (document.readyState === 'complete') {
      schedulePopup();
    } else {
      const handleLoad = () => {
        schedulePopup();
      };
      window.addEventListener('load', handleLoad, { once: true });
      
      // Cleanup
      return () => {
        window.removeEventListener('load', handleLoad);
      };
    }
  }, [location.pathname]); // ✅ وابستگی به location.pathname برای بررسی تغییر مسیر

  const handleClose = useCallback(() => {
    setIsOpen(false);
    // Track event asynchronously
    requestAnimationFrame(() => {
      trackEvent('welcome_popup_closed', {
        method: 'close_button'
      });
    });
  }, []);

  const handleConsultationClick = useCallback(() => {
    // Track event asynchronously
    requestAnimationFrame(() => {
      trackEvent('welcome_popup_cta_click', {
        button_type: 'consultation',
        destination: '/consultation'
      });
    });
    setIsOpen(false);
    navigate('/consultation');
  }, [navigate]);

  const handleSignupClick = useCallback(() => {
    // Track event asynchronously
    requestAnimationFrame(() => {
      trackEvent('welcome_popup_cta_click', {
        button_type: 'signup',
        destination: '/login'
      });
    });
    setIsOpen(false);
    navigate('/login');
  }, [navigate]);

  const handleOverlayClick = useCallback((e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  }, [handleClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in"
      onClick={handleOverlayClick}
    >
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto animate-in slide-in-from-bottom-5 duration-300">
        {/* Header with Close Button */}
        <div className="relative p-6 pb-4">
          <button
            onClick={handleClose}
            className="absolute top-6 left-6 w-8 h-8 rounded-full bg-[#F3F4F6] hover:bg-[#E8E8E8] flex items-center justify-center transition-colors"
            aria-label="بستن"
          >
            <X className="w-5 h-5 text-[#888888]" />
          </button>
        </div>

        <div className="px-8 pb-8 space-y-6">
          {/* Title */}
          <div className="text-center space-y-2">
            <h2 className="text-[#1A2011] flex items-center justify-center gap-2">
              <span className="text-3xl">👋</span>
              سلام به دوستان خوبمون
            </h2>
          </div>

          {/* Main Content */}
          <div className="space-y-6">
            {/* Apology Section */}
            <div className="text-center space-y-3">
              <p className="text-[#484D2C] leading-relaxed">
                اگر این روزها یه کم شلوغی، کندی یا ضعف توی جابه‌جایی‌ها می‌بینید،
                صمیمانه بابتش عذر می‌خوایم{' '}
                <span className="text-xl">🙏</span>
              </p>
              <p className="text-[#484D2C] leading-relaxed">
                در حال اسباب‌کشی به خونه جدیدمون هستیم و قول می‌دیم خیلی زود جمع‌وجورش کنیم{' '}
                <span className="text-xl">💪</span>
              </p>
            </div>

            {/* Divider */}
            <div className="border-t border-[#E8E8E8]"></div>

            {/* Your Opinion Matters */}
            <div className="bg-gradient-to-br from-[#F9E1B4]/30 to-[#F9E1B4]/10 rounded-2xl p-6 space-y-4 border border-[#F9E1B4]/50">
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl">🗣️</span>
                <h3 className="text-[#1A2011]">نظرت خیلی مهمه</h3>
              </div>
              
              <p className="text-[#484D2C] leading-relaxed text-center">
                هر جا از گشتن تو سایت تا خرید به مشکلی خوردی یا پیشنهادی داشتی،
                خیلی خوشحال می‌شیم تو پیام‌رسان محبوبت با ما به شماره{' '}
                <a 
                  href="tel:09219675992"
                  className="font-bold text-[#1A2011] hover:text-[#16A34A] transition-colors"
                >
                  ۰۹۲۱۹۶۷۵۹۹۲
                </a>
                {' '}در ارتباط باشی{' '}
                <span className="text-xl">💬</span>
              </p>

              {/* Helper Note */}
              <div className="bg-white/60 rounded-xl p-3 border border-[#F9E1B4]">
                <div className="flex items-start gap-2 text-sm text-[#888888]">
                  <MessageCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-[#16A34A]" />
                  <p className="leading-relaxed">
                    <span className="font-bold text-[#1A2011]">راهنما:</span>
                    {' '}لینک شناور پیام‌رسان همیشه گوشه پایینِ چپ همه صفحه‌ها در دسترسه
                  </p>
                </div>
              </div>
            </div>

            {/* Good News Section */}
            <div className="bg-gradient-to-br from-[#D1FAE5] to-[#D1FAE5]/30 rounded-2xl p-6 space-y-4 border border-[#16A34A]/30">
              <div className="flex items-center justify-center gap-2">
                <Sparkles className="w-6 h-6 text-[#16A34A]" />
                <h3 className="text-[#1A2011]">اما خبر خوب!</h3>
              </div>
              
              <p className="text-[#065F46] leading-relaxed text-center">
                مشاوره هوشمند و صفحه پروفایل شخصی فعال شده{' '}
                <span className="text-xl">🎉</span>
              </p>
              
              <p className="text-[#484D2C] text-sm leading-relaxed text-center">
                حتی همین الان هم می‌تونی تغییراتش رو ببینی
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="space-y-3 pt-2">
              <button
                onClick={handleConsultationClick}
                className="w-full bg-gradient-to-l from-[#16A34A] to-[#065F46] hover:from-[#065F46] hover:to-[#16A34A] text-white py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-3 group"
              >
                <TrendingUp className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span>مشاوره هوشمند</span>
              </button>

              <button
                onClick={handleSignupClick}
                className="w-full bg-white border-2 border-[#1A2011] text-[#1A2011] hover:bg-[#1A2011] hover:text-white py-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-3 group"
              >
                <UserPlus className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span>ثبت‌نام</span>
              </button>
            </div>

            {/* Footer Note */}
            <p className="text-center text-xs text-[#888888] pt-2">
              این پیام فقط یکبار نمایش داده می‌شود
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}