import { useState, useEffect } from 'react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogDescription,
  DialogFooter
} from './ui/dialog';
import { Button } from './ui/button';
import { X, Info, AlertCircle, Percent, Megaphone } from 'lucide-react';

interface Popup {
  id: string;
  title: string;
  content: string;
  type: 'info' | 'warning' | 'promotion' | 'announcement';
  image_url?: string;
  link_url?: string;
  link_text?: string;
  is_active: boolean;
  start_date?: string;
  end_date?: string;
  show_once_per_session: boolean;
  delay_seconds: number;
  position: 'center' | 'bottom-right' | 'top';
  created_at: string;
  updated_at: string;
}

const typeIcons = {
  info: Info,
  warning: AlertCircle,
  promotion: Percent,
  announcement: Megaphone,
};

const typeColors = {
  info: 'text-blue-600',
  warning: 'text-yellow-600',
  promotion: 'text-green-600',
  announcement: 'text-purple-600',
};

export function PopupManager() {
  const [popups, setPopups] = useState<Popup[]>([]);
  const [currentPopup, setCurrentPopup] = useState<Popup | null>(null);
  const [shownPopupIds, setShownPopupIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load shown popup IDs from sessionStorage
    const shown = sessionStorage.getItem('shown_popups');
    if (shown) {
      try {
        setShownPopupIds(new Set(JSON.parse(shown)));
      } catch (e) {
        console.error('Error parsing shown popups:', e);
      }
    }
    
    fetchPopups();
  }, []);

  useEffect(() => {
    if (popups.length > 0 && !currentPopup) {
      showNextPopup();
    }
  }, [popups]);

  const fetchPopups = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/popups`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        console.error('Failed to fetch popups');
        return;
      }

      const data = await response.json();
      if (data.success && data.popups) {
        setPopups(data.popups);
      }
    } catch (error) {
      console.error('Error fetching popups:', error);
    } finally {
      setLoading(false);
    }
  };

  const showNextPopup = () => {
    // Find the first popup that hasn't been shown yet (if show_once_per_session is true)
    const nextPopup = popups.find(popup => {
      if (popup.show_once_per_session && shownPopupIds.has(popup.id)) {
        return false;
      }
      return true;
    });

    if (nextPopup) {
      const delay = nextPopup.delay_seconds * 1000;
      setTimeout(() => {
        setCurrentPopup(nextPopup);
      }, delay);
    }
  };

  const handleClose = () => {
    if (currentPopup) {
      // Mark this popup as shown
      const newShownIds = new Set(shownPopupIds);
      newShownIds.add(currentPopup.id);
      setShownPopupIds(newShownIds);
      
      // Save to sessionStorage
      sessionStorage.setItem('shown_popups', JSON.stringify(Array.from(newShownIds)));
      
      setCurrentPopup(null);
      
      // Try to show next popup after a delay
      setTimeout(() => {
        showNextPopup();
      }, 1000);
    }
  };

  if (loading || !currentPopup) {
    return null;
  }

  const TypeIcon = typeIcons[currentPopup.type];

  // Center popup
  if (currentPopup.position === 'center') {
    return (
      <Dialog open={true} onOpenChange={handleClose}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <div className="flex items-start gap-3">
              <div className={`
                w-10 h-10 rounded-full flex items-center justify-center
                ${currentPopup.type === 'info' ? 'bg-blue-100' : ''}
                ${currentPopup.type === 'warning' ? 'bg-yellow-100' : ''}
                ${currentPopup.type === 'promotion' ? 'bg-green-100' : ''}
                ${currentPopup.type === 'announcement' ? 'bg-purple-100' : ''}
              `}>
                <TypeIcon size={20} className={typeColors[currentPopup.type]} />
              </div>
              <div className="flex-1">
                <DialogTitle className="text-right">{currentPopup.title}</DialogTitle>
                {currentPopup.image_url && (
                  <img 
                    src={currentPopup.image_url} 
                    alt={currentPopup.title}
                    className="w-full rounded-lg mt-3 mb-2"
                  />
                )}
                <DialogDescription 
                  className="text-right mt-2"
                  dangerouslySetInnerHTML={{ __html: currentPopup.content }}
                />
              </div>
            </div>
          </DialogHeader>
          
          {currentPopup.link_url && (
            <DialogFooter className="gap-2">
              <Button
                variant="outline"
                onClick={handleClose}
              >
                بستن
              </Button>
              <a
                href={currentPopup.link_url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={handleClose}
              >
                <Button className="bg-[#1A2011] hover:bg-[#484D2C] text-white">
                  {currentPopup.link_text || 'اطلاعات بیشتر'}
                </Button>
              </a>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    );
  }

  // Bottom-right popup
  if (currentPopup.position === 'bottom-right') {
    return (
      <div 
        className="fixed bottom-4 left-4 z-50 bg-white rounded-[16px] shadow-2xl border border-[#E8E8E8] max-w-sm animate-in slide-in-from-bottom-5"
        dir="rtl"
      >
        <div className="p-4">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-start gap-3 flex-1">
              <div className={`
                w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0
                ${currentPopup.type === 'info' ? 'bg-blue-100' : ''}
                ${currentPopup.type === 'warning' ? 'bg-yellow-100' : ''}
                ${currentPopup.type === 'promotion' ? 'bg-green-100' : ''}
                ${currentPopup.type === 'announcement' ? 'bg-purple-100' : ''}
              `}>
                <TypeIcon size={20} className={typeColors[currentPopup.type]} />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-[16px] text-[#1A2011]">
                  {currentPopup.title}
                </h3>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="text-[#888888] hover:text-[#1A2011] transition-colors flex-shrink-0"
            >
              <X size={20} />
            </button>
          </div>

          {currentPopup.image_url && (
            <img 
              src={currentPopup.image_url} 
              alt={currentPopup.title}
              className="w-full rounded-lg mb-3"
            />
          )}

          <div 
            className="text-[14px] text-[#666666] mb-3"
            dangerouslySetInnerHTML={{ __html: currentPopup.content }}
          />

          {currentPopup.link_url && (
            <a
              href={currentPopup.link_url}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleClose}
            >
              <Button 
                className="w-full bg-[#1A2011] hover:bg-[#484D2C] text-white"
                size="sm"
              >
                {currentPopup.link_text || 'اطلاعات بیشتر'}
              </Button>
            </a>
          )}
        </div>
      </div>
    );
  }

  // Top banner popup
  if (currentPopup.position === 'top') {
    return (
      <div 
        className="fixed top-0 left-0 right-0 z-50 bg-white shadow-lg border-b border-[#E8E8E8] animate-in slide-in-from-top-5"
        dir="rtl"
      >
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1">
              <div className={`
                w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0
                ${currentPopup.type === 'info' ? 'bg-blue-100' : ''}
                ${currentPopup.type === 'warning' ? 'bg-yellow-100' : ''}
                ${currentPopup.type === 'promotion' ? 'bg-green-100' : ''}
                ${currentPopup.type === 'announcement' ? 'bg-purple-100' : ''}
              `}>
                <TypeIcon size={16} className={typeColors[currentPopup.type]} />
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[14px] text-[#1A2011]">
                    {currentPopup.title}:
                  </span>
                  <span 
                    className="text-[14px] text-[#666666]"
                    dangerouslySetInnerHTML={{ __html: currentPopup.content }}
                  />
                </div>
              </div>

              {currentPopup.link_url && (
                <a
                  href={currentPopup.link_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={handleClose}
                  className="flex-shrink-0"
                >
                  <Button 
                    className="bg-[#1A2011] hover:bg-[#484D2C] text-white"
                    size="sm"
                  >
                    {currentPopup.link_text || 'اطلاعات بیشتر'}
                  </Button>
                </a>
              )}
            </div>

            <button
              onClick={handleClose}
              className="text-[#888888] hover:text-[#1A2011] transition-colors flex-shrink-0"
            >
              <X size={20} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
