import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  FileText, 
  Upload, 
  User, 
  Smartphone, 
  Check, 
  Info, 
  ChevronRight, 
  ChevronLeft, 
  Send,
  AlertCircle,
  Image as ImageIcon,
  X
} from 'lucide-react';
import { LabelWithTooltip } from "./ui/label-with-tooltip";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../utils/supabase/info";
import { createClient } from "@supabase/supabase-js";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { SimpleSelect } from "./ui/simple-select";
import { MultiSelect } from "./ui/multi-select";
import { Checkbox } from "./ui/checkbox";
import { logger } from "../src/utils/logger";

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

interface FormData {
  // مرحله 1
  scalp_type: string;
  scalp_temperament: string;
  hair_state: string;
  hair_shaft: string;
  hair_length: string;
  main_problems: string[];

  // مرحله 2
  stress_level: string;
  wash_frequency: string;
  has_digestive_issues: boolean;
  uses_heat: boolean;
  has_salon_history: boolean;
  salon_history_details: string;
  current_products: string;
  medical_history: string;
  main_goals: string[];
  environmental_conditions: string[];

  // مرحله 3
  uploaded_files: File[];
  additional_notes: string;

  // مرحله 4
  first_name: string;
  last_name: string;
  age: string;
  gender: string;

  // مرحله 5
  phone: string;
  otp_code: string;
}

const STEP_TITLES = [
  "خوش آمدید",
  "مشخصات مو و پوست سر",
  "سبک زندگی و سوابق",
  "تصاویر و توضیحات",
  "اطلاعات شخصی",
  "احراز هویت و ارسال",
];

export function ConsultationWizard() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [otpSent, setOtpSent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState<FormData>({
    scalp_type: "",
    scalp_temperament: "",
    hair_state: "",
    hair_shaft: "",
    hair_length: "",
    main_problems: [],
    stress_level: "",
    wash_frequency: "",
    has_digestive_issues: false,
    uses_heat: false,
    has_salon_history: false,
    salon_history_details: "",
    current_products: "",
    medical_history: "",
    main_goals: [],
    environmental_conditions: [],
    uploaded_files: [],
    additional_notes: "",
    first_name: "",
    last_name: "",
    age: "",
    gender: "",
    phone: "",
    otp_code: "",
  });

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const validateStep = (): boolean => {
    if (step === 0) return true;

    // Step 1 (مشخصات مو) اختیاری شد - بدون validation

    // Step 2 و 3 اختیاری هستند - بدون validation

    if (step === 4) {
      if (!formData.age || !formData.gender) {
        toast.error("لطفا سن و جنسیت را وارد کنید");
        return false;
      }
    }

    if (step === 5) {
      if (!otpSent && !formData.phone) {
        toast.error("لطفا شماره موبایل را وارد کنید");
        return false;
      }
      if (otpSent && formData.otp_code.length !== 6) {
        toast.error("لطفا کد تایید ۶ رقمی را وارد کنید");
        return false;
      }
    }

    return true;
  };

  const handleNext = () => {
    if (!validateStep()) return;

    if (step < 5) {
      setStep(step + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handlePrevious = () => {
    if (step > 0) {
      setStep(step - 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleSendOTP = async () => {
    if (!formData.phone || formData.phone.length < 11) {
      toast.error("لطفا شماره موبایل معتبر وارد کنید");
      return;
    }

    setIsSubmitting(true);
    
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/send-otp`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ phone: formData.phone }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "ارسال کد تایید با خطا مواجه شد");
      }

      setOtpSent(true);
      
      // Show OTP code in console for development/testing
      if (result.debug?.otpCode) {
        logger.sensitive("=".repeat(50));
        logger.sensitive("🔐 کد تایید برای تست:", result.debug.otpCode);
        logger.sensitive("📱 شماره موبایل:", formData.phone);
        logger.sensitive("=".repeat(50));
        
        if (!result.debug.smsSuccess) {
          toast.success(`کد تایید: ${result.debug.otpCode} (برای تست - در console هم موجود است)`);
        } else {
          toast.success("کد تایید ارسال شد");
        }
      } else {
        toast.success("کد تایید ارسال شد");
      }
    } catch (error: any) {
      logger.error("Error sending OTP:", error);
      toast.error(error.message || "ارسال کد تایید با خطا مواجه شد");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFinalSubmit = async () => {
    if (!validateStep()) return;

    setIsSubmitting(true);

    try {
      // Step 1: Upload images to Supabase Storage if any
      let photoUrls: string[] = [];
      
      if (formData.uploaded_files.length > 0) {
        logger.log(`📤 Uploading ${formData.uploaded_files.length} files to storage...`);
        
        for (const file of formData.uploaded_files) {
          try {
            const fileExt = file.name.split('.').pop();
            const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
            const filePath = `consultation-photos/${fileName}`;

            // Upload to Supabase Storage
            const { data: uploadData, error: uploadError } = await supabase.storage
              .from('make-fbc72c25-consultation-photos')
              .upload(filePath, file, {
                cacheControl: '3600',
                upsert: false,
              });

            if (uploadError) {
              logger.error('❌ Error uploading file:', uploadError);
              throw uploadError;
            }

            logger.log('✅ File uploaded successfully:', filePath);

            // Get signed URL (valid for 10 years)
            const { data: urlData, error: urlError } = await supabase.storage
              .from('make-fbc72c25-consultation-photos')
              .createSignedUrl(filePath, 315360000); // 10 years in seconds

            if (urlError) {
              logger.error('❌ Error creating signed URL:', urlError);
              throw urlError;
            }

            if (urlData?.signedUrl) {
              photoUrls.push(urlData.signedUrl);
              logger.log('✅ Signed URL created');
            }
          } catch (fileError) {
            logger.error('❌ Error processing file:', file.name, fileError);
            toast.error(`خطا در آپلود فایل ${file.name}`);
          }
        }
        
        logger.log(`✅ Successfully uploaded ${photoUrls.length} files`);
      }

      // Step 2: Verify OTP and save consultation
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/verify-otp`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            phone: formData.phone,
            otpCode: formData.otp_code,
            formData: {
              scalp_type: formData.scalp_type,
              scalp_temperament: formData.scalp_temperament,
              hair_state: formData.hair_state,
              hair_shaft: formData.hair_shaft,
              hair_length: formData.hair_length,
              main_problems: formData.main_problems,
              stress_level: formData.stress_level,
              wash_frequency: formData.wash_frequency,
              has_digestive_issues: formData.has_digestive_issues,
              uses_heat: formData.uses_heat,
              has_salon_history: formData.has_salon_history,
              salon_history_details: formData.salon_history_details,
              current_products: formData.current_products,
              medical_history: formData.medical_history,
              main_goals: formData.main_goals,
              environmental_conditions: formData.environmental_conditions,
              additional_notes: formData.additional_notes,
              first_name: formData.first_name,
              last_name: formData.last_name,
              age: formData.age,
              gender: formData.gender,
              photo_urls: photoUrls, // ⭐ Add photo URLs
            },
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        logger.error("❌ Submission failed. Full response:", result);
        if (result.debugInfo) {
          logger.error("🔍 Debug Info:");
          logger.error("  Code:", result.debugInfo.code);
          logger.error("  Message:", result.debugInfo.message);
          logger.error("  Details:", result.debugInfo.details);
          logger.error("  Hint:", result.debugInfo.hint);
        }
        throw new Error(result.error || "ثبت مشاوره با خطا مواجه شد");
      }

      // Navigate to success page with consultation ID
      navigate(`/consultation/success/${result.consultationId}`);
    } catch (error: any) {
      logger.error("Error submitting consultation:", error);
      toast.error(error.message || "ثبت مشاوره با خطا مواجه شد");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const currentFiles = formData.uploaded_files;

    if (currentFiles.length + files.length > 3) {
      toast.error("حداکثر ۳ فایل مجاز است");
      return;
    }

    updateFormData("uploaded_files", [...currentFiles, ...files]);
  };

  const removeFile = (index: number) => {
    const newFiles = formData.uploaded_files.filter((_, i) => i !== index);
    updateFormData("uploaded_files", newFiles);
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] pb-8">
      {/* Progress Bar */}
      <div className="sticky top-[80px] bg-[#FAFAFA]/80 backdrop-blur-md border-b border-[#E8E8E8] z-40">
        <div className="max-w-3xl mx-auto px-6 py-4">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-[#1A2011]">
              مرحله {step + 1} از ۶
            </span>
            <span className="text-xs text-[#888888]">{STEP_TITLES[step]}</span>
          </div>
          <div className="h-2 bg-[#E8E8E8] rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-[#484D2C]"
              animate={{ width: `${((step + 1) / 6) * 100}%` }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-3xl mx-auto px-6 py-8">
        <div className="bg-white rounded-[24px] border border-[#E8E8E8] p-8 shadow-sm">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {step === 0 && <Step0 />}
              {step === 1 && <Step1 formData={formData} updateFormData={updateFormData} />}
              {step === 2 && <Step2 formData={formData} updateFormData={updateFormData} />}
              {step === 3 && (
                <Step3
                  formData={formData}
                  updateFormData={updateFormData}
                  handleFileUpload={handleFileUpload}
                  removeFile={removeFile}
                />
              )}
              {step === 4 && <Step4 formData={formData} updateFormData={updateFormData} />}
              {step === 5 && (
                <Step5
                  formData={formData}
                  updateFormData={updateFormData}
                  otpSent={otpSent}
                  isSubmitting={isSubmitting}
                  handleSendOTP={handleSendOTP}
                  setOtpSent={setOtpSent}
                />
              )}
            </motion.div>
          </AnimatePresence>

          {/* Navigation Buttons */}
          <div className="mt-12 pt-6 border-t border-[#E8E8E8] flex justify-between">
            {step > 0 && (
              <Button
                onClick={handlePrevious}
                variant="ghost"
                className="h-[48px] px-6 rounded-[12px] text-[#444444] hover:bg-[#FAFAFA]"
              >
                <ChevronRight className="w-5 h-5 ml-2" />
                مرحله قبل
              </Button>
            )}

            {step < 5 && (
              <Button
                onClick={handleNext}
                className={`h-[48px] px-8 bg-[#1A2011] hover:bg-[#484D2C] text-white rounded-[12px] shadow-lg ${
                  step === 0 ? "mr-auto" : ""
                }`}
              >
                {step === 0 ? "شروع مشاوره" : "مرحله بعد"}
                <ChevronLeft className="w-5 h-5 mr-2" />
              </Button>
            )}

            {step === 5 && otpSent && (
              <Button
                onClick={handleFinalSubmit}
                disabled={isSubmitting}
                className="h-[56px] px-8 bg-[#1A2011] hover:bg-[#484D2C] text-white rounded-[16px] text-lg shadow-xl mr-auto"
              >
                {isSubmitting ? "در حال ارسال..." : "تایید و ثبت نهایی"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Step 0: Welcome
function Step0() {
  return (
    <div className="text-center">
      <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-[#484D2C] to-[#2A2F15] flex items-center justify-center">
        <Activity className="w-12 h-12 text-white" />
      </div>

      <h1 className="text-3xl md:text-4xl mb-4 text-[#1A2011]">
        مشاوره هوشمند نورسا
      </h1>

      <p className="text-[#666666] mb-8 leading-relaxed max-w-2xl mx-auto">
        با استفاده از هوش مصنوعی و تجربه متخصصین، محصولات مراقبتی اختصاصی برای موی
        شما طراحی می‌شود.
      </p>

      <div className="bg-[#FAFAFA] rounded-[24px] p-6 mb-6 text-right">
        <h3 className="text-lg mb-4 text-[#1A2011]">مراحل مشاوره:</h3>

        <div className="space-y-4">
          {[
            {
              num: "۱",
              title: "مشخصات مو",
              desc: "اطلاعات دقیق درباره نوع مو و پوست سر شما",
            },
            {
              num: "۲",
              title: "سبک زندگی",
              desc: "عادات روزانه و سوابق پزشکی",
            },
            {
              num: "۳",
              title: "تصاویر",
              desc: "بارگذاری تصویر برای تشخیص دقیق‌تر",
            },
            {
              num: "۴",
              title: "اطلاعات شخصی",
              desc: "نام و سن برای شخصی‌سازی بهتر",
            },
            {
              num: "۵",
              title: "تایید نهایی",
              desc: "دریافت نتیجه از طریق پیامک",
            },
          ].map((item) => (
            <div key={item.num} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-[#484D2C] text-white flex items-center justify-center flex-shrink-0 text-sm">
                {item.num}
              </div>
              <div>
                <p className="text-[#1A2011] mb-1">{item.title}</p>
                <p className="text-sm text-[#666666]">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-4 justify-center">
        <div className="flex items-center gap-2 text-sm text-[#16A34A]">
          <Check className="w-5 h-5 flex-shrink-0" />
          <span>مدت زمان تقریبی: ۳-۵ دقیقه</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-[#16A34A]">
          <Check className="w-5 h-5 flex-shrink-0" />
          <span>تمامی اطلاعات کاملاً محرمانه است</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-[#16A34A]">
          <Check className="w-5 h-5 flex-shrink-0" />
          <span>شما می‌توانید با کلیک روی علامت <Info className="inline w-4 h-4 mx-1" /> از متن راهنما در کنار سوالات استفاده کنید.</span>
        </div>
      </div>
    </div>
  );
}

// Step 1: Hair & Scalp Info
function Step1({
  formData,
  updateFormData,
}: {
  formData: FormData;
  updateFormData: (field: keyof FormData, value: any) => void;
}) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
          <Activity className="w-6 h-6" />
        </div>
        <h2 className="text-2xl text-[#1A2011]">مشخصات مو و پوست سر</h2>
      </div>

      <div className="space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <LabelWithTooltip
              htmlFor="scalp_type"
              tooltip="نوع پوست سر بر اساس زمان چرب شدن مشخص می‌شود: چرب: ۱–۳ روز معمولی: ۳–۵ روز خشک: ۵+ روز"
            >
              جنس پوست سر
            </LabelWithTooltip>
            <SimpleSelect
              value={formData.scalp_type}
              onChange={(val) => updateFormData("scalp_type", val)}
              options={["خشک", "چرب", "مختلط", "نرمال"]}
            />
          </div>

          <div>
            <LabelWithTooltip
              htmlFor="scalp_temperament"
              tooltip="روش تشخیص طبع سر: کف دست را روی ملاج بگذارید. سرد: بدون گرما معتدل: گرمای خفیف گرم: گرمای سریع"
            >
              طبع سر
            </LabelWithTooltip>
            <SimpleSelect
              value={formData.scalp_temperament}
              onChange={(val) => updateFormData("scalp_temperament", val)}
              options={["سرد", "گرم", "معتدل"]}
            />
          </div>
        </div>

        <div>
          <LabelWithTooltip
            tooltip="تست تخلخل مو: یک تار موی خشک را ۲ دقیقه در آب قرار دهید: شناور: تخلخل کم معلق: تخلخل متوسط غرق‌شده: تخلخل زیاد"
          >
            ویژگی‌های ظاهری مو
          </LabelWithTooltip>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <LabelWithTooltip htmlFor="hair_state">
              حالت مو
            </LabelWithTooltip>
            <SimpleSelect
              value={formData.hair_state}
              onChange={(val) => updateFormData("hair_state", val)}
              options={["صاف", "مجعد / فردار"]}
            />
          </div>

          <div>
            <LabelWithTooltip htmlFor="hair_shaft">
              جنس ساقه
            </LabelWithTooltip>
            <SimpleSelect
              value={formData.hair_shaft}
              onChange={(val) => updateFormData("hair_shaft", val)}
              options={["چرب", "خشک", "معمولی", "مختلط"]}
            />
          </div>

          <div>
            <LabelWithTooltip htmlFor="hair_length">طول مو</LabelWithTooltip>
            <SimpleSelect
              value={formData.hair_length}
              onChange={(val) => updateFormData("hair_length", val)}
              options={["کوتاه", "متوسط", "بلند"]}
            />
          </div>
        </div>

        <div>
          <LabelWithTooltip
            tooltip="چه مشکل مو باید درمان بشه؟ لطفاً مشکلات اصلی موی خود را که نیاز به درمان دارند انتخاب کنید. می‌توانید چندین گزینه را انتخاب نمایید. این اطلاعات پایه اصلی طراحی برنامه درمانی شخصی‌سازی شده برای شماست."
          >
            مشکلات اصلی
          </LabelWithTooltip>
          <MultiSelect
            value={formData.main_problems}
            onChange={(val) => updateFormData("main_problems", val)}
            options={[
              "موخوره",
              "شوره سر",
              "پوسته‌ریزی",
              "ریزش مو",
              "نازکی مو",
              "موی آسیب دیده",
              "موی خشک",
              "موی چرب",
              "موی کم‌پشت",
              "موی وز",
              "خارش پوست سر",
              "سفیدی مو",
              "بوی بد کف سر",
              "پسوریازیس",
              "اگزما",
              "زخم یا جوش",
              "ریشه موی سست",
            ]}
          />
        </div>
      </div>
    </div>
  );
}

// Step 2: Lifestyle
function Step2({
  formData,
  updateFormData,
}: {
  formData: FormData;
  updateFormData: (field: keyof FormData, value: any) => void;
}) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
          <FileText className="w-6 h-6" />
        </div>
        <h2 className="text-2xl text-[#1A2011]">سبک زندگی و سوابق</h2>
      </div>

      <div className="space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <LabelWithTooltip
              htmlFor="stress_level"
              tooltip="استرس مزمن یکی از عوامل مهم ریزش مو است. ⚠️ کاهش استرس می‌تواند اثربخشی درمان را تا ۴۰٪ افزایش دهد."
            >
              میزان استرس روزانه
            </LabelWithTooltip>
            <SimpleSelect
              value={formData.stress_level}
              onChange={(val) => updateFormData("stress_level", val)}
              options={["کم", "متوسط", "زیاد"]}
            />
          </div>

          <div>
            <LabelWithTooltip htmlFor="wash_frequency">
              تعداد دفعات شستشو در هفته
            </LabelWithTooltip>
            <Input
              type="number"
              value={formData.wash_frequency}
              onChange={(e) => updateFormData("wash_frequency", e.target.value)}
              placeholder="مثال: ۳"
              className="h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white"
            />
          </div>
        </div>

        <div className="space-y-3">
          <Checkbox
            label="مشکلات گوارشی (یبوست، نفخ و...)"
            checked={formData.has_digestive_issues}
            onChange={(val) => updateFormData("has_digestive_issues", val)}
          />

          <Checkbox
            label="استفاده مداوم از سشوار یا اتوی مو؟"
            checked={formData.uses_heat}
            onChange={(val) => updateFormData("uses_heat", val)}
          />

          <Checkbox
            label="سابقه اعمال آرایشگاهی در ۶ ماه گذشته؟ (رنگ، دکلره، کراتین)"
            checked={formData.has_salon_history}
            onChange={(val) => updateFormData("has_salon_history", val)}
          />

          <AnimatePresence>
            {formData.has_salon_history && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden pr-8"
              >
                <Textarea
                  value={formData.salon_history_details}
                  onChange={(e) =>
                    updateFormData("salon_history_details", e.target.value)
                  }
                  placeholder="توضیحات سوابق آرایشگاهی..."
                  className="min-h-[80px] p-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white resize-none"
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div>
          <LabelWithTooltip
            htmlFor="current_products"
            tooltip="برای مشاوره دقیق‌تر، محصولات فعلی خود را لیست کنید: شامپو، نرم‌کننده، ماسک، سرم، روغن، اسکراب یا مکمل‌ها."
          >
            محصولات مراقبتی مورد استفاده
          </LabelWithTooltip>
          <Textarea
            value={formData.current_products}
            onChange={(e) => updateFormData("current_products", e.target.value)}
            placeholder="نام شامپو، ماسک مو یا سرم‌هایی که استفاده می‌کنید..."
            className="min-h-[80px] p-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white resize-none"
          />
        </div>

        <div>
          <LabelWithTooltip
            htmlFor="medical_history"
            tooltip="داروها یا بیماری‌هایی که بر رشد یا ریزش مو تأثیر می‌گذارند را وارد کنید. داروهای هورمونی، اعصاب و کورتون‌ها بسیار مهم هستند."
          >
            سابقه دارو یا بیماری
          </LabelWithTooltip>
          <Textarea
            value={formData.medical_history}
            onChange={(e) => updateFormData("medical_history", e.target.value)}
            placeholder="توضیحات بیماری یا دارو..."
            className="min-h-[80px] p-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white resize-none"
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <LabelWithTooltip
              tooltip="اهداف مراقبت از مو لطفاً اهداف اصلی خود را انتخاب کنید. توصیه می‌شود حداکثر ۳ هدف مشخص شود تا برنامه درمانی دقیق‌تر طراحی شود."
            >
              هدف اصلی شما
            </LabelWithTooltip>
            <MultiSelect
              value={formData.main_goals}
              onChange={(val) => updateFormData("main_goals", val)}
              options={[
                "تقویت مو",
                "درمان ریزش مو",
                "افزایش حجم",
                "کنترل چربی",
                "رفع خشکی",
                "ترمیم موی آسیب دیده",
                "رفع شوره",
                "براقیت و درخشندگی",
                "رویش مجدد مو",
                "رفع سفیدی مو",
              ]}
            />
          </div>

          <div>
            <LabelWithTooltip
              tooltip="شرایط محیطی زندگی شما لطفاً شرایطی که بیشترین تأثیر را بر سلامت موی شما دارد انتخاب کنید. می‌توانید چند گزینه را انتخاب نمایید."
            >
              شرایط محیطی زندگی
            </LabelWithTooltip>
            <MultiSelect
              value={formData.environmental_conditions}
              onChange={(val) => updateFormData("environmental_conditions", val)}
              options={[
                "خشکی",
                "رطوبت",
                "آلودگی هوا",
                "قرارگیری در معرض آفتاب",
                "تعریق زیاد روزانه",
                "قرارگیری در معرض مواد شیمیایی",
              ]}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// Step 3: Images
function Step3({
  formData,
  updateFormData,
  handleFileUpload,
  removeFile,
}: {
  formData: FormData;
  updateFormData: (field: keyof FormData, value: any) => void;
  handleFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  removeFile: (index: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
          <Upload className="w-6 h-6" />
        </div>
        <h2 className="text-2xl text-[#1A2011]">تصاویر و توضیحات</h2>
      </div>

      <div className="space-y-6">
        <div>
          <LabelWithTooltip
            tooltip="برای تشخیص دقیق‌تر لطفاً از ناحیه دچار ریزش یا مشکل، با نور کافی عکس یا فیلم تهیه کنید. تمامی تصاویر محرمانه نگهداری می‌شوند."
          >
            بارگذاری تصاویر
          </LabelWithTooltip>

          <label className="block cursor-pointer">
            <div className="bg-[#FAFAFA] border-2 border-dashed border-[#E8E8E8] rounded-[20px] p-8 text-center hover:border-[#1A2011] transition-colors">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white flex items-center justify-center">
                <ImageIcon className="w-8 h-8 text-[#888888]" />
              </div>
              <p className="text-[#1A2011] mb-2">برای بارگذاری کلیک کنید</p>
              <p className="text-sm text-[#666666]">
                حداکثر ۳ تصویر یا ویدئو (فرمت JPG, PNG, MP4)
              </p>
            </div>
            <input
              type="file"
              multiple
              accept="image/*,video/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>

        {formData.uploaded_files.length > 0 && (
          <div className="grid grid-cols-3 gap-4">
            {formData.uploaded_files.map((file, index) => (
              <div
                key={index}
                className="relative aspect-square rounded-[16px] overflow-hidden bg-[#F4F4F5] border border-[#E8E8E8]"
              >
                {file.type.startsWith("image/") ? (
                  <img
                    src={URL.createObjectURL(file)}
                    alt={`آپلود ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <FileText className="w-12 h-12 text-[#888888]" />
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => removeFile(index)}
                  className="absolute top-2 left-2 w-6 h-6 rounded-full bg-destructive text-white flex items-center justify-center hover:bg-destructive/90"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div>
          <LabelWithTooltip
            htmlFor="additional_notes"
            tooltip="در این قسمت می‌توانید هرگونه اطلاعات تکمیلی درباره وضعیت موی خود را شرح دهید. اطلاعات بیشتر مثل سابقه خانوادگی ریزش مو یا تغییرات اخیر سبک زندگی کمک زیادی به تشخیص می‌کند."
          >
            توضیحات تکمیلی (اختیاری)
          </LabelWithTooltip>
          <Textarea
            value={formData.additional_notes}
            onChange={(e) => updateFormData("additional_notes", e.target.value)}
            placeholder="هر نکته‌ای که فکر می‌کنید برای تشخیص بهتر کمک می‌کند..."
            className="min-h-[120px] p-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white resize-none"
          />
        </div>

        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-[16px] p-4 flex gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-yellow-800">
            تصاویر شما کاملاً محرمانه باقی می‌ماند و تنها توسط هوش‌مصنوعی و کارشناس متخصص جهت آنالیز
            رویت می‌شود.
          </p>
        </div>
      </div>
    </div>
  );
}

// Step 4: Personal Info
function Step4({
  formData,
  updateFormData,
}: {
  formData: FormData;
  updateFormData: (field: keyof FormData, value: any) => void;
}) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
          <User className="w-6 h-6" />
        </div>
        <h2 className="text-2xl text-[#1A2011]">اطلاعات شخصی</h2>
      </div>

      <div className="space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <LabelWithTooltip
              htmlFor="first_name"
              tooltip="درج نام و نام‌خانوادگی صرفاً برای ثبت قانونی و فرآیند بازگشت وجه ضروری است. در صورت تمایل می‌توانید این فیلدها را خالی بگذارید. ✨ لطفاً دقت فرمایید مشخصات وارد شده با اطلاعات مندرج در فاکتور خرید یکسان باشد."
            >
              نام
            </LabelWithTooltip>
            <Input
              value={formData.first_name}
              onChange={(e) => updateFormData("first_name", e.target.value)}
              placeholder="مثال: علی"
              className="h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white"
            />
          </div>

          <div>
            <LabelWithTooltip htmlFor="last_name">نام خانوادگی</LabelWithTooltip>
            <Input
              value={formData.last_name}
              onChange={(e) => updateFormData("last_name", e.target.value)}
              placeholder="مثال: محمدی"
              className="h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white"
            />
          </div>

          <div>
            <LabelWithTooltip htmlFor="age" required>
              سن
            </LabelWithTooltip>
            <Input
              type="number"
              value={formData.age}
              onChange={(e) => updateFormData("age", e.target.value)}
              placeholder="مثال: ۲۸"
              className="h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:bg-white"
            />
          </div>

          <div>
            <LabelWithTooltip
              htmlFor="gender"
              required
              tooltip="روش‌های درمانی پیشنهاد شده در زنان و مردان متفاوت است. لطفاً جنسیت را دقیق وارد کنید."
            >
              جنسیت
            </LabelWithTooltip>
            <SimpleSelect
              value={formData.gender}
              onChange={(val) => updateFormData("gender", val)}
              options={["زن", "مرد"]}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// Step 5: OTP
function Step5({
  formData,
  updateFormData,
  otpSent,
  isSubmitting,
  handleSendOTP,
  setOtpSent,
}: {
  formData: FormData;
  updateFormData: (field: keyof FormData, value: any) => void;
  otpSent: boolean;
  isSubmitting: boolean;
  handleSendOTP: () => void;
  setOtpSent: (val: boolean) => void;
}) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
          <Smartphone className="w-6 h-6" />
        </div>
        <h2 className="text-2xl text-[#1A2011]">احراز هویت و ارسال</h2>
      </div>

      <p className="text-[#666666] mb-8 leading-relaxed">
        برای دریافت نتیجه مشاوره، شماره موبایل خود را وارد کنید. نتیجه به صورت
        پیامک برای شما ارسال خواهد شد.
      </p>

      <div className="max-w-md mx-auto space-y-6">
        <div>
          <LabelWithTooltip htmlFor="phone" required>
            شماره موبایل
          </LabelWithTooltip>
          <Input
            type="tel"
            dir="ltr"
            value={formData.phone}
            onChange={(e) => updateFormData("phone", e.target.value)}
            placeholder="0912..."
            disabled={otpSent}
            className="h-[56px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[16px] focus:border-[#1A2011] focus:bg-white text-lg font-mono text-center"
          />
        </div>

        {!otpSent && (
          <Button
            onClick={handleSendOTP}
            disabled={isSubmitting}
            className="w-full h-[56px] bg-[#484D2C] hover:bg-[#2A2F15] text-white rounded-[16px] text-lg"
          >
            {isSubmitting ? (
              "در حال ارسال..."
            ) : (
              <>
                دریافت کد تایید
                <Send className="w-5 h-5 mr-2" />
              </>
            )}
          </Button>
        )}

        <AnimatePresence>
          {otpSent && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden space-y-4"
            >
              <div className="bg-green-50 border border-green-200 rounded-[12px] p-3 text-center">
                <p className="text-sm text-green-700">
                  کد تایید به شماره <span className="font-mono">{formData.phone}</span> ارسال
                  شد
                </p>
              </div>

              <div>
                <LabelWithTooltip htmlFor="otp_code" required>
                  کد تایید ۶ رقمی
                </LabelWithTooltip>
                <Input
                  type="text"
                  maxLength={6}
                  value={formData.otp_code}
                  onChange={(e) => updateFormData("otp_code", e.target.value)}
                  placeholder="- - - - - -"
                  className="h-[64px] px-4 bg-[#FAFAFA] border-2 border-[#E8E8E8] rounded-[16px] focus:border-[#1A2011] focus:bg-white text-2xl font-mono text-center tracking-wide"
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  setOtpSent(false);
                  updateFormData("otp_code", "");
                }}
                className="text-sm text-[#888888] hover:text-[#1A2011] transition-colors"
              >
                تغییر شماره موبایل
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}