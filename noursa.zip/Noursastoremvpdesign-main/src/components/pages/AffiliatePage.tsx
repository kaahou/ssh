import { TrendingUp } from 'lucide-react';
import { ComingSoon } from './ComingSoon';

export function AffiliatePage() {
  return (
    <ComingSoon
      title="برنامه همکاری در فروش"
      description="به زودی می‌توانید با معرفی محصولات نورسا به دوستان خود، درآمد کسب کنید و از مزایای ویژه بهره‌مند شوید."
      icon={TrendingUp}
      color="#16A34A"
      progress={65}
    />
  );
}