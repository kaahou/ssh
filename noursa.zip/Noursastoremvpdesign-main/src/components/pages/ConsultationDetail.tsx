import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowRight, MessageSquare, Calendar, Clock, CheckCircle, FileText } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import ReactMarkdown from 'react-markdown';
import { logger } from '../../src/utils/logger';
import { useUser } from '../UserContext';

interface ConsultationData {
  id: string;
  phone: string;
  first_name?: string;
  last_name?: string;
  age?: string;
  gender?: string;
  created_at: string;
  consultation_result?: string | null;
  status: string;
  personal_info?: any;
}

export function ConsultationDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [consultation, setConsultation] = useState<ConsultationData | null>(null);
  const [loading, setLoading] = useState(true);

  // Field translations for display
  const fieldTranslations: Record<string, string> = {
    'age': 'سن',
    'gender': 'جنسیت',
    'hair_shaft': 'جنس ساقه مو',
    'hair_state': 'حالت مو',
    'main_goals': 'اهداف اصلی',
    'scalp_type': 'جنس پوست سر',
    'hair_length': 'طول مو',
    'stress_level': 'میزان استرس',
    'main_problems': 'مشکلات اصلی',
    'wash_frequency': 'تعداد دفعات شستشو',
    'medical_history': 'سابقه پزشکی',
    'current_products': 'محصولات فعلی',
    'scalp_temperament': 'طبع سر',
    'has_digestive_issues': 'مشکلات گوارشی',
    'environmental_conditions': 'شرایط محیطی',
    'uses_heat': 'استفاده از سشوار/اتو',
    'has_salon_history': 'سابقه آرایشگاهی',
    'salon_history_details': 'جزئیات آرایشگاهی',
    'additional_notes': 'توضیحات اضافی',
  };

  useEffect(() => {
    const controller = new AbortController();
    
    const fetchConsultationDetail = async () => {
      try {
        setLoading(true);
        const savedPhone = localStorage.getItem('consultation_phone');
        
        if (!savedPhone) {
          logger.warn('No saved phone found in localStorage');
          navigate('/profile/consultations');
          return;
        }

        logger.sensitive('Fetching consultation with ID:', id, 'for phone:', savedPhone);

        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/consultations/${id}`,
          {
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
            signal: controller.signal,
          }
        );

        logger.log('Response status:', response.status, response.ok);

        if (response.ok) {
          const data = await response.json();
          logger.log('Response data received');
          
          // Verify response has consultation data
          if (!data || !data.consultation) {
            logger.error('Invalid consultation data received');
            navigate('/profile/consultations');
            return;
          }
          
          logger.success('Consultation data valid');
          
          // Verify this consultation belongs to the user
          if (data.consultation.phone !== savedPhone) {
            logger.error('Phone mismatch - unauthorized access attempt');
            navigate('/profile/consultations');
            return;
          }
          
          logger.success('Setting consultation data');
          setConsultation(data.consultation);
        } else {
          const errorData = await response.json().catch(() => ({}));
          logger.error('Response not OK:', response.status, errorData);
          navigate('/profile/consultations');
        }
      } catch (error: any) {
        if (error.name === 'AbortError') {
          logger.log('Fetch aborted - component unmounted');
          return;
        }
        logger.error('Error fetching consultation detail:', error);
        navigate('/profile/consultations');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchConsultationDetail();
    }
    
    return () => controller.abort();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1A2011] border-r-transparent"></div>
          <p className="mt-4 text-[#888888]">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  if (!consultation) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <div className="text-center">
          <p className="text-[#888888] mb-4">مشاوره یافت نشد</p>
          <button
            onClick={() => navigate('/profile/consultations')}
            className="px-4 py-2 bg-[#1A2011] text-white rounded-lg hover:bg-[#484D2C] transition-colors"
          >
            بازگشت به لیست مشاوره‌ها
          </button>
        </div>
      </div>
    );
  }

  const hasResult = consultation.consultation_result && consultation.consultation_result.trim() !== '';

  // Prepare display fields from personal_info
  const displayFields: Array<{ label: string; value: any }> = [];
  
  if (consultation.personal_info && typeof consultation.personal_info === 'object') {
    Object.entries(consultation.personal_info).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== '') {
        // Format array values
        let displayValue = value;
        if (Array.isArray(value)) {
          displayValue = value.join('، ');
        } else if (typeof value === 'boolean') {
          displayValue = value ? 'بله' : 'خیر';
        }
        
        displayFields.push({
          label: fieldTranslations[key] || key,
          value: displayValue
        });
      }
    });
  }

  return (
    <div className="max-w-4xl mx-auto pb-8">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={() => navigate('/profile/consultations')}
          className="flex items-center gap-2 text-[#666666] hover:text-[#1A2011] transition-colors mb-4"
        >
          <ArrowRight size={20} />
          <span>بازگشت به لیست</span>
        </button>

        <div className="bg-white rounded-[24px] border border-[#E8E8E8] p-6 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-full bg-[#1A2011] flex items-center justify-center flex-shrink-0">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-2xl mb-2 text-[#1A2011]">مشاوره سلامت مو</h1>
              <div className="flex flex-wrap gap-4 text-sm text-[#666666]">
                <div className="flex items-center gap-1.5">
                  <Calendar size={16} />
                  <span>{new Date(consultation.created_at).toLocaleDateString('fa-IR')}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <FileText size={16} />
                  <span className="font-mono">کد: {String(consultation.id).slice(0, 8)}</span>
                </div>
              </div>
            </div>
            
            {hasResult ? (
              <div className="flex items-center gap-2 px-4 py-2 bg-[#D1FAE5] text-[#065F46] rounded-full">
                <CheckCircle size={18} />
                <span>پاسخ داده شده</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-4 py-2 bg-[#FEF3C7] text-[#92400E] rounded-full">
                <Clock size={18} />
                <span>در حال بررسی</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Personal Information */}
      {(consultation.first_name || consultation.last_name || consultation.age || consultation.gender) && (
        <div className="bg-white rounded-[24px] border border-[#E8E8E8] p-6 shadow-sm mb-6">
          <h2 className="text-lg mb-4 text-[#1A2011] flex items-center gap-2">
            <FileText size={20} />
            اطلاعات شخصی
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {consultation.first_name && (
              <div className="flex items-center gap-3 p-3 bg-[#FAFAFA] rounded-lg">
                <span className="text-sm text-[#666666] min-w-[100px]">نام:</span>
                <span className="text-[#1A2011]">{consultation.first_name}</span>
              </div>
            )}
            {consultation.last_name && (
              <div className="flex items-center gap-3 p-3 bg-[#FAFAFA] rounded-lg">
                <span className="text-sm text-[#666666] min-w-[100px]">نام خانوادگی:</span>
                <span className="text-[#1A2011]">{consultation.last_name}</span>
              </div>
            )}
            {consultation.age && (
              <div className="flex items-center gap-3 p-3 bg-[#FAFAFA] rounded-lg">
                <span className="text-sm text-[#666666] min-w-[100px]">سن:</span>
                <span className="text-[#1A2011]">{consultation.age}</span>
              </div>
            )}
            {consultation.gender && (
              <div className="flex items-center gap-3 p-3 bg-[#FAFAFA] rounded-lg">
                <span className="text-sm text-[#666666] min-w-[100px]">جنسیت:</span>
                <span className="text-[#1A2011]">{consultation.gender}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Consultation Information */}
      {displayFields.length > 0 && (
        <div className="bg-white rounded-[24px] border border-[#E8E8E8] p-6 shadow-sm mb-6">
          <h2 className="text-lg mb-4 text-[#1A2011]">اطلاعات مشاوره</h2>
          <div className="space-y-3">
            {displayFields
              .filter(field => !field.label.toLowerCase().includes('عکس') && !field.label.toLowerCase().includes('photo'))
              .map((field, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-[#FAFAFA] rounded-lg hover:bg-[#F4F4F5] transition-colors">
                  <span className="text-sm text-[#666666] min-w-[180px] flex-shrink-0">{field.label}:</span>
                  <span className="text-[#1A2011] flex-1">{String(field.value)}</span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Consultation Result */}
      {hasResult ? (
        <div className="bg-gradient-to-br from-[#1A2011] to-[#484D2C] rounded-[24px] p-6 shadow-lg text-white">
          <h2 className="text-xl mb-4 flex items-center gap-2">
            <CheckCircle size={24} />
            نتیجه مشاوره
          </h2>
          <div className="bg-white/10 backdrop-blur-sm rounded-[16px] p-6">
            <div className="prose prose-invert max-w-none">
              <ReactMarkdown
                components={{
                  h1: ({ children }) => <h1 className="text-2xl font-bold mb-4 text-white">{children}</h1>,
                  h2: ({ children }) => <h2 className="text-xl font-bold mb-3 text-white">{children}</h2>,
                  h3: ({ children }) => <h3 className="text-lg font-bold mb-2 text-white">{children}</h3>,
                  p: ({ children }) => <p className="mb-4 text-white/90 leading-relaxed">{children}</p>,
                  ul: ({ children }) => <ul className="list-disc list-inside mb-4 space-y-2 text-white/90">{children}</ul>,
                  ol: ({ children }) => <ol className="list-decimal list-inside mb-4 space-y-2 text-white/90">{children}</ol>,
                  li: ({ children }) => <li className="text-white/90">{children}</li>,
                  strong: ({ children }) => <strong className="font-bold text-white">{children}</strong>,
                }}
              >
                {consultation.consultation_result}
              </ReactMarkdown>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-[#FEF3C7] border border-[#FDE68A] rounded-[24px] p-6">
          <div className="flex items-start gap-3">
            <Clock className="w-6 h-6 text-[#92400E] flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-medium text-[#92400E] mb-2">در حال بررسی</h3>
              <p className="text-sm text-[#78350F]">
                مشاوره شما توسط متخصصین ما در حال بررسی است. به محض آماده شدن نتیجه، از طریق پیامک به شما اطلاع داده خواهد شد.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}