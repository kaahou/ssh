import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ShoppingCart, Minus, Plus, Package, Shield, Truck } from "lucide-react";
import { Product, ProductCard } from "../ProductCard";
import { useCart } from "../CartContext";
import { toast } from "sonner@2.0.3";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { OptimizedImage } from "../OptimizedImage";

interface ProductDetailPageProps {
  product: Product;
  relatedProducts: Product[];
  onBack: () => void;
}

interface Category {
  categories_id: number;
  name: string;
  slug: string;
}

export function ProductDetailPage({
  product,
  relatedProducts,
  onBack,
}: ProductDetailPageProps) {
  const { addItem, items } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [categoryName, setCategoryName] = useState("");

  // Function to format description text with proper paragraphs
  const formatDescription = (text: string) => {
    console.log('📝 formatDescription called with text:', text?.substring(0, 100), '...');
    console.log('📝 Text length:', text?.length || 0);
    
    if (!text || !text.trim()) {
      console.log('⚠️ Text is empty or whitespace only');
      return [{ type: 'paragraph', content: 'توضیحات محصول در حال حاضر موجود نیست.' }];
    }

    // Replace HTML entities with actual characters
    const cleanedText = text
      .replace(/&zwnj;/g, '\u200c')  // Zero-width non-joiner
      .replace(/&bull;/g, '\u2022')  // Bullet point
      .replace(/&nbsp;/g, '\u00a0')  // Non-breaking space
      .replace(/&mdash;/g, '\u2014') // Em dash
      .replace(/&ndash;/g, '\u2013') // En dash
      .replace(/&hellip;/g, '\u2026'); // Ellipsis

    const lines = cleanedText.split('\n');
    const formatted: Array<{ type: string; content: string; items?: string[] }> = [];
    let currentList: string[] = [];
    let listType: 'bullet' | 'number' | null = null;

    lines.forEach((line, index) => {
      const trimmed = line.trim();
      
      // Skip completely empty lines between content
      if (!trimmed && index > 0 && index < lines.length - 1) {
        // If we were building a list, close it
        if (currentList.length > 0 && listType) {
          formatted.push({ type: listType, content: '', items: [...currentList] });
          currentList = [];
          listType = null;
        }
        return;
      }
      
      // Check for bullet points (•, -, *)
      const bulletMatch = trimmed.match(/^[•\-\*]\s*(.+)$/);
      if (bulletMatch) {
        if (listType !== 'bullet') {
          // Close previous list if exists
          if (currentList.length > 0 && listType) {
            formatted.push({ type: listType, content: '', items: [...currentList] });
            currentList = [];
          }
          listType = 'bullet';
        }
        currentList.push(bulletMatch[1]);
        return;
      }

      // Check for numbered lists (1., 2., etc.)
      const numberMatch = trimmed.match(/^\d+[\.\)]\s*(.+)$/);
      if (numberMatch) {
        if (listType !== 'number') {
          // Close previous list if exists
          if (currentList.length > 0 && listType) {
            formatted.push({ type: listType, content: '', items: [...currentList] });
            currentList = [];
          }
          listType = 'number';
        }
        currentList.push(numberMatch[1]);
        return;
      }

      // Regular paragraph
      if (trimmed) {
        // Close any open list
        if (currentList.length > 0 && listType) {
          formatted.push({ type: listType, content: '', items: [...currentList] });
          currentList = [];
          listType = null;
        }
        formatted.push({ type: 'paragraph', content: trimmed });
      }
    });

    // Close any remaining list
    if (currentList.length > 0 && listType) {
      formatted.push({ type: listType, content: '', items: [...currentList] });
    }

    return formatted.length > 0 ? formatted : [{ type: 'paragraph', content: text }];
  };

  // Fetch category name
  useEffect(() => {
    async function fetchCategoryName() {
      if (!product.category_id) {
        setCategoryName(product.category || "");
        return;
      }

      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/categories`,
          {
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
          }
        );

        if (response.ok) {
          const data = await response.json();
          const category = data.categories?.find(
            (cat: Category) => cat.categories_id === product.category_id
          );
          setCategoryName(category?.name || "");
        }
      } catch (error) {
        console.error("Error fetching category:", error);
      }
    }

    fetchCategoryName();
  }, [product.category_id, product.category]);

  const handleAddToCart = (event?: React.MouseEvent) => {
    console.log('🛒 Adding product to cart, quantity:', quantity);
    console.log('📦 Product details:', {
      id: product.id,
      product_id: product.product_id,
      name: product.name || product.product_name,
      variant: product.variant_name
    });
    
    // CRITICAL: Stop event propagation to prevent any parent handlers
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    
    try {
      for (let i = 0; i < quantity; i++) {
        addItem(product);
      }
      console.log('✅ Product added successfully');
      
      const productName = product.variant_name 
        ? `${product.variant_name} ${product.product_name}` 
        : (product.product_name || product.name || 'محصول');
      toast.success(`${productName} (${quantity} عدد) به سبد خرید اضافه شد`);
      console.log('✅ Toast shown successfully');
      
      setQuantity(1);
    } catch (error) {
      console.error('❌ Error in handleAddToCart:', error);
      toast.error('خطا در افزودن به سبد خرید');
    }
  };

  // Support both old and new field names
  const productImage = product.image_urls || product.image_url || product.image || '';
  const productOriginalPrice = product.old_price || product.original_price || product.originalPrice;
  const productCategory = product.category || '';
  const productDescription = product.full_description || product.description || 'توضیحات محصول در حال حاضر موجود نیست.';
  
  // 🔍 Debug: بررسی توضیحات محصول
  console.log('🔍 Product description debug:', {
    has_full_description: !!product.full_description,
    has_description: !!product.description,
    full_description_length: product.full_description?.length || 0,
    description_length: product.description?.length || 0,
    final_description: productDescription,
    final_description_length: productDescription.length
  });
  
  // Combine variant_name and product_name
  const productName = product.variant_name 
    ? `${product.variant_name} ${product.product_name}` 
    : (product.product_name || product.name || 'بدون نام');
  
  const shortDescription = product.short_description || '';

  const hasDiscount = productOriginalPrice && productOriginalPrice > product.price;
  const discountPercent = hasDiscount
    ? Math.round(((productOriginalPrice! - product.price) / productOriginalPrice!) * 100)
    : 0;

  const features = [
    { icon: Truck, text: "ارسال رایگان برای سفارش بالای یک میلیون تومان" },
    { icon: Shield, text: "گارانتی اصالت کالا" },
    { icon: Package, text: "ضمانت بازگشت ۱۰۰٪ وجه" },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <Button variant="ghost" onClick={onBack} className="mb-6 rounded-[12px] hover:bg-[#F4F4F5]">
        <ArrowRight className="w-4 h-4 ml-2" />
        بازگشت
      </Button>

      {/* Product Details */}
      <div className="grid md:grid-cols-2 gap-8 md:gap-12 mb-[48px]">
        {/* Product Image */}
        <div className="space-y-4">
          <div className="relative aspect-square rounded-[16px] overflow-hidden bg-[#F3F4F6]">
            <OptimizedImage
              src={productImage}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {hasDiscount && (
              <Badge variant="destructive" className="absolute top-4 right-4 rounded-full">
                {discountPercent}% تخفیف
              </Badge>
            )}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="mb-2 text-[#1A2011]">{productName}</h1>
            {shortDescription && (
              <p className="text-[#888888] mb-4 leading-relaxed">
                {shortDescription}
              </p>
            )}
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="outline" className="rounded-full border-[#E8E8E8]">{categoryName}</Badge>
              <Badge variant="secondary" className="bg-[#D1FAE5] text-[#065F46] rounded-full">
                موجود در انبار
              </Badge>
            </div>
          </div>

          {/* Price */}
          <div className="bg-[#F4F4F5] rounded-[16px] p-6">
            <div className="flex items-baseline gap-3 mb-2">
              <span className="text-3xl text-[#1A2011]">
                {product.price.toLocaleString('fa-IR')}
              </span>
              <span className="text-[#888888]">تومان</span>
            </div>
            {hasDiscount && (
              <div className="flex items-center gap-2">
                <span className="text-[#888888] line-through">
                  {productOriginalPrice!.toLocaleString('fa-IR')} تومان
                </span>
                <Badge variant="destructive" className="rounded-full">{discountPercent}% تخفیف</Badge>
              </div>
            )}
          </div>

          {/* Quantity Selector */}
          <div className="space-y-3">
            <label className="text-[#1A2011]">تعداد:</label>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
                className="rounded-[12px] border-[#E8E8E8]"
              >
                <Minus className="w-4 h-4" />
              </Button>
              <div className="w-16 h-10 flex items-center justify-center border border-[#E8E8E8] rounded-[12px]">
                {quantity}
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(quantity + 1)}
                className="rounded-[12px] border-[#E8E8E8]"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Add to Cart Button */}
          <Button
            size="lg"
            className="w-full h-[56px] rounded-[12px] bg-[#1A2011] hover:bg-[#484D2C]"
            onClick={(e) => handleAddToCart(e)}
          >
            <ShoppingCart className="w-5 h-5 ml-2" />
            افزودن به سبد خرید
          </Button>

          {/* Features */}
          <div className="space-y-3 pt-6 border-t border-[#E8E8E8]">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="flex items-start gap-3 text-[#888888]">
                  <Icon className="w-5 h-5 mt-0.5" />
                  <span>{feature.text}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Description */}
      <div className="mb-[48px]">
        <h2 className="mb-6 text-[#1A2011] pb-3 border-b border-[#E8E8E8]">توضیحات محصول</h2>
        <div className="bg-[#F9FAFB] rounded-[16px] p-6 md:p-8">
          <div className="text-[#4B5563] leading-[1.9] text-[15px]">
            {formatDescription(productDescription).map((item, index) => {
              if (item.type === 'paragraph') {
                return (
                  <p key={index} className="text-justify mb-5 last:mb-0">
                    {item.content}
                  </p>
                );
              } else if (item.type === 'bullet') {
                return (
                  <ul key={index} className="list-disc pr-6 space-y-2.5 my-5 marker:text-[#9CA3AF]">
                    {item.items?.map((listItem, listIndex) => (
                      <li key={listIndex} className="pr-2 pl-2">{listItem}</li>
                    ))}
                  </ul>
                );
              } else if (item.type === 'number') {
                return (
                  <ol key={index} className="list-decimal pr-6 space-y-2.5 my-5 marker:text-[#9CA3AF]">
                    {item.items?.map((listItem, listIndex) => (
                      <li key={listIndex} className="pr-2 pl-2">{listItem}</li>
                    ))}
                  </ol>
                );
              }
              return null;
            })}
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div>
          <h2 className="mb-6 text-[#1A2011]">محصولات مرتبط</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {relatedProducts.map((relatedProduct) => {
              const relatedProductSlug = relatedProduct.slug || relatedProduct.product_id || relatedProduct.id;
              return (
                <Link
                  key={String(relatedProduct.product_id || relatedProduct.id)}
                  to={`/product/${relatedProductSlug}`}
                  className="cursor-pointer block"
                >
                  <ProductCard
                    product={relatedProduct}
                    onAddToCart={(product) => {
                      addItem(product);
                      const productName = product.variant_name 
                        ? `${product.variant_name} ${product.product_name}` 
                        : (product.product_name || product.name || 'محصول');
                      toast.success(`${productName} به سبد خرید اضافه شد`);
                    }}
                  />
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}