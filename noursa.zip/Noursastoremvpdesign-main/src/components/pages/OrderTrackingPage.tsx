import { LogIn, Package } from "lucide-react";
import { Link } from "react-router-dom";

export function OrderTrackingPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-[#1A2011] mb-4">پیگیری سفارش</h1>
          <div className="w-24 h-1 bg-[#1A2011] mx-auto rounded-full"></div>
        </div>

        {/* Main Content */}
        <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-8 md:p-12 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-[#F5F5F5] rounded-full mb-6">
            <Package className="w-10 h-10 text-[#1A2011]" />
          </div>

          <h2 className="text-[#1A2011] mb-4">پیگیری سفارشات شما</h2>
          
          <p className="text-[#666666] leading-relaxed mb-6">
            برای مشاهده و پیگیری وضعیت سفارشات خود، لطفاً وارد حساب کاربری خود شوید.
            پس از ورود، می‌توانید تمام سفارشات خود را در بخش <strong>«پروفایل &gt; سفارشات»</strong> مشاهده کنید.
          </p>

          <div className="bg-[#F9FAFB] border border-[#E8E8E8] rounded-lg p-6 mb-8 text-right">
            <h3 className="text-[#1A2011] mb-3">اطلاعاتی که می‌توانید مشاهده کنید:</h3>
            <ul className="space-y-2 text-[#666666]">
              <li className="flex items-start gap-2">
                <span className="text-[#1A2011] mt-1">✓</span>
                <span>وضعیت فعلی سفارش (در انتظار تایید، در حال آماده‌سازی، ارسال شده، تحویل داده شده)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#1A2011] mt-1">✓</span>
                <span>جزئیات محصولات سفارش داده شده</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#1A2011] mt-1">✓</span>
                <span>مبلغ پرداختی و کد پیگیری</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#1A2011] mt-1">✓</span>
                <span>تاریخ ثبت و تحویل سفارش</span>
              </li>
            </ul>
          </div>

          {/* Action Button */}
          <Link
            to="/login"
            className="inline-flex items-center gap-2 bg-[#1A2011] text-white px-8 py-4 rounded-full hover:bg-[#2d3420] transition-colors"
          >
            <LogIn className="w-5 h-5" />
            ورود به حساب کاربری
          </Link>

          <p className="text-[#888888] text-sm mt-6">
            حساب کاربری ندارید؟{" "}
            <Link to="/login" className="text-[#1A2011] hover:underline">
              ثبت‌نام کنید
            </Link>
          </p>
        </div>

        {/* Support Section */}
        <div className="mt-8 bg-gradient-to-l from-[#1A2011] to-[#2d3420] text-white rounded-[16px] p-6 text-center">
          <h3 className="mb-3">سوالی درباره سفارش دارید؟</h3>
          <p className="mb-4 opacity-90">تیم پشتیبانی ما آماده کمک به شماست</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="tel:05138373530"
              className="inline-block bg-white text-[#1A2011] px-6 py-3 rounded-full hover:bg-opacity-90 transition-all"
            >
              تماس: <span dir="ltr">۰۵۱-۳۸۳۷۳۵۳۰</span>
            </a>
            <Link
              to="/contact"
              className="inline-block bg-white/10 border border-white/30 text-white px-6 py-3 rounded-full hover:bg-white/20 transition-all"
            >
              فرم تماس با ما
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}