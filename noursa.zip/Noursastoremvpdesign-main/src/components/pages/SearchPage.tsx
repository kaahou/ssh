import { useState, useEffect } from "react";
import { Search, Loader2 } from "lucide-react";
import { Product, ProductCard } from "../ProductCard";
import { Input } from "../ui/input";
import { motion } from "motion/react";
import { Calendar, ChevronLeft } from "lucide-react";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { useCart } from "../CartContext";
import { toast } from "sonner@2.0.3";
import { useNavigate, Link } from "react-router-dom";

interface Article {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  featured: boolean;
  image_url?: string;
  created_at: string;
}

interface SearchPageProps {
  initialQuery?: string;
}

// Helper function to format date
function formatDate(dateString: string): string {
  try {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Intl.DateTimeFormat('fa-IR', options).format(date);
  } catch {
    return dateString;
  }
}

function ArticleCard({
  article,
}: {
  article: Article;
}) {
  const navigate = useNavigate();
  return (
    <motion.button
      onClick={() => navigate(`/read/${article.slug}`)}
      whileHover={{ y: -4 }}
      className="bg-white rounded-[20px] border border-[#E8E8E8] overflow-hidden hover:shadow-lg transition-shadow duration-300 group text-right h-full w-full flex flex-col"
    >
      {/* Image */}
      <div className="relative h-[200px] w-full bg-gradient-to-br from-[#484D2C]/10 to-[#F9E1B4]/30 flex items-center justify-center">
        <div className="text-4xl">🌿</div>
        {/* Category Badge */}
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full text-[12px] text-[#484D2C]">
          {article.category}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-1 flex flex-col">
        {/* Meta */}
        <div className="flex items-center gap-3 text-[12px] text-[#888888] mb-3">
          <div className="flex items-center gap-1.5">
            <Calendar size={14} />
            <span>{formatDate(article.created_at)}</span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-[16px] md:text-[18px] text-[#1A2011] group-hover:text-[#484D2C] transition-colors line-clamp-2 mb-3">
          {article.title}
        </h3>

        {/* Excerpt */}
        <p className="text-[14px] text-[#888888] line-clamp-2 mb-4 leading-relaxed flex-1">
          {article.excerpt}
        </p>

        {/* Read More */}
        <div className="flex items-center gap-2 text-[14px] text-[#484D2C] group-hover:gap-3 transition-all mt-auto">
          <span>مطالعه بیشتر</span>
          <ChevronLeft size={18} />
        </div>
      </div>
    </motion.button>
  );
}

export function SearchPage({ initialQuery = "" }: SearchPageProps) {
  const [query, setQuery] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{ products: Product[], articles: Article[] }>({ products: [], articles: [] });
  const { addItem } = useCart();
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    if (initialQuery) {
      handleSearch(initialQuery);
    }
  }, [initialQuery]);

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setHasSearched(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/search?q=${encodeURIComponent(searchQuery)}`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        setResults({
          products: data.products || [],
          articles: data.articles || [],
        });
      }
    } catch (error) {
      console.error("Error searching:", error);
      toast.error("خطا در جستجو");
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = (product: Product) => {
    addItem(product);
    const productName = product.variant_name 
      ? `${product.variant_name} ${product.product_name}` 
      : (product.product_name || product.name || 'محصول');
    toast.success(`${productName} به سبد خرید اضافه شد`);
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] py-8 pb-20">
      <div className="container mx-auto px-4 md:px-6 max-w-[1440px]">
        {/* Header & Search Input */}
        <div className="mb-10 max-w-2xl mx-auto text-center">
          <h1 className="text-[32px] md:text-[42px] text-[#1A2011] mb-6">
            جستجو در نورسا
          </h1>
          <div className="relative">
            <Input
              type="text"
              placeholder="جستجو در محصولات و مقالات..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch(query);
                }
              }}
              className="h-[56px] pr-12 pl-4 bg-white border-[#E8E8E8] rounded-[16px] text-[16px] shadow-sm focus:border-[#1A2011]"
            />
            <Search
              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#888888] cursor-pointer hover:text-[#1A2011] transition-colors"
              size={24}
              onClick={() => handleSearch(query)}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-10 h-10 animate-spin text-[#1A2011] mb-4" />
            <p className="text-[#888888]">در حال جستجو...</p>
          </div>
        ) : hasSearched ? (
          <div className="space-y-16">
            {/* Products Section */}
            <section>
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-[#E8E8E8]">
                <h2 className="text-2xl font-bold text-[#1A2011]">محصولات</h2>
                <span className="bg-[#E8E8E8] text-[#444444] px-2.5 py-0.5 rounded-full text-sm font-medium">
                  {results.products.length}
                </span>
              </div>
              
              {results.products.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {results.products.map((product) => (
                    <Link 
                      key={product.id || product.product_id}
                      to={`/product/${product.slug || product.product_id || product.id}`}
                      className="block"
                    >
                      <ProductCard
                        product={product}
                        onAddToCart={handleAddToCart}
                      />
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 bg-white rounded-xl border border-dashed border-[#E8E8E8]">
                  <p className="text-[#888888]">محصولی با این مشخصات یافت نشد.</p>
                </div>
              )}
            </section>

            {/* Articles Section */}
            <section>
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-[#E8E8E8]">
                <h2 className="text-2xl font-bold text-[#1A2011]">مقالات</h2>
                <span className="bg-[#E8E8E8] text-[#444444] px-2.5 py-0.5 rounded-full text-sm font-medium">
                  {results.articles.length}
                </span>
              </div>

              {results.articles.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {results.articles.map((article) => (
                    <ArticleCard
                      key={article.id || article.slug}
                      article={article}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 bg-white rounded-xl border border-dashed border-[#E8E8E8]">
                  <p className="text-[#888888]">مقاله‌ای با این مشخصات یافت نشد.</p>
                </div>
              )}
            </section>
          </div>
        ) : null}
      </div>
    </div>
  );
}