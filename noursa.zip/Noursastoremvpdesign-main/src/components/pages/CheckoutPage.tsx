import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { ShoppingBag, MapPin, User, Phone, CreditCard, ArrowRight, Loader2, Minus, Plus, Truck, Check, Shield, Trash2 } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { useCart } from "../CartContext";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { logger } from "../../src/utils/logger";
import { OptimizedImage } from "../OptimizedImage";

export function CheckoutPage() {
  // ✅ Merchant ID زرین‌پال برای دامنه جدید نورسا تنظیم شده است
  // دامنه ثبت شده در پنل زرین‌پال: nursaa.ir
  const REGISTERED_DOMAIN = "https://nursaa.ir";

  const navigate = useNavigate();
  const { items, removeItem, updateQuantity, clearCart, getTotalPrice } = useCart();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    customerName: "",
    phone: "",
    email: "",
    state: "",
    city: "",
    address: "",
    postalCode: "",
  });

  const [paymentMethod, setPaymentMethod] = useState<"zarinpal" | "card-to-card">("zarinpal");
  const [registerMe, setRegisterMe] = useState(false);

  const totalPrice = getTotalPrice();
  const discount = 0;
  const shippingCost = 80000;
  const finalPrice = totalPrice - discount + shippingCost;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.customerName || !formData.phone || !formData.state || !formData.city || !formData.address) {
      toast.error("لطفا فیلدهای الزامی را پر کنید");
      return;
    }

    if (items.length === 0) {
      toast.error("سبد خرید شما خالی است");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            customerName: formData.customerName,
            phone: formData.phone,
            email: formData.email,
            state: formData.state,
            city: formData.city,
            street: formData.address,
            postalCode: formData.postalCode,
            paymentMethod,
            items: items.map((item) => ({
              productId: String(item.product_id || item.id),
              name: item.variant_name
                ? `${item.variant_name} ${item.product_name}`
                : item.product_name || item.name || "محصول",
              price: item.price,
              quantity: item.quantity,
            })),
            totalAmount: finalPrice,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "خطا در ثبت سفارش");
      }

      if (paymentMethod === "zarinpal") {
        const orderId = data.orderId;
        
        // Save pending order details for verification
        localStorage.setItem("pendingPaymentOrder", JSON.stringify({
          orderId,
          amount: finalPrice
        }));
        
        // Request payment from Zarinpal
        try {
          const callbackOrigin = REGISTERED_DOMAIN || window.location.origin;
          const amountInRials = finalPrice * 10; // Convert Toman to Rial

          const paymentResponse = await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/payment/zarinpal/request`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${publicAnonKey}`,
              },
              body: JSON.stringify({
                amount: amountInRials,
                description: `سفارش شماره ${orderId}`,
                callback_url: `${callbackOrigin}/payment/callback`,
                mobile: formData.phone,
                email: formData.email,
                orderId: orderId
              }),
            }
          );
          
          const paymentData = await paymentResponse.json();
          
          if (paymentData.success && paymentData.payment_url) {
             window.location.href = paymentData.payment_url;
             return;
          } else {
             logger.error("Zarinpal error details:", paymentData);
             
             let errorMessage = "خطا در اتصال به درگاه پرداخت";
             
             // Handle specific Zarinpal errors
             if (paymentData.details?.errors?.code === -14) {
               errorMessage = `خطای دامنه (-14): آدرس بازگشت با دامنه ثبت شده در زرین‌پال مطابقت ندارد. لطفا REGISTERED_DOMAIN را در فایل CheckoutPage.tsx تنظیم کنید.`;
             } else if (paymentData.details?.errors?.message) {
               errorMessage = `خطای زرین‌پال: ${paymentData.details.errors.message}`;
             }
             
             throw new Error(errorMessage);
          }
        } catch (paymentError) {
           logger.error("Payment request failed:", paymentError);
           // Rethrow if it's already a specific error, otherwise generic
           if (paymentError instanceof Error && paymentError.message.includes("خطا")) {
             throw paymentError;
           }
           throw new Error("خطا در ایجاد درخواست پرداخت");
        }
      }

      toast.success("سفارش شما با موفقیت ثبت شد!");
      clearCart();
      setFormData({
        customerName: "",
        phone: "",
        email: "",
        state: "",
        city: "",
        address: "",
        postalCode: "",
      });

      setTimeout(() => {
        navigate("/");
      }, 2000);
    } catch (error) {
      logger.error("Error submitting order:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ثبت سفارش");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-[#F4F4F5] flex items-center justify-center">
            <ShoppingBag className="w-12 h-12 text-[#888888]" />
          </div>
          <h2 className="mb-4 text-[#1A2011]">سبد خرید شما خالی است</h2>
          <p className="text-[#888888] mb-8">
            هنوز محصولی به سبد خرید خود اضافه نکرده‌اید
          </p>
          <Button
            onClick={() => navigate("/products")}
            className="h-[48px] px-[24px] rounded-[12px] bg-[#1A2011] hover:bg-[#484D2C]"
          >
            مشاهده محصولات
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      {/* Breadcrumb */}
      <div className="bg-white border-b border-[#E8E8E8]">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <button
              onClick={() => navigate("/")}
              className="text-[#888888] hover:text-[#1A2011] transition-colors"
            >
              خانه
            </button>
            <ArrowRight className="w-4 h-4 text-[#888888] rotate-180" />
            <button
              onClick={() => navigate("/products")}
              className="text-[#888888] hover:text-[#1A2011] transition-colors"
            >
              فروشگاه
            </button>
            <ArrowRight className="w-4 h-4 text-[#888888] rotate-180" />
            <span className="text-[#1A2011]">تکمیل خرید</span>
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="container mx-auto px-4 py-8">
        <h1 className="mb-2 text-[#1A2011]">تکمیل خرید</h1>
        <p className="text-[#666666]">
          لطفا اطلاعات خود را با دقت وارد کنید
        </p>
      </div>

      <div className="container mx-auto px-4 pb-32 md:pb-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Section 1: Cart Items */}
            <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
                  ۱
                </div>
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-[#1A2011]" />
                  <h2 className="text-[#1A2011]">سبد خرید شما</h2>
                </div>
              </div>

              <div className="space-y-4">
                {items.map((item) => {
                  const itemId = String(item.product_id || item.id);
                  const itemName = item.variant_name
                    ? `${item.variant_name} ${item.product_name}`
                    : item.product_name || item.name || "محصول";
                  const itemImage = item.image_url || item.image || "";

                  return (
                    <div
                      key={itemId}
                      className="flex gap-4 p-4 rounded-[16px] border border-[#E8E8E8] hover:border-[#1A2011]/20 transition-colors"
                    >
                      {/* Image */}
                      <div className="w-20 h-20 rounded-[12px] overflow-hidden bg-[#F3F4F6] flex-shrink-0">
                        <OptimizedImage
                          src={itemImage}
                          alt={itemName}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="mb-1 line-clamp-1 text-[#1A2011]">
                          {itemName}
                        </h3>
                        <p className="text-sm text-[#666666] mb-2">
                          قیمت واحد: {item.price.toLocaleString("fa-IR")} تومان
                        </p>

                        {/* Quantity Controls */}
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7 rounded-[8px] border-[#E8E8E8]"
                            onClick={() =>
                              updateQuantity(itemId, item.quantity - 1)
                            }
                          >
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="w-8 text-center text-sm text-[#1A2011]">
                            {item.quantity}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7 rounded-[8px] border-[#E8E8E8]"
                            onClick={() =>
                              updateQuantity(itemId, item.quantity + 1)
                            }
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      {/* Price & Remove */}
                      <div className="flex flex-col items-end justify-between">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive hover:bg-[#FEE2E2]/50 rounded-[12px] h-8 w-8"
                          onClick={() => {
                            removeItem(itemId);
                            toast.success("محصول از سبد خرید حذف شد");
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        <p className="text-[#1A2011]">
                          {(item.price * item.quantity).toLocaleString("fa-IR")}{" "}
                          تومان
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Section 2: Customer Info & Address */}
            <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
                  ۲
                </div>
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-[#1A2011]" />
                  <h2 className="text-[#1A2011]">اطلاعات تماس و آدرس</h2>
                </div>
              </div>

              <div className="space-y-4">
                {/* Contact Information */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-[#444444] mb-2 block">
                      نام و نام خانوادگی <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="name"
                      value={formData.customerName}
                      onChange={(e) =>
                        setFormData({ ...formData, customerName: e.target.value })
                      }
                      placeholder="نام کامل خود را وارد کنید"
                      className="h-[48px] rounded-[12px] border-[#E8E8E8] bg-[#FAFAFA] focus:bg-white focus:border-[#1A2011]"
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone" className="text-[#444444] mb-2 block">
                      شماره تماس <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                      className="h-[48px] rounded-[12px] border-[#E8E8E8] bg-[#FAFAFA] focus:bg-white focus:border-[#1A2011]"
                    />
                  </div>
                </div>

                {/* Address Information */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="state" className="text-[#444444] mb-2 block">
                      استان <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="state"
                      value={formData.state}
                      onChange={(e) =>
                        setFormData({ ...formData, state: e.target.value })
                      }
                      placeholder="نام استان را وارد کنید"
                      className="h-[48px] rounded-[12px] border-[#E8E8E8] bg-[#FAFAFA] focus:bg-white focus:border-[#1A2011]"
                    />
                  </div>

                  <div>
                    <Label htmlFor="city" className="text-[#444444] mb-2 block">
                      شهر <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) =>
                        setFormData({ ...formData, city: e.target.value })
                      }
                      placeholder="نام شهر را وارد کنید"
                      className="h-[48px] rounded-[12px] border-[#E8E8E8] bg-[#FAFAFA] focus:bg-white focus:border-[#1A2011]"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="address" className="text-[#444444] mb-2 block">
                    آدرس کامل <span className="text-destructive">*</span>
                  </Label>
                  <Textarea
                    id="address"
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                    placeholder="آدرس دقیق و کامل محل تحویل سفارش را وارد کنید"
                    rows={3}
                    className="rounded-[12px] border-[#E8E8E8] bg-[#FAFAFA] focus:bg-white focus:border-[#1A2011] resize-none"
                    style={{ height: "90px" }}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label
                      htmlFor="postalCode"
                      className="text-[#444444] mb-2 block"
                    >
                      کد پستی
                    </Label>
                    <Input
                      id="postalCode"
                      value={formData.postalCode}
                      onChange={(e) =>
                        setFormData({ ...formData, postalCode: e.target.value })
                      }
                      placeholder="۱۲۳۴۵۶۷۸۹۰"
                      className="h-[48px] rounded-[12px] border-[#E8E8E8] bg-[#FAFAFA] focus:bg-white focus:border-[#1A2011]"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-[#444444] mb-2 block">
                      ایمیل
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      placeholder="example@email.com"
                      className="h-[48px] rounded-[12px] border-[#E8E8E8] bg-[#FAFAFA] focus:bg-white focus:border-[#1A2011]"
                    />
                  </div>
                </div>

                {/* Shipping Method */}
                <div className="pt-4">
                  <Label className="text-[#444444] mb-3 block">روش ارسال</Label>
                  <div className="border-2 border-[#1A2011] bg-[#1A2011]/5 rounded-[12px] p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full border-2 border-[#1A2011] flex items-center justify-center flex-shrink-0">
                        <div className="w-2.5 h-2.5 rounded-full bg-[#1A2011]" />
                      </div>
                      <div className="flex items-center gap-3 flex-1">
                        <div className="w-10 h-10 rounded-full bg-[#1A2011] flex items-center justify-center">
                          <Truck className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="text-[#1A2011] mb-0.5">پست پیشتاز</p>
                          <p className="text-sm text-[#666666]">
                            ۳ تا ۵ روز کاری - ۸۰,۰۰۰ تومان
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Section 3: Payment Method */}
            <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-[#1A2011] text-white flex items-center justify-center">
                  ۳
                </div>
                <div className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-[#1A2011]" />
                  <h2 className="text-[#1A2011]">روش پرداخت</h2>
                </div>
              </div>

              <div className="space-y-3">
                {/* Zarinpal */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod("zarinpal")}
                  className={`w-full border-2 rounded-[12px] p-4 text-right transition-all ${
                    paymentMethod === "zarinpal"
                      ? "border-[#1A2011] bg-[#1A2011]/5"
                      : "border-[#E8E8E8] hover:border-[#1A2011]/30"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                        paymentMethod === "zarinpal"
                          ? "border-[#1A2011]"
                          : "border-[#E8E8E8]"
                      }`}
                    >
                      {paymentMethod === "zarinpal" && (
                        <div className="w-2.5 h-2.5 rounded-full bg-[#1A2011]" />
                      )}
                    </div>
                    <div className="flex items-center gap-3 flex-1">
                      <div className="w-10 h-10 rounded-full bg-[#F9E1B4] flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-[#1A2011]" />
                      </div>
                      <div>
                        <p className="text-[#1A2011] mb-0.5">
                          زرین‌پال (درگاه بانکی)
                        </p>
                        <p className="text-sm text-[#666666]">
                          پرداخت آنلاین امن
                        </p>
                      </div>
                    </div>
                  </div>
                </button>

                {/* Card to Card */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod("card-to-card")}
                  className={`w-full border-2 rounded-[12px] p-4 text-right transition-all ${
                    paymentMethod === "card-to-card"
                      ? "border-[#1A2011] bg-[#1A2011]/5"
                      : "border-[#E8E8E8] hover:border-[#1A2011]/30"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                        paymentMethod === "card-to-card"
                          ? "border-[#1A2011]"
                          : "border-[#E8E8E8]"
                      }`}
                    >
                      {paymentMethod === "card-to-card" && (
                        <div className="w-2.5 h-2.5 rounded-full bg-[#1A2011]" />
                      )}
                    </div>
                    <div className="flex items-center gap-3 flex-1">
                      <div className="w-10 h-10 rounded-full bg-[#E8E8E8] flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-[#1A2011]" />
                      </div>
                      <div>
                        <p className="text-[#1A2011] mb-0.5">کارت به کارت</p>
                        <p className="text-sm text-[#666666]">
                          واریز مستقیم به حساب
                        </p>
                      </div>
                    </div>
                  </div>
                </button>

                {/* Card to Card Details */}
                <AnimatePresence>
                  {paymentMethod === "card-to-card" && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="bg-[#F9E1B4]/10 border-2 border-[#F9E1B4] rounded-[12px] p-4 mt-3">
                        <h3 className="text-[#1A2011] mb-4">
                          اطلاعات حساب مقصد
                        </h3>

                        <div className="space-y-3 mb-4">
                          <div className="bg-white rounded-[8px] p-3 border border-[#E8E8E8]">
                            <p className="text-sm text-[#666666] mb-1">
                              شماره کارت
                            </p>
                            <p className="text-[#1A2011] font-mono">
                              ۵۸۹۲-۱۰۱۶-۳۰۲۵-۵۲۸۵
                            </p>
                          </div>
                          <div className="bg-white rounded-[8px] p-3 border border-[#E8E8E8]">
                            <p className="text-sm text-[#666666] mb-1">
                              شماره شبا
                            </p>
                            <p className="text-[#1A2011] font-mono">
                              IR060150000003101104766441
                            </p>
                          </div>
                          <div className="bg-white rounded-[8px] p-3 border border-[#E8E8E8]">
                            <p className="text-sm text-[#666666] mb-1">
                              نام صاحب حساب
                            </p>
                            <p className="text-[#1A2011]">مرضیه ایزدی یزدان‌آبادی</p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6 lg:sticky lg:top-24">
              <h3 className="mb-6 text-[#1A2011]">خلاصه سفارش</h3>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-[#666666]">جمع کل محصولات:</span>
                  <span className="text-[#1A2011]">
                    {totalPrice.toLocaleString("fa-IR")} تومان
                  </span>
                </div>

                {discount > 0 && (
                  <div className="flex justify-between text-destructive">
                    <span>تخفیف:</span>
                    <span>-{discount.toLocaleString("fa-IR")} تومان</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span className="text-[#666666]">هزینه ارسال:</span>
                  <span className="text-[#1A2011]">
                    {shippingCost.toLocaleString("fa-IR")} تومان
                  </span>
                </div>

                <div className="pt-4 border-t-2 border-[#E8E8E8]">
                  <div className="flex justify-between items-baseline mb-2">
                    <span className="text-[#444444]">مبلغ قابل پرداخت:</span>
                    <span className="text-[20px] text-[#1A2011]">
                      {finalPrice.toLocaleString("fa-IR")} تومان
                    </span>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleSubmitOrder}
                disabled={isSubmitting}
                className="w-full h-[52px] rounded-[12px] bg-[#1A2011] hover:bg-[#484D2C] text-white"
              >
                {isSubmitting ? (
                  "در حال پردازش..."
                ) : (
                  <>
                    <Check className="w-5 h-5 ml-2" />
                    تایید و پرداخت
                  </>
                )}
              </Button>

              <div className="mt-4 flex items-center justify-center gap-2 text-[#16A34A]">
                <Shield className="w-4 h-4" />
                <span className="text-sm">پرداخت امن</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Sticky Bottom */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t-2 border-[#E8E8E8] p-4 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] z-50">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[#666666]">مبلغ قابل پرداخت:</span>
          <span className="text-[18px] text-[#1A2011]">
            {finalPrice.toLocaleString("fa-IR")} تومان
          </span>
        </div>

        <Button
          onClick={handleSubmitOrder}
          disabled={isSubmitting}
          className="w-full h-[52px] rounded-[12px] bg-[#1A2011] hover:bg-[#484D2C] text-white"
        >
          {isSubmitting ? (
            "در حال پردازش..."
          ) : (
            <>
              <Check className="w-5 h-5 ml-2" />
              تایید و پرداخت
            </>
          )}
        </Button>
      </div>
    </div>
  );
}