import { Link } from 'react-router-dom';

export function ReturnPolicyPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-[#1A2011] mb-8">بازگشت کالا</h1>

        <div className="space-y-8">
          {/* شرایط بازگشت */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">شرایط بازگشت کالا</h2>
            <p className="text-[#888888] mb-4">
              در فروشگاه نورسا، رضایت شما برای ما اولویت است. شما می‌توانید کالای خریداری شده را با رعایت شرایط زیر مرجوع کنید:
            </p>
            <ul className="list-disc list-inside space-y-2 text-[#888888] mr-4">
              <li>حداکثر ۷ روز پس از تحویل کالا</li>
              <li>کالا نباید استفاده شده باشد</li>
              <li>بسته‌بندی اصلی کالا سالم باشد</li>
              <li>تمام لوازم جانبی و هدایای همراه کالا موجود باشد</li>
              <li>برچسب‌ها و برگه‌های اطلاعاتی کالا سالم باشد</li>
            </ul>
          </section>

          {/* کالاهای غیرقابل بازگشت */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">کالاهای غیرقابل بازگشت</h2>
            <ul className="list-disc list-inside space-y-2 text-[#888888] mr-4">
              <li>محصولات بهداشتی و آرایشی پس از باز شدن</li>
              <li>کالاهای سفارشی و شخصی‌سازی شده</li>
              <li>محصولات دیجیتال</li>
              <li>کالاهای تخفیف‌دار بیش از ۵۰٪</li>
              <li>محصولات با مهر و امضای شخصی</li>
            </ul>
          </section>

          {/* نحوه درخواست بازگشت */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">نحوه درخواست بازگشت کالا</h2>
            <div className="space-y-3 text-[#888888]">
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۱</span>
                <p>با شماره تلفن <span dir="ltr">۰۵۱-۳۸۳۷۳۵۳۰</span> تماس بگیرید یا از طریق فرم تماس با ما پیام بفرستید.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۲</span>
                <p>کد سفارش و دلیل بازگشت کالا را اعلام کنید.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۳</span>
                <p>پس از تایید درخواست، کالا را با بسته‌بندی مناسب به آدرس ما ارسال کنید.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۴</span>
                <p>پس از دریافت و بررسی کالا، وجه به حساب شما بازگردانده می‌شود.</p>
              </div>
            </div>
          </section>

          {/* بازگشت وجه */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">بازگشت وجه</h2>
            <p className="text-[#888888] mb-4">
              پس از تایید درخواست بازگشت و دریافت کالا:
            </p>
            <ul className="list-disc list-inside space-y-2 text-[#888888] mr-4">
              <li>بازگشت وجه به حساب بانکی: ۳-۵ روز کاری</li>
              <li>بازگشت به کیف پول فروشگاه: فوری</li>
              <li>هزینه ارسال در صورت تایید درخواست، بازگردانده می‌شود</li>
            </ul>
          </section>

          {/* تعویض کالا */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">تعویض کالا</h2>
            <p className="text-[#888888] mb-4">
              در صورت تمایل به تعویض کالا با محصول دیگر:
            </p>
            <ul className="list-disc list-inside space-y-2 text-[#888888] mr-4">
              <li>درخواست تعویض را اعلام کنید</li>
              <li>محصول جایگزین را مشخص کنید</li>
              <li>در صورت اختلاف قیمت، مابه‌التفاوت محاسبه می‌شود</li>
              <li>تعویض رایگان برای کالاهای معیوب</li>
            </ul>
          </section>

          {/* کالای معیوب */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">کالای معیوب یا اشتباه</h2>
            <p className="text-[#888888] mb-4">
              اگر کالای دریافتی معیوب یا اشتباه است:
            </p>
            <ul className="list-disc list-inside space-y-2 text-[#888888] mr-4">
              <li>فوری با ما تماس بگیرید</li>
              <li>تصویری از کالا ارسال کنید</li>
              <li>هزینه ارسال بازگشت به عهده فروشگاه است</li>
              <li>کالا در اسرع وقت تعویض یا بازپرداخت می‌شود</li>
            </ul>
          </section>

          {/* تماس با ما */}
          <section className="bg-[#F9E1B4] p-6 rounded-lg">
            <h2 className="text-[#1A2011] mb-4">سوال دارید؟</h2>
            <p className="text-[#1A2011] mb-4">
              برای هرگونه سوال در مورد بازگشت کالا، با ما در تماس باشید:
            </p>
            <div className="flex flex-wrap gap-4">
              <Link 
                to="/contact"
                className="inline-block px-6 py-2 bg-[#1A2011] text-white rounded-lg hover:bg-[#2A3021] transition-colors"
              >
                تماس با ما
              </Link>
              <a 
                href="tel:05138373530"
                className="px-6 py-2 bg-white text-[#1A2011] rounded-lg hover:bg-[#F4F4F5] transition-colors border border-[#1A2011]"
              >
                ۰۵۱-۳۸۳۷۳۵۳۰

              </a>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}