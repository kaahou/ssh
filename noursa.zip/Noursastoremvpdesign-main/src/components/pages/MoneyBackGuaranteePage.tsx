import { CheckCircle2, MessageSquare, Calendar, Search, Wallet, Shield, Clock, Users, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SEOHead } from '../SEOHead';
// Import analytics to ensure global types are loaded
import '../../utils/analytics';

// Helper function for tracking custom events
const trackEvent = (eventName: string, params?: Record<string, any>) => {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    window.gtag('event', eventName, params);
  }
};

export function MoneyBackGuaranteePage() {
  const navigate = useNavigate();

  const handleConsultationClick = () => {
    trackEvent('money_back_guarantee_consultation_click', {
      location: 'hero_section'
    });
    navigate('/consultation');
  };

  const handleConsultationClickConversion = () => {
    trackEvent('money_back_guarantee_consultation_click', {
      location: 'conversion_section'
    });
    navigate('/consultation');
  };

  const handleRefundRequestClick = () => {
    trackEvent('money_back_guarantee_refund_request_click', {
      status: 'disabled_under_3_months'
    });
    // این دکمه در حال حاضر غیرفعال است
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="ضمانت بازگشت ۱۰۰٪ وجه تا ۶ ماه | نورسا"
        description="با خرید از نورسا، تا ۶ ماه ضمانت بازگشت ۱۰۰٪ وجه دریافت کنید. اگر پس از مصرف اصولی محصول پیشنهادی، به نتیجه نرسیدید، کل مبلغ بازگردانده می‌شود."
        canonical="https://nursaa.ir/money-back-guarantee"
        ogType="website"
        ogImage="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo-main.png"
      />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-bl from-[#16A34A]/5 via-background to-[#F9E1B4]/10 overflow-hidden">
        <div className="container mx-auto px-4 py-16 md:py-24 max-w-5xl">
          <div className="text-center space-y-6">
            {/* Icon */}
            <div className="flex justify-center">
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-[#16A34A] to-[#065F46] flex items-center justify-center shadow-lg">
                <Shield className="w-12 h-12 md:w-14 md:h-14 text-white" />
              </div>
            </div>

            {/* Title */}
            <h1 className="text-[#1A2011]">
              ضمانت بازگشت ۱۰۰٪ وجه تا ۶ ماه
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-[#484D2C] max-w-3xl mx-auto leading-relaxed">
              اگر پس از مصرف اصولی و مستمر محصول پیشنهادی کارشناسان ما، به نتیجه دلخواه نرسیدید، کل مبلغ پرداختی شما بازگردانده می‌شود.
            </p>

            {/* CTA Button */}
            <div className="pt-4">
              <button
                onClick={handleConsultationClick}
                className="bg-[#16A34A] hover:bg-[#065F46] text-white px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 inline-flex items-center gap-3"
              >
                <MessageSquare className="w-5 h-5" />
                دریافت مشاوره تخصصی با ضمانت
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center space-y-6 mb-12">
            <h2 className="text-[#1A2011]">چرا این ضمانت؟</h2>
            <p className="text-[#484D2C] max-w-2xl mx-auto leading-relaxed">
              در نورسا، ما به توانمندی محصولات خود اطمینان کامل داریم. 
              ضمانت ما نشان‌دهنده تعهد ما به سلامت و رضایت شماست. 
              با راهنمایی تخصصی و پشتیبانی مستمر، ریسک خرید را به صفر می‌رسانیم.
            </p>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-[#D1FAE5] to-white p-6 rounded-2xl border border-[#16A34A]/20 text-center space-y-4">
              <div className="flex justify-center">
                <div className="w-14 h-14 rounded-full bg-[#16A34A] flex items-center justify-center">
                  <Users className="w-7 h-7 text-white" />
                </div>
              </div>
              <h3 className="text-[#1A2011]">توصیه اختصاصی</h3>
              <p className="text-sm text-[#484D2C] leading-relaxed">
                کارشناسان ما محصول مناسب را بر اساس نیاز شما انتخاب می‌کنند
              </p>
            </div>

            <div className="bg-gradient-to-br from-[#DBEAFE] to-white p-6 rounded-2xl border border-[#1E40AF]/20 text-center space-y-4">
              <div className="flex justify-center">
                <div className="w-14 h-14 rounded-full bg-[#1E40AF] flex items-center justify-center">
                  <MessageSquare className="w-7 h-7 text-white" />
                </div>
              </div>
              <h3 className="text-[#1A2011]">پشتیبانی مستمر</h3>
              <p className="text-sm text-[#484D2C] leading-relaxed">
                در طول مصرف، همیشه در کنار شما هستیم و راهنمایی می‌کنیم
              </p>
            </div>

            <div className="bg-gradient-to-br from-[#FEF3C7] to-white p-6 rounded-2xl border border-[#F59E0B]/20 text-center space-y-4">
              <div className="flex justify-center">
                <div className="w-14 h-14 rounded-full bg-[#F59E0B] flex items-center justify-center">
                  <Shield className="w-7 h-7 text-white" />
                </div>
              </div>
              <h3 className="text-[#1A2011]">حذف ریسک خرید</h3>
              <p className="text-sm text-[#484D2C] leading-relaxed">
                خرید شما بدون هیچ نگرانی، با ضمانت کامل بازگشت وجه
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Conditions Checklist */}
      <section className="py-16 bg-gradient-to-b from-background to-[#F9E1B4]/5">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-[#1A2011]">شرایط استفاده از ضمانت</h2>
            <p className="text-[#484D2C]">
              برای استفاده از ضمانت بازگشت وجه، رعایت موارد زیر الزامی است:
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Condition 1 */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-[#E8E8E8] flex gap-4 hover:shadow-md transition-shadow">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-full bg-[#16A34A] flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="text-[#1A2011]">توصیه محصول توسط کارشناس</h4>
                <p className="text-sm text-[#484D2C] leading-relaxed">
                  محصول باید توسط کارشناس مجموعه نورسا پس از بررسی نیاز شما پیشنهاد شده باشد
                </p>
              </div>
            </div>

            {/* Condition 2 */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-[#E8E8E8] flex gap-4 hover:shadow-md transition-shadow">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-full bg-[#16A34A] flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="text-[#1A2011]">مصرف منظم طبق دستورالعمل</h4>
                <p className="text-sm text-[#484D2C] leading-relaxed">
                  محصول باید به طور مستمر و طبق دستورالعمل کارشناس مصرف شود
                </p>
              </div>
            </div>

            {/* Condition 3 */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-[#E8E8E8] flex gap-4 hover:shadow-md transition-shadow">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-full bg-[#16A34A] flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="text-[#1A2011]">ارسال گزارش هفتگی</h4>
                <p className="text-sm text-[#484D2C] leading-relaxed">
                  ارسال گزارش هفتگی به همراه عکس یا ویدئو و توضیحات مربوطه
                </p>
              </div>
            </div>

            {/* Condition 4 */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-[#E8E8E8] flex gap-4 hover:shadow-md transition-shadow">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-full bg-[#16A34A] flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="text-[#1A2011]">حداقل ۳ ماه مصرف مداوم</h4>
                <p className="text-sm text-[#484D2C] leading-relaxed">
                  برای ارزیابی نتیجه، حداقل ۳ ماه مصرف منظم و مستمر الزامی است
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-[#1A2011]">مسیر ضمانت شما</h2>
            <p className="text-[#484D2C]">
              فرآیند کامل از مشاوره تا بازگشت وجه
            </p>
          </div>

          {/* Timeline - Desktop */}
          <div className="hidden md:block">
            <div className="relative">
              {/* Line */}
              <div className="absolute top-24 left-0 right-0 h-1 bg-gradient-to-l from-[#16A34A] via-[#1E40AF] to-[#F59E0B]"></div>
              
              <div className="grid grid-cols-4 gap-6 relative">
                {/* Step 1 */}
                <div className="text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#F59E0B] to-[#92400E] flex items-center justify-center shadow-lg relative z-10 border-4 border-white">
                      <MessageSquare className="w-10 h-10 text-white" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-[#1A2011]">مرحله ۱</h4>
                    <h3 className="text-[#484D2C]">ثبت‌نام و مشاوره</h3>
                    <p className="text-sm text-[#888888]">
                      دریافت مشاوره تخصصی و توصیه محصول مناسب
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#1E40AF] to-[#1E3A8A] flex items-center justify-center shadow-lg relative z-10 border-4 border-white">
                      <Calendar className="w-10 h-10 text-white" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-[#1A2011]">مرحله ۲</h4>
                    <h3 className="text-[#484D2C]">مصرف و گزارش</h3>
                    <p className="text-sm text-[#888888]">
                      مصرف منظم و ارسال گزارش هفتگی (ماه ۱ تا ۳)
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#16A34A] to-[#065F46] flex items-center justify-center shadow-lg relative z-10 border-4 border-white">
                      <Search className="w-10 h-10 text-white" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-[#1A2011]">مرحله ۳</h4>
                    <h3 className="text-[#484D2C]">ارزیابی نتیجه</h3>
                    <p className="text-sm text-[#888888]">
                      بررسی نتایج پس از ۳ ماه مصرف مستمر
                    </p>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#16A34A] to-[#065F46] flex items-center justify-center shadow-lg relative z-10 border-4 border-white">
                      <Wallet className="w-10 h-10 text-white" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-[#1A2011]">مرحله ۴</h4>
                    <h3 className="text-[#484D2C]">بازگشت ۱۰۰٪ وجه</h3>
                    <p className="text-sm text-[#888888]">
                      در صورت عدم رضایت تا پایان ماه ۶
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Timeline - Mobile */}
          <div className="md:hidden space-y-6">
            {/* Step 1 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#F59E0B] to-[#92400E] flex items-center justify-center shadow-lg">
                  <MessageSquare className="w-8 h-8 text-white" />
                </div>
              </div>
              <div className="flex-1 space-y-2">
                <h4 className="text-[#1A2011]">مرحله ۱</h4>
                <h3 className="text-[#484D2C]">ثبت‌نام و مشاوره</h3>
                <p className="text-sm text-[#888888]">
                  دریافت مشاوره تخصصی و توصیه محصول مناسب
                </p>
              </div>
            </div>

            <div className="flex justify-center">
              <div className="w-1 h-8 bg-gradient-to-b from-[#F59E0B] to-[#1E40AF]"></div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#1E40AF] to-[#1E3A8A] flex items-center justify-center shadow-lg">
                  <Calendar className="w-8 h-8 text-white" />
                </div>
              </div>
              <div className="flex-1 space-y-2">
                <h4 className="text-[#1A2011]">مرحله ۲</h4>
                <h3 className="text-[#484D2C]">مصرف و گزارش</h3>
                <p className="text-sm text-[#888888]">
                  مصرف منظم و ارسال گزارش هفتگی (ماه ۱ تا ۳)
                </p>
              </div>
            </div>

            <div className="flex justify-center">
              <div className="w-1 h-8 bg-gradient-to-b from-[#1E40AF] to-[#16A34A]"></div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#16A34A] to-[#065F46] flex items-center justify-center shadow-lg">
                  <Search className="w-8 h-8 text-white" />
                </div>
              </div>
              <div className="flex-1 space-y-2">
                <h4 className="text-[#1A2011]">مرحله ۳</h4>
                <h3 className="text-[#484D2C]">ارزیابی نتیجه</h3>
                <p className="text-sm text-[#888888]">
                  بررسی نتایج پس از ۳ ماه مصرف مستمر
                </p>
              </div>
            </div>

            <div className="flex justify-center">
              <div className="w-1 h-8 bg-[#16A34A]"></div>
            </div>

            {/* Step 4 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#16A34A] to-[#065F46] flex items-center justify-center shadow-lg">
                  <Wallet className="w-8 h-8 text-white" />
                </div>
              </div>
              <div className="flex-1 space-y-2">
                <h4 className="text-[#1A2011]">مرحله ۴</h4>
                <h3 className="text-[#484D2C]">بازگشت ۱۰۰٪ وجه</h3>
                <p className="text-sm text-[#888888]">
                  در صورت عدم رضایت تا پایان ماه ۶
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Refund Request Button Section */}
      <section className="py-16 bg-gradient-to-b from-background to-[#E8E8E8]/30">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <div className="bg-white p-8 md:p-12 rounded-2xl shadow-lg border border-[#E8E8E8] space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 rounded-full bg-[#CCCCCC] flex items-center justify-center">
                <FileText className="w-8 h-8 text-[#888888]" />
              </div>
            </div>
            
            <h3 className="text-[#1A2011]">درخواست بازگشت وجه</h3>
            <p className="text-[#484D2C]">
              اگر پس از ۳ ماه مصرف منظم به نتیجه دلخواه نرسیده‌اید، می‌توانید درخواست بازگشت وجه ثبت کنید
            </p>
            
            <button
              onClick={handleRefundRequestClick}
              disabled
              className="bg-[#CCCCCC] text-[#888888] px-8 py-4 rounded-xl cursor-not-allowed inline-flex items-center gap-3"
            >
              <Clock className="w-5 h-5" />
              ثبت درخواست ضمانت بازگشت وجه
            </button>
            
            <p className="text-sm text-[#888888]">
              فعال پس از حداقل ۳ ماه مصرف منظم
            </p>
          </div>
        </div>
      </section>

      {/* Conversion Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-[#1A2011] to-[#144236]">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-white">شروع مطمئن، فقط با مشاوره تخصصی</h2>
              <p className="text-[#F9E1B4] text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
                تمام ضمانت‌ها فقط شامل محصولاتی است که پس از بررسی تخصصی به شما پیشنهاد شده‌اند.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button
                onClick={handleConsultationClickConversion}
                className="bg-[#F9E1B4] hover:bg-[#F9E1B4]/90 text-[#1A2011] px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 inline-flex items-center gap-3"
              >
                <MessageSquare className="w-5 h-5" />
                ثبت‌نام و دریافت مشاوره
              </button>
            </div>

            <div className="flex items-center justify-center gap-3 text-[#D1FAE5]">
              <Shield className="w-5 h-5" />
              <span className="text-sm">محصولات با ضمانت اصالت و کیفیت</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}