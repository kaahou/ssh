import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { User, Smartphone, Lock, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { useUser } from "../UserContext";
import { logger } from "../../src/utils/logger";

// Helper to convert Persian/Arabic digits to English
const normalizeDigits = (str: string) => {
  if (!str) return "";
  return str.replace(/[۰-۹]/g, (d) => String.fromCharCode(d.charCodeAt(0) - 1728))
            .replace(/[٠-٩]/g, (d) => String.fromCharCode(d.charCodeAt(0) - 1584));
};

interface LoginPageProps {
  onBack?: () => void;
}

export function LoginPage({ onBack }: LoginPageProps) {
  const navigate = useNavigate();
  const [phone, setPhone] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [timer, setTimer] = useState(0);
  const { reloadUser } = useUser();

  // Timer countdown effect
  useEffect(() => {
    if (otpSent && timer > 0) {
      const interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
      
      return () => clearInterval(interval);
    }
    // اگر شرط false بود، cleanup نداریم
  }, [otpSent, timer]);

  // Format time as mm:ss
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSendOTP = async () => {
    let normalizedPhone = normalizeDigits(phone);
    
    // Auto-fix phone number format if user entered 912... instead of 0912...
    if (normalizedPhone && normalizedPhone.length === 10 && !normalizedPhone.startsWith('0')) {
      normalizedPhone = '0' + normalizedPhone;
    }

    if (!normalizedPhone || normalizedPhone.length < 11) {
      toast.error("لطفا شماره موبایل معتبر وارد کنید");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/send-otp`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ phone: normalizedPhone }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "ارسال کد تایید با خطا مواجه شد");
      }

      // Check if SMS was actually sent successfully according to backend
      if (result.debug && result.debug.smsSuccess === false) {
        logger.error("SMS Provider Error:", result.debug.smsError);
        // Show the specific error from backend or a generic one
        throw new Error("خطا در سیستم ارسال پیامک. لطفا دقایقی دیگر تلاش کنید.");
      }

      setOtpSent(true);
      setTimer(120); // Start 2 minute timer
      toast.success(result.message || "کد تایید به شماره شما ارسال شد");
    } catch (error: any) {
      logger.error("Error sending OTP:", error);
      toast.error(error.message || "ارسال کد تایید با خطا مواجه شد");
      
      // If we are in the OTP screen and resend failed, we don't want to go back to phone entry
      // But if we are in phone entry and it failed, we stay there.
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifyOTP = async () => {
    const normalizedOtp = normalizeDigits(otpCode);
    const normalizedPhone = normalizeDigits(phone);

    if (!normalizedOtp || normalizedOtp.length !== 6) {
      toast.error("لطفا کد ۶ رقمی را وارد کنید");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/verify-login-otp`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            phone: normalizedPhone,
            otpCode: normalizedOtp,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "تایید کد با خطا مواجه شد");
      }

      const message = result.isNewUser 
        ? "🎉 حساب کاربری شما با موفقیت ایجاد شد!" 
        : "✅ خوش آمدید!";
      
      toast.success(message);
      setIsLoggedIn(true);

      // Save user to localStorage and sessionStorage
      if (result.user?.user_id) {
        localStorage.setItem('userId', result.user.user_id.toString());
        localStorage.setItem('userPhone', result.user.phone || normalizedPhone);
        // Also save to sessionStorage for current session
        sessionStorage.setItem('userId', result.user.user_id.toString());
        logger.sensitive('User logged in:', result.user);
      }

      // Reload user context
      reloadUser();

      // Redirect to profile after 1.5 seconds
      setTimeout(() => {
        navigate('/profile');
      }, 1500);
    } catch (error: any) {
      logger.error("Error verifying OTP:", error);
      toast.error(error.message || "تایید کد با خطا مواجه شد");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResendOTP = async () => {
    setOtpCode("");
    await handleSendOTP();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F9E1B4]/20 via-white to-[#1A2011]/5 py-12 px-4">
      <div className="container mx-auto max-w-md">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Back Button */}
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-6 text-[#1A2011] hover:bg-[#F9E1B4]/20"
          >
            <ArrowRight className="w-4 h-4 ml-2" />
            بازگشت
          </Button>

          {/* Login Card */}
          <div className="bg-white rounded-[24px] shadow-lg border border-[#E8E8E8] overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-l from-[#1A2011] to-[#2d3820] text-white p-8 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm"
              >
                <User className="w-10 h-10" />
              </motion.div>
              <h1 className="text-2xl mb-2">ورود به نورسا</h1>
              <p className="text-white/80 text-sm">
                {otpSent
                  ? "کد تایید را وارد کنید"
                  : "شماره موبایل خود را وارد کنید"}
              </p>
            </div>

            {/* Content */}
            <div className="p-8">
              <AnimatePresence mode="wait">
                {!isLoggedIn ? (
                  <motion.div
                    key="login-form"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                  >
                    {!otpSent ? (
                      // Phone Input Step
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <Label htmlFor="phone" className="text-[#1A2011]">
                            <Smartphone className="w-4 h-4 inline ml-2" />
                            شماره موبایل
                          </Label>
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="09123456789"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            maxLength={11}
                            className="text-center text-lg tracking-wider"
                            dir="ltr"
                          />
                          <p className="text-xs text-gray-500 text-center">
                            کد تایید به این شماره ارسال می‌شود
                          </p>
                        </div>

                        <Button
                          onClick={handleSendOTP}
                          disabled={isSubmitting || phone.length < 11}
                          className="w-full bg-[#1A2011] hover:bg-[#2d3820] text-white rounded-[12px] h-12"
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                              در حال ارسال...
                            </>
                          ) : (
                            <>
                              <Smartphone className="w-4 h-4 ml-2" />
                              دریافت کد تایید
                            </>
                          )}
                        </Button>
                      </div>
                    ) : (
                      // OTP Verification Step
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <Label htmlFor="otp" className="text-[#1A2011]">
                            <Lock className="w-4 h-4 inline ml-2" />
                            کد تایید
                          </Label>
                          <Input
                            id="otp"
                            type="text"
                            placeholder="••••••"
                            value={otpCode}
                            onChange={(e) => {
                              const normalized = normalizeDigits(e.target.value);
                              setOtpCode(normalized.replace(/\D/g, ""));
                            }}
                            maxLength={6}
                            className="text-center text-2xl tracking-widest font-mono"
                            dir="ltr"
                          />
                          <p className="text-xs text-gray-500 text-center">
                            کد ۶ رقمی ارسال شده به {phone}
                          </p>
                        </div>

                        <div className="space-y-3">
                          <Button
                            onClick={handleVerifyOTP}
                            disabled={isSubmitting || otpCode.length !== 6}
                            className="w-full bg-[#1A2011] hover:bg-[#2d3820] text-white rounded-[12px] h-12"
                          >
                            {isSubmitting ? (
                              <>
                                <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                                در حال تایید...
                              </>
                            ) : (
                              <>
                                <Lock className="w-4 h-4 ml-2" />
                                تایید و ورود
                              </>
                            )}
                          </Button>

                          {timer > 0 ? (
                            <div className="text-center text-sm text-[#888888] h-10 flex items-center justify-center">
                              ارسال مجدد کد تا {formatTime(timer)} دیگر
                            </div>
                          ) : (
                            <Button
                              onClick={handleResendOTP}
                              variant="outline"
                              className="w-full rounded-[12px] border-[#E8E8E8]"
                            >
                              ارسال مجدد کد
                            </Button>
                          )}
                        </div>
                      </div>
                    )}
                  </motion.div>
                ) : (
                  // Success State
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-8"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2, type: "spring" }}
                      className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4"
                    >
                      <svg
                        className="w-10 h-10 text-green-500"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </motion.div>
                    <h2 className="text-2xl text-[#1A2011] mb-2">
                      ورود موفقیت‌آمیز!
                    </h2>
                    <p className="text-gray-600">
                      در حال انتقال به صفحه اصلی...
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}