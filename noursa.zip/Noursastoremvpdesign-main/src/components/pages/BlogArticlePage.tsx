import { useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { motion } from "motion/react";
import {
  ArrowRight,
  Calendar,
  ChevronLeft,
  Loader2,
  Clock,
} from "lucide-react";
import { Button } from "../ui/button";
import { Breadcrumb } from "../Breadcrumb";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../utils/supabase/info";

interface Article {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  featured: boolean;
  image_url?: string;
  created_at: string;
  reading_time?: string;
}

// Helper function to format date
function formatDate(dateString: string): string {
  try {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return new Intl.DateTimeFormat("fa-IR", options).format(date);
  } catch {
    return dateString;
  }
}

export function BlogArticlePage() {
  const { slug: articleSlug } = useParams();
  const navigate = useNavigate();
  const [article, setArticle] = useState<Article | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (articleSlug) {
      fetchArticle();
    }
  }, [articleSlug]);

  const fetchArticle = async () => {
    if (!articleSlug) return;
    try {
      // Fetch single article
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/articles/${articleSlug}`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch article");
      }

      const data = await response.json();
      setArticle(data.article);

      // Fetch related articles
      const relatedResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/articles`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (relatedResponse.ok) {
        const relatedData = await relatedResponse.json();
        const related = (relatedData.articles || [])
          .filter((a: Article) => a.slug !== articleSlug)
          .slice(0, 3);
        setRelatedArticles(related);
      }
    } catch (error) {
      console.error("Error fetching article:", error);
      toast.error("خطا در بارگذاری مقاله");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAFAFA] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#1A2011]" />
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen bg-[#FAFAFA] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl text-[#1A2011] mb-4">مقاله یافت نشد</h2>
          <Button onClick={() => navigate("/blog")}>بازگشت به مقالات</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA] py-8 pb-20">
      <div className="container mx-auto px-4 md:px-6 max-w-[1440px]">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Breadcrumb
            items={[
              { label: "خانه", onClick: () => navigate("/") },
              { label: "مقالات", onClick: () => navigate("/blog") },
              { label: article.title },
            ]}
          />
        </div>

        {/* Back Button */}
        <button
          onClick={() => navigate("/blog")}
          className="flex items-center gap-2 text-[#484D2C] mb-8 hover:gap-3 transition-all"
        >
          <ArrowRight size={20} />
          <span>بازگشت به مقالات</span>
        </button>

        {/* Main Article Card */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-[24px] border border-[#E8E8E8] overflow-hidden mb-8">
            {/* Hero Image */}
            <div className="h-[300px] md:h-[400px] bg-gradient-to-br from-[#484D2C] to-[#1A2011] flex items-center justify-center">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                <span className="text-[32px]">🌿</span>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 md:p-10">
              {/* Meta */}
              <div className="flex flex-wrap items-center gap-4 md:gap-6 text-[14px] text-[#888888] mb-6 pb-6 border-b border-[#E8E8E8]">
                <div className="flex items-center gap-2">
                  <Calendar size={18} />
                  <span>{formatDate(article.created_at)}</span>
                </div>
                {article.reading_time && (
                  <div className="flex items-center gap-2">
                    <Clock size={18} />
                    <span>{article.reading_time}</span>
                  </div>
                )}
                <div className="bg-[#F9E1B4]/30 text-[#484D2C] px-3 py-1.5 rounded-full text-[13px]">
                  {article.category}
                </div>
              </div>

              {/* Title */}
              <h1 className="text-[28px] md:text-[40px] text-[#1A2011] leading-tight mb-8">
                {article.title}
              </h1>

              {/* Article Body */}
              <ArticleContent content={article.content} />

              {/* CTA to Store */}
              <div className="mt-10 pt-8 border-t border-[#E8E8E8]">
                <button
                  onClick={() => navigate("/products")}
                  className="inline-flex items-center gap-2 h-[52px] px-8 bg-[#1A2011] text-white rounded-[12px] hover:bg-[#222222] shadow-lg transition-colors"
                >
                  <span>مشاهده محصولات نورسا</span>
                  <ChevronLeft size={20} />
                </button>
              </div>
            </div>
          </div>

          {/* Related Articles */}
          {relatedArticles.length > 0 && (
            <div>
              <h2 className="text-[22px] md:text-[26px] text-[#1A2011] mb-6">
                مقالات مرتبط
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {relatedArticles.map((relatedArticle) => (
                  <Link
                    key={relatedArticle.id || relatedArticle.slug}
                    to={`/read/${relatedArticle.slug}`}
                    className="bg-white rounded-[20px] border border-[#E8E8E8] overflow-hidden hover:shadow-lg transition-shadow group text-right block"
                  >
                    <motion.div whileHover={{ y: -4 }}>
                    {/* Image */}
                    <div className="h-[160px] bg-gradient-to-br from-[#484D2C]/10 to-[#F9E1B4]/30 flex items-center justify-center">
                      <span className="text-3xl">🌿</span>
                    </div>

                    {/* Content */}
                    <div className="p-5">
                      <div className="flex items-center gap-2 text-[12px] text-[#888888] mb-3">
                        <Calendar size={14} />
                        <span>{formatDate(relatedArticle.created_at)}</span>
                      </div>
                      <h3 className="text-[15px] text-[#1A2011] line-clamp-2 group-hover:text-[#484D2C] transition-colors">
                        {relatedArticle.title}
                      </h3>
                    </div>
                    </motion.div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ArticleContent({ content }: { content: string }) {
  // Parse content - split by double line breaks for paragraphs
  const blocks = content.split("\n\n").filter(block => block.trim());

  // Enhanced HTML-aware inline formatting renderer
  const renderInlineFormatting = (text: string): (string | JSX.Element)[] => {
    const elements: (string | JSX.Element)[] = [];
    let buffer = '';
    let elementKey = 0;

    // Function to parse a single segment and extract HTML/Markdown formatting
    const parseSegment = (segment: string, startKey: number): (string | JSX.Element)[] => {
      const result: (string | JSX.Element)[] = [];
      let key = startKey;
      
      // HTML tag regex - matches opening and closing tags
      const htmlRegex = /<(\w+)([^>]*)>(.*?)<\/\1>|<(br\s*\/?)>/gi;
      // Markdown bold regex
      const markdownBoldRegex = /\*\*(.*?)\*\*/g;
      
      let lastIndex = 0;
      let match;
      
      // First pass: handle HTML tags
      const htmlMatches: Array<{index: number, length: number, element: JSX.Element}> = [];
      
      while ((match = htmlRegex.exec(segment)) !== null) {
        const tag = match[1] || match[4];
        const attributes = match[2] || '';
        const innerContent = match[3] || '';
        
        if (tag === 'br') {
          htmlMatches.push({
            index: match.index,
            length: match[0].length,
            element: <br key={`br-${key++}`} />
          });
        } else if (tag === 'strong' || tag === 'b') {
          htmlMatches.push({
            index: match.index,
            length: match[0].length,
            element: <strong key={`strong-${key++}`} className="font-semibold text-[#1A2011]">{innerContent}</strong>
          });
        } else if (tag === 'em' || tag === 'i') {
          htmlMatches.push({
            index: match.index,
            length: match[0].length,
            element: <em key={`em-${key++}`} className="italic">{innerContent}</em>
          });
        } else if (tag === 'code') {
          htmlMatches.push({
            index: match.index,
            length: match[0].length,
            element: <code key={`code-${key++}`} className="bg-gray-100 px-2 py-1 rounded text-sm font-mono text-[#484D2C]">{innerContent}</code>
          });
        } else if (tag === 'a') {
          const hrefMatch = attributes.match(/href=["']([^"']*)["']/);
          const href = hrefMatch ? hrefMatch[1] : '#';
          htmlMatches.push({
            index: match.index,
            length: match[0].length,
            element: <a key={`a-${key++}`} href={href} className="text-[#484D2C] underline hover:text-[#1A2011]" target="_blank" rel="noopener noreferrer">{innerContent}</a>
          });
        } else if (tag === 'span') {
          htmlMatches.push({
            index: match.index,
            length: match[0].length,
            element: <span key={`span-${key++}`}>{innerContent}</span>
          });
        } else {
          // Unknown tag - just show content
          htmlMatches.push({
            index: match.index,
            length: match[0].length,
            element: <span key={`unknown-${key++}`}>{innerContent}</span>
          });
        }
      }
      
      // Build result with HTML elements inserted
      if (htmlMatches.length === 0) {
        // No HTML, check for markdown
        const mdBoldMatches: Array<{index: number, length: number, element: JSX.Element}> = [];
        
        while ((match = markdownBoldRegex.exec(segment)) !== null) {
          mdBoldMatches.push({
            index: match.index,
            length: match[0].length,
            element: <strong key={`md-bold-${key++}`} className="font-semibold text-[#1A2011]">{match[1]}</strong>
          });
        }
        
        if (mdBoldMatches.length === 0) {
          return [segment];
        }
        
        // Build with markdown
        lastIndex = 0;
        mdBoldMatches.forEach(item => {
          if (item.index > lastIndex) {
            result.push(segment.slice(lastIndex, item.index));
          }
          result.push(item.element);
          lastIndex = item.index + item.length;
        });
        
        if (lastIndex < segment.length) {
          result.push(segment.slice(lastIndex));
        }
        
        return result;
      }
      
      // Build with HTML elements
      lastIndex = 0;
      htmlMatches.forEach(item => {
        if (item.index > lastIndex) {
          // Check for markdown in the text between HTML tags
          const textBetween = segment.slice(lastIndex, item.index);
          const mdProcessed = parseSegment(textBetween, key);
          result.push(...mdProcessed);
          key += mdProcessed.length;
        }
        result.push(item.element);
        lastIndex = item.index + item.length;
      });
      
      if (lastIndex < segment.length) {
        const remaining = segment.slice(lastIndex);
        const mdProcessed = parseSegment(remaining, key);
        result.push(...mdProcessed);
      }
      
      return result;
    };
    
    return parseSegment(text, 0);
  };

  return (
    <div className="prose prose-lg max-w-none">
      {blocks.map((block, index) => {
        const trimmedBlock = block.trim();
        
        // Heading 2: ##
        if (trimmedBlock.startsWith("##")) {
          return (
            <h2
              key={index}
              className="text-[22px] md:text-[26px] text-[#1A2011] mt-10 mb-5 font-semibold"
            >
              {trimmedBlock.replace(/^##\s*/, "").trim()}
            </h2>
          );
        }

        // Heading 3: ###
        if (trimmedBlock.startsWith("###")) {
          return (
            <h3 key={index} className="text-[20px] text-[#1A2011] mt-8 mb-4 font-semibold">
              {trimmedBlock.replace(/^###\s*/, "").trim()}
            </h3>
          );
        }

        // Tip Box: 💡
        if (trimmedBlock.includes("💡")) {
          const tipText = trimmedBlock.replace(/💡\s*(نکته مهم:|نکته:)?/i, "").trim();
          return (
            <div
              key={index}
              className="bg-[#F9E1B4]/20 border-r-4 border-[#F9E1B4] rounded-[16px] p-6 md:p-8 my-8"
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">💡</span>
                <div className="flex-1">
                  <h4 className="text-[17px] font-semibold text-[#1A2011] mb-3">
                    نکته مهم
                  </h4>
                  <p className="text-[15px] md:text-[16px] text-[#444444] leading-[1.8]">
                    {renderInlineFormatting(tipText)}
                  </p>
                </div>
              </div>
            </div>
          );
        }

        // Blockquote: starts with >
        if (trimmedBlock.startsWith(">")) {
          return (
            <blockquote
              key={index}
              className="border-r-4 border-[#484D2C] bg-[#FAFAFA] pr-6 py-4 my-6 rounded-r-[12px]"
            >
              <p className="text-[16px] md:text-[17px] text-[#444444] leading-[1.8] italic">
                {renderInlineFormatting(trimmedBlock.replace(/^>\s*/, "").trim())}
              </p>
            </blockquote>
          );
        }

        // Unordered List: lines starting with • or - or *
        const listLines = trimmedBlock.split("\n");
        const isUnorderedList = listLines.every(
          line => line.trim().match(/^[•\-*]\s+/)
        );
        
        if (isUnorderedList && listLines.length > 1) {
          return (
            <ul key={index} className="space-y-3 my-6 pr-6">
              {listLines.map((line, i) => {
                const cleanLine = line.trim().replace(/^[•\-*]\s+/, "");
                return (
                  <li
                    key={i}
                    className="text-[16px] md:text-[17px] text-[#444444] leading-[1.8] relative before:content-['●'] before:absolute before:-right-5 before:text-[#484D2C]"
                  >
                    {renderInlineFormatting(cleanLine)}
                  </li>
                );
              })}
            </ul>
          );
        }

        // Ordered List: lines starting with 1. 2. etc or ۱. ۲. etc
        const isOrderedList = listLines.every(
          line => line.trim().match(/^(\d+|[۰-۹]+)[.)]\s+/)
        );
        
        if (isOrderedList && listLines.length > 1) {
          return (
            <ol key={index} className="space-y-3 my-6 pr-8 list-decimal list-inside">
              {listLines.map((line, i) => {
                const cleanLine = line.trim().replace(/^(\d+|[۰-۹]+)[.)]\s+/, "");
                return (
                  <li
                    key={i}
                    className="text-[16px] md:text-[17px] text-[#444444] leading-[1.8]"
                  >
                    {renderInlineFormatting(cleanLine)}
                  </li>
                );
              })}
            </ol>
          );
        }

        // Horizontal Rule: --- or ***
        if (trimmedBlock.match(/^(-{3,}|\*{3,})$/)) {
          return (
            <hr
              key={index}
              className="my-10 border-t-2 border-[#E8E8E8]"
            />
          );
        }

        // Regular paragraph - skip empty ones
        if (trimmedBlock.length === 0) {
          return null;
        }

        return (
          <p
            key={index}
            className="text-[16px] md:text-[18px] text-[#444444] leading-[1.9] mb-6"
          >
            {renderInlineFormatting(trimmedBlock)}
          </p>
        );
      })}
    </div>
  );
}