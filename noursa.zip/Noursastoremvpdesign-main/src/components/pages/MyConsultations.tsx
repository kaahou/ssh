import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Clock, CheckCircle, ChevronLeft, AlertCircle } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import { useUser } from '../UserContext';

interface Consultation {
  id: string;
  phone: string;
  first_name?: string;
  last_name?: string;
  created_at: string;
  consultation_result?: string | null;
  status: string;
  personal_info?: any;
}

export function MyConsultations() {
  const navigate = useNavigate();
  const { user } = useUser();
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [loading, setLoading] = useState(true);
  const [phoneInput, setPhoneInput] = useState('');
  const [showPhonePrompt, setShowPhonePrompt] = useState(false);

  // Helper function to navigate to consultation detail
  const handleConsultationClick = (consultation: Consultation) => {
    // Save phone to localStorage for ConsultationDetail page
    localStorage.setItem('consultation_phone', consultation.phone);
    navigate(`/profile/consultations/${consultation.id}`);
  };

  useEffect(() => {
    const controller = new AbortController();
    
    const loadConsultations = async () => {
      const savedPhone = localStorage.getItem('consultation_phone');
      const userPhone = user?.phone;
      const phoneToUse = userPhone || savedPhone;

      if (phoneToUse) {
        try {
          setLoading(true);
          const response = await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/consultations/by-phone/${phoneToUse}`,
            {
              headers: {
                Authorization: `Bearer ${publicAnonKey}`,
              },
              signal: controller.signal,
            }
          );

          if (response.ok) {
            const data = await response.json();
            setConsultations(data.consultations || []);
            setShowPhonePrompt(false);
          } else {
            console.error('Failed to fetch consultations');
          }
        } catch (error: any) {
          if (error.name === 'AbortError') {
            return;
          }
          console.error('Error fetching consultations:', error);
        } finally {
          setLoading(false);
        }
      } else {
        setLoading(false);
        setShowPhonePrompt(true);
      }
    };

    loadConsultations();
    
    return () => controller.abort();
  }, [user]);

  const fetchConsultations = async (phone: string) => {
    const controller = new AbortController();
    
    try {
      setLoading(true);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/consultations/by-phone/${phone}`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
          signal: controller.signal,
        }
      );

      if (response.ok) {
        const data = await response.json();
        setConsultations(data.consultations || []);
        // Save phone to localStorage for future visits
        localStorage.setItem('consultation_phone', phone);
        setShowPhonePrompt(false);
      } else {
        console.error('Failed to fetch consultations');
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        return;
      }
      console.error('Error fetching consultations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneInput && phoneInput.length >= 11) {
      fetchConsultations(phoneInput);
    }
  };

  const getStatusInfo = (consultation: Consultation) => {
    if (consultation.consultation_result && consultation.consultation_result.trim() !== '') {
      return {
        label: 'پاسخ داده شده',
        color: 'bg-[#D1FAE5] text-[#065F46]',
        icon: CheckCircle
      };
    }
    return {
      label: 'در حال بررسی',
      color: 'bg-[#FEF3C7] text-[#92400E]',
      icon: Clock
    };
  };

  if (showPhonePrompt) {
    return (
      <div className="max-w-md mx-auto">
        <div className="bg-white rounded-[24px] border border-[#E8E8E8] p-8 shadow-sm">
          <div className="text-center mb-6">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#1A2011] flex items-center justify-center">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl mb-2 text-[#1A2011]">مشاوره‌های من</h2>
            <p className="text-[#666666]">
              لطفا شماره موبایلی که با آن مشاوره ثبت کرده‌اید را وارد کنید
            </p>
          </div>

          <form onSubmit={handlePhoneSubmit}>
            <div className="mb-4">
              <label className="block text-sm mb-2 text-[#1A2011]">شماره موبایل</label>
              <input
                type="tel"
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                placeholder="09123456789"
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:outline-none focus:border-[#1A2011] focus:bg-white"
                maxLength={11}
                dir="ltr"
              />
            </div>

            <button
              type="submit"
              disabled={!phoneInput || phoneInput.length < 11}
              className="w-full h-[48px] bg-[#1A2011] text-white rounded-[12px] hover:bg-[#484D2C] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              مشاهده مشاوره‌ها
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1A2011] border-r-transparent"></div>
        <p className="mt-4 text-[#888888]">در حال بارگذاری...</p>
      </div>
    );
  }

  if (consultations.length === 0) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-[24px] border border-[#E8E8E8] p-12 shadow-sm text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-[#FAFAFA] flex items-center justify-center">
            <AlertCircle className="w-10 h-10 text-[#888888]" />
          </div>
          <h2 className="text-2xl mb-3 text-[#1A2011]">هنوز مشاوره‌ای ثبت نکرده‌اید</h2>
          <p className="text-[#666666] mb-6">
            برای دریافت مشاوره تخصصی از متخصصین نورسا، می‌توانید فرم مشاوره را تکمیل کنید
          </p>
          <button
            onClick={() => navigate('/consultation')}
            className="px-6 py-3 bg-[#1A2011] text-white rounded-[12px] hover:bg-[#484D2C] transition-colors"
          >
            درخواست مشاوره جدید
          </button>
          
          <div className="mt-6">
            <button
              onClick={() => setShowPhonePrompt(true)}
              className="text-sm text-[#666666] hover:text-[#1A2011] transition-colors"
            >
              شماره موبایل دیگری دارید؟
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl text-[#1A2011]">مشاوره‌های من</h2>
        <button
          onClick={() => setShowPhonePrompt(true)}
          className="text-sm text-[#666666] hover:text-[#1A2011] transition-colors"
        >
          ��غییر شماره موبایل
        </button>
      </div>

      <div className="space-y-4">
        {consultations.map((consultation) => {
          const statusInfo = getStatusInfo(consultation);
          const StatusIcon = statusInfo.icon;
          
          return (
            <div
              key={consultation.id}
              onClick={() => handleConsultationClick(consultation)}
              className="bg-white rounded-[16px] border border-[#E8E8E8] p-6 hover:border-[#1A2011] hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-[#FAFAFA] flex items-center justify-center group-hover:bg-[#1A2011] transition-colors">
                      <MessageSquare className="w-6 h-6 text-[#1A2011] group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <h3 className="text-lg text-[#1A2011]">
                        مشاوره سلامت مو
                      </h3>
                      <p className="text-sm text-[#888888]">
                        {new Date(consultation.created_at).toLocaleDateString('fa-IR', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm ${statusInfo.color}`}>
                      <StatusIcon size={16} />
                      {statusInfo.label}
                    </span>
                    <span className="text-sm text-[#888888] font-mono">
                      کد: {String(consultation.id).slice(0, 8)}
                    </span>
                  </div>

                  {consultation.consultation_result && (
                    <p className="text-sm text-[#16A34A] font-medium">
                      ✓ نتیجه مشاوره آماده است
                    </p>
                  )}
                </div>

                <div className="mr-4">
                  <ChevronLeft className="w-6 h-6 text-[#888888] group-hover:text-[#1A2011] transition-colors" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 text-center">
        <button
          onClick={() => navigate('/consultation')}
          className="px-6 py-3 bg-[#1A2011] text-white rounded-[12px] hover:bg-[#484D2C] transition-colors"
        >
          درخواست مشاوره جدید
        </button>
      </div>
    </div>
  );
}