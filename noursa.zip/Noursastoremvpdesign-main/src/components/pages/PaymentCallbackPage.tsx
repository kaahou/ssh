import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Loader2, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "../ui/button";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { useCart } from "../CartContext";
import { logger } from "../../src/utils/logger";

export function PaymentCallbackPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { clearCart } = useCart();
  const [status, setStatus] = useState<"loading" | "success" | "failed">("loading");
  const [message, setMessage] = useState("در حال بررسی وضعیت پرداخت...");

  const authority = searchParams.get("Authority");
  const paymentStatus = searchParams.get("Status");

  useEffect(() => {
    let mounted = true;

    async function verify() {
      // Avoid double verification if strict mode
      if (!mounted) return;

      if (!authority || paymentStatus !== "OK") {
        setStatus("failed");
        setMessage("پرداخت ناموفق بود یا توسط کاربر لغو شد.");
        return;
      }

      const pendingOrderJson = localStorage.getItem("pendingPaymentOrder");
      if (!pendingOrderJson) {
        setStatus("failed");
        setMessage("اطلاعات سفارش یافت نشد.");
        return;
      }

      try {
        const pendingOrder = JSON.parse(pendingOrderJson);
        const { orderId, amount } = pendingOrder;

        logger.log(`Verifying payment for Order ${orderId}, Amount: ${amount}, Authority: ${authority}`);
        
        const amountInRials = amount * 10; // Convert Toman to Rial

        // Verify with backend
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/payment/zarinpal/verify`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({
              authority,
              amount: amountInRials,
              orderId: orderId,
            }),
          }
        );

        const data = await response.json();

        if (response.ok && (data.success || data.code === 100 || data.code === 101)) {
          // Update order status
          const updateResponse = await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders/${orderId}/status`,
            {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${publicAnonKey}`,
              },
              body: JSON.stringify({
                status: "processing", 
                payment_info: {
                  method: "zarinpal",
                  ref_id: data.ref_id,
                  card_pan: data.card_pan,
                  authority: authority,
                  status: "paid_zarinpal",
                  paid_at: new Date().toISOString(),
                },
              }),
            }
          );

          if (updateResponse.ok) {
            setStatus("success");
            setMessage("پرداخت با موفقیت انجام شد. سفارش شما ثبت گردید.");
            clearCart();
            localStorage.removeItem("pendingPaymentOrder");
            
            // Redirect to orders page after 2 seconds
            setTimeout(() => {
              navigate("/profile/orders");
            }, 2000);
          } else {
             logger.error("Order status update failed", await updateResponse.text());
             // Payment was successful but order update failed. 
             // Ideally we should tell user to contact support with RefID.
             setStatus("success"); 
             setMessage(`پرداخت انجام شد اما بروزرسانی سفارش با خطا مواجه شد. لطفا کد پیگیری ${data.ref_id} را به پشتیبانی اعلام کنید.`);
             clearCart();
             localStorage.removeItem("pendingPaymentOrder");
             
             // Redirect to orders page after 3 seconds
             setTimeout(() => {
               navigate("/profile/orders");
             }, 3000);
          }
        } else {
          logger.error("Payment verification failed", data);
          setStatus("failed");
          setMessage("پرداخت تایید نشد. مبلغ کسر شده طی ۷۲ ساعت به حساب شما بازخواهد گشت.");
        }
      } catch (error) {
        logger.error("Payment verification error:", error);
        setStatus("failed");
        setMessage("خطا در ارتباط با سرور. لطفا با پشتیبانی تماس بگیرید.");
      }
    }

    if (status === "loading") {
        verify();
    }

    return () => { mounted = false; };
  }, [authority, paymentStatus]);

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
      {status === "loading" && (
        <div className="text-center">
          <Loader2 className="w-16 h-16 text-primary animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">در حال پردازش پرداخت...</h2>
          <p className="text-muted-foreground">لطفا صبر کنید</p>
        </div>
      )}

      {status === "success" && (
        <div className="text-center max-w-md">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-green-700 mb-4">پرداخت موفق</h2>
          <p className="text-gray-600 mb-8">{message}</p>
          <div className="flex gap-4 justify-center">
            <Button onClick={() => navigate("/")} variant="outline">
              بازگشت به خانه
            </Button>
            <Button onClick={() => navigate("/profile/orders")}>
              پیگیری سفارش
            </Button>
          </div>
        </div>
      )}

      {status === "failed" && (
        <div className="text-center max-w-md">
          <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <XCircle className="w-10 h-10 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-red-700 mb-4">پرداخت ناموفق</h2>
          <p className="text-gray-600 mb-8">{message}</p>
          <div className="flex gap-4 justify-center">
            <Button onClick={() => navigate("/checkout")} variant="outline">
              تلاش مجدد
            </Button>
            <Button onClick={() => navigate("/")} variant="ghost">
              بازگشت به خانه
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}