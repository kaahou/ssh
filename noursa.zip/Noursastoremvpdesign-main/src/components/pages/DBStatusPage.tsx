import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../ui/button";
import { ArrowRight, Loader2, CheckCircle, XCircle, Database } from "lucide-react";
import { projectId, publicAnonKey } from "../../utils/supabase/info";

export function DBStatusPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function checkStatus() {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/db-status`,
          {
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
          }
        );

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${await response.text()}`);
        }

        const data = await response.json();
        setStatus(data);
      } catch (err: any) {
        console.error("Error checking DB status:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    checkStatus();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4" dir="rtl">
      <div className="container mx-auto max-w-4xl">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6 text-[#1A2011] hover:bg-[#F9E1B4]/20"
        >
          <ArrowRight className="w-4 h-4 ml-2" />
          بازگشت
        </Button>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex items-center gap-3 mb-6">
            <Database className="w-8 h-8 text-[#1A2011]" />
            <h1 className="text-2xl">وضعیت دیتابیس</h1>
          </div>

          {loading && (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-[#1A2011]" />
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
              <p className="mb-2">❌ خطا در اتصال به سرور</p>
              <pre className="text-xs bg-red-100 p-2 rounded overflow-auto">
                {error}
              </pre>
            </div>
          )}

          {status && (
            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">
                  آخرین بررسی: {new Date(status.timestamp).toLocaleString("fa-IR")}
                </p>
              </div>

              <div className="space-y-4">
                {Object.entries(status.checks || {}).map(([tableName, check]: [string, any]) => (
                  <div
                    key={tableName}
                    className={`border rounded-lg p-4 ${
                      check.exists
                        ? "border-green-200 bg-green-50"
                        : "border-red-200 bg-red-50"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {check.exists ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <XCircle className="w-5 h-5 text-red-600" />
                        )}
                        <div>
                          <h3 className="font-medium text-lg">
                            جدول {tableName}
                          </h3>
                          {check.exists && (
                            <p className="text-sm text-gray-600 mt-1">
                              تعداد رکوردها: {check.count}
                            </p>
                          )}
                          {check.error && (
                            <p className="text-sm text-red-600 mt-1">
                              خطا: {check.error}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm">
                <p className="mb-2">📋 اطلاعات کامل:</p>
                <pre className="text-xs bg-white p-3 rounded overflow-auto max-h-96">
                  {JSON.stringify(status, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
