import { useState, useEffect } from "react";
import { Search, SlidersHorizontal, ChevronRight, ChevronLeft } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { Product, ProductCard } from "../ProductCard";
import { useCart } from "../CartContext";
import { toast } from "sonner@2.0.3";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { logger } from "../../src/utils/logger";

interface ProductListPageProps {
  products: Product[];
  categorySlug?: string; // Optional category slug for direct category access
}

interface Category {
  categories_id?: number;
  id?: number;
  name: string;
  slug: string;
}

export function ProductListPage({ products, categorySlug }: ProductListPageProps) {
  const { addItem } = useCart();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCategoryId = searchParams.get("category");
  
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(initialCategoryId || "all");
  const [sortBy, setSortBy] = useState("score"); // تغییر از "default" به "score"
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(8); // Default for lg screens (4 cols x 2 rows)

  // Update items per page based on screen size
  useEffect(() => {
    const updateItemsPerPage = () => {
      const width = window.innerWidth;
      if (width < 768) {
        setItemsPerPage(4); // mobile: 2 cols x 2 rows
      } else if (width < 1024) {
        setItemsPerPage(6); // tablet: 3 cols x 2 rows
      } else {
        setItemsPerPage(8); // desktop: 4 cols x 2 rows
      }
    };

    updateItemsPerPage();
    window.addEventListener('resize', updateItemsPerPage);
    return () => window.removeEventListener('resize', updateItemsPerPage);
  }, []);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, selectedCategory, sortBy]);

  // Helper to normalize Persian text for comparison
  const normalizePersian = (str: string) => {
    if (!str) return "";
    return str
      .replace(/ي/g, "ی")
      .replace(/ك/g, "ک")
      .replace(/آ/g, "ا")
      .replace(/\u200C/g, " ") // Replace half-space with space
      .trim()
      .toLowerCase();
  };

  // Helper to tokenize string into words
  const tokenize = (str: string) => {
    return normalizePersian(str).split(/[\s\-_.،,]+/).filter(t => t.length > 2);
  };

  // Update selected category when URL param changes
  useEffect(() => {
    if (initialCategoryId) {
      setSelectedCategory(initialCategoryId);
    } else {
      setSelectedCategory("all");
    }
  }, [initialCategoryId]);

  // Fetch categories from backend
  useEffect(() => {
    async function fetchCategories() {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/categories`,
          {
            headers: {
              Authorization: `Bearer ${publicAnonKey}`,
            },
          }
        );

        if (!response.ok) {
          throw new Error("Failed to fetch categories");
        }

        const data = await response.json();
        setCategories(data.categories || []);
      } catch (error) {
        logger.error("Error fetching categories:", error);
      } finally {
        setIsLoadingCategories(false);
      }
    }

    fetchCategories();
  }, []);

  // Handle categorySlug prop - Set selected category based on slug
  useEffect(() => {
    if (categorySlug && categories.length > 0) {
      // Find category with matching slug
      const matchingCategory = categories.find(c => c.slug === categorySlug);
      if (matchingCategory) {
        const catId = String(matchingCategory.categories_id || matchingCategory.id);
        setSelectedCategory(catId);
        logger.log(`Category slug ${categorySlug} matched to category ID ${catId}`);
      } else {
        logger.warn(`No category found with slug: ${categorySlug}`);
        setSelectedCategory("all");
      }
    } else if (!categorySlug && !initialCategoryId) {
      // Only reset to "all" if there's no categorySlug and no URL param
      setSelectedCategory("all");
    }
  }, [categorySlug, categories, initialCategoryId]);

  const handleAddToCart = (product: Product) => {
    addItem(product);
    const productName = product.variant_name 
      ? `${product.variant_name} ${product.product_name}` 
      : (product.product_name || product.name || 'محصول');
    toast.success(`${productName} به سبد خرید اضافه شد`);
  };

  // Find name of selected category for legacy matching
  const selectedCategoryObj = categories.find(c => 
    String(c.categories_id || c.id) === selectedCategory
  );
  const selectedCategoryName = selectedCategoryObj ? selectedCategoryObj.name : null;

  // Filter products
  let filteredProducts = products.filter((product) => {
    // Match search query - if empty, match all
    const query = normalizePersian(searchQuery);
    
    // Create combined product name for search
    const productName = product.variant_name 
      ? `${product.variant_name} ${product.product_name}` 
      : (product.product_name || product.name || '');
    
    const shortDescription = product.short_description || '';
    const variantName = product.variant_name || '';
    const originalName = product.product_name || '';
    
    const matchesSearch = query === "" || 
      (productName && normalizePersian(productName).includes(query)) ||
      (shortDescription && normalizePersian(shortDescription).includes(query)) ||
      (variantName && normalizePersian(variantName).includes(query)) ||
      (originalName && normalizePersian(originalName).includes(query));
    
    // Category filtering
    let matchesCategory = selectedCategory === "all";
    
    if (!matchesCategory) {
      // 1. Try matching by category_id (Preferred & Exact)
      const productCategoryId = product.category_id;
      if (productCategoryId !== null && productCategoryId !== undefined) {
        if (String(productCategoryId) === selectedCategory) {
          matchesCategory = true;
        }
      }
      
      // 2. Legacy Support: Try matching by category name string
      // Only works if categories are loaded and we found the name for the ID
      if (!matchesCategory && selectedCategoryName && product.category) {
        const pCat = normalizePersian(product.category);
        const sCat = normalizePersian(selectedCategoryName);
        
        // A. Direct containment
        if (pCat === sCat || pCat.includes(sCat) || sCat.includes(pCat)) {
          matchesCategory = true;
        } else {
          // B. Token-based matching (Fuzzy)
          // Split both strings into words and check for overlap
          const pTokens = tokenize(product.category);
          const sTokens = tokenize(selectedCategoryName);
          
          // If any significant word matches, we consider it a match
          // We filter out very short words in tokenize to avoid false positives on "و", "از", etc.
          const hasOverlap = pTokens.some(pt => 
            sTokens.some(st => st.includes(pt) || pt.includes(st))
          );
          
          if (hasOverlap) {
            matchesCategory = true;
          }
        }
      }

      // 3. Fallback: Try matching product.category (string) against selectedCategory (ID)
      if (!matchesCategory && product.category && String(product.category) === selectedCategory) {
        matchesCategory = true;
      }
    }
    
    return matchesSearch && matchesCategory;
  });

  // Sort products
  if (sortBy === "score") {
    // مرتب‌سازی بر اساس امتیاز (بالاترین امتیاز اول)
    filteredProducts = [...filteredProducts].sort((a, b) => {
      const scoreA = a.score ?? -1; // محصولات بدون امتیاز در آخر
      const scoreB = b.score ?? -1;
      if (scoreB !== scoreA) {
        return scoreB - scoreA; // امتیاز بالاتر اول
      }
      // اگر امتیاز یکسان بود، جدیدترها اول
      const dateA = new Date(a.created_at || 0).getTime();
      const dateB = new Date(b.created_at || 0).getTime();
      return dateB - dateA;
    });
  } else if (sortBy === "price-low") {
    filteredProducts = [...filteredProducts].sort((a, b) => a.price - b.price);
  } else if (sortBy === "price-high") {
    filteredProducts = [...filteredProducts].sort((a, b) => b.price - a.price);
  } else if (sortBy === "name") {
    filteredProducts = [...filteredProducts].sort((a, b) => {
      const nameA = a.variant_name ? `${a.variant_name} ${a.product_name}` : (a.product_name || a.name || '');
      const nameB = b.variant_name ? `${b.variant_name} ${b.product_name}` : (b.product_name || b.name || '');
      return nameA.localeCompare(nameB);
    });
  } else if (sortBy === "default") {
    // مرتب‌سازی پیش‌فرض نیز بر اساس score (همان منطق score)
    filteredProducts = [...filteredProducts].sort((a, b) => {
      const scoreA = a.score ?? -1;
      const scoreB = b.score ?? -1;
      if (scoreB !== scoreA) {
        return scoreB - scoreA;
      }
      const dateA = new Date(a.created_at || 0).getTime();
      const dateB = new Date(b.created_at || 0).getTime();
      return dateB - dateA;
    });
  }

  // Pagination logic
  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedProducts = filteredProducts.slice(startIndex, endIndex);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Show loading state if filtering by category but categories haven't loaded yet
  // This prevents "No products found" flash when we rely on name matching
  const isWaitingForCategoryMatch = selectedCategory !== "all" && isLoadingCategories;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="mb-2 text-[#1A2011]">محصولات</h1>
        <p className="text-[#888888]">
          {isWaitingForCategoryMatch ? "..." : filteredProducts.length} محصول یافت شد
        </p>
      </div>

      {/* Filters */}
      <div className="mb-8 space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#888888]" />
          <Input
            type="text"
            placeholder="جستجوی محصول..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10 rounded-[12px] border-[#E8E8E8] h-[48px]"
          />
        </div>

        {/* Category and Sort */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            {isLoadingCategories ? (
              <div className="flex items-center gap-2 w-full h-[48px] px-3 rounded-[12px] border border-[#E8E8E8] bg-white opacity-70 cursor-wait">
                <SlidersHorizontal className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">در حال بارگذاری دسته‌بندی‌ها...</span>
              </div>
            ) : (
              <Select 
                value={selectedCategory} 
                onValueChange={(val) => {
                  setSelectedCategory(val);
                  const newParams = new URLSearchParams(searchParams);
                  if (val === 'all') {
                    newParams.delete('category');
                  } else {
                    newParams.set('category', val);
                  }
                  setSearchParams(newParams);
                }}
              >
                <SelectTrigger className="rounded-[12px] border-[#E8E8E8] h-[48px]">
                  <div className="flex items-center gap-2 w-full">
                    <SlidersHorizontal className="w-4 h-4" />
                    <SelectValue placeholder="دسته‌بندی" />
                  </div>
                </SelectTrigger>
                <SelectContent className="rounded-[12px]">
                  <SelectItem key="all" value="all">همه محصولات</SelectItem>
                  {categories.map((cat) => {
                    const catId = cat.categories_id || cat.id;
                    if (!catId) return null;
                    return (
                      <SelectItem key={catId} value={String(catId)}>
                        {cat.name}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="flex-1">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="rounded-[12px] border-[#E8E8E8] h-[48px]">
                <SelectValue placeholder="مرتب‌سازی" />
              </SelectTrigger>
              <SelectContent className="rounded-[12px]">
                <SelectItem key="default" value="default">پیش‌فرض</SelectItem>
                <SelectItem key="price-low" value="price-low">قیمت: کم به زیاد</SelectItem>
                <SelectItem key="price-high" value="price-high">قیمت: زیاد به کم</SelectItem>
                <SelectItem key="name" value="name">نام محصول</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      {isWaitingForCategoryMatch ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-[300px] rounded-[16px] bg-gray-100 animate-pulse border border-[#E8E8E8]" />
          ))}
        </div>
      ) : filteredProducts.length > 0 ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {paginatedProducts.map((product, index) => {
              const productSlug = product.slug || product.product_id || product.id;
              // Priority load first 4 products (above the fold)
              const isPriority = currentPage === 1 && index < 4;
              
              return (
                <Link
                  key={String(product.product_id || product.id)}
                  to={`/product/${productSlug}`}
                  className="cursor-pointer block"
                >
                  <ProductCard
                    product={product}
                    onAddToCart={(product) => handleAddToCart(product)}
                    priority={isPriority}
                  />
                </Link>
              );
            })}
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-4 mt-8">
              <Button
                variant="outline"
                onClick={handlePrevPage}
                disabled={currentPage === 1}
                className="rounded-[12px] border-[#E8E8E8] hover:border-[#1A2011] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronRight className="w-5 h-5" />
                <span>قبلی</span>
              </Button>

              <div className="flex items-center gap-2">
                <span className="text-[#888888] text-sm">
                  صفحه {currentPage} از {totalPages}
                </span>
              </div>

              <Button
                variant="outline"
                onClick={handleNextPage}
                disabled={currentPage === totalPages}
                className="rounded-[12px] border-[#E8E8E8] hover:border-[#1A2011] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span>بعدی</span>
                <ChevronLeft className="w-5 h-5" />
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-16">
          <p className="text-[#888888] mb-4">
            محصولی با این مشخصات یافت نشد
          </p>
          <Button
            variant="outline"
            onClick={() => {
              setSearchQuery("");
              setSelectedCategory("all");
              setSortBy("default");
            }}
            className="rounded-[12px] border-[#E8E8E8] hover:border-[#1A2011]"
          >
            پاک کردن فیلترها
          </Button>
        </div>
      )}
    </div>
  );
}