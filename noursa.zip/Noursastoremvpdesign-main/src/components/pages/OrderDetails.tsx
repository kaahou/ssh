import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowRight, ShoppingBag, MapPin, Phone, Mail, Package, Calendar, CreditCard, Loader2 } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface OrderItem {
  id: number;
  product_id: number;
  product_name: string;
  quantity: number;
  unit_price: number;
}

interface Order {
  id: string;
  customer_name?: string;
  phone?: string;
  address?: string;
  created_at: string;
  status: string;
  payment_status: string;
  subtotal: number;
  post_price: number;
  discount_amount: number;
  total_amount: number;
}

export function OrderDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrderDetails();
  }, [id]);

  const fetchOrderDetails = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/orders/${id}`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        setOrder(data.order);
        setItems(data.items || []);
      } else {
        console.error('Failed to fetch order details');
      }
    } catch (error) {
      console.error('Error fetching order details:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'processing': return 'در حال پردازش';
      case 'cancelled': return 'لغو شده';
      case 'pending': return 'در انتظار';
      default: return status;
    }
  };

  const getPaymentStatusLabel = (paymentStatus: string) => {
    switch (paymentStatus) {
      case 'paid_zarinpal': return 'پرداخت شده (زرین‌پال)';
      case 'paid_card': return 'پرداخت شده (کارت به کارت)';
      case 'paid_manual': return 'پرداخت شده (دستی)';
      case 'awaiting_verification': return 'در انتظار تایید پرداخت';
      case 'pending': return 'در انتظار پرداخت';
      case 'unpaid_manual': return 'پرداخت نشده';
      default: return paymentStatus;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-[#1A2011] animate-spin mx-auto mb-4" />
          <p className="text-[#888888]">در حال بارگذاری جزئیات سفارش...</p>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <div className="bg-white rounded-[24px] border border-[#E8E8E8] p-12">
          <h2 className="text-2xl mb-3 text-[#1A2011]">سفارش یافت نشد</h2>
          <p className="text-[#666666] mb-6">
            متأسفانه سفارش مورد نظر یافت نشد
          </p>
          <button
            onClick={() => navigate('/profile/orders')}
            className="px-6 py-3 bg-[#1A2011] text-white rounded-[12px] hover:bg-[#484D2C] transition-colors"
          >
            بازگشت به سفارشات
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={() => navigate('/profile/orders')}
          className="flex items-center gap-2 text-[#666666] hover:text-[#1A2011] transition-colors mb-4"
        >
          <ArrowRight size={20} />
          بازگشت به سفارشات
        </button>
        <h1 className="text-2xl text-[#1A2011]">جزئیات سفارش</h1>
      </div>

      <div className="space-y-6">
        {/* Order Info Card */}
        <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-[#F9E1B4]/20 rounded-full flex items-center justify-center">
              <ShoppingBag size={24} className="text-[#484D2C]" />
            </div>
            <div>
              <h2 className="text-lg text-[#1A2011]">سفارش شماره {String(order.id).slice(-8)}</h2>
              <p className="text-sm text-[#888888]">
                {new Date(order.created_at).toLocaleDateString('fa-IR', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-[#E8E8E8]">
            <div>
              <p className="text-sm text-[#888888] mb-1">وضعیت سفارش</p>
              <p className="text-[#1A2011]">{getStatusLabel(order.status)}</p>
            </div>
            <div>
              <p className="text-sm text-[#888888] mb-1">وضعیت پرداخت</p>
              <p className="text-[#1A2011]">{getPaymentStatusLabel(order.payment_status)}</p>
            </div>
          </div>
        </div>

        {/* Customer Info Card */}
        <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
          <h3 className="text-lg text-[#1A2011] mb-4">اطلاعات</h3>
          
          <div className="space-y-3">
            {order.customer_name && (
              <div className="flex items-start gap-3">
                <Package size={20} className="text-[#888888] mt-0.5" />
                <div>
                  <p className="text-sm text-[#888888]">نام</p>
                  <p className="text-[#1A2011]">{order.customer_name}</p>
                </div>
              </div>
            )}

            {order.phone && (
              <div className="flex items-start gap-3">
                <Phone size={20} className="text-[#888888] mt-0.5" />
                <div>
                  <p className="text-sm text-[#888888]">شماره تماس</p>
                  <p className="text-[#1A2011]" dir="ltr">{order.phone}</p>
                </div>
              </div>
            )}

            {order.address && (
              <div className="flex items-start gap-3">
                <MapPin size={20} className="text-[#888888] mt-0.5" />
                <div>
                  <p className="text-sm text-[#888888]">آدرس ارسال</p>
                  <p className="text-[#1A2011]">{order.address}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Order Items Card */}
        <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
          <h3 className="text-lg text-[#1A2011] mb-4">محصولات سفارش</h3>
          
          <div className="space-y-3">
            {items.map((item, index) => (
              <div
                key={item.id || index}
                className="flex items-center justify-between p-4 bg-[#FAFAFA] rounded-[12px]"
              >
                <div className="flex-1">
                  <p className="text-[#1A2011] mb-1">{item.product_name}</p>
                  <p className="text-sm text-[#888888]">
                    تعداد: {item.quantity.toLocaleString('fa-IR')} عدد
                  </p>
                </div>
                <div className="text-left">
                  <p className="text-[#1A2011]">
                    {item.unit_price.toLocaleString('fa-IR')} تومان
                  </p>
                  <p className="text-sm text-[#888888]">
                    جمع: {(item.unit_price * item.quantity).toLocaleString('fa-IR')} تومان
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Price Summary Card */}
        <div className="bg-white rounded-[20px] border border-[#E8E8E8] p-6">
          <h3 className="text-lg text-[#1A2011] mb-4">خلاصه مالی</h3>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-[#E8E8E8]">
              <span className="text-[#666666]">جمع محصولات</span>
              <span className="text-[#1A2011]">{order.subtotal.toLocaleString('fa-IR')} تومان</span>
            </div>

            <div className="flex items-center justify-between pb-3 border-b border-[#E8E8E8]">
              <span className="text-[#666666]">هزینه ارسال</span>
              <span className="text-[#1A2011]">
                {order.post_price === 0 ? 'رایگان' : `${order.post_price.toLocaleString('fa-IR')} تومان`}
              </span>
            </div>

            {order.discount_amount > 0 && (
              <div className="flex items-center justify-between pb-3 border-b border-[#E8E8E8]">
                <span className="text-[#666666]">تخفیف</span>
                <span className="text-[#DC2626]">-{order.discount_amount.toLocaleString('fa-IR')} تومان</span>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <span className="text-lg text-[#1A2011]">مبلغ نهایی</span>
              <span className="text-xl text-[#16A34A]">
                {order.total_amount.toLocaleString('fa-IR')} تومان
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
