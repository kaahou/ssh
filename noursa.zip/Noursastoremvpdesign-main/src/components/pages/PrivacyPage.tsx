export function PrivacyPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-[#1A2011] mb-4">سیاست حریم خصوصی</h1>
          <div className="w-24 h-1 bg-[#1A2011] mx-auto rounded-full"></div>
          <p className="text-[#888888] mt-4">
            حفظ حریم خصوصی شما برای ما بسیار مهم است
          </p>
        </div>

        {/* Content */}
        <div className="space-y-6">
          {/* Section 1 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۱. جمع‌آوری اطلاعات</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                فروشگاه نورسا برای ارائه خدمات بهتر، اطلاعات زیر را از کاربران جمع‌آوری می‌کند:
              </p>
              <ul className="list-disc list-inside space-y-2 mr-4">
                <li>اطلاعات شخصی (نام، نام خانوادگی، شماره تماس)</li>
                <li>آدرس پستی برای ارسال محصولات</li>
                <li>اطلاعات پرداخت (از طریق درگاه امن پرداخت)</li>
                <li>اطلاعات مرورگر و دستگاه برای بهبود تجربه کاربری</li>
              </ul>
            </div>
          </div>

          {/* Section 2 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۲. استفاده از اطلاعات</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>اطلاعات جمع‌آوری شده برای موارد زیر استفاده می‌شود:</p>
              <ul className="list-disc list-inside space-y-2 mr-4">
                <li>پردازش و ارسال سفارشات</li>
                <li>ارتباط با مشتریان در خصوص سفارشات</li>
                <li>بهبود خدمات و محصولات</li>
                <li>ارسال اطلاعیه‌های مهم (با رضایت کاربر)</li>
                <li>پیشگیری از تقلب و سوء استفاده</li>
              </ul>
            </div>
          </div>

          {/* Section 3 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۳. حفاظت از اطلاعات</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                نورسا از روش‌های امنیتی پیشرفته برای محافظت از اطلاعات شخصی کاربران استفاده می‌کند:
              </p>
              <ul className="list-disc list-inside space-y-2 mr-4">
                <li>رمزگذاری اطلاعات حساس با پروتکل SSL</li>
                <li>ذخیره‌سازی ایمن داده‌ها در سرورهای محافظت شده</li>
                <li>دسترسی محدود به اطلاعات کاربران</li>
                <li>بررسی و به‌روزرسانی مستمر سیستم‌های امنیتی</li>
              </ul>
            </div>
          </div>

          {/* Section 4 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۴. اشتراک‌گذاری اطلاعات</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                نورسا اطلاعات شخصی شما را با اشخاص ثالث به اشتراک نمی‌گذارد، 
                مگر در موارد زیر:
              </p>
              <ul className="list-disc list-inside space-y-2 mr-4">
                <li>شرکت‌های پست و حمل‌ونقل (فقط برای ارسال محصولات)</li>
                <li>درگاه‌های پرداخت امن (برای پردازش تراکنش‌ها)</li>
                <li>الزام قانونی یا درخواست مقامات ذی‌صلاح</li>
              </ul>
            </div>
          </div>

          {/* Section 5 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۵. کوکی‌ها (Cookies)</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                وب‌سایت نورسا از کوکی‌ها برای بهبود تجربه کاربری استفاده می‌کند. 
                کاربران می‌توانند از طریق تنظیمات مرورگر خود، کوکی‌ها را غیرفعال کنند.
              </p>
            </div>
          </div>

          {/* Section 6 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۶. حقوق کاربران</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>کاربران دارای حقوق زیر هستند:</p>
              <ul className="list-disc list-inside space-y-2 mr-4">
                <li>دسترسی به اطلاعات شخصی خود</li>
                <li>درخواست اصلاح یا حذف اطلاعات نادرست</li>
                <li>لغو اشتراک از دریافت ایمیل‌های تبلیغاتی</li>
                <li>درخواست حذف حساب کاربری</li>
              </ul>
            </div>
          </div>

          {/* Section 7 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۷. تغییرات در سیاست حریم خصوصی</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                نورسا ممکن است این سیاست حریم خصوصی را در آینده به‌روزرسانی کند. 
                هرگونه تغییر اساسی به کاربران از طریق ایمیل یا وب‌سایت اطلاع داده خواهد شد.
              </p>
            </div>
          </div>

          {/* Section 8 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۸. تماس با ما</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                در صورت هرگونه سوال یا نگرانی درباره حریم خصوصی، می‌توانید با ما تماس بگیرید:
              </p>
              <ul className="list-none space-y-2 mt-4">
                <li>📞 <span dir="ltr">۰۵۱-۳۸۳۷۳۵۳۰</span></li>
                <li>✉️ ایمیل: be@nursaa.ir</li>
              </ul>
            </div>
          </div>

          {/* Contact CTA */}
          <div className="bg-gradient-to-l from-[#1A2011] to-[#2d3420] text-white rounded-[16px] p-6 text-center">
            <h3 className="mb-3">حریم خصوصی شما برای ما مهم است</h3>
            <p className="mb-4 opacity-90">
              برای هرگونه سوال درباره حریم خصوصی با ما تماس بگیرید
            </p>
            <a 
              href="mailto:be@nursaa.ir"
              className="inline-block bg-white text-[#1A2011] px-6 py-3 rounded-full hover:bg-opacity-90 transition-all"
            >
              ارسال ایمیل
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}