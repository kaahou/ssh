import { motion } from "motion/react";
import { CheckCircle, Copy, Home, Phone, MessageCircle } from "lucide-react";
import { Button } from "../ui/button";
import { toast } from "sonner@2.0.3";
import { useNavigate } from "react-router-dom";

interface ConsultationSuccessPageProps {
  consultationId?: string;
}

export function ConsultationSuccessPage({
  consultationId = "",
}: ConsultationSuccessPageProps) {
  const navigate = useNavigate();

  const handleCopyId = () => {
    navigator.clipboard.writeText(consultationId);
    toast.success("کد پیگیری کپی شد");
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Success Animation */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.6 }}
          className="flex justify-center mb-8"
        >
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#16A34A] to-[#15803D] flex items-center justify-center shadow-2xl">
            <CheckCircle className="w-14 h-14 text-white" />
          </div>
        </motion.div>

        {/* Main Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[24px] border border-[#E8E8E8] p-8 md:p-12 shadow-lg text-center"
        >
          <h1 className="text-3xl md:text-4xl text-[#1A2011] mb-4">
            مشاوره شما با موفقیت ثبت شد!
          </h1>

          <p className="text-[#666666] text-lg mb-8 leading-relaxed">
            اطلاعات شما دریافت شد و در حال بررسی توسط تیم متخصص نورسا است.
            نتیجه مشاوره به زودی از طریق پیامک برای شما ارسال خواهد شد.
          </p>

          {/* Tracking Code Section */}
          <div className="bg-gradient-to-br from-[#F9E1B4]/30 to-[#F9E1B4]/10 rounded-[20px] border border-[#F9E1B4] p-6 mb-8">
            <h3 className="text-[#1A2011] mb-3">
              کد پیگیری مشاوره شما
            </h3>
            <div className="flex items-center justify-center gap-3 mb-4">
              <code className="text-2xl md:text-3xl text-[#1A2011] font-mono bg-white px-6 py-3 rounded-[12px] border border-[#E8E8E8]">
                {consultationId}
              </code>
              <Button
                onClick={handleCopyId}
                variant="outline"
                size="icon"
                className="h-12 w-12 rounded-[12px] border-[#E8E8E8] hover:bg-[#FAFAFA]"
              >
                <Copy className="w-5 h-5 text-[#484D2C]" />
              </Button>
            </div>
            <p className="text-sm text-[#888888]">
              این کد را یادداشت کنید. برای پیگیری وضعیت مشاوره به این کد نیاز خواهید داشت.
            </p>
          </div>

          {/* Info Boxes */}
          <div className="grid md:grid-cols-2 gap-4 mb-8 text-right">
            <div className="bg-[#FAFAFA] rounded-[16px] p-5">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1A2011] flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-[#1A2011] mb-2">
                    دریافت نتیجه
                  </h4>
                  <p className="text-sm text-[#666666] leading-relaxed">
                    نتیجه مشاوره حداکثر ظرف ۲۴ ساعت از طریق پیامک برای شما ارسال خواهد شد.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-[#FAFAFA] rounded-[16px] p-5">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1A2011] flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-[#1A2011] mb-2">
                    پشتیبانی
                  </h4>
                  <p className="text-sm text-[#666666] leading-relaxed">
                    در صورت هرگونه سوال، با پشتیبانی نورسا در ارتباط باشید.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => navigate("/")}
              className="h-[52px] px-8 bg-[#1A2011] hover:bg-[#484D2C] text-white rounded-[12px] shadow-lg"
            >
              <Home className="w-5 h-5 ml-2" />
              بازگشت به صفحه اصلی
            </Button>
            
            <Button
              onClick={() => navigate("/products")}
              variant="outline"
              className="h-[52px] px-8 border-[#E8E8E8] rounded-[12px] hover:bg-[#FAFAFA]"
            >
              مشاهده محصولات
            </Button>
          </div>
        </motion.div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-8 text-center"
        >
          <p className="text-sm text-[#888888] leading-relaxed">
            برای کسب اطلاعات بیشتر درباره محصولات نورسا، می‌توانید به{" "}
            <button
              onClick={() => navigate("/blog")}
              className="text-[#484D2C] hover:underline"
            >
              بخش مقالات
            </button>{" "}
            مراجعه کنید.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
