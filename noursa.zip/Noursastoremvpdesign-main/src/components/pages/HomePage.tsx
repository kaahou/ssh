import { ArrowRight, Sparkles, Heart, Search } from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "../ui/button";
import { Product, ProductCard } from "../ProductCard";
import { useCart } from "../CartContext";
import { toast } from "sonner@2.0.3";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { OptimizedImage } from "../OptimizedImage";
import { SEOHead, createWebsiteStructuredData } from "../SEOHead";
import { logger } from "../../src/utils/logger";

interface Category {
  categories_id?: number;
  id?: number;
  parent_id: number | null;
  slug: string;
  name: string;
  sort_order: number;
  image_url: string | null;
  created_at: string;
  updated_at: string;
}

export function HomePage() {
  const { addItem } = useCart();
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);

  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [isLoadingFeatured, setIsLoadingFeatured] = useState(true);

  const navigate = useNavigate();

  // Fetch categories
  useEffect(() => {
    const controller = new AbortController();
    const fetchCategories = async () => {
      try {
        setIsLoadingCategories(true);
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/categories`,
          { headers: { Authorization: `Bearer ${publicAnonKey}` }, signal: controller.signal }
        );
        if (!response.ok) throw new Error("Failed to fetch categories");
        const data = await response.json();
        setCategories(data.categories || []);
      } catch (error: any) {
        if (error.name !== "AbortError") {
          logger.error(error);
          toast.error("خطا در دریافت دسته‌بندی‌ها");
        }
      } finally {
        setIsLoadingCategories(false);
      }
    };
    fetchCategories();
    return () => controller.abort();
  }, []);

  // Fetch featured products
  useEffect(() => {
    const controller = new AbortController();
    const fetchFeatured = async () => {
      try {
        setIsLoadingFeatured(true);
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/products/featured`,
          {
            headers: { Authorization: `Bearer ${publicAnonKey}` },
            signal: controller.signal,
          }
        );
        if (!response.ok) throw new Error("Failed to fetch featured products");
        const data = await response.json();
        logger.log(`✅ دریافت ${data.products?.length || 0} محصول ویژه از سرور (مرتب شده فقط بر اساس SCORE):`);
        data.products?.forEach((p: any, idx: number) => {
          logger.log(`  ${idx + 1}. ${p.product_name} - امتیاز: ${p.score === null ? 'NULL' : p.score}`);
        });
        setFeaturedProducts(data.products || []);
      } catch (error: any) {
        if (error.name !== "AbortError") {
          logger.error(error);
          toast.error("خطا در دریافت محصولات ویژه");
        }
      } finally {
        setIsLoadingFeatured(false);
      }
    };
    fetchFeatured();
    return () => controller.abort();
  }, []);

  const handleAddToCart = (product: Product, event?: React.MouseEvent) => {
    event?.preventDefault();
    event?.stopPropagation();
    try {
      addItem(product);
      toast.success("به سبد خرید اضافه شد");
    } catch {
      toast.error("خطا در افزودن به سبد خرید");
    }
  };

  const handleSearch = (query: string) => {
    if (query.trim()) navigate(`/search?q=${query}`);
  };

  return (
    <div className="space-y-[48px] pb-16">
      <SEOHead 
        title="خرید آنلاین روغن‌های طبیعی"
        description="خرید آنلاین انواع روغن‌های طبیعی مراقبت از مو، روغن‌های درمانی، روغن‌های زیبایی و اسانس‌های گیاهی با ضمانت اصالت و ارسال سریع به سراسر کشور"
        keywords="روغن طبیعی، روغن مو، روغن آرگان، روغن نارگیل، روغن درمانی، اسانس گیاهی، روغن زیبایی، خرید روغن اصل"
        structuredData={createWebsiteStructuredData()}
      />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-bl from-[#1A2011]/10 via-background to-[#F9E1B4]/20 overflow-hidden min-h-[500px] md:min-h-[600px] flex items-end">
        <div className="absolute inset-0 md:hidden">
          <OptimizedImage
            src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/hair_elixir.png"
            alt="محصول ویژه نورسا"
            className="w-full h-full object-cover opacity-70"
            priority={true}
            preload={true}
            loading="eager"
          />
        </div>
        <div className="absolute inset-0 hidden md:block">
          <OptimizedImage
            src="https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/hero_desktop.png"
            alt="محصول ویژه نورسا"
            className="w-full h-full object-cover opacity-70"
            priority={true}
            preload={true}
            loading="eager"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-[#1A2011]/40 via-[#1A2011]/20 to-transparent will-change-transform" />
        <div className="container mx-auto px-4 py-8 relative z-10 w-full h-full flex flex-col justify-end md:justify-center gap-8 md:-translate-y-[100px]">
          <div className="max-w-2xl hidden md:block">
            <h1 className="mb-6 text-[#1A2011] drop-shadow-[0_2px_8px_rgba(249,225,180,0.9)] text-5xl md:text-6xl">
              خرید آنلاین با بهترین کیفیت و قیمت
            </h1>
            <p className="text-[#1A2011] drop-shadow-[0_2px_6px_rgba(249,225,180,0.8)] text-xl md:text-2xl">
              در فروشگاه نورسا، تجربه‌ای متفاوت از خرید آنلاین را با محصولات باکیفیت و ارسال سریع تجربه کنید.
            </p>
          </div>
          <div className="flex flex-row gap-4 flex-wrap">
            <Link to="/products">
              <Button size="lg" className="h-[56px] px-[32px] rounded-[12px] bg-[#F9E1B4] text-[#1A2011] hover:bg-[#F9E1B4]/90 shadow-lg">
                مشاهده محصولات <ArrowRight className="w-5 h-5 mr-2" />
              </Button>
            </Link>
            <Link to="/consultation">
              <Button size="lg" className="h-[56px] px-[32px] rounded-[12px] bg-[#1A2011] text-[#F9E1B4] hover:bg-[#1A2011]/90 shadow-lg border-2 border-[#F9E1B4]/30">
                مشاوره هوشمند <Heart className="w-5 h-5 mr-2" />
              </Button>
            </Link>
          </div>
        </div>
        <div className="absolute top-10 left-10 w-72 h-72 bg-[#1A2011]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-[#F9E1B4]/20 rounded-full blur-3xl" />
      </section>

      {/* Search Section */}
      <section className="container mx-auto px-4 relative z-20 -mt-[64px]">
        <div className="bg-white p-2 rounded-[20px] shadow-[0_8px_30px_rgb(0,0,0,0.08)] border border-[#E8E8E8] max-w-3xl mx-auto flex items-center gap-2 mt-[20px]">
          <div className="flex-1 flex items-center px-4 h-14">
            <Search className="w-6 h-6 text-[#888888] ml-3" />
            <input
              type="text"
              placeholder="جستجو در محصولات و مقالات..."
              className="w-full h-full bg-transparent border-none outline-none text-lg text-[#1A2011] placeholder:text-[#888888]"
              onKeyDown={(e) => { if (e.key === 'Enter') handleSearch((e.target as HTMLInputElement).value); }}
            />
          </div>
          <Button
            size="lg"
            variant="ghost"
            onClick={() => {
              const input = document.querySelector('input[type="text"]') as HTMLInputElement;
              if (input) handleSearch(input.value);
            }}
            className="h-12 w-12 p-0 rounded-full hover:bg-[#F4F4F5] text-[#1A2011]"
          >
            <ArrowRight className="w-6 h-6 rotate-180" />
          </Button>
        </div>
      </section>

      {/* Categories Section */}
      <section className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-[#1A2011]">خرید بر اساس دسته‌بندی</h2>
          <p className="text-[#888888]">سریع‌تر به محصول دلخواهتان برسید</p>
        </div>
        {isLoadingCategories ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
            {[1,2,3,4,5,6].map(i => (
              <div key={i} className="p-6 bg-white rounded-[16px] border border-[#E8E8E8] animate-pulse">
                <div className="w-28 h-28 mx-auto mb-2 rounded-full bg-[#E8E8E8]" />
                <div className="h-6 bg-[#E8E8E8] rounded mx-auto w-24" />
              </div>
            ))}
          </div>
        ) : categories.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
            {categories.map((category, index) => (
              <Link
                key={`category-${category.categories_id || category.id}-${index}`}
                to={`/category/${category.slug}`}
                className="group p-6 bg-white rounded-[16px] border border-[#E8E8E8] hover:border-[#1A2011] hover:shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1)] transition-all block"
              >
                {category.image_url ? (
                  <div className="w-28 h-28 mx-auto mb-2 rounded-full overflow-hidden bg-[#FEF5E7] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <OptimizedImage src={category.image_url} alt={category.name} className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className="w-28 h-28 mx-auto mb-2 rounded-full bg-[#FEF5E7] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Sparkles className="w-12 h-12 text-[#1A2011]" />
                  </div>
                )}
                <h3 className="text-center text-[#1A2011]">{category.name}</h3>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-[#888888]">دسته‌بندی موجود نیست</div>
        )}
      </section>

      {/* Featured Products Section */}
      <section className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="mb-2 text-[#1A2011]">محصولات ویژه</h2>
            <p className="text-[#888888]">محصولات با بالاترین امتیاز</p>
          </div>
          <Link to="/products">
            <Button variant="outline">
              مشاهده همه <ArrowRight className="w-4 h-4 mr-2" />
            </Button>
          </Link>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory hide-scrollbar" dir="rtl">
          {featuredProducts.map((product, index) => (
            <Link key={product.id} to={`/product/${product.slug || product.id}`} className="flex-shrink-0 w-[280px] md:w-[320px] snap-start">
              <ProductCard product={product} priority={index < 3} onAddToCart={handleAddToCart} />
            </Link>
          ))}
        </div>
      </section>

      {/* Consultation Section */}
      <section className="container mx-auto px-4 consultation-section">
        <div className="bg-gradient-to-br from-[#1A2011] to-[#484D2C] rounded-[20px] p-12 text-center text-white">
          <h2 className="mb-4 text-white">نیاز به مشاوره دارید؟</h2>
          <p className="mb-8 text-white/90 max-w-2xl mx-auto">
            کارشناسان ما آماده‌اند تا شما را در انتخاب بهترین محصولات راهنمایی کنند
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/consultation">
              <Button size="lg" className="h-[56px] px-[32px] rounded-[12px] bg-[#F9E1B4] text-[#1A2011] hover:bg-[#F9E1B4]/90">
                شروع مشاوره هوشمند
              </Button>
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}