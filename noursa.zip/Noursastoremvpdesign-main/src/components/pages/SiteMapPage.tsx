import { Home, ShoppingBag, FileText, HelpCircle, Phone, Package, Shield, Truck, RotateCcw, Info, FileCheck, Lock, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

export function SiteMapPage() {
  const siteMap = [
    {
      title: "صفحات اصلی",
      icon: Home,
      links: [
        { name: "صفحه اصلی", to: "/" },
        { name: "محصولات", to: "/products" },
        { name: "سبد خرید", to: "/checkout" },
        { name: "وبلاگ", to: "/blog" }
      ]
    },
    {
      title: "خدمات و مشاوره",
      icon: HelpCircle,
      links: [
        { name: "مشاوره هوشمند", to: "/consultation" },
        { name: "تماس با ما", to: "/contact" },
        { name: "پرسش‌های متداول", to: "/faq" }
      ]
    },
    {
      title: "اطلاعات فروشگاه",
      icon: Info,
      links: [
        { name: "درباره ما", to: "/about" },
        { name: "قوانین و مقررات", to: "/terms" },
        { name: "سیاست حریم خصوصی", to: "/privacy" }
      ]
    },
    {
      title: "خرید و ارسال",
      icon: Truck,
      links: [
        { name: "راهنمای خرید و ارسال", to: "/shipping-guide" },
        { name: "پیگیری سفارش", to: "/order-tracking" }
      ]
    },
    {
      title: "ضمانت و بازگشت",
      icon: Shield,
      links: [
        { name: "بازگشت کالا", to: "/return-policy" },
        { name: "ضمانت بازگشت ۱۰۰٪ وجه", to: "/money-back-guarantee" }
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-[#1A2011] mb-4 text-center">نقشه سایت</h1>
        <p className="text-[#888888] mb-12 text-center">
          دسترسی سریع به تمام صفحات و بخش‌های فروشگاه نورسا
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {siteMap.map((section, idx) => {
            const Icon = section.icon;
            return (
              <div
                key={idx}
                className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8] hover:shadow-md transition-shadow"
              >
                <div className="flex items-center gap-3 mb-4 pb-3 border-b border-[#E8E8E8]">
                  <div className="w-10 h-10 rounded-full bg-[#F9E1B4] flex items-center justify-center">
                    <Icon className="w-5 h-5 text-[#1A2011]" />
                  </div>
                  <h2 className="text-[#1A2011]">{section.title}</h2>
                </div>
                <ul className="space-y-2">
                  {section.links.map((link, linkIdx) => (
                    <li key={linkIdx}>
                      <Link
                        to={link.to}
                        className="text-[#888888] hover:text-[#1A2011] hover:underline transition-colors block text-right w-full"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Quick Stats */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-[#F9E1B4] p-6 rounded-lg text-center">
            <ShoppingBag className="w-8 h-8 text-[#1A2011] mx-auto mb-2" />
            <div className="text-2xl text-[#1A2011] mb-1">۱۰۰+</div>
            <div className="text-sm text-[#1A2011]">محصول</div>
          </div>
          <div className="bg-[#F9E1B4] p-6 rounded-lg text-center">
            <Package className="w-8 h-8 text-[#1A2011] mx-auto mb-2" />
            <div className="text-2xl text-[#1A2011] mb-1">۵۰۰+</div>
            <div className="text-sm text-[#1A2011]">سفارش</div>
          </div>
          <div className="bg-[#F9E1B4] p-6 rounded-lg text-center">
            <Shield className="w-8 h-8 text-[#1A2011] mx-auto mb-2" />
            <div className="text-2xl text-[#1A2011] mb-1">۱۰۰٪</div>
            <div className="text-sm text-[#1A2011]">ضمانت</div>
          </div>
          <div className="bg-[#F9E1B4] p-6 rounded-lg text-center">
            <Truck className="w-8 h-8 text-[#1A2011] mx-auto mb-2" />
            <div className="text-2xl text-[#1A2011] mb-1">۲۴ ساعته</div>
            <div className="text-sm text-[#1A2011]">ارسال سریع</div>
          </div>
        </div>

        {/* Search Section */}
        <div className="mt-12 bg-white p-8 rounded-lg shadow-sm border border-[#E8E8E8] text-center">
          <Search className="w-12 h-12 text-[#1A2011] mx-auto mb-4" />
          <h2 className="text-[#1A2011] mb-3">به دنبال چیزی هستید؟</h2>
          <p className="text-[#888888] mb-6">
            اگر صفحه مورد نظر خود را پیدا نکردید، می‌توانید با ما تماس بگیرید.
          </p>
          <Link
            to="/contact"
            className="inline-block px-8 py-3 bg-[#1A2011] text-white rounded-lg hover:bg-[#2A3021] transition-colors"
          >
            تماس با ما
          </Link>
        </div>
      </div>
    </div>
  );
}