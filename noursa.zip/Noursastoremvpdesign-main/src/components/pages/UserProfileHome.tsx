import { useNavigate } from "react-router-dom";
import { useUser } from '../UserContext';
import { 
  User, 
  CheckCircle, 
  Gift, 
  Sparkles,
  MessageSquare,
  ShoppingBag,
  Wallet,
  TrendingUp,
  ChevronLeft,
  Package,
  Camera,
  Users,
  Wrench,
  Code,
  Sparkle
} from 'lucide-react';
import { motion } from 'motion/react';

export function UserProfileHome() {
  const navigate = useNavigate();
  const { user, loading, isProfileComplete, getCompletionPercentage } = useUser();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#484D2C] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-[#888888]">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  const currentHour = new Date().getHours();
  const greeting = currentHour < 12 ? 'صبح بخیر' : currentHour < 18 ? 'روز بخیر' : 'عصر بخیر';
  
  const getDisplayName = () => {
    if (user?.first_name && user?.last_name) {
      return `${user.first_name} ${user.last_name}`;
    }
    if (user?.first_name) return user.first_name;
    if (user?.last_name) return user.last_name;
    return 'کاربر گرامی';
  };
  
  const userName = getDisplayName();
  const completionPercentage = getCompletionPercentage();

  // Mock data - باید از backend بیاید
  const stats = {
    orders: 0,
    consultations: 0,
    balance: 0,
    points: 0
  };

  return (
    <div className="space-y-6">
      {/* Profile Completion Alert */}
      {!isProfileComplete() && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-[#F59E0B] to-[#F97316] rounded-[20px] p-6 text-white relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full translate-x-16 -translate-y-16" />
          
          <div className="relative flex items-start gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
              <Gift size={24} />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-[18px] mb-2">پروفایل خود را تکمیل کنید!</h3>
              <p className="text-[14px] text-white/90 mb-4">
                با تکمیل اطلاعات پروفایل، امتیاز وفاداری دریافت کنید و از تخفیف ویژه بهره‌مند شوید.
              </p>
              <div className="flex items-center gap-4 flex-wrap">
                <button
                  onClick={() => navigate('/profile/settings')}
                  className="h-[44px] px-6 bg-white text-[#F59E0B] rounded-[12px] font-bold hover:bg-white/90 transition-all flex items-center gap-2"
                >
                  <Sparkles size={18} />
                  <span>تکمیل اطلاعات</span>
                </button>
                <div className="flex items-center gap-2 text-white/80">
                  <Gift size={16} />
                  <span className="text-[13px]">۱۰۰ امتیاز هدیه</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Welcome Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-[#484D2C] to-[#2A2F15] rounded-[24px] p-6 md:p-8 text-white relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
        
        <div className="relative flex items-center gap-4">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-white/20 rounded-full flex items-center justify-center border-2 border-white/30">
            <User size={32} className="text-white" />
          </div>
          
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-[20px] md:text-[24px] font-bold">
                {greeting}، {userName}
              </h1>
              {isProfileComplete() && (
                <div className="w-6 h-6 bg-[#16A34A] rounded-full flex items-center justify-center">
                  <CheckCircle size={14} className="text-white" />
                </div>
              )}
            </div>
            <p className="text-[13px] md:text-[14px] text-white/80">
              امروز چطور می‌توانیم به شما کمک کنیم؟
            </p>
          </div>
        </div>
      </motion.div>

      {/* Main Content Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* همکاری در فروش - در دست توسعه */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-white via-white to-[#F9E1B4]/10 rounded-[20px] border-2 border-dashed border-[#F59E0B]/30 p-6 relative overflow-hidden group cursor-not-allowed"
        >
          {/* Animated background pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-[#F59E0B] to-[#F97316] rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-0 right-0 w-40 h-40 bg-gradient-to-br from-[#484D2C] to-[#6B7345] rounded-full blur-3xl animate-pulse delay-1000" />
          </div>
          
          {/* Header with badge */}
          <div className="relative flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B]/20 to-[#F97316]/20 rounded-[12px] flex items-center justify-center relative">
                <MessageSquare size={20} className="text-[#F59E0B]" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-[#F59E0B] to-[#F97316] rounded-full flex items-center justify-center">
                  <Wrench size={10} className="text-white" />
                </div>
              </div>
              <div>
                <h3 className="font-bold text-[16px] text-[#1A2011]">همکاری در فروش</h3>
                <span className="text-[11px] text-[#F59E0B] font-medium">در حال توسعه...</span>
              </div>
            </div>
            
            {/* Animated badge */}
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
                rotate: [0, -3, 3, -3, 0]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3
              }}
              className="bg-gradient-to-r from-[#F59E0B] to-[#F97316] text-white text-[10px] px-3 py-1.5 rounded-full flex items-center gap-1 shadow-lg"
            >
              <Sparkle size={12} className="animate-spin" style={{ animationDuration: '3s' }} />
              <span className="font-bold">به زودی</span>
            </motion.div>
          </div>
          
          {/* Content */}
          <div className="relative text-center py-8">
            <div className="relative inline-block mb-4">
              <Code size={64} className="text-[#F59E0B]/20" />
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <Wrench size={28} className="text-[#F59E0B]" />
              </motion.div>
            </div>
            
            <h4 className="font-bold text-[15px] text-[#1A2011] mb-2">
              سیستم همکاری در فروش در حال توسعه است
            </h4>
            <p className="text-[13px] text-[#888888] mb-4 max-w-[280px] mx-auto">
              تیم ما در حال آماده‌سازی یک سیستم همکاری پیشرفته برای شماست. به زودی می‌توانید به ما افتخار همکاری بدهید.
            </p>
            
            {/* Progress indicator */}
            <div className="w-full max-w-[200px] mx-auto">
              <div className="h-2 bg-[#F9E1B4]/30 rounded-full overflow-hidden">
                <motion.div
                  animate={{ width: ['0%', '70%', '0%'] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                  className="h-full bg-gradient-to-r from-[#F59E0B] to-[#F97316] rounded-full"
                />
              </div>
              <p className="text-[10px] text-[#F59E0B] mt-2 font-medium">در حال پیشرفت ۷۰٪</p>
            </div>
          </div>
        </motion.div>

        {/* کیف پول - در دست توسعه */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-gradient-to-br from-white via-white to-[#F9E1B4]/10 rounded-[20px] border-2 border-dashed border-[#16A34A]/30 p-6 relative overflow-hidden group cursor-not-allowed"
        >
          {/* Animated background pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#16A34A] to-[#15803D] rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-gradient-to-br from-[#484D2C] to-[#6B7345] rounded-full blur-3xl animate-pulse delay-1000" />
          </div>
          
          {/* Header with badge */}
          <div className="relative flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#16A34A]/20 to-[#15803D]/20 rounded-[12px] flex items-center justify-center relative">
                <ShoppingBag size={20} className="text-[#16A34A]" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-[#16A34A] to-[#15803D] rounded-full flex items-center justify-center">
                  <Wrench size={10} className="text-white" />
                </div>
              </div>
              <div>
                <h3 className="font-bold text-[16px] text-[#1A2011]">کیف پول من</h3>
                <span className="text-[11px] text-[#16A34A] font-medium">در حال توسعه...</span>
              </div>
            </div>
            
            {/* Animated badge */}
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
                rotate: [0, 3, -3, 3, 0]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3,
                delay: 0.5
              }}
              className="bg-gradient-to-r from-[#16A34A] to-[#15803D] text-white text-[10px] px-3 py-1.5 rounded-full flex items-center gap-1 shadow-lg"
            >
              <Sparkle size={12} className="animate-spin" style={{ animationDuration: '3s' }} />
              <span className="font-bold">به زودی</span>
            </motion.div>
          </div>
          
          {/* Content */}
          <div className="relative text-center py-8">
            <div className="relative inline-block mb-4">
              <Package size={64} className="text-[#16A34A]/20" />
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <Wrench size={28} className="text-[#16A34A]" />
              </motion.div>
            </div>
            
            <h4 className="font-bold text-[15px] text-[#1A2011] mb-2">
              کیف پول شما در حال آماده‌سازی است
            </h4>
            <p className="text-[13px] text-[#888888] mb-4 max-w-[280px] mx-auto">
              به زودی می‌توانید از خدمات کیف پول خودتان استفاده کنید. صبور باشید!
            </p>
            
            {/* Progress indicator */}
            <div className="w-full max-w-[200px] mx-auto">
              <div className="h-2 bg-[#F9E1B4]/30 rounded-full overflow-hidden">
                <motion.div
                  animate={{ width: ['0%', '85%', '0%'] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  className="h-full bg-gradient-to-r from-[#16A34A] to-[#15803D] rounded-full"
                />
              </div>
              <p className="text-[10px] text-[#16A34A] mt-2 font-medium">در حال پیشرفت ۸۵٪</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}