import { Wallet as WalletIcon } from 'lucide-react';
import { ComingSoon } from './ComingSoon';

export function WalletPage() {
  return (
    <ComingSoon
      title="کیف پول نورسا"
      description="به زودی می‌توانید موجودی خود را مدیریت کنید، شارژ کیف پول انجام دهید و از امتیازات و تخفیفات ویژه استفاده کنید."
      icon={WalletIcon}
      color="#F59E0B"
      progress={75}
    />
  );
}