import { motion } from 'motion/react';
import { Wrench, Sparkle, Code, Rocket, Zap } from 'lucide-react';

interface ComingSoonProps {
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
  progress: number;
}

export function ComingSoon({ title, description, icon: Icon, color, progress }: ComingSoonProps) {
  return (
    <div className="min-h-[600px] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-[600px]"
      >
        {/* Main Card */}
        <div className={`bg-gradient-to-br from-white via-white to-[${color}]/5 rounded-[32px] border-2 border-dashed p-8 md:p-12 relative overflow-hidden`}
          style={{ borderColor: `${color}40` }}
        >
          {/* Animated background blobs */}
          <div className="absolute inset-0 opacity-5">
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                x: [0, 20, 0],
                y: [0, -20, 0]
              }}
              transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
              className={`absolute top-0 left-0 w-40 h-40 bg-gradient-to-br rounded-full blur-3xl`}
              style={{ 
                background: `linear-gradient(135deg, ${color}, ${color}dd)` 
              }}
            />
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                x: [0, -30, 0],
                y: [0, 30, 0]
              }}
              transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute bottom-0 right-0 w-56 h-56 bg-[#484D2C] rounded-full blur-3xl"
            />
          </div>

          {/* Content */}
          <div className="relative text-center">
            {/* Animated Icon */}
            <div className="relative inline-block mb-8">
              <motion.div
                animate={{
                  rotate: [0, 5, -5, 0],
                  scale: [1, 1.05, 1]
                }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className={`w-24 h-24 mx-auto rounded-[24px] flex items-center justify-center relative`}
                style={{ backgroundColor: `${color}15` }}
              >
                <Icon size={48} style={{ color }} />
                
                {/* Rotating wrench */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="absolute -top-2 -right-2 w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: color }}
                >
                  <Wrench size={20} className="text-white" />
                </motion.div>

                {/* Sparkles */}
                <motion.div
                  animate={{
                    scale: [0, 1, 0],
                    rotate: [0, 180, 360]
                  }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -top-4 -left-4"
                  style={{ color }}
                >
                  <Sparkle size={24} />
                </motion.div>
                
                <motion.div
                  animate={{
                    scale: [0, 1, 0],
                    rotate: [0, -180, -360]
                  }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  className="absolute -bottom-4 -right-4"
                  style={{ color }}
                >
                  <Sparkle size={20} />
                </motion.div>
              </motion.div>
            </div>

            {/* Badge */}
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
                rotate: [0, -2, 2, -2, 0]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-white text-[12px] font-bold mb-6 shadow-lg"
              style={{ 
                background: `linear-gradient(135deg, ${color}, ${color}dd)` 
              }}
            >
              <Rocket size={16} />
              <span>به زودی راه‌اندازی می‌شود</span>
              <Zap size={16} />
            </motion.div>

            {/* Title */}
            <h1 className="text-[28px] md:text-[36px] font-bold text-[#1A2011] mb-4">
              {title}
            </h1>

            {/* Description */}
            <p className="text-[15px] md:text-[16px] text-[#666666] mb-8 max-w-[400px] mx-auto leading-relaxed">
              {description}
            </p>

            {/* Progress Bar */}
            <div className="max-w-[300px] mx-auto mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[13px] font-medium text-[#888888]">پیشرفت توسعه</span>
                <span className="text-[13px] font-bold" style={{ color }}>
                  {progress}٪
                </span>
              </div>
              <div className="h-3 bg-[#F9E1B4]/30 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 1.5, ease: "easeOut", delay: 0.5 }}
                  className="h-full rounded-full relative"
                  style={{ 
                    background: `linear-gradient(90deg, ${color}, ${color}dd)` 
                  }}
                >
                  {/* Shine effect */}
                  <motion.div
                    animate={{
                      x: ['-100%', '200%']
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: 2
                    }}
                    className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  />
                </motion.div>
              </div>
            </div>

            {/* Features Preview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
              {[
                { icon: Code, label: 'کدنویسی' },
                { icon: Wrench, label: 'طراحی' },
                { icon: Rocket, label: 'تست' }
              ].map((item, index) => {
                const ItemIcon = item.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 + index * 0.1 }}
                    className="bg-white/50 backdrop-blur-sm rounded-[16px] p-4 border border-[#E8E8E8]"
                  >
                    <div className="w-10 h-10 mx-auto mb-2 rounded-[12px] flex items-center justify-center"
                      style={{ backgroundColor: `${color}15` }}
                    >
                      <ItemIcon size={20} style={{ color }} />
                    </div>
                    <p className="text-[12px] text-[#888888]">{item.label}</p>
                    <motion.div
                      animate={{ width: ['0%', '100%'] }}
                      transition={{ 
                        duration: 1.5, 
                        delay: 1 + index * 0.2,
                        repeat: Infinity,
                        repeatDelay: 3
                      }}
                      className="h-1 mt-2 rounded-full"
                      style={{ backgroundColor: `${color}40` }}
                    />
                  </motion.div>
                );
              })}
            </div>

            {/* Footer Message */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="text-[13px] text-[#AAAAAA] mt-8"
            >
              تیم ما با تمام توان در حال کار بر روی این بخش است 💪
            </motion.p>
          </div>
        </div>

        {/* Floating particles */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -100],
                x: [0, Math.random() * 40 - 20],
                opacity: [0, 1, 0]
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: i * 0.5,
                ease: "easeOut"
              }}
              className="absolute w-2 h-2 rounded-full"
              style={{
                backgroundColor: color,
                left: `${Math.random() * 100}%`,
                bottom: 0
              }}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}
