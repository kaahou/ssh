import { Link } from 'react-router-dom';

export function ShippingGuidePage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-[#1A2011] mb-8">راهنمای خرید و ارسال</h1>

        <div className="space-y-8">
          {/* نحوه خرید */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">نحوه خرید از فروشگاه نورسا</h2>
            <div className="space-y-3 text-[#888888]">
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۱</span>
                <p>محصول مورد نظر خود را از فروشگاه انتخاب کنید.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۲</span>
                <p>محصول را به سبد خرید اضافه کنید.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۳</span>
                <p>پس از اتمام خرید، روی آیکون سبد خرید کلیک کنید.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۴</span>
                <p>اطلاعات خود را وارد کرده و روش ارسال را انتخاب کنید.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-[#1A2011] text-white flex-shrink-0 text-sm">۵</span>
                <p>پرداخت را انجام دهید و منتظر تحویل سفارش باشید.</p>
              </div>
            </div>
          </section>

          {/* روش‌های ارسال */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">روش‌های ارسال</h2>
            <div>
              <h3 className="text-[#1A2011] mb-2">ارسال با پست پیشتاز (۳-۵ روز کاری)</h3>
              <p className="text-[#888888]">
                هزینه ارسال: ۸۰,۰۰۰ تومان<br />
                برای سفارش‌های بالای ۱,۰۰۰,۰۰۰ تومان رایگان
              </p>
            </div>
          </section>

          {/* زمان پردازش */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">زمان پردازش سفارش</h2>
            <p className="text-[#888888] mb-3">
              پس از ثبت سفارش و تایید پرداخت، محصولات شما آماده‌سازی می‌شوند:
            </p>
            <ul className="list-disc list-inside space-y-2 text-[#888888] mr-4">
              <li>محصولات موجود: ۲۴ ساعت</li>
              <li>محصولات تحت سفارش: ۳-۷ روز کاری</li>
            </ul>
          </section>

          {/* پیگیری سفارش */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">پیگیری سفارش</h2>
            <p className="text-[#888888] mb-3">
              برای پیگیری وضعیت سفارش خود، وارد حساب کاربری شوید و از منوی پروفایل بخش «سفارشات» را انتخاب کنید.
              در آنجا می‌توانید وضعیت تمام سفارشات خود را به صورت زنده مشاهده کنید.
            </p>
            <Link 
              to="/order-tracking"
              className="inline-block px-6 py-2 bg-[#1A2011] text-white rounded-lg hover:bg-[#2A3021] transition-colors"
            >
              راهنمای پیگیری
            </Link>
          </section>

          {/* شرایط ارسال */}
          <section className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-4">شرایط ارسال</h2>
            <ul className="list-disc list-inside space-y-2 text-[#888888] mr-4">
              <li>تمامی محصولات با بسته‌بندی مناسب ارسال می‌شوند.</li>
              <li>ارسال به تمام نقاط کشور امکان‌پذیر است.</li>
              <li>هزینه ارسال به مناطق دورافتاده ممکن است متفاوت باشد.</li>
              <li>در صورت عدم حضور گیرنده، سفارش به پست محل ارسال می‌شود.</li>
              <li>تحویل محصولات در روزهای تعطیل انجام نمی‌شود.</li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}