import { Mail, Phone, MapPin, Instagram, Send, Clock } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitError('');
    
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-fbc72c25/contact-messages`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            full_name: formData.name,
            email: formData.email || null,
            phone_number: formData.phone,
            subject: formData.subject,
            message: formData.message
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'خطا در ارسال پیام');
      }

      setSubmitSuccess(true);
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
      
      setTimeout(() => setSubmitSuccess(false), 5000);
    } catch (error) {
      console.error('Error submitting contact form:', error);
      setSubmitError(error instanceof Error ? error.message : 'خطا در ارسال پیام. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-[#1A2011] mb-4 text-center">تماس با ما</h1>
        <p className="text-[#888888] mb-12 text-center">
          ما همیشه آماده پاسخگویی به سوالات و پیشنهادات شما هستیم.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
            <h2 className="text-[#1A2011] mb-6">فرم تماس</h2>
            
            {submitSuccess && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-800">
                پیام شما با موفقیت ارسال شد. به زودی با شما تماس خواهیم گرفت.
              </div>
            )}

            {submitError && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-800">
                {submitError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[#1A2011] mb-2">نام و نام خانوادگی *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8E8E8] rounded-lg focus:outline-none focus:border-[#1A2011]"
                  placeholder="نام خود را وارد کنید"
                />
              </div>

              <div>
                <label className="block text-[#1A2011] mb-2">ایمیل</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8E8E8] rounded-lg focus:outline-none focus:border-[#1A2011]"
                  placeholder="example@email.com"
                />
              </div>

              <div>
                <label className="block text-[#1A2011] mb-2">شماره تماس *</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8E8E8] rounded-lg focus:outline-none focus:border-[#1A2011]"
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                />
              </div>

              <div>
                <label className="block text-[#1A2011] mb-2">موضوع *</label>
                <select
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8E8E8] rounded-lg focus:outline-none focus:border-[#1A2011]"
                >
                  <option value="">انتخاب کنید</option>
                  <option value="product">سوال درباره محصول</option>
                  <option value="order">پیگیری سفارش</option>
                  <option value="return">بازگشت کالا</option>
                  <option value="complaint">شکایت</option>
                  <option value="suggestion">پیشنهاد</option>
                  <option value="other">سایر</option>
                </select>
              </div>

              <div>
                <label className="block text-[#1A2011] mb-2">پیام شما *</label>
                <textarea
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={5}
                  className="w-full px-4 py-2 border border-[#E8E8E8] rounded-lg focus:outline-none focus:border-[#1A2011] resize-none"
                  placeholder="پیام خود را بنویسید..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#1A2011] text-white rounded-lg hover:bg-[#2A3021] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'در حال ارسال...' : 'ارسال پیام'}
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Address & Phone */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
              <h2 className="text-[#1A2011] mb-6">اطلاعات تماس</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#F9E1B4] flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#1A2011]" />
                  </div>
                  <div>
                    <h3 className="text-[#1A2011] mb-1">تلفن تماس</h3>
                    <p className="text-[#888888]">۰۵۱-۳۸۳۷۳۵۳۰</p>
                    <p className="text-[#888888]">۰۹۲۱۹۶۷۵۹۹۲</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#F9E1B4] flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-[#1A2011]" />
                  </div>
                  <div>
                    <h3 className="text-[#1A2011] mb-1">ایمیل</h3>
                    <p className="text-[#888888]">be@nursaa.ir</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#F9E1B4] flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#1A2011]" />
                  </div>
                  <div>
                    <h3 className="text-[#1A2011] mb-1">آدرس</h3>
                    <p className="text-[#888888]">
                      خراسان رضوی، گلمکان، اسجیل، صاحب‌الزمان ۴
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#F9E1B4] flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-[#1A2011]" />
                  </div>
                  <div>
                    <h3 className="text-[#1A2011] mb-1">ساعات کاری</h3>
                    <p className="text-[#888888]">شنبه تا پنجشنبه: ۹ صبح تا ۶ عصر</p>
                    <p className="text-[#888888]">جمعه: تعطیل</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Media */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-[#E8E8E8]">
              <h2 className="text-[#1A2011] mb-4">شبکه‌های اجتماعی</h2>
              <p className="text-[#888888] mb-4">
                ما را در شبکه‌های اجتماعی دنبال کنید تا از آخرین اخبار و تخفیف‌ها باخبر شوید.
              </p>
              <div className="flex items-center gap-3">
                <a
                  href="#"
                  className="w-12 h-12 rounded-full bg-[#F9E1B4] flex items-center justify-center hover:bg-[#1A2011] hover:text-white transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="w-6 h-6" />
                </a>
                <a
                  href="#"
                  className="w-12 h-12 rounded-full bg-[#F9E1B4] flex items-center justify-center hover:bg-[#1A2011] hover:text-white transition-colors"
                  aria-label="Eitaa"
                >
                  <Send className="w-6 h-6" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div className="bg-[#F9E1B4] p-6 rounded-lg">
              <h2 className="text-[#1A2011] mb-4">لینک‌های مفید</h2>
              <div className="space-y-2">
                <Link
                  to="/faq"
                  className="block text-[#1A2011] hover:underline"
                >
                  پرسش‌های متداول
                </Link>
                <Link
                  to="/shipping-guide"
                  className="block text-[#1A2011] hover:underline"
                >
                  راهنمای خرید و ارسال
                </Link>
                <Link
                  to="/return-policy"
                  className="block text-[#1A2011] hover:underline"
                >
                  بازگشت کالا
                </Link>
                <Link
                  to="/money-back-guarantee"
                  className="block text-[#1A2011] hover:underline"
                >
                  ضمانت بازگشت وجه
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}