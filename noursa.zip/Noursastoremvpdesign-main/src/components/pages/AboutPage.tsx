export function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-[#1A2011] mb-4">درباره نورسا</h1>
          <div className="w-24 h-1 bg-[#1A2011] mx-auto rounded-full"></div>
        </div>

        {/* Content */}
        <div className="space-y-8">
          {/* Company Introduction */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-8">
            <h2 className="text-[#1A2011] mb-4">فروشگاه آنلاین نورسا</h2>
            <p className="text-[#888888] leading-relaxed mb-4">
              فروشگاه آنلاین نورسا با هدف ارائه محصولات با کیفیت و خدمات عالی به مشتریان عزیز، 
              فعالیت خود را آغاز کرده است. ما با تکیه بر تجربه و دانش تیم متخصص خود، 
              تلاش می‌کنیم تا بهترین تجربه خرید آنلاین را برای شما فراهم آوریم.
            </p>
            <p className="text-[#888888] leading-relaxed">
              در نورسا، رضایت مشتری در اولویت اول قرار دارد و ما همواره در تلاش هستیم 
              تا با ارائه محصولات اصل و خدمات پس از فروش مناسب، اعتماد شما را جلب کنیم.
            </p>
          </div>

          {/* Mission & Vision */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-[#F9E1B4] bg-opacity-20 border border-[#F9E1B4] rounded-[16px] p-6">
              <h3 className="text-[#1A2011] mb-3">ماموریت ما</h3>
              <p className="text-[#888888] leading-relaxed">
                ارائه محصولات با کیفیت، خدمات عالی و ایجاد تجربه‌ای لذت‌بخش 
                برای مشتریان در فضای خرید آنلاین.
              </p>
            </div>
            <div className="bg-[#1A2011] bg-opacity-5 border border-[#1A2011] rounded-[16px] p-6">
              <h3 className="text-[#1A2011] mb-3">چشم‌انداز ما</h3>
              <p className="text-[#888888] leading-relaxed">
                تبدیل شدن به یکی از پیشروترین فروشگاه‌های آنلاین کشور با 
                تمرکز بر کیفیت، اعتماد و رضایت مشتری.
              </p>
            </div>
          </div>

          {/* Values */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-8">
            <h2 className="text-[#1A2011] mb-6">ارزش‌های ما</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-[#1A2011] rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white text-2xl">✓</span>
                </div>
                <h4 className="text-[#1A2011] mb-2">کیفیت</h4>
                <p className="text-[#888888] text-sm">
                  ارائه محصولات با بالاترین کیفیت
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#1A2011] rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white text-2xl">♥</span>
                </div>
                <h4 className="text-[#1A2011] mb-2">اعتماد</h4>
                <p className="text-[#888888] text-sm">
                  جلب اعتماد مشتریان با شفافیت
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[#1A2011] rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white text-2xl">★</span>
                </div>
                <h4 className="text-[#1A2011] mb-2">رضایت</h4>
                <p className="text-[#888888] text-sm">
                  رضایت مشتری در اولویت اول
                </p>
              </div>
            </div>
          </div>

          {/* Contact CTA */}
          <div className="bg-gradient-to-l from-[#1A2011] to-[#2d3420] text-white rounded-[16px] p-8 text-center">
            <h3 className="mb-3">سوالی دارید؟</h3>
            <p className="mb-6 opacity-90">
              تیم ما آماده پاسخگویی به سوالات شماست
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <a 
                href="tel:05138373530"
                className="inline-block bg-white text-[#1A2011] px-6 py-3 rounded-full hover:bg-opacity-90 transition-all"
              >
                تماس با ما: <span dir="ltr">۰۵۱-۳۸۳۷۳۵۳۰</span>
              </a>
              <a 
                href="mailto:be@nursaa.ir"
                className="inline-block bg-[#F9E1B4] text-[#1A2011] px-6 py-3 rounded-full hover:bg-opacity-90 transition-all"
              >
                ایمیل: be@nursaa.ir
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}