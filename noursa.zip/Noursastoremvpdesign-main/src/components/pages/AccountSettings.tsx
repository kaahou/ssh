import { useState, useEffect, useRef } from 'react';
import { useUser } from '../UserContext';
import { User, Check, Loader2, LogOut, Calendar } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import jalaali from 'jalaali-js';

export function AccountSettings() {
  const { user, loading, updateUser, getCompletionPercentage, logout } = useUser();
  const [saving, setSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    birth_date: '',
    address: '',
  });

  // Calculate completion percentage
  const completionPercentage = getCompletionPercentage();

  // Load user data into form when user is loaded
  useEffect(() => {
    if (user) {
      setFormData({
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        email: user.email || '',
        birth_date: user.profile?.birth_date || '',
        address: user.profile?.address || '',
      });
    }
  }, [user]);

  // Helper function to convert Gregorian date to Persian display
  const gregorianToPersianDisplay = (gregorianDate: string): string => {
    if (!gregorianDate) return '';
    
    try {
      const date = new Date(gregorianDate);
      const { jy, jm, jd } = jalaali.toJalaali(
        date.getFullYear(),
        date.getMonth() + 1,
        date.getDate()
      );
      
      return `${jy}/${String(jm).padStart(2, '0')}/${String(jd).padStart(2, '0')}`;
    } catch (error) {
      console.error('Error converting date:', error);
      return '';
    }
  };

  const handlePersonalInfoSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      const success = await updateUser({
        first_name: formData.first_name,
        last_name: formData.last_name,
        email: formData.email,
        profile: {
          ...(user?.profile || {}),
          birth_date: formData.birth_date,
          address: formData.address,
        }
      });

      if (success) {
        toast.success('✅ اطلاعات با موفقیت ذخیره شد', {
          style: { direction: 'rtl', fontFamily: 'inherit' }
        });
      } else {
        toast.error('❌ خطا در ذخیره اطلاعات', {
          style: { direction: 'rtl', fontFamily: 'inherit' }
        });
      }
    } catch (error) {
      console.error('Error saving personal info:', error);
      toast.error('❌ خطا در ذخیره اطلاعات', {
        style: { direction: 'rtl', fontFamily: 'inherit' }
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#484D2C] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-[#888888]">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="font-bold text-[24px] text-[#1A2011] mb-2">تنظیمات حساب کاربری</h1>
        <p className="text-[#888888]">مدیریت اطلاعات شخصی و تنظیمات حساب</p>
      </div>

      {/* Profile Completion Progress */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-[#F9E1B4]/20 to-[#F9E1B4]/40 rounded-[16px] p-6 border border-[#F9E1B4]"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-[16px] text-[#1A2011] mb-1">
              تکمیل پروفایل
            </h3>
            <p className="text-[13px] text-[#888888]">
              پروفایل شما {completionPercentage.toLocaleString('fa-IR')}٪ تکمیل شده است
            </p>
          </div>
          <div className="text-[28px] font-bold text-[#484D2C]">
            {completionPercentage.toLocaleString('fa-IR')}٪
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="h-3 bg-white rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-[#484D2C] to-[#16A34A] transition-all duration-500"
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
      </motion.div>

      {/* Personal Information Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-[20px] border border-[#E8E8E8] p-6 md:p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#F9E1B4]/20 rounded-full flex items-center justify-center">
            <User size={20} className="text-[#484D2C]" />
          </div>
          <h2 className="font-bold text-[18px] text-[#1A2011]">اطلاعات شخصی</h2>
        </div>
        
        <form onSubmit={handlePersonalInfoSave} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* نام */}
            <div>
              <label htmlFor="first_name" className="block text-[14px] font-medium text-[#1A2011] mb-2">
                نام <span className="text-red-500">*</span>
              </label>
              <input
                id="first_name"
                type="text"
                value={formData.first_name}
                onChange={(e) => setFormData({...formData, first_name: e.target.value})}
                placeholder="مثال: محمد"
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:outline-none transition-colors"
                required
              />
            </div>

            {/* نام خانوادگی */}
            <div>
              <label htmlFor="last_name" className="block text-[14px] font-medium text-[#1A2011] mb-2">
                نام خانوادگی <span className="text-red-500">*</span>
              </label>
              <input
                id="last_name"
                type="text"
                value={formData.last_name}
                onChange={(e) => setFormData({...formData, last_name: e.target.value})}
                placeholder="مثال: محمدی"
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:outline-none transition-colors"
                required
              />
            </div>
          </div>

          {/* شماره تماس (غیرقابل تغییر) */}
          <div>
            <label htmlFor="phone" className="block text-[14px] font-medium text-[#1A2011] mb-2">
              شماره تماس
            </label>
            <input
              id="phone"
              type="text"
              value={user?.phone || ''}
              disabled
              className="w-full h-[48px] px-4 bg-[#F5F5F5] border border-[#E8E8E8] rounded-[12px] text-[#888888] cursor-not-allowed"
            />
            <p className="text-[12px] text-[#888888] mt-1">
              برای تغییر شماره تماس، با پشتیبانی تماس بگیرید
            </p>
          </div>

          {/* ایمیل */}
          <div>
            <label htmlFor="email" className="block text-[14px] font-medium text-[#1A2011] mb-2">
              ایمیل
            </label>
            <input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              placeholder="example@email.com"
              className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:outline-none transition-colors"
              dir="ltr"
            />
          </div>

          {/* تاریخ تولد */}
          <div>
            <label htmlFor="birth_date" className="block text-[14px] font-medium text-[#1A2011] mb-2">
              تاریخ تولد 
            </label>
            <div className="relative">
              <input
                id="birth_date"
                type="date"
                value={formData.birth_date}
                onChange={(e) => setFormData({...formData, birth_date: e.target.value})}
                className="w-full h-[48px] px-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[12px] focus:border-[#1A2011] focus:outline-none transition-colors"
              />
            </div>
            <p className="text-[12px] text-[#16A34A] mt-1 font-medium">
              تاریخ تولد میلادی خود را ثبت کنید و تاریخ شمسی آن را اینجا ببینید :)
              {formData.birth_date && ` → ${gregorianToPersianDisplay(formData.birth_date)}`}
            </p>
          </div>

          {/* آدرس */}
          <div>
            <label htmlFor="address" className="block text-[14px] font-medium text-[#1A2011] mb-2">
              آدرس
            </label>
            <textarea
              id="address"
              value={formData.address}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              placeholder="آدرس کامل خود را وارد کنید..."
              className="w-full h-[100px] p-4 bg-[#FAFAFA] border border-[#E8E8E8] rounded-[16px] resize-none focus:border-[#1A2011] focus:outline-none transition-colors"
            />
          </div>

          {/* دکمه ذخیره */}
          <button
            type="submit"
            disabled={saving}
            className="h-[52px] px-8 bg-[#1A2011] text-white rounded-[12px] font-semibold hover:bg-[#222222] disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
          >
            {saving ? (
              <>
                <Loader2 className="animate-spin" size={18} />
                در حال ذخیره...
              </>
            ) : (
              <>
                <Check size={18} />
                ذخیره تغییرات
              </>
            )}
          </button>
        </form>
      </motion.div>

      {/* Logout Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-[20px] border border-[#E8E8E8] p-6 md:p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#FEE2E2] rounded-full flex items-center justify-center">
            <LogOut size={20} className="text-[#DC2626]" />
          </div>
          <h2 className="font-bold text-[18px] text-[#1A2011]">خروج از حساب</h2>
        </div>
        
        <p className="text-[#888888] mb-6">
          با خروج از حساب کاربری، دسترسی شما به پروفایلتان قطع خواهد شد و دوباره باید وارد شوید.
        </p>
        
        <button
          onClick={() => {
            logout();
            window.location.href = '/';
          }}
          className="h-[48px] px-8 border border-[#DC2626] text-[#DC2626] rounded-[12px] font-semibold hover:bg-[#FEE2E2] transition-colors flex items-center justify-center gap-2"
        >
          <LogOut size={18} />
          خروج از حساب کاربری
        </button>
      </motion.div>
    </div>
  );
}