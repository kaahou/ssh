export function TermsPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-[#1A2011] mb-4">قوانین و مقررات</h1>
          <div className="w-24 h-1 bg-[#1A2011] mx-auto rounded-full"></div>
          <p className="text-[#888888] mt-4">
            لطفاً قبل از استفاده از خدمات نورسا، قوانین و مقررات را با دقت مطالعه فرمایید
          </p>
        </div>

        {/* Content */}
        <div className="space-y-6">
          {/* Section 1 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۱. کلیات</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                با استفاده از وب‌سایت و خدمات فروشگاه آنلاین نورسا، شما تمامی قوانین و 
                مقررات ذکر شده در این صفحه را می‌پذیرید.
              </p>
              <p>
                فروشگاه نورسا این حق را برای خود محفوظ می‌دارد که در هر زمان این قوانین 
                را بدون اطلاع قبلی تغییر دهد.
              </p>
            </div>
          </div>

          {/* Section 2 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۲. ثبت سفارش و خرید</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                <strong className="text-[#1A2011]">• قیمت‌ها:</strong> تمامی قیمت‌های 
                درج شده به تومان بوده و شامل مالیات بر ارزش افزوده می‌باشد.
              </p>
              <p>
                <strong className="text-[#1A2011]">• موجودی:</strong> موجودی محصولات 
                به صورت لحظه‌ای به‌روزرسانی می‌شود اما امکان تغییر موجودی بین زمان سفارش 
                و تایید نهایی وجود دارد.
              </p>
              <p>
                <strong className="text-[#1A2011]">• تایید سفارش:</strong> پس از ثبت سفارش، 
                تیم ما سفارش شما را بررسی و حداکثر ظرف ۲۴ ساعت با شما تماس خواهد گرفت.
              </p>
            </div>
          </div>

          {/* Section 3 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۳. ارسال و تحویل</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                <strong className="text-[#1A2011]">• زمان ارسال:</strong> محصولات ظرف 
                ۲ تا ۵ روز کاری پس از تایید نهایی سفارش ارسال می‌شوند.
              </p>
              <p>
                <strong className="text-[#1A2011]">• هزینه ارسال:</strong> هزینه ارسال 
                بسته به وزن، حجم و مقصد محاسبه و در زمان ثبت سفارش اعلام می‌شود.
              </p>
              <p>
                <strong className="text-[#1A2011]">• بررسی هنگام تحویل:</strong> 
                مشتریان موظف هستند بسته را هنگام تحویل بررسی کنند. در صورت وجود هرگونه 
                مشکل، باید بلافاصله به تیم پشتیبانی اطلاع دهند.
              </p>
            </div>
          </div>

          {/* Section 4 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۴. مرجوعی و استرداد</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                <strong className="text-[#1A2011]">• مهلت مرجوعی:</strong> مشتریان 
                می‌توانند ظرف ۷ روز از تاریخ تحویل، محصولات را مرجوع کنند.
              </p>
              <p>
                <strong className="text-[#1A2011]">• شرایط مرجوعی:</strong> محصول باید 
                در بسته‌بندی اصلی، بدون استفاده و سالم باشد.
              </p>
              <p>
                <strong className="text-[#1A2011]">• بازپرداخت:</strong> پس از تایید 
                مرجوعی، مبلغ ظرف ۷ روز کاری به حساب مشتری بازگردانده می‌شود.
              </p>
            </div>
          </div>

          {/* Section 5 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۵. گارانتی محصولات</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                تمامی محصولات دارای گارانتی اصالت و سلامت فیزیکی هستند. در صورت بروز 
                هرگونه مشکل، مشتری می‌تواند با تیم پشتیبانی تماس بگیرد.
              </p>
            </div>
          </div>

          {/* Section 6 */}
          <div className="bg-white border border-[#E8E8E8] rounded-[16px] p-6">
            <h2 className="text-[#1A2011] mb-4">۶. مسئولیت کاربر</h2>
            <div className="text-[#888888] leading-relaxed space-y-3">
              <p>
                کاربران موظف هستند اطلاعات صحیح و کامل خود را در زمان ثبت سفارش وارد کنند. 
                مسئولیت هرگونه خطا در اطلاعات با خود کاربر است.
              </p>
            </div>
          </div>

          {/* Contact */}
          <div className="bg-gradient-to-l from-[#1A2011] to-[#2d3420] text-white rounded-[16px] p-6 text-center">
            <h3 className="mb-3">سوالی درباره قوانین دارید؟</h3>
            <p className="mb-4 opacity-90">
              برای اطلاعات بیشتر با تیم پشتیبانی تماس بگیرید
            </p>
            <a 
              href="tel:02112345678"
              className="inline-block bg-white text-[#1A2011] px-6 py-3 rounded-full hover:bg-opacity-90 transition-all"
            >
<span dir="ltr">۰۵۱-۳۸۳۷۳۵۳۰</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
