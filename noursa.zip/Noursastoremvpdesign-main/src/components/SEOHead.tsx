import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  type?: 'website' | 'article' | 'product';
  structuredData?: any;
}

export function SEOHead({
  title,
  description,
  keywords,
  image = 'https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo_horizontal.png',
  type = 'website',
  structuredData
}: SEOHeadProps) {
  const location = useLocation();
  const baseUrl = 'https://nursaa.ir';
  const currentUrl = `${baseUrl}${location.pathname}`;

  // Default values
  const defaultTitle = 'خرید آنلاین محصولات آرایشی و بهداشتی | nursaa.ir';
  const defaultDescription = 'خرید آنلاین انواع روغن‌های طبیعی مراقبت از مو، روغن‌های درمانی، روغن‌های زیبایی و اسانس‌های گیاهی با ضمانت اصالت و ارسال سریع به سراسر کشور';
  const defaultKeywords = 'روغن طبیعی، روغن مو، روغن آرگان، روغن نارگیل، روغن درمانی، اسانس گیاهی، روغن زیبایی، خرید روغن اصل، nursaa';

  const pageTitle = title ? `خرید آنلاین محصولات آرایشی و بهداشتی | ${title} nursaa.ir` : defaultTitle;
  const pageDescription = description || defaultDescription;
  const pageKeywords = keywords || defaultKeywords;

  useEffect(() => {
    // Update document title
    document.title = pageTitle;

    // Update or create meta tags
    updateMetaTag('description', pageDescription);
    updateMetaTag('keywords', pageKeywords);

    // Open Graph tags
    updateMetaTag('og:title', pageTitle, 'property');
    updateMetaTag('og:description', pageDescription, 'property');
    updateMetaTag('og:url', currentUrl, 'property');
    updateMetaTag('og:image', image, 'property');
    updateMetaTag('og:type', type, 'property');
    updateMetaTag('og:site_name', 'nursaa', 'property');
    updateMetaTag('og:locale', 'fa_IR', 'property');

    // Twitter Card tags
    updateMetaTag('twitter:card', 'summary_large_image', 'name');
    updateMetaTag('twitter:title', pageTitle, 'name');
    updateMetaTag('twitter:description', pageDescription, 'name');
    updateMetaTag('twitter:image', image, 'name');

    // Additional SEO tags
    updateMetaTag('author', 'nursaa', 'name');
    updateMetaTag('robots', 'index, follow', 'name');
    updateMetaTag('googlebot', 'index, follow', 'name');
    updateMetaTag('language', 'Persian', 'name');
    updateMetaTag('revisit-after', '7 days', 'name');

    // Canonical URL
    updateLinkTag('canonical', currentUrl);

    // Structured Data (JSON-LD)
    if (structuredData) {
      updateStructuredData(structuredData);
    } else {
      // Default Organization structured data
      updateStructuredData({
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: 'nursaa',
        url: baseUrl,
        logo: image,
        description: defaultDescription,
        contactPoint: {
          '@type': 'ContactPoint',
          contactType: 'Customer Service',
          availableLanguage: 'Persian'
        },
        sameAs: [
          // Add social media URLs here if available
        ]
      });
    }
  }, [pageTitle, pageDescription, pageKeywords, currentUrl, image, type, structuredData]);

  return null; // This component doesn't render anything
}

// Helper functions
function updateMetaTag(name: string, content: string, attribute: 'name' | 'property' = 'name') {
  let meta = document.querySelector(`meta[${attribute}="${name}"]`);
  
  if (!meta) {
    meta = document.createElement('meta');
    meta.setAttribute(attribute, name);
    document.head.appendChild(meta);
  }
  
  meta.setAttribute('content', content);
}

function updateLinkTag(rel: string, href: string) {
  let link = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement;
  
  if (!link) {
    link = document.createElement('link');
    link.rel = rel;
    document.head.appendChild(link);
  }
  
  link.href = href;
}

function updateStructuredData(data: any) {
  const scriptId = 'structured-data';
  let script = document.getElementById(scriptId);
  
  if (!script) {
    script = document.createElement('script');
    script.id = scriptId;
    script.type = 'application/ld+json';
    document.head.appendChild(script);
  }
  
  script.textContent = JSON.stringify(data);
}

// Pre-defined structured data generators
export const createProductStructuredData = (product: any) => ({
  '@context': 'https://schema.org',
  '@type': 'Product',
  name: product.name,
  description: product.description,
  image: product.image,
  brand: {
    '@type': 'Brand',
    name: product.brand || 'nursaa'
  },
  offers: {
    '@type': 'Offer',
    url: `https://nursaa.ir/product/${product.slug}`,
    priceCurrency: 'IRR',
    price: product.price,
    availability: product.stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock'
  }
});

export const createArticleStructuredData = (article: any) => ({
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: article.title,
  description: article.excerpt,
  image: article.image,
  author: {
    '@type': 'Organization',
    name: 'nursaa'
  },
  publisher: {
    '@type': 'Organization',
    name: 'nursaa',
    logo: {
      '@type': 'ImageObject',
      url: 'https://jqxhriqljtpsateawvmb.supabase.co/storage/v1/object/public/siteimages/logos/logo_horizontal.png'
    }
  },
  datePublished: article.created_at,
  dateModified: article.updated_at || article.created_at
});

export const createBreadcrumbStructuredData = (items: Array<{ name: string; url: string }>) => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: items.map((item, index) => ({
    '@type': 'ListItem',
    position: index + 1,
    name: item.name,
    item: `https://nursaa.ir${item.url}`
  }))
});

export const createWebsiteStructuredData = () => ({
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: 'nursaa',
  url: 'https://nursaa.ir',
  potentialAction: {
    '@type': 'SearchAction',
    target: {
      '@type': 'EntryPoint',
      urlTemplate: 'https://nursaa.ir/search?q={search_term_string}'
    },
    'query-input': 'required name=search_term_string'
  }
});